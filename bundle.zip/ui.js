//  Presentation layer and rendering pipeline initialization.

// [UI.A]
function getTheme() {
  if (typeof window !== 'undefined' && window.activeThemeColors) {
    return window.activeThemeColors;
  }
  return {
    id: 'default',
    c1: '#00e5ff', c2: '#d946ef', c3: '#f05f9f', c4: '#ff9100', c5: '#38bdf8', bg: '#03050d',
    c1Light: '#8ef3ff', c2Light: '#f0abfc', c3Light: '#ff8fb0', c4Light: '#ffc166', c5Light: '#93c5fd',
    rgb1: { r: 0, g: 229, b: 255, cssRgb: '0, 229, 255', norm: [0, 0.898, 1] },
    rgb2: { r: 217, g: 70, b: 239, cssRgb: '217, 70, 239', norm: [0.851, 0.275, 0.937] },
    rgb3: { r: 240, g: 95, b: 159, cssRgb: '240, 95, 159', norm: [0.941, 0.373, 0.624] },
    rgb4: { r: 255, g: 145, b: 0, cssRgb: '255, 145, 0', norm: [1, 0.569, 0] },
    rgb5: { r: 56, g: 189, b: 248, cssRgb: '56, 189, 248', norm: [0.22, 0.741, 0.973] }
  };
}

//  Thread Lag & Memory Monitor: High-frequency sampler tracking WebView thread freezes (>20ms).
window._maxThreadLag = 0;
window._lastThreadLag = 0;

// [UI.B]
let threadLagMonitorId = null;

function startThreadLagMonitor() {
  if (threadLagMonitorId !== null) return;
  let lastTick = performance.now();
  const lagSamples = [];

  // [UI.C]
  threadLagMonitorId = setInterval(() => {
    const now = performance.now();
    const delta = now - lastTick;
    lastTick = now;

    const lag = Math.max(0, Math.round(delta - 20));

    if (lag > 5) {
      lagSamples.push({ time: now, lag: lag });
      if (lag > window._maxThreadLag) {
        window._maxThreadLag = lag;
      }
    }

    const cutoff = now - 2000;
    while (lagSamples.length > 0 && lagSamples[0].time < cutoff) {
      lagSamples.shift();
    }

    let peakLast = 0;
    for (let i = 0; i < lagSamples.length; i++) {
      if (lagSamples[i].lag > peakLast) {
        peakLast = lagSamples[i].lag;
      }
    }
    window._lastThreadLag = peakLast;
  }, 20);
}

// [UI.CM_STOP]
function stopThreadLagMonitor() {
  if (threadLagMonitorId !== null) {
    clearInterval(threadLagMonitorId);
    threadLagMonitorId = null;
  }
}

// [UI.D]
function getJSHeapSizeMB() {
  if (typeof performance !== 'undefined' && performance.memory && typeof performance.memory.usedJSHeapSize === 'number') {
    return performance.memory.usedJSHeapSize / (1024 * 1024);
  }
  return null;
}

window.perfProfiler = {
  times: { sim: 0, towers: 0, drawMobs: 0, drawFx: 0, total: 0 },
  accum: { sim: 0, towers: 0, drawMobs: 0, drawFx: 0, frames: 0 },
  lastFlush: performance.now(),
  report: ''
};

//  Glow sprites cache for high-performance additive blending.
const GLOW_SPRITES = Object.create(null);
// [UI.E]
function createGlowSprite(color) {
  const size = 64;
  const c = document.createElement('canvas');
  c.width = size;
  c.height = size;
  const gCtx = c.getContext('2d');
  const half = size / 2;
  const grad = gCtx.createRadialGradient(half, half, 0, half, half, half);
  grad.addColorStop(0, color);
  grad.addColorStop(0.35, color);
  grad.addColorStop(1, 'transparent');
  gCtx.fillStyle = grad;
  gCtx.beginPath();
  gCtx.arc(half, half, half, 0, Math.PI * 2);
  gCtx.fill();
  return c;
}

//  Offscreen canvas cache for static grid and track rendering.
let offscreenGridCanvas = null;
let offscreenGridDirty = true;

// [UI.F]
function invalidateGridCache() {
  offscreenGridDirty = true;
  if (typeof clearFxSpriteCaches === 'function') clearFxSpriteCaches();
}

// [UI.FM_CHEV] Shared neon portal chevron renderer (used by map grid & battle previews).
function drawNeonChevron(targetCtx, cx, cy, ang, size, col) {
  targetCtx.save();
  targetCtx.translate(cx, cy);
  targetCtx.rotate(ang);
  targetCtx.lineCap = 'round';
  targetCtx.lineJoin = 'round';

  targetCtx.beginPath();
  targetCtx.moveTo(-size * 0.8, -size);
  targetCtx.lineTo(size * 0.9, 0);
  targetCtx.lineTo(-size * 0.8, size);

  targetCtx.strokeStyle = col;
  targetCtx.globalAlpha = 0.30;
  targetCtx.lineWidth = 7.5;
  targetCtx.stroke();

  targetCtx.globalAlpha = 1.0;
  targetCtx.lineWidth = 3.0;
  targetCtx.stroke();

  targetCtx.strokeStyle = '#ffffff';
  targetCtx.globalAlpha = 0.55;
  targetCtx.lineWidth = 1.2;
  targetCtx.stroke();
  targetCtx.restore();
}

// [UI.G]
function updateOffscreenGrid() {
  if (!offscreenGridCanvas) {
    offscreenGridCanvas = document.createElement('canvas');
  }

  const w = COLS * TILE_SIZE;
  const h = ROWS * TILE_SIZE;

  if (offscreenGridCanvas.width !== w || offscreenGridCanvas.height !== h) {
    offscreenGridCanvas.width = w;
    offscreenGridCanvas.height = h;
  }

  const oCtx = offscreenGridCanvas.getContext('2d');
  oCtx.clearRect(0, 0, w, h);

  const th = getTheme();
  const c1Rgb = th.rgb1 ? th.rgb1.cssRgb : '0, 229, 255';

  // Static grid cell background rendering.
  for (let r = 0; r < ROWS; r++) {
    for (let c = 0; c < COLS; c++) {
      const cellVal = grid[r] ? grid[r][c] : 0;
      oCtx.fillStyle = (cellVal === 1)
        ? `rgba(${c1Rgb}, 0.08)`
        : (cellVal === 3 ? 'rgba(0, 0, 0, 0.78)' : 'rgba(8, 12, 26, 0.40)');
      oCtx.fillRect(c * TILE_SIZE, r * TILE_SIZE, TILE_SIZE, TILE_SIZE);

      oCtx.strokeStyle = (cellVal === 1)
        ? `rgba(${c1Rgb}, 0.18)`
        : (cellVal === 3 ? 'rgba(0, 0, 0, 0.90)' : `rgba(${c1Rgb}, 0.14)`);
      oCtx.lineWidth = 1;
      oCtx.strokeRect(c * TILE_SIZE, r * TILE_SIZE, TILE_SIZE, TILE_SIZE);
    }
  }

  oCtx.save();
  oCtx.strokeStyle = `rgba(${c1Rgb}, 0.34)`;
  oCtx.lineWidth = 1.6;

  // Static track side rails rendering.
  if (typeof pathCells !== 'undefined' && Array.isArray(pathCells)) {
    pathCells.forEach(cell => {
      if (cell.rails) {
        cell.rails.forEach(rail => {
          oCtx.beginPath();
          oCtx.moveTo(rail.x1, rail.y1);
          oCtx.lineTo(rail.x2, rail.y2);
          oCtx.stroke();
        });
      }
      if (cell.turnCurves) {
        cell.turnCurves.forEach(tc => {
          oCtx.beginPath();
          oCtx.moveTo(tc.startX, tc.startY);
          oCtx.arcTo(tc.cornerX, tc.cornerY, tc.endX, tc.endY, tc.r);
          oCtx.lineTo(tc.endX, tc.endY);
          oCtx.stroke();
        });
      }
    });
  }
  oCtx.restore();

  // Static spawn & base portal chevrons baked directly into offscreenGridCanvas
  if (typeof activePathTiles !== 'undefined' && activePathTiles && activePathTiles.length >= 2) {

    const startTile = activePathTiles[0];
    const nextTile = activePathTiles[1];
    const spawnX = startTile.c * TILE_SIZE;
    const spawnY = startTile.r * TILE_SIZE;
    const spawnAngle = Math.atan2(nextTile.r - startTile.r, nextTile.c - startTile.c);
    const offsets = [-14, 0, 14];

    for (let i = 0; i < 3; i++) {
      const off = offsets[i];
      drawNeonChevron(oCtx, spawnX + 35 + Math.cos(spawnAngle) * off, spawnY + 35 + Math.sin(spawnAngle) * off, spawnAngle, 13, th.c1);
    }

    const prevTile = activePathTiles[activePathTiles.length - 2];
    const endTile = activePathTiles[activePathTiles.length - 1];
    const baseX = endTile.c * TILE_SIZE;
    const baseY = endTile.r * TILE_SIZE;
    const baseAngle = Math.atan2(endTile.r - prevTile.r, endTile.c - prevTile.c);

    for (let i = 0; i < 3; i++) {
      const off = offsets[i];
      drawNeonChevron(oCtx, baseX + 35 + Math.cos(baseAngle) * off, baseY + 35 + Math.sin(baseAngle) * off, baseAngle, 13, th.c3);
    }
  }

  offscreenGridDirty = false;
}

//  Offscreen neon disc sprite cache for particle rendering optimization.
const NEON_DISC_SPRITES = Object.create(null);
// [UI.H]
function getNeonDiscSprite(color) {
  if (NEON_DISC_SPRITES[color]) return NEON_DISC_SPRITES[color];
  const size = 32;
  const c = document.createElement('canvas');
  c.width = size;
  c.height = size;
  const gCtx = c.getContext('2d');
  const half = size / 2;
  const grad = gCtx.createRadialGradient(half, half, 1, half, half, half);
  grad.addColorStop(0, '#ffffff');
  grad.addColorStop(0.35, color);
  grad.addColorStop(0.85, color + '55');
  grad.addColorStop(1, 'transparent');
  gCtx.fillStyle = grad;
  gCtx.beginPath();
  gCtx.arc(half, half, half, 0, Math.PI * 2);
  gCtx.fill();
  NEON_DISC_SPRITES[color] = c;
  return c;
}

//  Offscreen concentric smoke sprite cache.
let SMOKE_SPRITE = null;
// [UI.J]
function getSmokeSprite() {
  if (SMOKE_SPRITE) return SMOKE_SPRITE;
  const size = 64;
  const c = document.createElement('canvas');
  c.width = size;
  c.height = size;
  const sCtx = c.getContext('2d');
  const half = size / 2;
  const grad = sCtx.createRadialGradient(half, half, 4, half, half, half);
  grad.addColorStop(0, 'rgba(48, 54, 76, 0.9)');
  grad.addColorStop(0.5, 'rgba(28, 32, 48, 0.6)');
  grad.addColorStop(0.85, 'rgba(15, 18, 28, 0.2)');
  grad.addColorStop(1, 'transparent');
  sCtx.fillStyle = grad;
  sCtx.beginPath();
  sCtx.arc(half, half, half, 0, Math.PI * 2);
  sCtx.fill();
  SMOKE_SPRITE = c;
  return c;
}

// [UI.K]
function getGlowSprite(color) {
  if (!GLOW_SPRITES[color]) {
    GLOW_SPRITES[color] = createGlowSprite(color);
  }
  return GLOW_SPRITES[color];
}

// [UI.KK]
(function initGlobalReliableTouch() {
  const INTERACTIVE_SELECTOR = [
    'button',
    '[role="button"]',
    '.mode-3way-tab',
    '.level-btn',
    '.synth-pass-widget',
    '.loadout-widget-header',
    '.settings-collapsible-header',
    '.tactical-tips-widget',
    '.custom-palette-trigger',
    '.custom-palette-option',
    '.badge-half.interactive'
  ].join(',');

  const MOVE_THRESHOLD_PX = 24;
  let activeTarget = null;
  let startX = 0;
  let startY = 0;
  let movedTooFar = false;
  let lastNativeClickTime = 0;
  let syntheticClickInFlight = false;

  // Отслеживаем, сработал ли обычный нативный click сам по себе
  document.addEventListener('click', (e) => {
    if (syntheticClickInFlight) return;
    lastNativeClickTime = performance.now();
  }, true);

  document.addEventListener('pointerdown', (e) => {
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    const target = e.target && e.target.closest ? e.target.closest(INTERACTIVE_SELECTOR) : null;
    if (!target || target.disabled || target.classList.contains('is-disabled')) {
      activeTarget = null;
      return;
    }
    activeTarget = target;
    startX = e.clientX;
    startY = e.clientY;
    movedTooFar = false;
  }, { capture: true, passive: true });

  document.addEventListener('pointermove', (e) => {
    if (!activeTarget || movedTooFar) return;
    const dx = Math.abs(e.clientX - startX);
    const dy = Math.abs(e.clientY - startY);
    if (dx > MOVE_THRESHOLD_PX || dy > MOVE_THRESHOLD_PX) {
      movedTooFar = true;
    }
  }, { capture: true, passive: true });

  document.addEventListener('pointerup', (e) => {
    if (!activeTarget) return;
    const target = activeTarget;
    const wasMoved = movedTooFar;
    activeTarget = null;
    movedTooFar = false;

    if (wasMoved || target.disabled) return;

    // Проверяем, что палец при отпускании всё ещё находится в пределах кнопки (или рядом с ней)
    const rect = target.getBoundingClientRect();
    const pad = 12;
    const inside = (
      e.clientX >= rect.left - pad &&
      e.clientX <= rect.right + pad &&
      e.clientY >= rect.top - pad &&
      e.clientY <= rect.bottom + pad
    );
    if (!inside) return;

    const upTime = performance.now();
    // Даем браузеру 35мс на генерацию штатного click.
    // Если WebView проглотил click (после свайпа или из-за микро-сдвига пальца) — вызываем его принудительно!
    setTimeout(() => {
      if (lastNativeClickTime >= upTime - 15) return;
      if (target.disabled || !document.body.contains(target)) return;
      syntheticClickInFlight = true;
      try {
        target.click();
      } finally {
        syntheticClickInFlight = false;
      }
    }, 35);
  }, { capture: true, passive: true });

  document.addEventListener('pointercancel', () => {
    activeTarget = null;
    movedTooFar = false;
  }, { capture: true, passive: true });
})();

//  Banner and incoming threat alert visual indicators.
// [UI.L]
function showNewTowerBanner(type) {
  const banner = document.getElementById('newTowerBanner');
  if (!banner) return;
  const iconBox = document.getElementById('newTowerBannerIcon');
  const nameEl = document.getElementById('newTowerBannerName');
  if (iconBox) iconBox.innerHTML = TOWER_ICONS[type] || '';
  if (nameEl) nameEl.textContent = TOWER_NAMES[type] || type;
  banner.classList.add('visible');
  newTowerBannerHideTimer = 4.5;
}

// [UI.M]
function hideNewTowerBanner() {
  const banner = document.getElementById('newTowerBanner');
  if (banner) banner.classList.remove('visible');
  newTowerBannerHideTimer = 0;
}

// [UI.N]
function showIncomingAlert(type) {
  const banner = document.getElementById('incomingAlertBanner');
  const textEl = document.getElementById('incomingAlertText');
  if (!banner || !textEl) return;

  banner.className = 'incoming-alert-banner';
  banner.style.backdropFilter = 'none';
  banner.style.webkitBackdropFilter = 'none';
  banner.style.background = 'rgba(10, 12, 24, 0.92)';
  banner.style.willChange = 'transform, opacity';

  if (type === 'boss') {
    banner.classList.add('boss');
    textEl.textContent = t('boss_incoming');
  } else if (type === 'miniboss') {
    banner.classList.add('miniboss');
    textEl.textContent = t('miniboss_incoming');
  } else {
    return;
  }

  banner.classList.add('visible');
  activeBossAlertType = type;
  bossAlertShown = true;
  bossAlertHideTimer = 3.0;
}

// [UI.O]
function hideIncomingAlert() {
  const banner = document.getElementById('incomingAlertBanner');
  if (banner) banner.classList.remove('visible');
  activeBossAlertType = null;
}

//  Viewport canvas resize and camera coordinate transform system.
// [UI.P]
let _lastCanvasResizeW = 0;
let _lastCanvasResizeH = 0;

function isMobileInputFocused() {
  if (typeof devInputOpen !== 'undefined' && devInputOpen) return true;
  const active = document.activeElement;
  if (!active) return false;
  const tag = active.tagName;
  return tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || active.isContentEditable;
}

function resizeCanvasAndCamera(forceEv) {
  // Не пересчитываем холст и фон, когда на мобилке открыта клавиатура или поле ввода дев-меню
  if (isMobileInputFocused() && _lastCanvasResizeW > 0) {
    return;
  }

  const vpWidth = window.innerWidth || (window.visualViewport ? window.visualViewport.width : 360);
  const vpHeight = window.innerHeight || (window.visualViewport ? window.visualViewport.height : 640);

  // Если ширина не изменилась, а высота сжалась из-за выезда мобильной клавиатуры — игнорируем ресайз
  if (
    forceEv !== true &&
    _lastCanvasResizeW > 0 &&
    Math.abs(vpWidth - _lastCanvasResizeW) < 4 &&
    vpHeight < _lastCanvasResizeH * 0.85
  ) {
    return;
  }

  _lastCanvasResizeW = vpWidth;
  _lastCanvasResizeH = vpHeight;

  const dpr = Math.min(window.devicePixelRatio || 1, 1.5);

  canvas.width = vpWidth * dpr;
  canvas.height = vpHeight * dpr;
  ctx.setTransform(1, 0, 0, 1, 0, 0);

  FIELD_WIDTH = COLS * TILE_SIZE;
  FIELD_HEIGHT = ROWS * TILE_SIZE;

  const topHudEl = document.getElementById('topHud');
  const bottomEl = document.getElementById('controlsWrapper');
  const topH = (topHudEl && !topHudEl.classList.contains('hidden'))
    ? topHudEl.getBoundingClientRect().height
    : 76;
  const bottomH = (bottomEl && !bottomEl.classList.contains('hidden'))
    ? bottomEl.getBoundingClientRect().height
    : 110;

  const hudRect = (topHudEl && !topHudEl.classList.contains('hidden'))
    ? topHudEl.getBoundingClientRect()
    : null;
  const topSafeLimit = hudRect ? (hudRect.bottom + 10) : (topH + 10);

  const BOTTOM_RESERVE = Math.max(bottomH, 115);
  const usableHeight = Math.max(160, vpHeight - topSafeLimit - BOTTOM_RESERVE);

  const paddedWidth = FIELD_WIDTH;
  const paddedHeight = FIELD_HEIGHT;

  const oldBaseZoom = baseZoom || 1.0;
  const zoomRatio = (camZoom && oldBaseZoom) ? (camZoom / oldBaseZoom) : 1.0;

  baseZoom = Math.min(vpWidth / paddedWidth, usableHeight / paddedHeight);
  minZoom = baseZoom * 0.95;
  maxZoom = Math.max(2.2, baseZoom * 2.5);

  camZoom = Math.min(maxZoom, Math.max(minZoom, baseZoom * zoomRatio));

  const viewFieldH = FIELD_HEIGHT * camZoom;

  camX = (vpWidth / 2) - (FIELD_WIDTH * camZoom / 2);

  if (viewFieldH <= usableHeight) {
    const desiredCenterY = topSafeLimit + (usableHeight * 0.38);
    camY = Math.max(topSafeLimit, desiredCenterY - (viewFieldH / 2));
  } else {
    camY = topSafeLimit;
  }

  clampCamera();
  if (typeof invalidateGridCache === 'function') {
    invalidateGridCache();
  }
}

// [UI.Q]
function clampCamera() {
  const screenW = _lastCanvasResizeW || window.innerWidth;
  const screenH = _lastCanvasResizeH || window.innerHeight;
  const viewFieldW = FIELD_WIDTH * camZoom;
  const viewFieldH = FIELD_HEIGHT * camZoom;

  const topHudEl = document.getElementById('topHud');
  const bottomEl = document.getElementById('controlsWrapper');

  const topH = (topHudEl && !topHudEl.classList.contains('hidden'))
    ? topHudEl.getBoundingClientRect().height
    : 76;
  const bottomH = (bottomEl && !bottomEl.classList.contains('hidden'))
    ? bottomEl.getBoundingClientRect().height
    : 110;

  const hudRect = (topHudEl && !topHudEl.classList.contains('hidden'))
    ? topHudEl.getBoundingClientRect()
    : null;
  const topSafeLimit = hudRect ? (hudRect.bottom + 10) : (topH + 10);

  const BOTTOM_RESERVE = Math.max(bottomH, 115);
  const usableHeight = Math.max(100, screenH - topSafeLimit - BOTTOM_RESERVE);

  if (viewFieldW <= screenW) {
    camX = (screenW - viewFieldW) / 2;
  } else {
    camX = Math.max(screenW - viewFieldW, Math.min(0, camX));
  }

  const EXTRA_PAN_UP = (TILE_SIZE * 2) * camZoom;

  if (viewFieldH <= usableHeight) {
    const defaultY = Math.max(topSafeLimit, (topSafeLimit + (usableHeight * 0.38)) - (viewFieldH / 2));
    const minY = defaultY - EXTRA_PAN_UP;
    const maxY = defaultY;
    camY = Math.max(minY, Math.min(maxY, camY));
  } else {
    const minY = (screenH - BOTTOM_RESERVE) - viewFieldH - EXTRA_PAN_UP;
    const maxY = topSafeLimit;
    camY = Math.max(minY, Math.min(maxY, camY));
  }
}

// [UI.R]
function screenToWorld(sx, sy) {
  const rect = canvas.getBoundingClientRect();
  const relX = sx - rect.left;
  const relY = sy - rect.top;
  return {
    x: (relX - camX) / camZoom,
    y: (relY - camY) / camZoom
  };
}

// [UI.S]
function worldToScreen(wx, wy) {
  const rect = canvas.getBoundingClientRect();
  return {
    x: wx * camZoom + camX + rect.left,
    y: wy * camZoom + camY + rect.top
  };
}

window.addEventListener('resize', resizeCanvasAndCamera);
// [UI.T]
window.addEventListener('orientationchange', () => {
  setTimeout(() => resizeCanvasAndCamera(true), 150);
});
window.addEventListener('load', () => resizeCanvasAndCamera(true));

//  Lock default touch behaviors on active canvas and UI overlays.
// [UI.U]
document.addEventListener('touchmove', (e) => {
  const isScrollableOverlay = e.target.closest && e.target.closest(
    '.result-stack, .upgrades-row-list, .settings-box, .settings-collapsible-body, .settings-collapsible-widget, .loadout-widget, .loadout-widget-expanded, .loadout-grid, .levels-bg, .bp-tier-list, .shop-list-body'
  );
  if (isScrollableOverlay) {
    return;
  }
  if (gameState === 'PLAYING' && e.cancelable) {
    e.preventDefault();
  }
}, { passive: false });

//  Interactive level tutorial overlay and sequence step controller.
// [UI.V]
function initTutorialForLevel(lvl) {
  tutorialActive = false;
  tutorialLevel = null;
  tutorialStep = -1;
  tutorialTargetTower = null;
  tutorialDestCell = null;
  hideTutorialUI();

  // Гарантируем актуальный язык элементов перед запуском обучения
  if (typeof applyStaticTranslations === 'function') {
    applyStaticTranslations();
  }

  const showSkipButton = () => {
    const skipBtn = document.getElementById('tutorialSkipBtn');
    if (skipBtn) {
      skipBtn.textContent = (typeof t === 'function') ? t('skip_tutorial') : 'Skip Tutorial';
      skipBtn.classList.remove('hidden');
    }
  };

  if (lvl === 1 && !tutorialSeen.l1 && !hasClearedLevelBefore(1)) {
    tutorialActive = true;
    tutorialLevel = 1;
    tutorialStep = 0;
    tutorialDestCell = findTutorialBuildCell();
    showSkipButton();
  } else if (lvl === 2 && !tutorialSeen.l2 && !hasClearedLevelBefore(2)) {
    tutorialActive = true;
    tutorialLevel = 2;
    tutorialStep = -1;
    showSkipButton();
  }
}

// [UI.W]
function hideTutorialUI() {
  const layer = document.getElementById('tutorialLayer');
  if (layer) layer.classList.add('hidden');
  const skipBtn = document.getElementById('tutorialSkipBtn');
  if (skipBtn) skipBtn.classList.add('hidden');
  const closeHighlight = document.getElementById('tutorialCloseBtnHighlight');
  if (closeHighlight) closeHighlight.classList.add('hidden');
}

// [UI.X]
function completeTutorial(lvl) {
  tutorialActive = false;
  tutorialLevel = null;
  tutorialStep = -1;
  tutorialTargetTower = null;
  if (lvl === 1) tutorialSeen.l1 = true;
  if (lvl === 2) tutorialSeen.l2 = true;
  hideTutorialUI();
  saveGameSoon();
  safeTrack('tutorial_step_complete', { level: lvl });
}

// [UI.Y]
function skipTutorial() {
  if (!tutorialActive || !tutorialLevel) return;
  completeTutorial(tutorialLevel);
}

// [UI.Z]
function buildDiagnostics() {
  // [UI.AA]
  const probe = (label, fn) => {
    try { return { label, ok: true, value: fn() }; }
    catch (e) { return { label, ok: false, value: 'ERROR: ' + (e && e.message ? e.message : e) }; }
  };

  // [UI.AB]
  function audioReport() {
    const rows = [];
    rows.push(probe('audio.js loaded', () => typeof SFX !== 'undefined' && !!SFX));
    rows.push(probe('music.js loaded', () => typeof MusicManager !== 'undefined' && !!MusicManager));
    rows.push(probe('settings.sfxVolume', () => settings.sfxVolume));
    rows.push(probe('settings.musicVolume', () => settings.musicVolume));
    rows.push(probe('SFX.isEnabled()', () => SFX.isEnabled()));
    rows.push(probe('MUSIC.isEnabled()', () => MusicManager.isEnabled()));
    rows.push(probe('MUSIC.current()', () => MusicManager.current()));
    // [UI.AC]
    rows.push(probe('AudioContext state', () => {
      const c = SFX._ctx && SFX._ctx();
      return c ? c.state : 'no context yet (needs a tap)';
    }));
    // [UI.AD]
    rows.push(probe('sample pack loaded', () => {
      const n = SFX.sampleNames ? SFX.sampleNames() : [];
      return n.length ? n.length + ' samples' : 'none (using synth ticks)';
    }));
    return rows;
  }

  // [UI.AE]
  function generalReport() {
    return [
      probe('game booted', () => !!window.__gameBooted),
      probe('gameState', () => gameState),
      // [UI.AF]
      probe('currentLevel / maxUnlocked', () => `${currentLevel} / ${maxUnlockedLevel}`),
      probe('devMode', () => devMode),
      probe('perfMode', () => perfMode),
      // [UI.AG]
      probe('towers / enemies / projectiles', () => `${towers.length} / ${enemies.length} / ${projectiles.length}`),
      probe('data.js levels', () => Object.keys(LEVELS_DATA).length),
      probe('save present', () => !!localStorage.getItem('sectorDefenseTD_save_v1')),
      probe('selectedLoadout', () => selectedLoadout.join(', '))
    ];
  }

  // [UI.AH]
  function print(title, rows) {
    console.group('%c' + title, 'color:#00e5ff;font-weight:bold');
    rows.forEach(r => {
      const bad = !r.ok || r.value === false;
      console.log('%c' + (bad ? '✗' : '✓') + ' ' + r.label + ':',
        'color:' + (bad ? '#ff2a85' : '#8ef3ff'), r.value);
    });
    console.groupEnd();
  }

  const diag = function () {
    print('Synth Wave Defense — diagnostics', generalReport());
    print('Audio', audioReport());
    console.log('%cTip: diag.audio() for audio only, diag.fix() to force-restart audio, diag.silent() to check why nothing is audible.', 'color:#6f7c96');
    return undefined;
  };

  diag.audio = function () { print('Audio', audioReport()); };
  diag.game = function () { print('Game', generalReport()); };

  diag.silent = function () {
    const reasons = [];
    try {
      if (typeof SFX === 'undefined' || !SFX) reasons.push('audio.js did not load');
      else {
        if (!SFX.isEnabled()) reasons.push('SFX disabled — sound volume is at 0 in Settings');
        const c = SFX._ctx && SFX._ctx();
        if (!c) reasons.push('AudioContext not created yet — browser requires a gesture');
        else if (c.state === 'suspended') reasons.push('AudioContext suspended — tap page once or call diag.fix()');
      }
      if (typeof MusicManager === 'undefined' || !MusicManager) reasons.push('music.js did not load');
      else {
        if (!MusicManager.isEnabled()) reasons.push('music disabled — music volume is at 0 in Settings');
        if (!MusicManager.current()) reasons.push('no music category active right now');
      }
    } catch (e) { reasons.push('probe threw: ' + e.message); }

    if (!reasons.length) console.log('%c✓ Nothing is muting audio — it should be audible.', 'color:#8ef3ff');
    else reasons.forEach(r => console.log('%c✗ ' + r, 'color:#ff2a85'));
  };

  diag.fix = function () {
    try { SFX.unlock(); } catch (e) { console.log('SFX.unlock failed:', e.message); }
    try { musicUnlock(); } catch (e) { console.log('musicUnlock failed:', e.message); }
    try {
      applySfxVolume(settings.sfxVolume != null ? settings.sfxVolume : 100, false);
      applyMusicVolume(settings.musicVolume != null ? settings.musicVolume : 70, false);
    } catch (e) { console.log('volume reapply failed:', e.message); }
    try {
      const want = (gameState === 'PLAYING' || gameState === 'PAUSED') ? 'battle' : 'menu';
      MusicManager.play(want);
      console.log('%c✓ audio re-armed, music category: ' + want, 'color:#8ef3ff');
    } catch (e) { console.log('music restart failed:', e.message); }
  };

  diag.testSound = function () {
    try {
      SFX.unlock();
      ['tap', 'gun', 'explosion'].forEach((n, i) => setTimeout(() => SFX.play(n), i * 260));
      console.log('%cPlaying test audio ticks…', 'color:#8ef3ff');
    } catch (e) { console.log('test failed:', e.message); }
  };

  return diag;
}
window.diag = buildDiagnostics();

window.resetTutorial = function () {
  tutorialSeen.l1 = false;
  tutorialSeen.l2 = false;
  tutorialSeen.l3 = false;
  Object.keys(tutorialSeen).forEach(k => {
    if (k.startsWith('towerUnlock_l')) tutorialSeen[k] = false;
  });
  saveGameSoon();
  console.log('Tutorial flags reset.');
};

// [UI.AI]
function findTutorialBuildCell() {
  const centerC = (COLS - 1) / 2;
  const centerR = (ROWS - 1) / 2;
  let best = null;
  let bestDist = Infinity;
  for (let r = 0; r < ROWS; r++) {
    if (!grid[r]) continue;
    for (let c = 0; c < COLS; c++) {
      if (grid[r][c] !== 0) continue;
      const d = Math.hypot(c - centerC, r - centerR);
      if (d < bestDist) {
        bestDist = d;
        best = { c, r };
      }
    }
  }
  return best;
}

// [UI.AJ]
function applyTutorialHighlight(rect, text, mode) {
  const pad = 10;
  const spotlight = document.getElementById('tutorialSpotlight');
  spotlight.style.left = (rect.x - pad) + 'px';
  spotlight.style.top = (rect.y - pad) + 'px';
  spotlight.style.width = (rect.w + pad * 2) + 'px';
  spotlight.style.height = (rect.h + pad * 2) + 'px';
  spotlight.classList.remove('hidden');

  const cx = rect.x + rect.w / 2;
  const vw = window.innerWidth;
  const vh = window.innerHeight;
  const placeAbove = rect.y > vh * 0.5;

  const bubble = document.getElementById('tutorialBubble');
  document.getElementById('tutorialBubbleText').textContent = text;
  bubble.style.left = Math.min(Math.max(cx, 116), vw - 116) + 'px';
  bubble.style.top = placeAbove ? (rect.y - pad - 54) + 'px' : (rect.y + rect.h + pad + 16) + 'px';
  bubble.classList.remove('hidden');

  if (mode === 'tap') {
    const cy = rect.y + rect.h / 2;
    const tapPulse = document.getElementById('tutorialTapPulse');
    if (tapPulse) {
      tapPulse.style.left = cx + 'px';
      tapPulse.style.top = cy + 'px';
      tapPulse.classList.remove('hidden');
    }
    const dropRing = document.getElementById('tutorialDropRing');
    if (dropRing) dropRing.classList.add('hidden');

    const pointer = document.getElementById('tutorialPointer');
    if (pointer) {
      pointer.style.left = cx + 'px';
      pointer.style.top = cy + 'px';
      pointer.style.opacity = '1';
      pointer.classList.remove('hidden');
    }
  }
}

// [UI.AK]
function positionTutorialTapOnElement(el, text) {
  if (!el) return;
  const r = el.getBoundingClientRect();
  applyTutorialHighlight({ x: r.left, y: r.top, w: r.width, h: r.height }, text, 'tap');
}

// [UI.AL]
function positionTutorialTapAtWorld(wx, wy, text) {
  const screen = worldToScreen(wx, wy);
  const radius = 26 * camZoom;
  applyTutorialHighlight({ x: screen.x - radius, y: screen.y - radius, w: radius * 2, h: radius * 2 }, text, 'tap');
}

// [UI.AM]
function positionTutorialCloseStep() {
  const topLeft = worldToScreen(0, 0);
  const bottomRight = worldToScreen(FIELD_WIDTH, FIELD_HEIGHT);
  const pad = 6;
  const fieldWidth = Math.max(0, (bottomRight.x - topLeft.x) - pad * 2);
  const fieldHeight = Math.max(0, (bottomRight.y - topLeft.y) - pad * 2);

  const fieldEl = document.getElementById('tutorialFieldHighlight');
  if (fieldEl) {
    fieldEl.style.left = (topLeft.x + pad) + 'px';
    fieldEl.style.top = (topLeft.y + pad) + 'px';
    fieldEl.style.width = fieldWidth + 'px';
    fieldEl.style.height = fieldHeight + 'px';
    fieldEl.classList.remove('hidden');
  }

  const spotlight = document.getElementById('tutorialSpotlight');
  if (spotlight) {
    spotlight.style.left = (topLeft.x + pad) + 'px';
    spotlight.style.top = (topLeft.y + pad) + 'px';
    spotlight.style.width = fieldWidth + 'px';
    spotlight.style.height = fieldHeight + 'px';
    spotlight.classList.remove('hidden');
  }

  const towerBlock = document.getElementById('tutorialTowerBlock');
  if (towerBlock && selectedTower) {
    const tScreen = worldToScreen(selectedTower.c * TILE_SIZE, selectedTower.r * TILE_SIZE);
    const tileSizeScreen = TILE_SIZE * camZoom;
    towerBlock.style.left = tScreen.x + 'px';
    towerBlock.style.top = tScreen.y + 'px';
    towerBlock.style.width = tileSizeScreen + 'px';
    towerBlock.style.height = tileSizeScreen + 'px';
    towerBlock.classList.remove('hidden');
    // [UI.AN]
    towerBlock.onclick = (e) => {
      e.stopPropagation();
      if (typeof showHintToast === 'function') {
        showHintToast(typeof t === 'function' ? t('tut_close_hint') : 'Tap the empty field or ✕ to close');
      }
    };
  }

  const closeBtn = document.getElementById('inspectCloseBtn');
  const closeHighlight = document.getElementById('tutorialCloseBtnHighlight');
  if (closeBtn && closeHighlight) {
    const r = closeBtn.getBoundingClientRect();
    closeHighlight.style.left = r.left + 'px';
    closeHighlight.style.top = r.top + 'px';
    closeHighlight.style.width = r.width + 'px';
    closeHighlight.style.height = r.height + 'px';
    closeHighlight.innerHTML = closeBtn.innerHTML;
    closeHighlight.classList.remove('hidden');
  }

  let targetX, targetY;
  if (selectedTower) {
    const targetCellScreen = worldToScreen((selectedTower.c + 1.1) * TILE_SIZE, (selectedTower.r + 1.85) * TILE_SIZE);
    targetX = targetCellScreen.x;
    targetY = targetCellScreen.y;
  } else {
    targetX = topLeft.x + fieldWidth * 0.60;
    targetY = topLeft.y + fieldHeight * 0.76;
  }

  const maxSafeX = (bottomRight.x - pad) - 80;
  const maxSafeY = (bottomRight.y - pad) - 35;
  targetX = Math.min(targetX, maxSafeX);
  targetY = Math.min(targetY, maxSafeY);

  const bubble = document.getElementById('tutorialBubble');
  const bubbleText = document.getElementById('tutorialBubbleText');
  if (bubbleText) bubbleText.textContent = typeof t === 'function' ? t('tut_close') : 'Tap here or ✕ to close';
  if (bubble) {
    bubble.style.left = targetX + 'px';
    bubble.style.top = (targetY - 52) + 'px';
    bubble.classList.remove('hidden');
  }

  const tapPulse = document.getElementById('tutorialTapPulse');
  if (tapPulse) {
    tapPulse.style.left = targetX + 'px';
    tapPulse.style.top = targetY + 'px';
    tapPulse.classList.remove('hidden');
  }

  const pointer = document.getElementById('tutorialPointer');
  if (pointer) {
    pointer.style.left = targetX + 'px';
    pointer.style.top = targetY + 'px';
    pointer.style.opacity = '1';
    pointer.classList.remove('hidden');
  }

  const dropRing = document.getElementById('tutorialDropRing');
  if (dropRing) dropRing.classList.add('hidden');
}

// [UI.AO]
function animateTutorialTapGesture(now) {
  const pointer = document.getElementById('tutorialPointer');
  if (!pointer || pointer.classList.contains('hidden')) return;
  const cycle = (now % 1000) / 1000;
  const tap = Math.sin(cycle * Math.PI * 2);
  const offset = tap > 0 ? tap * 6 : 0;
  pointer.style.transform = `translate(${offset * 0.7}px, ${offset * 0.7}px) scale(${1 - offset * 0.015})`;
}

// [UI.AP]
function updateTutorialOverlay(now) {
  const layer = document.getElementById('tutorialLayer');
  const skipBtn = document.getElementById('tutorialSkipBtn');
  if (!layer) return;
  
  if (!tutorialActive || gameState !== 'PLAYING' || tutorialStep < 0) {
    layer.classList.add('hidden');
    if (skipBtn && tutorialActive) skipBtn.classList.add('hidden');
    return;
  }
  
  layer.classList.remove('hidden');
  if (skipBtn && tutorialActive) skipBtn.classList.remove('hidden');

  const fieldEl = document.getElementById('tutorialFieldHighlight');
  const closeHighlight = document.getElementById('tutorialCloseBtnHighlight');
  if (!(tutorialLevel === 2 && tutorialStep === 2)) {
    if (fieldEl) fieldEl.classList.add('hidden');
    if (closeHighlight) closeHighlight.classList.add('hidden');
  }

  if (tutorialLevel === 1 && tutorialStep === 0) {
    positionTutorialDrag(now);
  } else if (tutorialLevel === 1 && tutorialStep === 1) {
    positionTutorialTapOnElement(document.getElementById('waveBtn'), typeof t === 'function' ? t('tut_tap_go') : 'Tap GO to start the wave');
    animateTutorialTapGesture(now);
  } else if (tutorialLevel === 2 && tutorialStep === 0 && tutorialTargetTower) {
    positionTutorialTapAtWorld(tutorialTargetTower.x, tutorialTargetTower.y, typeof t === 'function' ? t('tut_tap_tower') : 'Tap your tower');
    animateTutorialTapGesture(now);
  } else if (tutorialLevel === 2 && tutorialStep === 1) {
    positionTutorialTapOnElement(document.getElementById('inspectUpgradeBtn'), typeof t === 'function' ? t('tut_upgrade') : 'Upgrade it here');
    animateTutorialTapGesture(now);
  } else if (tutorialLevel === 2 && tutorialStep === 2) {
    positionTutorialCloseStep();
    animateTutorialTapGesture(now);
  }
}

// [UI.AQ]
function positionTutorialDrag(now) {
  const srcEl = document.getElementById('btn-gun');
  if (!srcEl || !tutorialDestCell) return;
  const srcRect = srcEl.getBoundingClientRect();
  const hintText = (typeof window.t === 'function') ? window.t('tut_drag_tower') : 'Drag a tower onto the field';
  applyTutorialHighlight({ x: srcRect.left, y: srcRect.top, w: srcRect.width, h: srcRect.height }, hintText, 'drag');

  const destWorld = {
    x: tutorialDestCell.c * TILE_SIZE + TILE_SIZE / 2,
    y: tutorialDestCell.r * TILE_SIZE + TILE_SIZE / 2
  };
  const destScreen = worldToScreen(destWorld.x, destWorld.y);
  const tileScreenSize = TILE_SIZE * camZoom;

  const dropRing = document.getElementById('tutorialDropRing');
  if (dropRing) {
    dropRing.style.left = (destScreen.x - tileScreenSize * 0.36) + 'px';
    dropRing.style.top = (destScreen.y - tileScreenSize * 0.36) + 'px';
    dropRing.style.width = (tileScreenSize * 0.72) + 'px';
    dropRing.style.height = (tileScreenSize * 0.72) + 'px';
    dropRing.classList.remove('hidden');
  }

  const srcCx = srcRect.left + srcRect.width / 2;
  const srcCy = srcRect.top + srcRect.height / 2;

  const period = 2000;
  const animT = (now % period) / period;
  let px, py, opacity, scale;

  if (animT < 0.20) {
    px = srcCx;
    py = srcCy;
    const appearProg = Math.min(1, animT / 0.12);
    opacity = appearProg;
    scale = 1.0 - Math.sin(appearProg * Math.PI * 0.5) * 0.08;
  } else if (animT < 0.70) {
    const moveT = (animT - 0.20) / 0.50;
    const eased = moveT < 0.5 
      ? 2 * moveT * moveT 
      : 1 - Math.pow(-2 * moveT + 2, 2) / 2;
    px = srcCx + (destScreen.x - srcCx) * eased;
    py = srcCy + (destScreen.y - srcCy) * eased;
    opacity = 1.0;
    scale = 0.92;
  } else if (animT < 0.85) {
    px = destScreen.x;
    py = destScreen.y;
    opacity = 1.0;
    scale = 1.0;
  } else {
    px = destScreen.x;
    py = destScreen.y;
    opacity = Math.max(0, 1.0 - (animT - 0.85) / 0.15);
    scale = 1.0;
  }

  const pointer = document.getElementById('tutorialPointer');
  if (pointer) {
    pointer.style.left = px + 'px';
    pointer.style.top = py + 'px';
    pointer.style.opacity = opacity.toFixed(3);
    pointer.style.transform = `scale(${scale.toFixed(3)})`;
    pointer.classList.remove('hidden');
  }

  const tapPulse = document.getElementById('tutorialTapPulse');
  if (tapPulse) tapPulse.classList.add('hidden');
}

// [UI.AR]
function setGlow(color, blur) {
  if (perfMode === 'low') {
    ctx.shadowBlur = 0;
    return;
  }
  ctx.shadowColor = color;
  ctx.shadowBlur = Math.min(blur, 8);
}

// [UI.AS]
function pushParticle(p) {
  const cap = perfMode === 'low' ? 85 : 150;
  if (particles.length > cap) {
    if (!p.isSmoke && !p.isBossFx && !p.isCrossFlash && Math.random() < 0.45) return;
    particles[0].life *= 0.45;
  }
  particles.push(p);
}

// [UI.AT]
function formatResourceVal(val) {
  const n = Math.floor(Number(val) || 0);
  if (n < 1000) return String(n);
  if (n < 10000) {
    const k = Math.floor(n / 100) / 10;
    return (k % 1 === 0 ? k.toFixed(0) : k.toFixed(1)) + 'K';
  }
  if (n < 1000000) {
    return Math.floor(n / 1000) + 'K';
  }
  const m = Math.floor(n / 100000) / 10;
  return (m % 1 === 0 ? m.toFixed(0) : m.toFixed(1)) + 'M';
}

// Единый контроллер видимости элементов верхней панели
// [UI.AU]
function syncTopHudVisibility() {
  const isActiveBattle = (typeof gameState !== 'undefined' && gameState === 'PLAYING');

  const diamondBadge = document.getElementById('hudDiamondBadge');
  const prismBadge = document.getElementById('hudPrismBadge');
  const econHpBadge = document.getElementById('econHpSplitBadge');
  const levelWaveBadge = document.getElementById('levelWaveSplitBadge');
  const hudRightGroup = document.getElementById('hudRightGroup');

  if (diamondBadge) diamondBadge.classList.toggle('hidden', isActiveBattle);
  if (prismBadge) prismBadge.classList.toggle('hidden', isActiveBattle);

  if (econHpBadge) econHpBadge.classList.toggle('hidden', !isActiveBattle);
  if (levelWaveBadge) levelWaveBadge.classList.toggle('hidden', !isActiveBattle);

  if (hudRightGroup) hudRightGroup.classList.remove('hidden');

  if (typeof updateHudSpeedWidget === 'function') updateHudSpeedWidget();
}
window.syncTopHudVisibility = syncTopHudVisibility;

// [UI.AV]
function updateDiamondUI() {
  const formatted = formatResourceVal(diamonds);
  const el = document.getElementById('globalDiamondsVal');
  if (el) el.textContent = formatted;
  const elLevels = document.getElementById('levelsDiamondVal');
  if (elLevels) elLevels.textContent = formatted;
  const elUpgrades = document.getElementById('upgradesDiamondVal');
  if (elUpgrades) elUpgrades.textContent = formatted;
  const elShop = document.getElementById('shopDiamondVal');
  if (elShop) elShop.textContent = formatted;
  const elBp = document.getElementById('bpDiamondVal');
  if (elBp) elBp.textContent = formatted;
  const badge = document.getElementById('hudDiamondBadge');
  if (badge) {
    if (devMode) {
      badge.classList.add('interactive');
      badge.title = "Click: +50 / Hold: set amount (Dev Mode)";
    } else {
      badge.classList.remove('interactive');
      badge.removeAttribute('title');
    }
  }
  syncTopHudVisibility();
}

// [UI.AW]
function updatePrismUI() {
  const formatted = formatResourceVal(prisms);
  const el = document.getElementById('globalPrismsVal');
  if (el) el.textContent = formatted;
  const elLevels = document.getElementById('levelsPrismVal');
  if (elLevels) elLevels.textContent = formatted;
  const elUpgrades = document.getElementById('upgradesPrismVal');
  if (elUpgrades) elUpgrades.textContent = formatted;
  const elShop = document.getElementById('shopPrismVal');
  if (elShop) elShop.textContent = formatted;
  const elBp = document.getElementById('bpPrismVal');
  if (elBp) elBp.textContent = formatted;
  const badge = document.getElementById('hudPrismBadge');
  if (badge) {
    if (devMode) {
      badge.classList.add('interactive');
      badge.title = "Click: +10 / Hold: set amount (Dev Mode)";
    } else {
      badge.classList.remove('interactive');
      badge.removeAttribute('title');
    }
  }
  syncTopHudVisibility();
}

// [UI.AX] Заглушки до динамической инициализации системного модуля
function initDevResourceHold() {}
function handleDevDiamondClick() {}
function handleDevPrismClick() {}
function handleDevGoldClick() {}
function handleDevHpClick() {}

const BASE_BRANCH_ICONS = {
  base_hp: `<svg width="34" height="34" viewBox="-20 -20 40 40"><g transform="scale(1.35)"><path d="M 0 8 L -7.5 0.5 A 4.8 4.8 0 0 1 0 -6 A 4.8 4.8 0 0 1 7.5 0.5 Z" fill="#f05f9f"/></g></svg>`,
  base_gold: `<svg width="34" height="34" viewBox="-20 -20 40 40"><g transform="translate(-12, -12)"><circle cx="12" cy="12" r="11" fill="#ff9100"/><text x="12" y="17.5" font-size="16" font-weight="900" fill="#000000" text-anchor="middle" font-family="Montserrat, sans-serif">$</text></g></svg>`
};
const BASE_BRANCH_COLORS = { base_hp: '#f05f9f', base_gold: '#ff9100' };

const CUSTOM_LOCK_SVG = `<svg width="12" height="12" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.2" fill="none" stroke-linecap="round" stroke-linejoin="round" style="flex:none;"><path d="M 7,10 V 6 C 7,3.5 9,2 12,2 C 15,2 17,3.5 17,6 V 10"/><rect x="4" y="10" width="16" height="12" rx="3" fill="currentColor" fill-opacity="0.2"/></svg>`;

// [UI.BN]
function enablePointerScroll(el) {
  if (!el || el.dataset.pointerScrollBound) return;
  el.dataset.pointerScrollBound = '1';

  let isDown = false;
  let startY = 0;
  let scrollTop = 0;
  let isDragging = false;

  // [UI.BO]
  el.addEventListener('pointerdown', (e) => {
    isDown = true;
    isDragging = false;
    startY = e.clientY;
    scrollTop = el.scrollTop;
  });

  // [UI.BP]
  el.addEventListener('pointermove', (e) => {
    if (!isDown) return;
    const dy = e.clientY - startY;
    if (Math.abs(dy) > 4) {
      isDragging = true;
      el.scrollTop = scrollTop - dy;
    }
  });

  // [UI.BQ]
  const endDrag = (e) => {
    if (isDragging && e) {
      // [UI.BR]
      const preventClick = (clickEv) => {
        clickEv.stopPropagation();
        clickEv.preventDefault();
      };
      el.addEventListener('click', preventClick, { capture: true, once: true });
      // [UI.BS]
      setTimeout(() => el.removeEventListener('click', preventClick, { capture: true }), 50);
    }
    isDown = false;
    isDragging = false;
  };

  el.addEventListener('pointerup', endDrag);
  el.addEventListener('pointercancel', endDrag);
  el.addEventListener('pointerleave', endDrag);
}

// [UI.BT]
function getUpgradeStatSummary(key, currentLvl) {
  const curEff = typeof getUpgradeEffectiveLevel === 'function' ? getUpgradeEffectiveLevel(key) : currentLvl;
  const isMaxed = currentLvl >= 15 && typeof isScalingBranch === 'function' && !isScalingBranch(key);

  const nextEff = (function() {
    const nextLvl = currentLvl + 1;
    if (nextLvl <= 10) return nextLvl;
    if (nextLvl <= 15) return nextLvl === 15 ? 16.5 : nextLvl;
    if (key === 'base_hp') return 16.5 + (nextLvl - 15);
    const k = nextLvl - 15;
    return 16.5 + 20 * (1 - Math.pow(0.95, k));
  })();
  const deltaEff = Math.max(0, nextEff - curEff);

  const _tr = (typeof window.t === 'function') ? window.t : ((k) => k.toUpperCase());
  const maxLabel = _tr('max') || 'MAX';
  const hpLabel = _tr('stat_hp') || 'HP:';
  const goldLabel = _tr('stat_gold') || 'GOLD:';
  const slowLabel = _tr('stat_slow') || 'SLOW:';
  const durLabel = _tr('stat_dur') || 'DUR:';
  const rngLabel = _tr('stat_rng') || 'RNG:';
  const dmgLabel = _tr('stat_dmg') || 'DMG:';
  const spdLabel = _tr('stat_spd') || 'SPD:';
  const dpsLabel = _tr('stat_dps') || 'DPS:';

  if (key === 'base_hp') {
    const curHp = 10 + Math.round(curEff);
    const nextTag = isMaxed ? `<span class="upg-stat-next">${maxLabel}</span>` : `<span class="upg-stat-next">+1 ${hpLabel.replace(':', '')}</span>`;
    return `<span class="upg-stat-cur"><span class="upg-lbl">${hpLabel}</span> ${curHp}</span>${nextTag}`;
  }

  if (key === 'base_gold') {
    const curGold = Math.round(curEff * 5);
    const stepGold = +(deltaEff * 5).toFixed(1);
    const nextTag = isMaxed ? `<span class="upg-stat-next">${maxLabel}</span>` : `<span class="upg-stat-next">+${stepGold}%</span>`;
    return `<span class="upg-stat-cur"><span class="upg-lbl">${goldLabel}</span> +${curGold}%</span>${nextTag}`;
  }

  const towerType = key.replace('_power', '');
  const conf = (typeof TOWER_CONFIGS !== 'undefined') ? TOWER_CONFIGS[towerType] : null;
  if (!conf) return '';

  const curRangeBonus = (typeof getUpgradeRangeBonus === 'function')
    ? getUpgradeRangeBonus(towerType, curEff)
    : (curEff <= 10 ? curEff * (conf.powerRange || 0) : 10 * (conf.powerRange || 0) + (curEff - 10) * 0.01);

  const nextRangeBonus = (typeof getUpgradeRangeBonus === 'function')
    ? getUpgradeRangeBonus(towerType, nextEff)
    : (nextEff <= 10 ? nextEff * (conf.powerRange || 0) : 10 * (conf.powerRange || 0) + (nextEff - 10) * 0.01);

  const curRng = Math.round(conf.range * (1 + curRangeBonus));
  const rngStep = Math.round((nextRangeBonus - curRangeBonus) * 100);
  const dStep = Math.round(deltaEff * (conf.powerDmg || 0) * 100);
  const rStep = Math.round(deltaEff * (conf.powerRate || 0) * 100);

  if (towerType === 'stasis') {
    const baseSlow = conf.slowFactor || 0.30;
    const baseDur = conf.slowDuration || 1.4;
    const curSlow = Math.min(90, Math.round(baseSlow * (1 + curEff * (conf.powerSlow || 0)) * 100));
    const curDur = +(baseDur * (1 + curEff * (conf.powerDuration || 0))).toFixed(1);
    const sStep = Math.round(deltaEff * (conf.powerSlow || 0) * 100);
    const durStep = Math.round(deltaEff * (conf.powerDuration || 0) * 100);

    const nextTag = isMaxed ? `<span class="upg-stat-next">${maxLabel}</span>` : `<span class="upg-stat-next">+${sStep}/${durStep}/${rngStep}%</span>`;
    return `<span class="upg-stat-cur"><span class="upg-lbl">${slowLabel}</span> ${curSlow}%<span class="upg-sep">·</span><span class="upg-lbl">${durLabel}</span> ${curDur}s<span class="upg-sep">·</span><span class="upg-lbl">${rngLabel}</span> ${curRng}</span>${nextTag}`;
  }

  const baseDmg = conf.damage || conf.dps || conf.baseDps || 0;
  const curDmg = +(baseDmg * (1 + curEff * (conf.powerDmg || 0))).toFixed(1);

  if (conf.fireRate) {
    const curRate = +(conf.fireRate / (1 + curEff * (conf.powerRate || 0))).toFixed(2);
    const nextTag = isMaxed ? `<span class="upg-stat-next">${maxLabel}</span>` : `<span class="upg-stat-next">+${dStep}/${rStep}/${rngStep}%</span>`;
    return `<span class="upg-stat-cur"><span class="upg-lbl">${dmgLabel}</span> ${curDmg} <span class="upg-sep">·</span> <span class="upg-lbl">${spdLabel}</span> ${curRate}s <span class="upg-sep">·</span> <span class="upg-lbl">${rngLabel}</span> ${curRng}</span>${nextTag}`;
  }

  const nextTag = isMaxed ? `<span class="upg-stat-next">${maxLabel}</span>` : `<span class="upg-stat-next">+${dStep}/${rngStep}%</span>`;
  return `<span class="upg-stat-cur"><span class="upg-lbl">${dpsLabel}</span> ${curDmg} <span class="upg-sep">·</span> <span class="upg-lbl">${rngLabel}</span> ${curRng}</span>${nextTag}`;
}

// [UI.BU]
function getUpgradeDetailedToast(key) {
  const curEff = typeof getUpgradeEffectiveLevel === 'function' ? getUpgradeEffectiveLevel(key) : (upgradeTreeData[key] || 0);
  if (key === 'base_hp') {
    const hp = 10 + Math.round(curEff);
    return `Base Health: ${hp} HP (+${Math.round(curEff)} bonus)`;
  }
  if (key === 'base_gold') {
    return `Bounty Bonus: +${Math.round(curEff * 5)}% Gold`;
  }
  const towerType = key.replace('_power', '');
  const conf = (typeof TOWER_CONFIGS !== 'undefined') ? TOWER_CONFIGS[towerType] : null;
  if (!conf) return '';
  const name = (typeof TOWER_NAMES !== 'undefined' && TOWER_NAMES[towerType]) ? TOWER_NAMES[towerType] : towerType;

  if (towerType === 'stasis') {
    const slow = Math.min(90, Math.round((conf.slowFactor || 0.30) * (1 + curEff * (conf.powerSlow || 0)) * 100));
    const dur = ((conf.slowDuration || 1.4) * (1 + curEff * (conf.powerDuration || 0))).toFixed(2);
    return `${name} Lv.1 Stats: ${slow}% Slow for ${dur}s`;
  }

  const baseDmg = conf.damage || conf.dps || conf.baseDps || 0;
  const dmg = (baseDmg * (1 + curEff * (conf.powerDmg || 0))).toFixed(1);
  const rng = Math.round(conf.range * (1 + curEff * (conf.powerRange || 0)));
  if (conf.fireRate) {
    const rate = (conf.fireRate / (1 + curEff * (conf.powerRate || 0))).toFixed(2);
    return `${name} Lv.1 Stats: ${dmg} DMG · ${rate}s Rate · ${rng} RNG`;
  }
  return `${name} Lv.1 Stats: ${dmg} DPS · ${rng} RNG`;
}

//  Meta-upgrade skill tree DOM interface renderer.
// [UI.BV]
function renderUpgradeTree() {
  updateDiamondUI();
  updatePrismUI();
  const container = document.getElementById('upgradesTreeBody');
  if (!container) return;
  enablePointerScroll(container);
  container.innerHTML = '';

  const th = getTheme();
  const primaryAccent = th.c1;
  BASE_BRANCH_COLORS.base_hp = th.c3;
  BASE_BRANCH_COLORS.base_gold = th.c4;
  BASE_BRANCH_ICONS.base_hp = `<svg width="34" height="34" viewBox="-20 -20 40 40"><g transform="scale(1.35)"><path d="M 0 8 L -7.5 0.5 A 4.8 4.8 0 0 1 0 -6 A 4.8 4.8 0 0 1 7.5 0.5 Z" fill="${th.c3}"/></g></svg>`;
  BASE_BRANCH_ICONS.base_gold = `<svg width="34" height="34" viewBox="-20 -20 40 40"><g transform="translate(-12, -12)"><circle cx="12" cy="12" r="11" fill="${th.c4}"/><text x="12" y="17.5" font-size="16" font-weight="900" fill="#000000" text-anchor="middle" font-family="Montserrat, sans-serif">$</text></g></svg>`;

  const maxStep = devMode ? 10 : getMaxUpgradeStep();
  const isPhase2UnlockedGlobally = devMode || getLoadoutReferenceLevel() >= 31 || maxUnlockedLevel >= 31 || (typeof clearedLevels !== 'undefined' && clearedLevels.includes(30));

  const towerRows = UPGRADE_BRANCH_SPECS.towers.map(card => {
    const towerType = card.icon;
    const isLockedCard = !devMode && getLoadoutReferenceLevel() < getTowerUnlockLevel(towerType);
    return {
      key: card.branches[0].key,
      label: card.title,
      iconHtml: TOWER_ICONS[towerType] || '',
      color: (TOWER_CONFIGS[towerType] && TOWER_CONFIGS[towerType].color) || primaryAccent,
      isLockedCard,
      lockedLabel: isLockedCard ? `${card.title} (Lv.${getTowerUnlockLevel(towerType)})` : card.title
    };
  });
  const baseRows = (UPGRADE_BRANCH_SPECS.base[0].branches || []).map(br => {
    const locName = br.key === 'base_hp'
      ? (typeof t === 'function' ? t('base_hp') : br.name)
      : (br.key === 'base_gold' ? (typeof t === 'function' ? t('bounty') : br.name) : br.name);
    return {
      key: br.key,
      label: locName,
      iconHtml: BASE_BRANCH_ICONS[br.key] || '',
      color: BASE_BRANCH_COLORS[br.key] || primaryAccent,
      isLockedCard: false,
      lockedLabel: locName
    };
  });

  // [UI.BW]
  const addGroupLabel = (text) => {
    const label = document.createElement('div');
    label.className = 'upgrades-row-group-label';
    label.textContent = text;
    container.appendChild(label);
  };

  // [UI.BX]
  const addRow = (row) => {
    const currentLvl = upgradeTreeData[row.key] || 0;
    const nextStep = currentLvl + 1;

    let isSectorGated = false;
    let lvlNeeded = 11;
    let isAscGatedByBranches = false;

    if (!row.isLockedCard && !devMode) {
      if (nextStep <= 10) {
        if (nextStep > maxStep) {
          isSectorGated = true;
          if (nextStep > 8) lvlNeeded = 31;
          else if (nextStep > 6) lvlNeeded = 21;
          else lvlNeeded = 11;
        }
      } else {
        if (!isPhase2UnlockedGlobally) {
          isSectorGated = true;
          lvlNeeded = 31;
        } else if (!areAllBranchesMaxPhase1()) {
          isAscGatedByBranches = true;
        }
      }
    }

    const card = document.createElement('div');
    card.className = 'upgrade-row-card' + (row.isLockedCard ? ' locked-row' : '');

    const iconWrap = document.createElement('div');
    iconWrap.className = 'upgrade-row-icon' + (row.isLockedCard ? ' locked-icon' : '');
    iconWrap.innerHTML = row.iconHtml;
    card.appendChild(iconWrap);

    const info = document.createElement('div');
    info.className = 'upgrade-row-info';

    const head = document.createElement('div');
    head.className = 'upgrade-row-head';
    const nameEl = document.createElement('span');
    nameEl.className = 'upgrade-row-name' + (row.isLockedCard ? ' locked-name' : '');
    nameEl.textContent = row.label;

    const lvlEl = document.createElement('span');
    lvlEl.className = 'upgrade-row-level';

    const _tr = (typeof window.t === 'function') ? window.t : ((k) => k);

    if (row.isLockedCard) {
      lvlEl.textContent = ''; 
    } else if (currentLvl < 10) {
      lvlEl.style.color = row.color;
      lvlEl.textContent = `${currentLvl}/10`;
    } else if (currentLvl < 15) {
      lvlEl.style.color = '#d946ef';
      lvlEl.textContent = `ASC ${currentLvl - 10}/5`;
    } else if (!isScalingBranch(row.key)) {
      lvlEl.style.color = '#d946ef';
      lvlEl.textContent = _tr('ascended_max') || 'ASCENDED MAX';
    } else {
      lvlEl.style.color = th.c1;
      lvlEl.textContent = (typeof t === 'function') ? t('synth_plus_n', { n: currentLvl - 15 }) : `SYNTH +${currentLvl - 15}`;
    }

    head.appendChild(nameEl);
    head.appendChild(lvlEl);
    info.appendChild(head);

    const segs = document.createElement('div');
    segs.className = 'upgrade-row-segments';

    if (currentLvl < 10) {
      for (let s = 1; s <= 10; s++) {
        const seg = document.createElement('div');
        seg.className = 'upgrade-row-seg' + (row.isLockedCard ? ' locked-seg' : '');
        if (!row.isLockedCard && s <= currentLvl) {
          seg.style.background = row.color;
        }
        segs.appendChild(seg);
      }
    } else if (currentLvl < 15 || !isScalingBranch(row.key)) {
      for (let s = 1; s <= 5; s++) {
        const seg = document.createElement('div');
        seg.className = 'upgrade-row-seg' + (row.isLockedCard ? ' locked-seg' : '');
        if (!row.isLockedCard && s <= (currentLvl - 10)) {
          seg.style.background = '#d946ef';
          seg.style.boxShadow = '0 0 8px #d946ef';
        }
        segs.appendChild(seg);
      }
    } else {
      const seg = document.createElement('div');
      seg.className = 'upgrade-row-seg';
      seg.style.flex = '1';
      seg.style.background = `linear-gradient(90deg, ${th.c1}, ${th.c2}, ${th.c3})`;
      seg.style.boxShadow = `0 0 10px rgba(${th.rgb2 ? th.rgb2.cssRgb : '217, 70, 239'}, 0.5)`;
      segs.appendChild(seg);
    }
    info.appendChild(segs);

    const statsLine = document.createElement('div');
    statsLine.className = 'upgrade-row-stats';
    if (row.isLockedCard) {
      statsLine.innerHTML = '';
    } else {
      statsLine.innerHTML = getUpgradeStatSummary(row.key, currentLvl);
    }
    info.appendChild(statsLine);

    card.appendChild(info);

    if (devMode && !row.isLockedCard && currentLvl > 0) {
      const minusBtn = document.createElement('button');
      minusBtn.className = 'upgrade-row-dev-minus';
      minusBtn.textContent = '−';
      minusBtn.onclick = () => handleNodeClick(row.key, currentLvl - 1);
      card.appendChild(minusBtn);
    }

    const buyBtn = document.createElement('button');
    buyBtn.className = 'upgrade-row-buy';

    if (row.isLockedCard) {
      const reqLvl = getTowerUnlockLevel(row.key.replace('_power', ''));
      buyBtn.classList.add('locked-buy');
      buyBtn.innerHTML = `${CUSTOM_LOCK_SVG}<span class="upgrade-row-buy-cost" style="color:#8ea3c4; font-size:11px; margin-left:3px; font-weight:900;">L${reqLvl}</span>`;
      // [UI.BY]
      buyBtn.onclick = () => {
        if (typeof sfx === 'function') sfx('denied');
        if (typeof showHintToast === 'function') {
          showHintToast(typeof t === 'function' ? t('unlocks_on_level_n', { n: reqLvl }) : `Unlocks on Level ${reqLvl}`);
        }
      };
    } else if (currentLvl >= 15 && !isScalingBranch(row.key)) {
      buyBtn.classList.add('locked-buy', 'max-buy');
      buyBtn.innerHTML = `<span class="upgrade-row-buy-cost" style="color:#d946ef; font-size:10px;">${_tr('ascended_max') || 'ASCENDED MAX'}</span>`;
      // [UI.BZ]
      buyBtn.onclick = () => {
        if (typeof sfx === 'function') sfx('denied');
        if (typeof showHintToast === 'function') {
          showHintToast(typeof t === 'function' ? t('branch_ascended_max') : 'Branch is ASCENDED MAX (Lvl 15)');
        }
      };
    } else if (isSectorGated) {
      buyBtn.classList.add('locked-buy');
      buyBtn.innerHTML = `${CUSTOM_LOCK_SVG}<span class="upgrade-row-buy-cost" style="color:#8ea3c4; font-size:11px; margin-left:3px; font-weight:900;">L${lvlNeeded}</span>`;
      // [UI.CA]
      buyBtn.onclick = () => {
        if (typeof sfx === 'function') sfx('denied');
        if (typeof showHintToast === 'function') {
          showHintToast(typeof t === 'function' ? t('unlocks_on_level_n', { n: lvlNeeded }) : `Unlocks on Level ${lvlNeeded}`);
        }
      };
    } else if (isAscGatedByBranches) {
      buyBtn.classList.add('locked-buy');
      buyBtn.innerHTML = `${CUSTOM_LOCK_SVG}<span class="upgrade-row-buy-cost" style="color:#d946ef; font-size:11px; margin-left:3px; font-weight:900;">ASC</span>`;
      // [UI.CB]
      buyBtn.onclick = () => {
        if (typeof sfx === 'function') sfx('denied');
        if (typeof showHintToast === 'function') {
          showHintToast(typeof t === 'function' ? t('upgrade_all_branches_10') : 'Upgrade all branches to 10/10 first to unlock ASC');
        }
      };
    } else {
      const costs = getUpgradeCostForLevel(nextStep);
      const costD = costs.diamonds;
      const costP = costs.prisms;

      const diamondIcon = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#00e5ff" stroke-width="2.2" stroke-linejoin="round" style="flex:none;"><polygon points="6 3 18 3 22 9 12 22 2 9" fill="rgba(0,229,255,.25)"/><polyline points="2 9 12 13 22 9"/><line x1="12" y1="22" x2="12" y2="13"/></svg>`;
      const prismIcon = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#d946ef" stroke-width="2.2" stroke-linejoin="round" style="flex:none;"><polygon points="12 2 21 12 12 22 3 12" fill="rgba(217,70,239,.25)"/><polyline points="3 12 12 15 21 12"/><line x1="12" y1="2" x2="12" y2="22"/></svg>`;

      const canAffordD = diamonds >= costD;
      const canAffordP = prisms >= costP;
      const canAffordBoth = canAffordD && canAffordP;

      if (costD > 0 && costP > 0) {
        buyBtn.classList.add('dual-cost-btn');
        buyBtn.innerHTML = `
          <div class="dual-cost-row">
            ${diamondIcon}
            <span class="upgrade-row-buy-cost" style="color:${canAffordD ? '#ffffff' : '#f05f9f'};">${costD}</span>
          </div>
          <div class="dual-cost-row">
            ${prismIcon}
            <span class="upgrade-row-buy-cost" style="color:${canAffordP ? '#ffffff' : '#f05f9f'};">${costP}</span>
          </div>
        `;
      } else if (costP > 0) {
        buyBtn.innerHTML = `${prismIcon}<span class="upgrade-row-buy-cost" style="color:${canAffordP ? '#ffffff' : '#f05f9f'};">${costP}</span>`;
      } else {
        buyBtn.innerHTML = `${diamondIcon}<span class="upgrade-row-buy-cost" style="color:${canAffordD ? '#ffffff' : '#f05f9f'};">${costD}</span>`;
      }

      if (!canAffordBoth) {
        buyBtn.style.opacity = '0.75';
      }

      buyBtn.onclick = () => handleNodeClick(row.key, nextStep);
    }
    card.appendChild(buyBtn);
    container.appendChild(card);
  };

  addGroupLabel(typeof t === 'function' ? t('towers_group') : 'Towers');
  towerRows.forEach(addRow);
  addGroupLabel(typeof t === 'function' ? t('base_group') : 'Base');
  baseRows.forEach(addRow);
}

let isNavigatingSection = false;
let modeLevelSections = { normal: 1, overdrive: 1, endless: 1 };

// [UI.CC]
function navLevelSection(dir) {
  if (isNavigatingSection) return;
  const target = currentLevelSection + dir;
  if (target < 1 || target > TOTAL_SECTIONS) return;
  
  let isTargetUnlocked = false;
  if (devMode) {
      isTargetUnlocked = true;
  } else if (currentLevelMode === 'overdrive') {
      const reqLvl = (target - 1) * LEVELS_PER_SECTION;
      isTargetUnlocked = reqLvl === 0 || !!overdriveClearedLevels[reqLvl];
  } else {
      isTargetUnlocked = maxUnlockedLevel > (target - 1) * LEVELS_PER_SECTION;
  }
  
  if (!isTargetUnlocked) {
    if (typeof sfx === 'function') sfx('denied');
    return;
  }

  // Воспроизводим звук перелистывания для обоих направлений
  if (typeof sfx === 'function') sfx('slide');

  const grid = document.getElementById('levelsGrid');
  if (!grid) {
    currentLevelSection = target;
    modeLevelSections[currentLevelMode] = target;
    renderLevelsGrid();
    return;
  }

  isNavigatingSection = true;
  grid.classList.remove('grid-swipe-out-left', 'grid-swipe-out-right', 'grid-swipe-in-left', 'grid-swipe-in-right');
  void grid.offsetWidth;
  const outClass = dir > 0 ? 'grid-swipe-out-left' : 'grid-swipe-out-right';
  const inClass = dir > 0 ? 'grid-swipe-in-right' : 'grid-swipe-in-left';

  grid.classList.add(outClass);

  // [UI.CD]
  setTimeout(() => {
    currentLevelSection = target;
    modeLevelSections[currentLevelMode] = target;
    renderLevelsGrid();
    grid.classList.remove(outClass);
    void grid.offsetWidth;
    grid.classList.add(inClass);

    // [UI.CE]
    setTimeout(() => {
      grid.classList.remove(inClass);
      isNavigatingSection = false;
    }, 220);
  }, 180);
}

let currentLevelMode = 'normal';

// [UI.CF]
function selectLevelMode(mode) {
  const checkOverdrive = (typeof isOverdriveUnlocked === 'function')
    ? isOverdriveUnlocked()
    : ((typeof window !== 'undefined' && typeof window.isOverdriveUnlocked === 'function') ? window.isOverdriveUnlocked() : (typeof maxUnlockedLevel === 'number' && maxUnlockedLevel > 20));

  const checkEndless = (typeof isEndlessUnlocked === 'function')
    ? isEndlessUnlocked()
    : ((typeof window !== 'undefined' && typeof window.isEndlessUnlocked === 'function') ? window.isEndlessUnlocked() : (typeof maxUnlockedLevel === 'number' && maxUnlockedLevel > 15));

  if (mode === 'overdrive') {
    if (!checkOverdrive) {
      if (typeof sfx === 'function') sfx('denied');
      if (typeof showHintToast === 'function') {
        showHintToast(typeof t === 'function' ? t('unlock_hardcore_hint') : 'Complete Normal Level 20 to unlock HARDCORE');
      }
      return;
    }
  } else if (mode === 'endless') {
    if (!checkEndless) {
      if (typeof sfx === 'function') sfx('denied');
      if (typeof showHintToast === 'function') {
        showHintToast(typeof t === 'function' ? t('unlock_endless_hint') : 'Complete Normal Level 15 to unlock Endless Arena');
      }
      return;
    }
  }

  if (typeof sfx === 'function') sfx('confirm');
  
  if (currentLevelMode) {
    modeLevelSections[currentLevelMode] = currentLevelSection;
  }
  
  currentLevelMode = mode;
  isOverdriveMode = (mode === 'overdrive');
  isEndlessMode = (mode === 'endless');

  let targetSec = modeLevelSections[mode] || 1;
  let maxAllowedSec = 1;
  
  if (typeof devMode !== 'undefined' && devMode) {
    maxAllowedSec = typeof TOTAL_SECTIONS !== 'undefined' ? TOTAL_SECTIONS : 5;
  } else if (mode === 'overdrive') {
    let maxHC = 1;
    const hcKeys = (typeof overdriveClearedLevels !== 'undefined') ? Object.keys(overdriveClearedLevels).map(Number) : [];
    if (hcKeys.length > 0) {
      maxHC = Math.max(...hcKeys) + 1;
    }
    maxAllowedSec = Math.ceil(maxHC / LEVELS_PER_SECTION);
  } else {
    maxAllowedSec = Math.ceil((typeof maxUnlockedLevel === 'number' ? maxUnlockedLevel : 1) / LEVELS_PER_SECTION);
  }
  
  currentLevelSection = Math.min(targetSec, Math.max(1, maxAllowedSec));
  modeLevelSections[mode] = currentLevelSection;

  updateModeSwitcherUI();
  if (mode === 'endless') {
    renderEndlessDashboardUI();
  } else {
    renderLevelsGrid();
  }
}

// [UI.CFM] Generalized autonomous live battle preview controller (Normal / Endless / Overdrive).
const ModeBattlePreview = (() => {
  const T_SIZE = 70;

  let activeMode = 'normal';
  let _rafId = null;
  let _lastTs = 0;
  let _lastDt = 0.016;
  let _simTime = 0;

  // Normal state
  const N_COLS = 7, N_ROWS = 5;
  const N_VIEW_X_MIN = 0.35 * T_SIZE;
  const N_VIEW_X_MAX = 6.65 * T_SIZE;
  const N_VIEW_Y_MIN = 0;
  const N_VIEW_Y_MAX = 4.15 * T_SIZE;
  const N_VIEW_W = N_VIEW_X_MAX - N_VIEW_X_MIN;
  const N_VIEW_H = N_VIEW_Y_MAX - N_VIEW_Y_MIN;
  const N_WAYPOINTS = [
    { x: 3.5 * T_SIZE, y: 5.5 * T_SIZE },
    { x: 3.5 * T_SIZE, y: 1.5 * T_SIZE },
    { x: 1.5 * T_SIZE, y: 1.5 * T_SIZE },
    { x: 1.5 * T_SIZE, y: 3.5 * T_SIZE },
    { x: 7.2 * T_SIZE, y: 3.5 * T_SIZE }
  ];
  const N_PATH_CELLS = new Set([
    '3,4', '3,3', '3,2', '3,1',
    '2,1', '1,1',
    '1,2', '1,3',
    '2,3', '3,3', '4,3', '5,3', '6,3'
  ]);

  // Endless state (15x7 = 1050x490, zoomed-out sleek mathematical ∞ over square grid)
  const E_COLS = 15, E_ROWS = 7;
  const E_VIEW_W = E_COLS * T_SIZE;
  const E_VIEW_H = E_ROWS * T_SIZE;
  const E_CX = E_VIEW_W * 0.5;
  const E_CY = E_VIEW_H * 0.5;
  const E_RX = 460;
  const E_RY = 182;
  const E_SAMPLES = 160;
  const E_CURVE = [];
  const E_PATH_CELLS = new Set();
  let E_TOTAL_LEN = 0;
  (function buildSmoothInfinityLut() {
    let prev = null;
    for (let i = 0; i <= E_SAMPLES; i++) {
      const t = (i / E_SAMPLES) * Math.PI * 2;
      const x = E_CX + E_RX * Math.sin(t);
      const y = E_CY + E_RY * Math.sin(2 * t);
      if (prev) E_TOTAL_LEN += Math.hypot(x - prev.x, y - prev.y);
      E_CURVE.push({ x, y, s: E_TOTAL_LEN });
      const tc = Math.floor(x / T_SIZE);
      const tr = Math.floor(y / T_SIZE);
      if (tc >= 0 && tc < E_COLS && tr >= 0 && tr < E_ROWS) {
        E_PATH_CELLS.add(tc + ',' + tr);
      }
      prev = { x, y };
    }
  })();

  function sampleLemniscate(dist) {
    let s = dist % E_TOTAL_LEN;
    if (s < 0) s += E_TOTAL_LEN;
    let lo = 0, hi = E_SAMPLES;
    while (lo < hi - 1) {
      const mid = (lo + hi) >> 1;
      if (E_CURVE[mid].s <= s) lo = mid;
      else hi = mid;
    }
    const p0 = E_CURVE[lo], p1 = E_CURVE[hi];
    const seg = Math.max(0.0001, p1.s - p0.s);
    const u = (s - p0.s) / seg;
    return {
      x: p0.x + (p1.x - p0.x) * u,
      y: p0.y + (p1.y - p0.y) * u,
      angle: Math.atan2(p1.y - p0.y, p1.x - p0.x)
    };
  }

  // Overdrive (Hardcore) state (7x4 = 490x280, strictly tile-aligned)
  const O_COLS = 7, O_ROWS = 4;
  const O_VIEW_W = O_COLS * T_SIZE;
  const O_VIEW_H = O_ROWS * T_SIZE;
  const O_WAYPOINTS = [
    { x: -0.2 * T_SIZE, y: 2.5 * T_SIZE },
    { x: 2.5 * T_SIZE,  y: 2.5 * T_SIZE },
    { x: 2.5 * T_SIZE,  y: 1.5 * T_SIZE },
    { x: 5.5 * T_SIZE,  y: 1.5 * T_SIZE }
  ];
  const O_PATH_CELLS = new Set([
    '0,2', '1,2', '2,2',
    '2,1', '3,1', '4,1', '5,1'
  ]);
  const O_BASE_X = 5.5 * T_SIZE;
  const O_BASE_Y = 1.5 * T_SIZE;

  let _gridCaches = { normal: null, endless: null, overdrive: null };
  let _gridCacheKeys = { normal: '', endless: '', overdrive: '' };

  let _waveTimer = 0;
  let _burstRemaining = 0;
  let _burstTimer = 0;
  let _endlessSpawnTimer = 0;
  let _endlessMobIdx = 0;
  let _odBreached = false;
  let _odBreachTimer = 0;
  let _odFlashTimer = 0;

  let previewEnemies = [];
  let previewProjectiles = [];
  let previewBolts = [];

  const normalTower = {
    type: 'gun', x: 2.5 * T_SIZE, y: 2.5 * T_SIZE,
    range: 155, fireRate: 0.48, damage: 16,
    angle: -Math.PI / 2, fireCooldown: 0.15, lastFire: -10, shotIndex: 0
  };

  const endlessTowers = [
    {
      type: 'gun', x: 3.5 * T_SIZE, y: 3.5 * T_SIZE,
      range: 245, fireRate: 0.42, damage: 16,
      angle: 0, fireCooldown: 0.15, lastFire: -10, shotIndex: 0
    },
    {
      type: 'tesla', x: 11.5 * T_SIZE, y: 3.5 * T_SIZE,
      range: 255, fireRate: 0.78, damage: 22,
      angle: Math.PI, fireCooldown: 0.30, lastFire: -10, shotIndex: 0
    }
  ];

  const odTower = {
    type: 'gun', x: 3.5 * T_SIZE, y: 2.5 * T_SIZE,
    range: 148, fireRate: 0.42, damage: 14,
    angle: Math.PI, fireCooldown: 0.15, lastFire: -10, shotIndex: 0
  };

  function traceNormalRails(tCtx) {
    const hr = 18, rIn = 18, rOut = 52;
    const p0 = N_WAYPOINTS[0], p1 = N_WAYPOINTS[1], p2 = N_WAYPOINTS[2], p3 = N_WAYPOINTS[3], p4 = N_WAYPOINTS[4];
    tCtx.beginPath();
    tCtx.moveTo(p0.x + hr, p0.y);
    tCtx.arcTo(p1.x + hr, p1.y - hr, p2.x - hr, p2.y - hr, rOut);
    tCtx.arcTo(p2.x - hr, p2.y - hr, p3.x - hr, p3.y + hr, rOut);
    tCtx.arcTo(p3.x - hr, p3.y + hr, p4.x, p4.y + hr, rOut);
    tCtx.lineTo(p4.x, p4.y + hr);
    tCtx.stroke();

    tCtx.beginPath();
    tCtx.moveTo(p0.x - hr, p0.y);
    tCtx.arcTo(p1.x - hr, p1.y + hr, p2.x + hr, p2.y + hr, rIn);
    tCtx.arcTo(p2.x + hr, p2.y + hr, p3.x + hr, p3.y - hr, rIn);
    tCtx.arcTo(p3.x + hr, p3.y - hr, p4.x, p4.y - hr, rIn);
    tCtx.lineTo(p4.x, p4.y - hr);
    tCtx.stroke();
  }

  function traceOverdriveRails(tCtx) {
    const hr = 18, rIn = 18, rOut = 48;
    const p0 = O_WAYPOINTS[0], p1 = O_WAYPOINTS[1], p2 = O_WAYPOINTS[2], p3 = O_WAYPOINTS[3];
    // Top rail (inside turn up at p1, outside turn right at p2)
    tCtx.beginPath();
    tCtx.moveTo(p0.x, p0.y - hr);
    tCtx.arcTo(p1.x - hr, p1.y - hr, p2.x - hr, p2.y - hr, rIn);
    tCtx.arcTo(p2.x - hr, p2.y - hr, p3.x, p3.y - hr, rOut);
    tCtx.lineTo(p3.x + 28, p3.y - hr);
    tCtx.stroke();
    // Bottom rail (outside turn up at p1, inside turn right at p2)
    tCtx.beginPath();
    tCtx.moveTo(p0.x, p0.y + hr);
    tCtx.arcTo(p1.x + hr, p1.y + hr, p2.x + hr, p2.y + hr, rOut);
    tCtx.arcTo(p2.x + hr, p2.y + hr, p3.x, p3.y + hr, rIn);
    tCtx.lineTo(p3.x + 28, p3.y + hr);
    tCtx.stroke();
  }

  function traceEndlessRails(tCtx) {
    tCtx.beginPath();
    tCtx.moveTo(E_CURVE[0].x, E_CURVE[0].y);
    for (let i = 1; i <= E_SAMPLES; i++) {
      tCtx.lineTo(E_CURVE[i].x, E_CURVE[i].y);
    }
    tCtx.closePath();
    tCtx.stroke();
  }

  function buildNormalGridCache(th) {
    const c1Rgb = th.rgb1 ? th.rgb1.cssRgb : '0, 229, 255';
    const off = document.createElement('canvas');
    off.width = N_COLS * T_SIZE;
    off.height = N_ROWS * T_SIZE + 70;
    const oCtx = off.getContext('2d');

    for (let r = 0; r < N_ROWS; r++) {
      for (let c = 0; c < N_COLS; c++) {
        const isPath = N_PATH_CELLS.has(c + ',' + r);
        oCtx.fillStyle = isPath ? `rgba(${c1Rgb}, 0.08)` : 'rgba(8, 12, 26, 0.40)';
        oCtx.fillRect(c * T_SIZE, r * T_SIZE, T_SIZE, T_SIZE);
        oCtx.strokeStyle = isPath ? `rgba(${c1Rgb}, 0.18)` : `rgba(${c1Rgb}, 0.14)`;
        oCtx.lineWidth = 1;
        oCtx.strokeRect(c * T_SIZE, r * T_SIZE, T_SIZE, T_SIZE);
      }
    }

    oCtx.save();
    oCtx.strokeStyle = `rgba(${c1Rgb}, 0.34)`;
    oCtx.lineWidth = 1.6;
    oCtx.lineJoin = 'round';
    oCtx.lineCap = 'round';
    traceNormalRails(oCtx);
    oCtx.restore();

    const spawnX = 3.5 * T_SIZE, spawnY = 4.35 * T_SIZE, spawnAng = -Math.PI / 2;
    const offsets = [-14, 0, 14];
    for (let i = 0; i < 3; i++) {
      drawNeonChevron(oCtx, spawnX + Math.cos(spawnAng) * offsets[i], spawnY + Math.sin(spawnAng) * offsets[i], spawnAng, 13, th.c1 || '#00e5ff');
    }
    return off;
  }

  function buildEndlessGridCache() {
    const off = document.createElement('canvas');
    off.width = E_VIEW_W;
    off.height = E_VIEW_H;
    const oCtx = off.getContext('2d');

    for (let r = 0; r < E_ROWS; r++) {
      for (let c = 0; c < E_COLS; c++) {
        const isPath = E_PATH_CELLS.has(c + ',' + r);
        oCtx.fillStyle = isPath ? 'rgba(217, 70, 239, 0.10)' : 'rgba(12, 8, 28, 0.44)';
        oCtx.fillRect(c * T_SIZE, r * T_SIZE, T_SIZE, T_SIZE);
        oCtx.strokeStyle = isPath ? 'rgba(217, 70, 239, 0.24)' : 'rgba(217, 70, 239, 0.14)';
        oCtx.lineWidth = 1;
        oCtx.strokeRect(c * T_SIZE, r * T_SIZE, T_SIZE, T_SIZE);
      }
    }

    oCtx.save();
    oCtx.lineJoin = 'round';
    oCtx.lineCap = 'round';
    oCtx.strokeStyle = 'rgba(217, 70, 239, 0.40)';
    oCtx.lineWidth = 1.8;
    traceEndlessRails(oCtx);
    oCtx.restore();

    // Directional chevrons aligned strictly along the smooth ∞ curve
    const chevFracs = [0.125, 0.375, 0.625, 0.875];
    for (let i = 0; i < chevFracs.length; i++) {
      const pt = sampleLemniscate(chevFracs[i] * E_TOTAL_LEN);
      drawNeonChevron(oCtx, pt.x, pt.y, pt.angle, 12, '#d946ef');
    }
    return off;
  }

  function buildOverdriveGridCache() {
    const off = document.createElement('canvas');
    off.width = O_VIEW_W;
    off.height = O_VIEW_H;
    const oCtx = off.getContext('2d');

    for (let r = 0; r < O_ROWS; r++) {
      for (let c = 0; c < O_COLS; c++) {
        const isPath = O_PATH_CELLS.has(c + ',' + r);
        oCtx.fillStyle = isPath ? 'rgba(240, 95, 159, 0.09)' : 'rgba(18, 6, 16, 0.44)';
        oCtx.fillRect(c * T_SIZE, r * T_SIZE, T_SIZE, T_SIZE);
        oCtx.strokeStyle = isPath ? 'rgba(240, 95, 159, 0.24)' : 'rgba(240, 95, 159, 0.14)';
        oCtx.lineWidth = 1;
        oCtx.strokeRect(c * T_SIZE, r * T_SIZE, T_SIZE, T_SIZE);
      }
    }

    oCtx.save();
    oCtx.strokeStyle = 'rgba(240, 95, 159, 0.44)';
    oCtx.lineWidth = 1.8;
    oCtx.lineJoin = 'round';
    oCtx.lineCap = 'round';
    traceOverdriveRails(oCtx);
    oCtx.restore();

    // 3 base portal chevrons centered inside tile (c=5, r=1)
    const offsets = [-14, 0, 14];
    for (let i = 0; i < 3; i++) {
      drawNeonChevron(oCtx, O_BASE_X + offsets[i], O_BASE_Y, 0, 12, '#f05f9f');
    }
    return off;
  }

  function advanceAlongWaypoints(e, waypoints, dt) {
    let rem = e.speed * dt;
    while (rem > 0 && e.wpIndex < waypoints.length) {
      const target = waypoints[e.wpIndex];
      const dx = target.x - e.x;
      const dy = target.y - e.y;
      const dist = Math.hypot(dx, dy);
      if (dist <= 0.001) {
        e.wpIndex++;
        continue;
      }
      e.angle = Math.atan2(dy, dx);
      if (rem >= dist) {
        e.x = target.x;
        e.y = target.y;
        rem -= dist;
        e.wpIndex++;
      } else {
        e.x += (dx / dist) * rem;
        e.y += (dy / dist) * rem;
        rem = 0;
      }
    }
  }

  function spawnNormalGrunt(initialDistOffset) {
    const cfg = (typeof ENEMY_CONFIGS !== 'undefined' && ENEMY_CONFIGS.grunt) ? ENEMY_CONFIGS.grunt : null;
    const e = {
      type: 'grunt',
      color: (cfg && cfg.color) || '#f05f9f',
      radius: 11,
      speed: 56,
      hp: 80,
      maxHp: 80,
      wpIndex: 1,
      x: N_WAYPOINTS[0].x,
      y: N_WAYPOINTS[0].y,
      angle: -Math.PI / 2,
      spawnTimer: (initialDistOffset && initialDistOffset > 0) ? 0 : 0.22,
      spawnDuration: 0.22,
      hitTilt: 0,
      _fxKbX: 0,
      _fxKbY: 0,
      _fxJitT: 0
    };
    if (initialDistOffset && initialDistOffset > 0) {
      advanceAlongWaypoints(e, N_WAYPOINTS, initialDistOffset / e.speed);
    }
    previewEnemies.push(e);
  }

  function spawnEndlessMob(distAlongCurve) {
    const types = ['grunt', 'scout', 'swarm'];
    const type = types[_endlessMobIdx % types.length];
    _endlessMobIdx++;
    const cfg = (typeof ENEMY_CONFIGS !== 'undefined' && ENEMY_CONFIGS[type]) ? ENEMY_CONFIGS[type] : null;
    const defCols = { grunt: '#f05f9f', scout: '#ff9100', swarm: '#00ffcc' };
    const defRads = { grunt: 13, scout: 12, swarm: 10 };
    const defSpds = { grunt: 84, scout: 108, swarm: 96 };
    const defHps  = { grunt: 54, scout: 38, swarm: 30 };

    const s = (distAlongCurve !== undefined) ? distAlongCurve : 0;
    const pt = sampleLemniscate(s);
    previewEnemies.push({
      type,
      color: (cfg && cfg.color) || defCols[type],
      radius: defRads[type],
      speed: defSpds[type],
      hp: defHps[type],
      maxHp: defHps[type],
      curveDist: s,
      x: pt.x,
      y: pt.y,
      angle: pt.angle,
      spawnTimer: 0.22,
      spawnDuration: 0.22,
      hitTilt: 0,
      _fxKbX: 0,
      _fxKbY: 0,
      _fxJitT: 0
    });
  }

  function spawnOverdriveTank() {
    const cfg = (typeof ENEMY_CONFIGS !== 'undefined' && ENEMY_CONFIGS.tank) ? ENEMY_CONFIGS.tank : null;
    previewEnemies = [{
      type: 'tank',
      color: (cfg && cfg.color) || '#a06fdc',
      radius: 15,
      isEnraged: true,
      speed: 64,
      hp: 260,
      maxHp: 260,
      wpIndex: 1,
      x: O_WAYPOINTS[0].x,
      y: O_WAYPOINTS[0].y,
      angle: 0,
      spawnTimer: 0.22,
      spawnDuration: 0.22,
      hitTilt: 0,
      _fxKbX: 0,
      _fxKbY: 0,
      _fxJitT: 0
    }];
  }

  function findTargetFor(tw) {
    const rSq = tw.range * tw.range;
    for (let i = 0; i < previewEnemies.length; i++) {
      const e = previewEnemies[i];
      const dx = e.x - tw.x;
      const dy = e.y - tw.y;
      if (dx * dx + dy * dy <= rSq) return e;
    }
    return null;
  }

  function stepGunTower(tw, dt) {
    const gunColor = (typeof TOWER_CONFIGS !== 'undefined' && TOWER_CONFIGS.gun && TOWER_CONFIGS.gun.color) || '#00e5ff';
    const target = findTargetFor(tw);
    if (tw.fireCooldown > 0) tw.fireCooldown = Math.max(0, tw.fireCooldown - dt);

    if (target) {
      const desired = Math.atan2(target.y - tw.y, target.x - tw.x);
      let diff = desired - tw.angle;
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
      const maxTurn = 12 * dt;
      if (Math.abs(diff) <= maxTurn) tw.angle = desired;
      else tw.angle += Math.sign(diff) * maxTurn;

      if (tw.fireCooldown <= 0 && Math.abs(diff) < 0.35) {
        tw.fireCooldown = tw.fireRate;
        tw.lastFire = _simTime;
        const cosA = Math.cos(tw.angle), sinA = Math.sin(tw.angle);
        const side = (tw.shotIndex === 0) ? -3.5 : 3.5;
        const mx = tw.x + cosA * 24 - sinA * side;
        const my = tw.y + sinA * 24 + cosA * side;
        tw.shotIndex = (tw.shotIndex + 1) % 2;

        if (typeof spawnFxMuzzleLayers === 'function') {
          spawnFxMuzzleLayers(mx, my, 'gun', gunColor, tw.angle);
        }
        previewProjectiles.push({
          x: mx, y: my, prevX: mx, prevY: my,
          target, speed: 460, damage: tw.damage, color: gunColor
        });
      }
    }
  }

  function stepTeslaTower(tw, dt) {
    const teslaColor = (typeof TOWER_CONFIGS !== 'undefined' && TOWER_CONFIGS.tesla && TOWER_CONFIGS.tesla.color) || '#00ffcc';
    if (tw.fireCooldown > 0) tw.fireCooldown = Math.max(0, tw.fireCooldown - dt);
    const first = findTargetFor(tw);
    if (!first || tw.fireCooldown > 0) return;

    tw.fireCooldown = tw.fireRate;
    tw.lastFire = _simTime;
    tw.angle = Math.atan2(first.y - tw.y, first.x - tw.x);

    const hitList = [first];
    let cur = first;
    for (let chain = 0; chain < 2; chain++) {
      let best = null, bestD = 115 * 115;
      for (let i = 0; i < previewEnemies.length; i++) {
        const cand = previewEnemies[i];
        if (hitList.indexOf(cand) !== -1) continue;
        const dx = cand.x - cur.x, dy = cand.y - cur.y;
        const dSq = dx * dx + dy * dy;
        if (dSq < bestD) { bestD = dSq; best = cand; }
      }
      if (!best) break;
      hitList.push(best);
      cur = best;
    }

    let prevX = tw.x, prevY = tw.y;
    for (let i = 0; i < hitList.length; i++) {
      const e = hitList[i];
      const ang = Math.atan2(e.y - prevY, e.x - prevX);
      previewBolts.push({ x1: prevX, y1: prevY, x2: e.x, y2: e.y, color: teslaColor, life: 0.22, maxLife: 0.22 });
      e.hp -= tw.damage;
      e.hitTilt = (Math.random() > 0.5 ? 1 : -1) * 0.14;
      e._fxJitT = 0.14;
      const killed = e.hp <= 0;
      if (typeof spawnFxHitLayers === 'function') {
        spawnFxHitLayers(e.x, e.y, killed ? 'mortar' : 'tesla', killed ? e.color : teslaColor, ang, e.radius);
      }
      if (killed) {
        const idx = previewEnemies.indexOf(e);
        if (idx !== -1) previewEnemies.splice(idx, 1);
        if (activeMode === 'endless' && previewEnemies.length < 10) {
          spawnEndlessMob((e.curveDist + E_TOTAL_LEN * 0.5) % E_TOTAL_LEN);
        }
      }
      prevX = e.x;
      prevY = e.y;
    }
  }

  function stepProjectiles(dt) {
    for (let i = previewProjectiles.length - 1; i >= 0; i--) {
      const p = previewProjectiles[i];
      p.prevX = p.x;
      p.prevY = p.y;
      if (!p.target || p.target.hp <= 0 || previewEnemies.indexOf(p.target) === -1) {
        previewProjectiles.splice(i, 1);
        continue;
      }
      const dx = p.target.x - p.x;
      const dy = p.target.y - p.y;
      const dist = Math.hypot(dx, dy);
      const stepDist = p.speed * dt;
      if (dist <= stepDist + p.target.radius * 0.7) {
        const hitAng = Math.atan2(dy, dx);
        p.target.hp -= p.damage;
        p.target.hitTilt = (Math.random() > 0.5 ? 1 : -1) * 0.14;
        p.target._fxKbX = Math.cos(hitAng) * 3.5;
        p.target._fxKbY = Math.sin(hitAng) * 3.5;
        p.target._fxJitT = 0.14;
        const killed = p.target.hp <= 0;
        if (typeof spawnFxHitLayers === 'function') {
          spawnFxHitLayers(p.target.x, p.target.y, killed ? 'mortar' : 'gun', killed ? p.target.color : p.color, hitAng, p.target.radius);
        }
        if (killed) {
          const deadDist = p.target.curveDist || 0;
          const idx = previewEnemies.indexOf(p.target);
          if (idx !== -1) previewEnemies.splice(idx, 1);
          if (activeMode === 'endless' && previewEnemies.length < 10) {
            spawnEndlessMob((deadDist + E_TOTAL_LEN * 0.5) % E_TOTAL_LEN);
          }
        }
        previewProjectiles.splice(i, 1);
      } else {
        p.x += (dx / dist) * stepDist;
        p.y += (dy / dist) * stepDist;
      }
    }
  }

  function step(dt) {
    _lastDt = dt;
    _simTime += dt;
    const kbDecay = Math.exp(-14 * dt);

    // Update lightning bolts
    for (let i = previewBolts.length - 1; i >= 0; i--) {
      previewBolts[i].life -= dt;
      if (previewBolts[i].life <= 0) previewBolts.splice(i, 1);
    }

    if (activeMode === 'normal') {
      _waveTimer -= dt;
      if (_waveTimer <= 0) {
        _waveTimer = 4.2;
        _burstRemaining = 3;
        _burstTimer = 0;
      }
      if (_burstRemaining > 0) {
        _burstTimer -= dt;
        if (_burstTimer <= 0) {
          spawnNormalGrunt(0);
          _burstRemaining--;
          _burstTimer = 0.65;
        }
      }
      for (let i = previewEnemies.length - 1; i >= 0; i--) {
        const e = previewEnemies[i];
        if (e.spawnTimer > 0) e.spawnTimer = Math.max(0, e.spawnTimer - dt);
        advanceAlongWaypoints(e, N_WAYPOINTS, dt);
        if (e._fxJitT > 0) e._fxJitT = Math.max(0, e._fxJitT - dt);
        e.hitTilt *= kbDecay;
        e._fxKbX *= kbDecay;
        e._fxKbY *= kbDecay;
        if (e.wpIndex >= N_WAYPOINTS.length) previewEnemies.splice(i, 1);
      }
      stepGunTower(normalTower, dt);
      stepProjectiles(dt);

    } else if (activeMode === 'endless') {
      _endlessSpawnTimer -= dt;
      if (_endlessSpawnTimer <= 0) {
        _endlessSpawnTimer = 0.75;
        if (previewEnemies.length < 16) {
          spawnEndlessMob(0);
        }
      }
      for (let i = 0; i < previewEnemies.length; i++) {
        const e = previewEnemies[i];
        if (e.spawnTimer > 0) e.spawnTimer = Math.max(0, e.spawnTimer - dt);
        e.curveDist = (e.curveDist + e.speed * dt) % E_TOTAL_LEN;
        const pt = sampleLemniscate(e.curveDist);
        e.x = pt.x;
        e.y = pt.y;
        e.angle = pt.angle;
        if (e._fxJitT > 0) e._fxJitT = Math.max(0, e._fxJitT - dt);
        e.hitTilt *= kbDecay;
        e._fxKbX *= kbDecay;
        e._fxKbY *= kbDecay;
      }
      stepGunTower(endlessTowers[0], dt);
      stepTeslaTower(endlessTowers[1], dt);
      stepProjectiles(dt);

    } else if (activeMode === 'overdrive') {
      if (_odFlashTimer > 0) {
        _odFlashTimer -= dt;
        if (_odFlashTimer <= 0) {
          const tint = document.getElementById('modePreviewTint');
          if (tint) tint.classList.remove('breach-flash');
        }
      }

      if (_odBreached) {
        _odBreachTimer -= dt;
        if (_odBreachTimer <= 0) {
          _odBreached = false;
          odTower.angle = Math.PI;
          odTower.fireCooldown = 0.15;
          spawnOverdriveTank();
        }
      } else {
        for (let i = previewEnemies.length - 1; i >= 0; i--) {
          const e = previewEnemies[i];
          if (e.spawnTimer > 0) e.spawnTimer = Math.max(0, e.spawnTimer - dt);
          advanceAlongWaypoints(e, O_WAYPOINTS, dt);
          if (e._fxJitT > 0) e._fxJitT = Math.max(0, e._fxJitT - dt);
          e.hitTilt *= kbDecay;
          e._fxKbX *= kbDecay;
          e._fxKbY *= kbDecay;
          if (e.wpIndex >= O_WAYPOINTS.length) {
            // Breach!
            if (typeof spawnEnemyBaseHitFx === 'function') {
              spawnEnemyBaseHitFx(O_BASE_X, O_BASE_Y, e);
            }
            previewEnemies.splice(i, 1);
            _odBreached = true;
            _odBreachTimer = 1.5;
            _odFlashTimer = 0.45;
            const tint = document.getElementById('modePreviewTint');
            if (tint) tint.classList.add('breach-flash');
          }
        }
        stepGunTower(odTower, dt);
      }
      stepProjectiles(dt);
    }
  }

  function renderOverdriveBaseShield(pCtx) {
    // Centered cleanly inside tile (c=6, r=1), strictly to the right of the portal chevrons in (c=5, r=1)
    const bx = 6.5 * T_SIZE;
    const by = O_BASE_Y;
    pCtx.save();
    if (_odBreached) {
      const pulse = 0.5 + 0.5 * Math.sin(_simTime * 14);
      const ringR = 24 + (1 - Math.max(0, _odBreachTimer / 1.5)) * 22;
      pCtx.beginPath();
      pCtx.arc(O_BASE_X, O_BASE_Y, ringR, 0, Math.PI * 2);
      pCtx.strokeStyle = `rgba(240, 95, 159, ${(0.85 * Math.max(0, _odBreachTimer / 1.5)).toFixed(2)})`;
      pCtx.lineWidth = 3;
      pCtx.stroke();

      pCtx.fillStyle = `rgba(240, 40, 90, ${(0.22 + 0.16 * pulse).toFixed(2)})`;
      pCtx.strokeStyle = '#ff2a85';
    } else {
      pCtx.fillStyle = 'rgba(240, 95, 159, 0.16)';
      pCtx.strokeStyle = '#f05f9f';
    }
    pCtx.lineWidth = 2;
    pCtx.beginPath();
    pCtx.roundRect ? pCtx.roundRect(bx - 28, by - 18, 56, 36, 10) : pCtx.rect(bx - 28, by - 18, 56, 36);
    pCtx.fill();
    pCtx.stroke();

    pCtx.fillStyle = _odBreached ? '#ff7aa8' : '#ffffff';
    pCtx.font = '800 16px Inter, sans-serif';
    pCtx.textAlign = 'center';
    pCtx.textBaseline = 'middle';
    pCtx.fillText(_odBreached ? '0 💔' : '1 ❤️', bx, by + 1);
    pCtx.restore();
  }

  function render(now) {
    const pCanvas = document.getElementById('modePreviewCanvas');
    if (!pCanvas) return;
    const rect = pCanvas.getBoundingClientRect();
    if (rect.width < 10 || rect.height < 10) return;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const pw = Math.round(rect.width * dpr);
    const ph = Math.round(rect.height * dpr);
    if (pCanvas.width !== pw || pCanvas.height !== ph) {
      pCanvas.width = pw;
      pCanvas.height = ph;
    }

    const pCtx = pCanvas.getContext('2d');
    const th = (typeof getTheme === 'function') ? getTheme() : { id: 'default', c1: '#00e5ff', rgb1: { cssRgb: '0, 229, 255' } };
    const palKey = th.id || 'default';
    const c1Rgb = th.rgb1 ? th.rgb1.cssRgb : '0, 229, 255';

    let viewXMin = 0, viewYMin = 0, viewW = E_VIEW_W, viewH = E_VIEW_H;
    let gridCache = null;

    if (activeMode === 'normal') {
      viewXMin = N_VIEW_X_MIN; viewYMin = N_VIEW_Y_MIN; viewW = N_VIEW_W; viewH = N_VIEW_H;
      if (!_gridCaches.normal || _gridCacheKeys.normal !== palKey) {
        _gridCaches.normal = buildNormalGridCache(th);
        _gridCacheKeys.normal = palKey;
      }
      gridCache = _gridCaches.normal;
    } else if (activeMode === 'endless') {
      viewXMin = 0; viewYMin = 0; viewW = E_VIEW_W; viewH = E_VIEW_H;
      if (!_gridCaches.endless) _gridCaches.endless = buildEndlessGridCache();
      gridCache = _gridCaches.endless;
    } else {
      viewXMin = 0; viewYMin = 0; viewW = O_VIEW_W; viewH = O_VIEW_H;
      if (!_gridCaches.overdrive) _gridCaches.overdrive = buildOverdriveGridCache();
      gridCache = _gridCaches.overdrive;
    }

    const previewScale = (activeMode === 'endless') ? Math.min(rect.width / (viewW + 24), rect.height / (viewH + 16)) : Math.max(rect.width / viewW, rect.height / viewH);
    const offsetX = (rect.width - viewW * previewScale) * 0.5 - viewXMin * previewScale;
    const offsetY = (rect.height - viewH * previewScale) * 0.5 - viewYMin * previewScale;

    pCtx.save();
    pCtx.scale(dpr, dpr);
    pCtx.clearRect(0, 0, rect.width, rect.height);
    pCtx.translate(offsetX, offsetY);
    pCtx.scale(previewScale, previewScale);

    // 1. Baked grid & track
    pCtx.drawImage(gridCache, 0, 0);

    // Animated dashed rails per mode
    pCtx.save();
    pCtx.lineCap = 'round';
    pCtx.lineJoin = 'round';
    if (activeMode === 'normal') {
      pCtx.strokeStyle = `rgba(${c1Rgb}, 0.85)`;
      pCtx.lineWidth = 1.8;
      pCtx.setLineDash([12, 10]);
      pCtx.lineDashOffset = -(_simTime * 36);
      traceNormalRails(pCtx);
    } else if (activeMode === 'endless') {
      pCtx.lineWidth = 2.6;
      pCtx.setLineDash([16, 14]);
      pCtx.strokeStyle = 'rgba(217, 70, 239, 0.85)';
      pCtx.lineDashOffset = -(_simTime * 48);
      traceEndlessRails(pCtx);

      pCtx.strokeStyle = 'rgba(0, 229, 255, 0.55)';
      pCtx.lineDashOffset = (_simTime * 48);
      traceEndlessRails(pCtx);
    } else {
      pCtx.strokeStyle = 'rgba(240, 95, 159, 0.85)';
      pCtx.lineWidth = 1.8;
      pCtx.setLineDash([12, 10]);
      pCtx.lineDashOffset = -(_simTime * 44);
      traceOverdriveRails(pCtx);
    }
    pCtx.restore();

    if (activeMode === 'overdrive') {
      renderOverdriveBaseShield(pCtx);
    }

    const towersToDraw = (activeMode === 'normal') ? [normalTower]
      : (activeMode === 'endless' ? endlessTowers : [odTower]);

    // Subtle range circles
    pCtx.save();
    pCtx.lineWidth = 1.2;
    pCtx.strokeStyle = (activeMode === 'endless') ? 'rgba(217, 70, 239, 0.16)'
      : (activeMode === 'overdrive' ? 'rgba(240, 95, 159, 0.16)' : `rgba(${c1Rgb}, 0.14)`);
    for (let i = 0; i < towersToDraw.length; i++) {
      const tw = towersToDraw[i];
      pCtx.beginPath();
      pCtx.arc(tw.x, tw.y, tw.range, 0, Math.PI * 2);
      pCtx.stroke();
    }
    pCtx.restore();

    // 2 & 3. Render towers, enemies, lightning bolts & combat FX via temporary ctx/camZoom swap
    const prevCtx = ctx;
    const prevZoom = (typeof camZoom !== 'undefined') ? camZoom : 1;
    try {
      ctx = pCtx;
      if (typeof camZoom !== 'undefined') camZoom = previewScale;

      if (typeof drawTowerModel === 'function') {
        for (let i = 0; i < towersToDraw.length; i++) {
          const tw = towersToDraw[i];
          const tCfg = (typeof TOWER_CONFIGS !== 'undefined' && TOWER_CONFIGS[tw.type]) ? TOWER_CONFIGS[tw.type] : null;
          const col = (tCfg && tCfg.color) || (tw.type === 'tesla' ? '#00ffcc' : '#00e5ff');
          const glow = (tCfg && tCfg.glow) || col;
          const target = findTargetFor(tw);
          const isTeslaShooting = (tw.type === 'tesla' && previewBolts.length > 0);
          pCtx.save();
          pCtx.translate(tw.x, tw.y);
          drawTowerModel(tw.type, tw.angle, col, 1, glow, false, false, isTeslaShooting, 0, {
            x: tw.x, y: tw.y, target, time: _simTime, lastFire: tw.lastFire, shotIndex: tw.shotIndex
          });
          pCtx.restore();
        }
      }

      for (let i = 0; i < previewEnemies.length; i++) {
        const e = previewEnemies[i];
        const jitX = e._fxJitT > 0 ? (Math.sin(_simTime * 80 + i) * 1.4) : 0;
        const jitY = e._fxJitT > 0 ? (Math.cos(_simTime * 75 + i) * 1.4) : 0;
        const renderEnemy = Object.assign({}, e, {
          x: e.x + (e._fxKbX || 0) + jitX,
          y: e.y + (e._fxKbY || 0) + jitY
        });
        if (typeof renderConfiguredEnemyModel === 'function') {
          renderConfiguredEnemyModel(renderEnemy, false);
        } else {
          pCtx.beginPath();
          pCtx.arc(renderEnemy.x, renderEnemy.y, renderEnemy.radius, 0, Math.PI * 2);
          pCtx.fillStyle = renderEnemy.color;
          pCtx.fill();
        }
      }

      if (typeof drawJaggedLightning === 'function') {
        for (let i = 0; i < previewBolts.length; i++) {
          const b = previewBolts[i];
          const a = Math.max(0, b.life / b.maxLife);
          drawJaggedLightning(b.x1, b.y1, b.x2, b.y2, b.color, a, 1.0);
        }
      }

      if (typeof updateAndDrawFxLayers === 'function') {
        updateAndDrawFxLayers(_lastDt, _simTime);
      }
    } finally {
      ctx = prevCtx;
      if (typeof camZoom !== 'undefined') camZoom = prevZoom;
    }

    // 4. Bullets with gradient tracers
    pCtx.save();
    pCtx.globalCompositeOperation = 'lighter';
    for (let i = 0; i < previewProjectiles.length; i++) {
      const p = previewProjectiles[i];
      const ang = Math.atan2(p.y - p.prevY, p.x - p.prevX);
      const tailX = p.x - Math.cos(ang) * 16;
      const tailY = p.y - Math.sin(ang) * 16;
      const tg = pCtx.createLinearGradient(tailX, tailY, p.x, p.y);
      tg.addColorStop(0, 'rgba(0, 229, 255, 0)');
      tg.addColorStop(1, p.color);
      pCtx.strokeStyle = tg;
      pCtx.lineWidth = 3;
      pCtx.lineCap = 'round';
      pCtx.beginPath();
      pCtx.moveTo(tailX, tailY);
      pCtx.lineTo(p.x, p.y);
      pCtx.stroke();

      pCtx.fillStyle = '#ffffff';
      pCtx.beginPath();
      pCtx.arc(p.x, p.y, 2.2, 0, Math.PI * 2);
      pCtx.fill();
    }
    pCtx.restore();
    pCtx.restore();
  }

  function tick(now) {
    const lvlSc = document.getElementById('levelsScreen');
    if (!lvlSc || lvlSc.classList.contains('hidden') || (typeof gameState !== 'undefined' && gameState === 'PLAYING')) {
      stop();
      return;
    }
    if (!_lastTs) _lastTs = now;
    const dt = Math.min(0.05, Math.max(0.001, (now - _lastTs) / 1000));
    _lastTs = now;
    try {
      step(dt);
      render(now);
    } catch (_e) {}
    _rafId = requestAnimationFrame(tick);
  }

  function isActive() {
    return _rafId !== null;
  }

  function initScenario(mode) {
    previewEnemies = [];
    previewProjectiles = [];
    previewBolts = [];
    if (typeof clearFxLayerState === 'function') clearFxLayerState();
    const tint = document.getElementById('modePreviewTint');
    if (tint) tint.classList.remove('breach-flash');

    _lastTs = 0;
    _lastDt = 0.016;
    _simTime = 0;

    if (mode === 'normal') {
      _waveTimer = 2.4;
      _burstRemaining = 0;
      _burstTimer = 0;
      normalTower.angle = -Math.PI / 2;
      normalTower.fireCooldown = 0.1;
      normalTower.lastFire = -10;
      normalTower.shotIndex = 0;
      spawnNormalGrunt(240);
      spawnNormalGrunt(200);
      spawnNormalGrunt(160);
    } else if (mode === 'endless') {
      _endlessSpawnTimer = 0.75;
      _endlessMobIdx = 0;
      endlessTowers[0].angle = 0;
      endlessTowers[0].fireCooldown = 0.15;
      endlessTowers[0].lastFire = -10;
      endlessTowers[1].angle = Math.PI;
      endlessTowers[1].fireCooldown = 0.30;
      endlessTowers[1].lastFire = -10;
      for (let i = 0; i < 14; i++) {
        spawnEndlessMob((i / 14) * E_TOTAL_LEN);
      }
    } else if (mode === 'overdrive') {
      _odBreached = false;
      _odBreachTimer = 0;
      _odFlashTimer = 0;
      odTower.angle = Math.PI;
      odTower.fireCooldown = 0.15;
      odTower.lastFire = -10;
      odTower.shotIndex = 0;
      spawnOverdriveTank();
    }
  }

  function start(mode) {
    const targetMode = (mode === 'endless' || mode === 'overdrive') ? mode : 'normal';
    if (_rafId !== null && activeMode === targetMode) return;
    activeMode = targetMode;
    initScenario(activeMode);
    if (_rafId === null) {
      _rafId = requestAnimationFrame(tick);
    }
  }

  function stop() {
    if (_rafId !== null) {
      cancelAnimationFrame(_rafId);
      _rafId = null;
    }
    previewEnemies = [];
    previewProjectiles = [];
    previewBolts = [];
    if (typeof clearFxLayerState === 'function') clearFxLayerState();
    const tint = document.getElementById('modePreviewTint');
    if (tint) tint.classList.remove('breach-flash');
  }

  return { start, stop, isActive };
})();

function startModeBattlePreview(mode) { ModeBattlePreview.start(mode); }
function stopModeBattlePreview() { ModeBattlePreview.stop(); }
function startNormalModePreview() { ModeBattlePreview.start('normal'); }
function stopNormalModePreview() { ModeBattlePreview.stop(); }

// [UI.CG]
function updateModeSwitcherUI() {
  const tabNormal = document.getElementById('tabNormal');
  const tabOverdrive = document.getElementById('tabOverdrive');
  const tabEndless = document.getElementById('tabEndless');
  const levelsScreen = document.getElementById('levelsScreen');

  const odUnlocked = (typeof isOverdriveUnlocked === 'function')
    ? isOverdriveUnlocked()
    : ((typeof window !== 'undefined' && typeof window.isOverdriveUnlocked === 'function') ? window.isOverdriveUnlocked() : false);

  const endlessUnlocked = (typeof isEndlessUnlocked === 'function')
    ? isEndlessUnlocked()
    : ((typeof window !== 'undefined' && typeof window.isEndlessUnlocked === 'function') ? window.isEndlessUnlocked() : false);

  if (tabNormal) tabNormal.classList.toggle('active', currentLevelMode === 'normal');
  if (tabOverdrive) {
    tabOverdrive.classList.toggle('active', currentLevelMode === 'overdrive');
    tabOverdrive.classList.toggle('locked', !odUnlocked);
  }
  if (tabEndless) {
    tabEndless.classList.toggle('active', currentLevelMode === 'endless');
    tabEndless.classList.toggle('locked', !endlessUnlocked);
  }

  if (levelsScreen) {
    levelsScreen.classList.toggle('mode-normal-active', currentLevelMode === 'normal');
    levelsScreen.classList.toggle('mode-overdrive-active', currentLevelMode === 'overdrive');
    levelsScreen.classList.toggle('mode-endless-active', currentLevelMode === 'endless');
  }

  const campaignView = document.getElementById('levelsCampaignView');
  const endlessView = document.getElementById('endlessDashboardView');
  const swipeHint = document.getElementById('chapterSwipeHint');

  if (currentLevelMode === 'endless') {
    if (campaignView) campaignView.classList.add('hidden');
    if (endlessView) {
      endlessView.classList.remove('hidden');
      if (swipeHint) {
        const endlessNav = document.querySelector('.endless-part-nav');
        if (endlessNav) endlessNav.after(swipeHint);
      }
    }
    if (typeof renderEndlessDashboardUI === 'function') renderEndlessDashboardUI();
  } else {
    if (campaignView) {
      campaignView.classList.remove('hidden');
      if (swipeHint) {
        const normalNav = document.querySelector('.level-part-navigator:not(.endless-part-nav)');
        if (normalNav) normalNav.after(swipeHint);
      }
    }
    if (endlessView) endlessView.classList.add('hidden');
  }

  const svgSlot = document.getElementById('modeArtSvgSlot');
  const previewStage = document.getElementById('modePreviewStage');
  const previewTint = document.getElementById('modePreviewTint');

  if (svgSlot) svgSlot.classList.add('hidden');
  if (previewStage) previewStage.classList.remove('hidden');
  if (previewTint) previewTint.classList.remove('breach-flash');
  startModeBattlePreview(currentLevelMode);

  const rulesBanner = document.getElementById('modeRulesBanner');
  if (rulesBanner) {
    if (currentLevelMode === 'overdrive') {
      rulesBanner.className = 'mode-rules-banner hardcore-rules';
      const hpHeartSvg = `<span style="display:inline-flex; align-items:center; vertical-align:middle; filter:drop-shadow(0 0 5px rgba(240,95,159,0.8)); margin:0 2px;"><svg width="13" height="12" viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" fill="#f05f9f"/></svg></span>`;
      const ruleText = (typeof t === 'function') ? t('rules_hardcore') : '1 {heart} BASE — 1.2 SPEED & ENRAGED MOBS';
      rulesBanner.innerHTML = ruleText.replace('{heart}', hpHeartSvg);
    } else if (currentLevelMode === 'endless') {
      rulesBanner.className = 'mode-rules-banner endless-rules';
      const prismIcon = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#d946ef" stroke-width="2.2" stroke-linejoin="round" style="vertical-align: middle; display: inline-block; margin: 0 1px 2px 2px;"><polygon points="12 2 21 12 12 22 3 12" fill="rgba(217,70,239,.25)"/><polyline points="3 12 12 15 21 12"/><line x1="12" y1="2" x2="12" y2="22"/></svg>`;
      const diamondIcon = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#00e5ff" stroke-width="2.2" stroke-linejoin="round" style="vertical-align: middle; display: inline-block; margin: 0 1px 2px 1px;"><polygon points="6 3 18 3 22 9 12 22 2 9" fill="rgba(0,229,255,.25)"/><polyline points="2 9 12 13 22 9"/><line x1="12" y1="22" x2="12" y2="13"/></svg>`;
      const ruleText = (typeof t === 'function') ? t('rules_endless') : 'Infinite Loop • Earn {prism} Prisms & {diamond} Diamonds';
      rulesBanner.innerHTML = ruleText.replace('{prism}', prismIcon).replace('{diamond}', diamondIcon);
    } else {
      rulesBanner.className = 'mode-rules-banner normal-rules';
      const diamondIcon = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#00e5ff" stroke-width="2.2" stroke-linejoin="round" style="vertical-align: middle; display: inline-block; margin: 0 1px 2px 1px;"><polygon points="6 3 18 3 22 9 12 22 2 9" fill="rgba(0,229,255,.25)"/><polyline points="2 9 12 13 22 9"/><line x1="12" y1="22" x2="12" y2="13"/></svg>`;
      const ruleText = (typeof t === 'function') ? t('rules_normal') : 'Standard TD Rules • Earn {diamond} Diamonds';
      rulesBanner.innerHTML = ruleText.replace('{diamond}', diamondIcon);
    }
  }
}

// [UI.CH]
function renderEndlessDashboardUI() {
  const valEl = document.getElementById('endlessRecordVal');
  const mapEl = document.getElementById('endlessMapText');
  const ticketEl = document.getElementById('endlessDeployTicketText');
  const fillEl = document.getElementById('highwayTrackFill');
  const thumbEl = document.getElementById('highwayThumbPin');
  const startEl = document.getElementById('highwayStartLabel');
  const currEl = document.getElementById('highwayCurrLabel');
  const endEl = document.getElementById('highwayEndLabel');
  const rewardEl = document.getElementById('highwayRewardBadge');

  const sec = currentLevelSection || 1;
  const bestWave = (typeof endlessBestWavesBySection !== 'undefined' && endlessBestWavesBySection[sec]) 
    ? endlessBestWavesBySection[sec] 
    : 0;
  if (valEl) valEl.textContent = typeof t === 'function' ? t('best_wave_n', { n: bestWave }) : `BEST : WAVE ${bestWave}`;

  const startWave = bestWave > 0 ? Math.floor(Math.max(0, bestWave - 1) / 10) * 10 + 1 : 1;
  const endWave = startWave + 9;
  const pct = bestWave >= startWave ? Math.min(100, Math.max(0, ((bestWave - startWave + 1) / 10) * 100)) : 0;

  if (startEl) startEl.textContent = startWave;
  if (currEl) currEl.textContent = `W${bestWave}`;
  if (endEl) endEl.textContent = endWave;

  if (fillEl) fillEl.style.width = `${pct}%`;
  if (thumbEl) thumbEl.style.left = `${pct}%`;

  if (rewardEl) {
    const prismReward = (endWave % 50 === 0) ? '+5' : '+1';
    rewardEl.innerHTML = `
      <span class="reward-val">${prismReward}</span>
      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#d946ef" stroke-width="2" stroke-linejoin="round">
        <polygon points="12 2 21 12 12 22 3 12" fill="rgba(217,70,239,.4)"/>
      </svg>
    `;
  }

  if (mapEl) mapEl.textContent = typeof t === 'function' ? t('chapter_n', { n: currentLevelSection }) : `CHAPTER ${currentLevelSection}`;

  const prevBtn = document.getElementById('endlessNavPrev');
  const nextBtn = document.getElementById('endlessNavNext');
  
  if (prevBtn) {
    prevBtn.disabled = currentLevelSection <= 1;
  }
  if (nextBtn) {
    const nextSecUnlocked = (typeof devMode !== 'undefined' && devMode) || maxUnlockedLevel > currentLevelSection * LEVELS_PER_SECTION;
    nextBtn.disabled = currentLevelSection >= (typeof TOTAL_SECTIONS !== 'undefined' ? TOTAL_SECTIONS : 5) || !nextSecUnlocked;
  }

  if (ticketEl) {
    const status = (typeof getEndlessEntryStatus === 'function') ? getEndlessEntryStatus() : { type: 'free', text: 'FREE (1/1)' };
    const labelText = status.type === 'free'
      ? (typeof t === 'function' ? t('free_ticket', { cur: 1, max: 1 }) : 'FREE (1/1)')
      : (status.type === 'ad'
          ? (typeof t === 'function' ? t('watch_ad_ticket', { cur: 2, max: 2 }) : 'WATCH AD (2/2)')
          : (status.text || status.label || '').toUpperCase());

    if (status.type === 'ad') {
      const adIconSvg = `<svg width="15" height="12" viewBox="0 0 16 13" fill="none" style="flex:none; margin-right:5px; vertical-align:middle;"><rect x="0.8" y="0.8" width="14.4" height="11.4" rx="2.5" fill="none" stroke="currentColor" stroke-width="1.6"/><polygon points="6,3.5 11,6.5 6,9.5" fill="currentColor"/></svg>`;
      ticketEl.innerHTML = `<span style="display:inline-flex; align-items:center; justify-content:center; white-space:nowrap;">${adIconSvg}${labelText}</span>`;
    } else if (status.type === 'diamonds') {
      const diamondIconSvg = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#00e5ff" stroke-width="2.2" stroke-linejoin="round" style="flex:none; margin-left:5px; vertical-align:middle; filter:drop-shadow(0 0 4px rgba(0,229,255,0.6));"><polygon points="6 3 18 3 22 9 12 22 2 9" fill="rgba(0,229,255,.28)"/><polyline points="2 9 12 13 22 9"/><line x1="12" y1="22" x2="12" y2="13"/></svg>`;
      const cost = status.cost || 15;
      ticketEl.innerHTML = `<span style="display:inline-flex; align-items:center; justify-content:center; width:100%;">${cost}${diamondIconSvg}</span>`;
    } else {
      ticketEl.textContent = labelText;
    }
  }

  const swipeHint = document.getElementById('chapterSwipeHint');
  if (swipeHint && typeof currentLevelMode !== 'undefined' && currentLevelMode === 'endless') {
    const canSwipe = (maxUnlockedLevel > 15 || devMode) && typeof TOTAL_SECTIONS !== 'undefined' && TOTAL_SECTIONS > 1;
    swipeHint.classList.toggle('hidden', !canSwipe);
  }
}

// [UI.CI]
function navEndlessLevel(dir) {
  const target = currentLevelSection + dir;
  if (target < 1 || (typeof TOTAL_SECTIONS !== 'undefined' && target > TOTAL_SECTIONS)) return;
  
  const isTargetUnlocked = (typeof devMode !== 'undefined' && devMode) || maxUnlockedLevel > (target - 1) * LEVELS_PER_SECTION;
  if (!isTargetUnlocked) {
    if (typeof showHintToast === 'function') {
      showHintToast(typeof t === 'function' ? t('chapter_locked') : 'Chapter locked!');
    }
    return;
  }
  
  currentLevelSection = target;
  if (typeof sfx === 'function') sfx('click');
  renderEndlessDashboardUI();
}

// [UI.CJ]
function confirmStartEndlessRun() {
  if (!isEndlessUnlocked()) {
    if (typeof showHintToast === 'function') {
      showHintToast(typeof t === 'function' ? t('unlock_endless_hint') : 'Complete Normal Level 15 to unlock Endless Arena');
    }
    return;
  }

  if (!selectedLoadout || selectedLoadout.length === 0) {
    if (typeof showHintToast === 'function') {
      showHintToast(typeof t === 'function' ? t('select_at_least_1_tower') : 'Select at least 1 tower!');
    }
    return;
  }

  const status = (typeof getEndlessEntryStatus === 'function') ? getEndlessEntryStatus() : { type: 'free', cost: 0 };

  // [UI.CK]
  const launch = () => {
    endlessDailyRunsUsed++;
    if (typeof saveGame === 'function') saveGame();
    if (typeof startEndlessMatch === 'function') startEndlessMatch();
  };

  if (status.type === 'free') {
    launch();
  } else if (status.type === 'ad') {
    if (typeof showAdPlaceholder === 'function') {
      showAdPlaceholder(launch, null);
    } else {
      launch();
    }
  } else if (status.type === 'diamonds') {
    if (diamonds < status.cost) {
      if (typeof showHintToast === 'function') {
        showHintToast(typeof t === 'function' ? t('need_diamonds_for_entry', { cost: status.cost }) : `Need ${status.cost} Diamonds for entry!`);
      }
      return;
    }
    diamonds -= status.cost;
    if (typeof updateDiamondUI === 'function') updateDiamondUI();
    launch();
  } else {
    launch();
  }
}
window.confirmStartEndlessRun = confirmStartEndlessRun;

if (typeof getEndlessEntryStatus !== 'undefined') {
  window.getEndlessEntryStatus = getEndlessEntryStatus;
}

// [UI.CL]
function renderLevelsGrid() {
  updateModeSwitcherUI();
  const levelsGrid = document.getElementById('levelsGrid');
  if (!levelsGrid) return;
  levelsGrid.innerHTML = '';

  const partLabel = document.getElementById('partNavLabel');
  const prevBtn = document.getElementById('partNavPrev');
  const nextBtn = document.getElementById('partNavNext');
  
  let nextSecUnlocked = false;
  if (devMode) {
      nextSecUnlocked = true;
  } else if (currentLevelMode === 'overdrive') {
      const reqLvl = currentLevelSection * LEVELS_PER_SECTION;
      nextSecUnlocked = !!overdriveClearedLevels[reqLvl];
  } else {
      nextSecUnlocked = maxUnlockedLevel > currentLevelSection * LEVELS_PER_SECTION;
  }

  if (partLabel) partLabel.textContent = typeof t === 'function' ? t('chapter_n', { n: currentLevelSection }) : `CHAPTER ${currentLevelSection}`;

  if (prevBtn) {
    const canGoPrev = currentLevelSection > 1;
    prevBtn.disabled = !canGoPrev;
  }
  if (nextBtn) {
    const canGoNext = currentLevelSection < TOTAL_SECTIONS && nextSecUnlocked;
    nextBtn.disabled = !canGoNext;
  }

  const swipeHint = document.getElementById('chapterSwipeHint');
  const canSwipe = (maxUnlockedLevel >= 11 || devMode) && typeof TOTAL_SECTIONS !== 'undefined' && TOTAL_SECTIONS > 1;
  if (swipeHint && currentLevelMode !== 'endless') {
    swipeHint.classList.toggle('hidden', !canSwipe);
  }

  const startLvl = (currentLevelSection - 1) * LEVELS_PER_SECTION + 1;
  const endLvl = currentLevelSection * LEVELS_PER_SECTION;

  for (let lvl = startLvl; lvl <= endLvl; lvl++) {
    const btn = document.createElement('button');

    if (currentLevelMode !== 'overdrive') {
      const isUnlocked = devMode || lvl <= maxUnlockedLevel;
      const earnedStars = levelStars[lvl] || 0;
      const isCleared = clearedLevels.includes(lvl) || earnedStars > 0;
      const isCurrent = lvl === maxUnlockedLevel && !isCleared;

      if (isUnlocked) {
        btn.className = 'level-card-btn' + (isCurrent ? ' current' : (isCleared ? ' cleared' : ''));
        btn.innerHTML = `
          <span class="level-num">${lvl}</span>
          <div class="level-card-stars">
            <span class="mini-star ${earnedStars >= 1 ? 'filled' : 'empty'}">★</span>
            <span class="mini-star ${earnedStars >= 2 ? 'filled' : 'empty'}">★</span>
            <span class="mini-star ${earnedStars >= 3 ? 'filled' : 'empty'}">★</span>
          </div>
        `;
        btn.onclick = () => startSpecificLevel(lvl);
      } else {
        btn.className = 'level-card-btn locked';
        btn.disabled = true;
        btn.innerHTML = `
          <svg width="20" height="20" viewBox="0 0 24 24" stroke="#475569" stroke-width="1.6" fill="none" stroke-linecap="round" stroke-linejoin="round">
            <path d="M 7,10 V 6 C 7,3.5 9,2 12,2 C 15,2 17,3.5 17,6 V 10" />
            <rect x="4" y="10" width="16" height="12" rx="3" fill="#080e1a" />
          </svg>
        `;
      }
    } else {
      const isOdCleared = !!overdriveClearedLevels[lvl];
      const isUnlockedInHC = devMode || isOdCleared || (lvl === 1) || !!overdriveClearedLevels[lvl - 1];
      const isCurrentOd = isUnlockedInHC && !isOdCleared;

      if (isUnlockedInHC) {
        btn.className = 'level-card-btn' + (isCurrentOd ? ' current' : (isOdCleared ? ' cleared' : ''));
        if (isOdCleared) {
          btn.innerHTML = `
            <span class="level-num">${lvl}</span>
            <div class="level-card-overdrive-badge filled" title="Hardcore Cleared">
              <span class="od-reward-tag" style="color:#ffd1f4;">+3</span>
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#d946ef" stroke-width="2" stroke-linejoin="round"><polygon points="12 2 21 12 12 22 3 12" fill="rgba(217,70,239,.4)"/></svg>
            </div>
          `;
        } else {
          btn.innerHTML = `
            <span class="level-num">${lvl}</span>
            <div class="level-card-overdrive-badge empty">
              <span class="od-reward-tag" style="color:#ffb3ea;">+3</span>
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#475569" stroke-width="1.8" stroke-linejoin="round"><polygon points="12 2 21 12 12 22 3 12" fill="#1a061c"/></svg>
            </div>
          `;
        }
        btn.onclick = () => startSpecificLevel(lvl);
      } else {
        btn.className = 'level-card-btn locked';
        btn.disabled = true;
        btn.innerHTML = `
          <svg width="20" height="20" viewBox="0 0 24 24" stroke="#52274b" stroke-width="1.6" fill="none" stroke-linecap="round" stroke-linejoin="round">
            <path d="M 7,10 V 6 C 7,3.5 9,2 12,2 C 15,2 17,3.5 17,6 V 10" />
            <rect x="4" y="10" width="16" height="12" rx="3" fill="#120412" />
          </svg>
        `;
      }
    }
    levelsGrid.appendChild(btn);
  }
}

let isDevModeActive = false;
let isDevExpanded = false;

// Developer mode panel interface and visibility control.
// [UI.CM]
function devJumpToWave(targetWave) {
  const lvlConfig = LEVELS_DATA[currentLevel];
  const maxW = lvlConfig ? lvlConfig.totalWaves : 10;
  if (!isEndlessMode && (targetWave < 1 || targetWave > maxW)) return;
  if (isEndlessMode && targetWave < 1) return;

  enemies = [];
  projectiles = [];
  spawnQueue = [];
  waveInProgress = false;
  waveTimerActive = false;
  autoWaveTimeRemaining = 0;
  wave = targetWave;
  startWave();
}

const DEV_SPEED_STEPS = [0.5, 0.75, 0.9, 1, 1.25, 1.5, 2, 4, 8];

//  Time modulation speed levels and HUD controls.
// [UI.DA]
function getHudAllowedSpeeds() {
  const tier = typeof timeModTier !== 'undefined' ? timeModTier : 0;
  if (tier >= 2) {
    return [0.5, 0.75, 0.9, 1.0, 1.25, 1.5, 2.0];
  } else if (tier >= 1) {
    return [0.9, 1.0, 1.25];
  }
  return [1.0];
}

// [UI.DB]
function updateHudSpeedWidget() {
  const widget = document.getElementById('hudSpeedWidget');
  if (!widget) return;

  const isCombatPause = (gameState === 'PAUSED' && (typeof settingsPreviousSource === 'undefined' || settingsPreviousSource === 'combat' || settingsPreviousSource === 'pause'));
  const isBattle = (gameState === 'PLAYING' || isCombatPause);

  const showWidget = isBattle && ((typeof timeModTier !== 'undefined' && timeModTier > 0) || devMode);
  widget.classList.toggle('hidden', !showWidget);

  if (!showWidget) return;

  const curSpeed = typeof gameTimeScale !== 'undefined' ? gameTimeScale : 1.0;
  const valEl = document.getElementById('hudSpeedVal');
  if (valEl) {
    valEl.textContent = `${curSpeed}x`;
  }

  const allowed = devMode ? DEV_SPEED_STEPS : getHudAllowedSpeeds();
  let curIdx = allowed.indexOf(curSpeed);
  if (curIdx === -1) {
    curIdx = allowed.reduce((closest, val, idx) =>
      Math.abs(val - curSpeed) < Math.abs(allowed[closest] - curSpeed) ? idx : closest, 0);
  }

  const fasterBtn = document.getElementById('hudSpeedFasterBtn');
  const slowerBtn = document.getElementById('hudSpeedSlowerBtn');

  if (fasterBtn) {
    fasterBtn.disabled = curIdx >= allowed.length - 1;
    fasterBtn.classList.toggle('disabled', curIdx >= allowed.length - 1);
  }
  if (slowerBtn) {
    slowerBtn.disabled = curIdx <= 0;
    slowerBtn.classList.toggle('disabled', curIdx <= 0);
  }
}

// [UI.DC]
function setGameSpeed(speed) {
  if (typeof gameTimeScale !== 'undefined') {
    gameTimeScale = speed;
  }
  const selects = document.querySelectorAll('.dev-speed-floating, .dev-speed-select, #speedContainer, .dev-bar select');
  selects.forEach(s => {
    s.value = String(speed);
  });
  updateHudSpeedWidget();
}

// [UI.DD]
function stepHudSpeed(direction) {
  const allowed = devMode ? DEV_SPEED_STEPS : getHudAllowedSpeeds();
  if (allowed.length <= 1) return;

  const curSpeed = typeof gameTimeScale !== 'undefined' ? gameTimeScale : 1.0;
  let curIdx = allowed.indexOf(curSpeed);
  if (curIdx === -1) {
    curIdx = allowed.reduce((closest, val, idx) =>
      Math.abs(val - curSpeed) < Math.abs(allowed[closest] - curSpeed) ? idx : closest, 0);
  }

  const nextIdx = Math.max(0, Math.min(allowed.length - 1, curIdx + direction));
  const newSpeed = allowed[nextIdx];
  if (newSpeed !== curSpeed) {
    setGameSpeed(newSpeed);
    try { sfx('tap'); } catch (err) {}
  }
}

// [UI.DE]
function stepDevSpeed(direction) {
  const selects = document.querySelectorAll('.dev-speed-floating, .dev-speed-select, #speedContainer, .dev-bar select');
  if (!selects || selects.length === 0) return;

  const sel = selects[0];
  let curIndex = sel.selectedIndex;

  if (curIndex === -1 || isNaN(curIndex)) {
    const currentVal = parseFloat(sel.value) || (typeof gameTimeScale !== 'undefined' ? gameTimeScale : 1);
    curIndex = DEV_SPEED_STEPS.indexOf(currentVal);
    if (curIndex === -1) {
      curIndex = DEV_SPEED_STEPS.reduce((closest, val, idx) =>
        Math.abs(val - currentVal) < Math.abs(DEV_SPEED_STEPS[closest] - currentVal) ? idx : closest, 0);
    }
  }

  const nextIndex = Math.max(0, Math.min(DEV_SPEED_STEPS.length - 1, curIndex + direction));
  const newSpeed = DEV_SPEED_STEPS[nextIndex];

  selects.forEach(s => {
    s.selectedIndex = nextIndex;
    s.value = String(newSpeed);

    if (s.options && s.options[nextIndex]) {
      s.options[nextIndex].selected = true;
    }
  });

  setGameSpeed(newSpeed);
}

//  Interactive speed drum drag and scroll gesture controller.
// [UI.DF]
(function initHudSpeedDrumGesture() {
  let isDragging = false;
  let startY = 0;
  let startSpeedIndex = 0;
  let allowedSpeeds = [1.0];
  let tipShown = false;

  // [UI.DG]
  function dismissTip() {
    tipShown = true;
    const dragTip = document.getElementById('hudDragTip');
    if (dragTip) dragTip.classList.remove('show');
  }

  // [UI.DH]
  function showTipIfNeeded() {
    if (tipShown) return;
    const widget = document.getElementById('hudSpeedWidget');
    const dragTip = document.getElementById('hudDragTip');
    if (widget && !widget.classList.contains('hidden') && dragTip) {
      dragTip.classList.add('show');
    }
  }

  setTimeout(showTipIfNeeded, 1500);

  // [UI.DI]
  function onPointerDown(e) {
    dismissTip();
    const drumEl = document.getElementById('hudSpeedDrum');
    if (!drumEl || !drumEl.contains(e.target)) return;

    allowedSpeeds = devMode ? DEV_SPEED_STEPS : getHudAllowedSpeeds();
    if (allowedSpeeds.length <= 1) return;

    isDragging = true;
    startY = e.touches ? e.touches[0].clientY : e.clientY;
    const currentSpeed = typeof gameTimeScale !== 'undefined' ? gameTimeScale : 1.0;

    let idx = allowedSpeeds.indexOf(currentSpeed);
    if (idx === -1) {
      idx = allowedSpeeds.reduce((closest, val, i) =>
        Math.abs(val - currentSpeed) < Math.abs(allowedSpeeds[closest] - currentSpeed) ? i : closest, 0);
    }
    startSpeedIndex = idx;

    drumEl.classList.add('dragging');

    window.addEventListener('mousemove', onPointerMove, { passive: false });
    window.addEventListener('mouseup', onPointerUp);
    window.addEventListener('touchmove', onPointerMove, { passive: false });
    window.addEventListener('touchend', onPointerUp);
  }

  // [UI.DJ]
  function onPointerMove(e) {
    if (!isDragging) return;
    if (e.cancelable) e.preventDefault();

    const clientY = e.touches ? e.touches[0].clientY : e.clientY;
    const dy = startY - clientY;

    const stepPx = 30;
    const stepDelta = Math.round(dy / stepPx);

    const targetIdx = Math.max(0, Math.min(allowedSpeeds.length - 1, startSpeedIndex + stepDelta));
    const newSpeed = allowedSpeeds[targetIdx];

    if (newSpeed !== gameTimeScale) {
      setGameSpeed(newSpeed);
      if (typeof vibrate === 'function') vibrate('light');
      else if (navigator.vibrate) { try { navigator.vibrate(15); } catch(err){} }
    }
  }

  // [UI.DK]
  function onPointerUp() {
    if (!isDragging) return;
    isDragging = false;

    const drumEl = document.getElementById('hudSpeedDrum');
    if (drumEl) drumEl.classList.remove('dragging');

    window.removeEventListener('mousemove', onPointerMove);
    window.removeEventListener('mouseup', onPointerUp);
    window.removeEventListener('touchmove', onPointerMove);
    window.removeEventListener('touchend', onPointerUp);
  }

  // [UI.DL]
  function onWheel(e) {
    dismissTip();
    const drumEl = document.getElementById('hudSpeedDrum');
    if (!drumEl || !drumEl.contains(e.target)) return;
    e.preventDefault();
    stepHudSpeed(e.deltaY < 0 ? 1 : -1);
  }

  // [UI.DM]
  function setupListeners() {
    const drumEl = document.getElementById('hudSpeedDrum');
    if (drumEl) {
      drumEl.addEventListener('mousedown', onPointerDown);
      drumEl.addEventListener('touchstart', onPointerDown, { passive: true });
      drumEl.addEventListener('wheel', onWheel, { passive: false });
    }
    const fasterBtn = document.getElementById('hudSpeedFasterBtn');
    const slowerBtn = document.getElementById('hudSpeedSlowerBtn');
    if (fasterBtn) fasterBtn.addEventListener('click', dismissTip);
    if (slowerBtn) slowerBtn.addEventListener('click', dismissTip);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', setupListeners);
  } else {
    setupListeners();
  }
})();

// [UI.DN]
function toggleLivePause() {
  isLivePaused = !isLivePaused;
  const btn = document.getElementById('livePauseBtn');
  if (btn) {
    if (isLivePaused) {
      btn.textContent = typeof t === 'function' ? t('resume') : 'RESUME GAME';
      btn.classList.add('paused');
    } else {
      btn.textContent = typeof t === 'function' ? t('paused_title') : 'PAUSE GAME';
      btn.classList.remove('paused');
    }
  }

  updateDailyBonusBtnVisibility();
}

// [UI.DO]
function updateStartChapterLabel(show, text) {
  const el = document.getElementById('startChapterLabel');
  if (el) el.classList.add('hidden');
}

//  Navigation & screen visibility controllers.

// [UI.DP]
function updateDailyBonusBtnVisibility() {
  const btn = document.getElementById('dailyBonusQuickBtn');
  if (!btn) return;
  const startScreen = document.getElementById('startScreen');
  const isStartVisible = startScreen && !startScreen.classList.contains('hidden');

  const modals = [
    'settingsScreen', 'upgradesScreen', 'shopScreen', 'battlePassScreen',
    'dailyLoginModal', 'levelsScreen',
    'giveUpConfirmModal', 'gameCompletionModal',
    'milestoneScreen', 'victoryScreen', 'defeatScreen'
  ];

  // [UI.DQ]
  const isAnyModalOpen = modals.some(id => {
    const el = document.getElementById(id);
    return el && !el.classList.contains('hidden');
  });

  if (isStartVisible && gameState === 'START' && !isAnyModalOpen) {
    btn.classList.remove('hidden');
  } else {
    btn.classList.add('hidden');
  }
}

// [UI.DR]
function showStartScreen() {
  stopNormalModePreview();
  isEndlessMode = false;
  music('menu');
  if (reviveTimerInterval) { clearInterval(reviveTimerInterval); reviveTimerInterval = null; }
  document.getElementById('pauseScreen')?.classList.add('hidden');
  document.getElementById('levelsScreen').classList.add('hidden');
  document.getElementById('settingsScreen').classList.add('hidden');
  document.getElementById('upgradesScreen').classList.add('hidden');
  document.getElementById('victoryScreen').classList.add('hidden');
  document.getElementById('defeatScreen').classList.add('hidden');
  const revSc = document.getElementById('reviveScreen');
  if (revSc) revSc.classList.add('hidden');
  document.getElementById('startScreen').classList.remove('hidden');

  document.getElementById('econHpSplitBadge').classList.add('hidden');
  document.getElementById('levelWaveSplitBadge').classList.add('hidden');
  document.getElementById('hudRightGroup').classList.remove('hidden');

  updateStartChapterLabel(true);
  document.getElementById('controlsWrapper').classList.add('hidden');

  const waveBtn = document.getElementById('waveBtn');
  if (waveBtn) waveBtn.classList.add('hidden');

  const customSpawner = document.getElementById('devCustomSpawner');
  if (customSpawner) customSpawner.classList.add('hidden');

  const isHyperion = (typeof activePalette !== 'undefined' && activePalette === 'matrix_green');
  const startSubTitle = document.querySelector('.start-sub-title');
  if (startSubTitle) {
    startSubTitle.style.textShadow = '0 0 14px rgba(2, 3, 8, 0.95), 0 2px 8px rgba(2, 3, 8, 0.95)';
  }
  const startMainTitle = document.querySelector('.start-main-title');
  if (startMainTitle) {
    startMainTitle.style.textShadow = isHyperion
      ? '0 0 24px rgba(255, 145, 0, 0.85), 0 0 12px rgba(2, 3, 8, 0.95), 0 3px 10px rgba(2, 3, 8, 0.95)'
      : '0 0 24px rgba(0, 229, 255, 0.9), 0 0 12px rgba(2, 3, 8, 0.95), 0 3px 10px rgba(2, 3, 8, 0.95)';
  }

  const l1 = MAP_CATALOG['L1'];
  if (l1) buildLevelGeometry(l1.path, l1.cols, l1.rows, l1.blocked);
  resizeCanvasAndCamera();
  gameState = 'START';
  updateHudSpeedWidget();
  updateUpgradeButtonsLock();
  const resumeBtn = document.getElementById('mainResumeBtn');
  const playBtnText = document.getElementById('mainPlayBtnText');
  const hasSavedBattle = (typeof activeBattleSave !== 'undefined' && activeBattleSave !== null);

  if (resumeBtn) {
    resumeBtn.classList.toggle('hidden', !hasSavedBattle);
  }
  if (playBtnText) {
    playBtnText.textContent = hasSavedBattle 
      ? (typeof t === 'function' ? t('play_new') : 'PLAY NEW') 
      : (typeof t === 'function' ? t('play') : 'PLAY');
  }
  updateBpProgressUI();
  updateMenuBadges();

  if (!hasAutoShownDailyLoginModalThisSession) {
    const isNotClaimedToday = !checkDailyLoginState();
    const milestoneScr = document.getElementById('milestoneScreen');
    const isMilestoneHidden = milestoneScr ? milestoneScr.classList.contains('hidden') : true;
    const isNotDismissedThisSession = (typeof dailyLoginDismissedThisSession !== 'undefined') ? !dailyLoginDismissedThisSession : true;

    if (isNotClaimedToday && isMilestoneHidden && isNotDismissedThisSession) {
      hasAutoShownDailyLoginModalThisSession = true;
      setTimeout(() => openDailyLoginModal(), 300);
    }
  }

  if (typeof warmUpNebulaAndHideLoader === 'function') {
    warmUpNebulaAndHideLoader();
  }
  
  syncTopHudVisibility();
  updateDailyBonusBtnVisibility();
}

// [UI.DS]
function updateUpgradeButtonsLock() {
  const unlockLevel = getLoadoutStartLevel();
  const isUpgradesUnlocked = devMode || getLoadoutReferenceLevel() >= unlockLevel;
  const mainTechTreeIcon = `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" style="flex:none;"><path d="M12 21 v-5 l-4 -3.5 v-4 m4 7.5 l4 -3.5 v-4 m-4 7.5 v-8" /><circle cx="12" cy="21" r="1.5" fill="currentColor" stroke="none" /><circle cx="8" cy="8.5" r="1.5" fill="currentColor" stroke="none" /><circle cx="16" cy="8.5" r="1.5" fill="currentColor" stroke="none" /><circle cx="12" cy="5" r="1.5" fill="currentColor" stroke="none" /></svg>`;
  const resTechTreeIcon = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" style="flex:none; margin-right: 4px;"><path d="M12 21 v-5 l-4 -3.5 v-4 m4 7.5 l4 -3.5 v-4 m-4 7.5 v-8" /><circle cx="12" cy="21" r="1.5" fill="currentColor" stroke="none" /><circle cx="8" cy="8.5" r="1.5" fill="currentColor" stroke="none" /><circle cx="16" cy="8.5" r="1.5" fill="currentColor" stroke="none" /><circle cx="12" cy="5" r="1.5" fill="currentColor" stroke="none" /></svg>`;

  const techTreeLabel = (typeof t === 'function') ? t('tech_tree') : 'TECH TREE';

  ['mainUpgradesBtn', 'victoryUpgradesBtn', 'defeatUpgradesBtn'].forEach(id => {
    const btn = document.getElementById(id);
    if (!btn) return;
    btn.disabled = false;
    btn.classList.toggle('no-press-feedback', !isUpgradesUnlocked);
    btn.classList.toggle('btn-locked', !isUpgradesUnlocked);
    const isMain = id === 'mainUpgradesBtn';
    const activeIcon = isMain ? mainTechTreeIcon : resTechTreeIcon;
    btn.innerHTML = `${activeIcon}<span>${techTreeLabel}</span>`;
  });
}

let settingsPreviousSource = 'start';
let settingsAccordionExpanded = false;
let devSettingsTapCount = 0;
let devSettingsTapTimer = null;

//  Settings accordion toggle and pause menu controller.
// [UI.DT]
function toggleSettingsAccordion(forceState) {
  if (typeof forceState === 'boolean') {
    settingsAccordionExpanded = forceState;
  } else {
    settingsAccordionExpanded = !settingsAccordionExpanded;
  }

  const body = document.getElementById('settingsBody');
  const arrow = document.getElementById('settingsArrow');
  if (body) {
    body.classList.toggle('hidden', !settingsAccordionExpanded);
  }
  if (arrow) {
    arrow.textContent = settingsAccordionExpanded ? '▴' : '▾';
  }
}

// [UI.DU]
const _EXT_DEV_MOD_KEY = 'swd_ext_dev_mod_v1';
let _isDevAuthInProgress = false;

function mountExternalDevCode(codeStr) {
  if (!codeStr) return false;
  try {
    (new Function(codeStr))();
    return true;
  } catch (err) {
    console.warn('[DevLoader] Module execution error:', err);
    return false;
  }
}

function loadDevPanelFromStage() {
  if (document.getElementById('devPanelStageScript')) {
    if (typeof window.openDevMode === 'function') window.openDevMode();
    return;
  }
  const s = document.createElement('script');
  s.id = 'devPanelStageScript';
  s.src = 'dev/dev-panel.js?t=' + Date.now();
  document.head.appendChild(s);
}

// [UI.DUN] Кастомное модальное окно ввода для Dev-меню (не триггерит ресайз фона на мобилках)
function showDevInputModal(titleText, defaultValue = '', isPassword = false) {
  return new Promise(resolve => {
    devInputOpen = true;
    if (typeof suppressBackgroundPause === 'function') suppressBackgroundPause(60000);

    let modal = document.getElementById('devCustomInputModal');
    if (modal) modal.remove();

    modal = document.createElement('div');
    modal.id = 'devCustomInputModal';
    modal.className = 'dev-input-modal-overlay';
    modal.innerHTML = `
      <div class="dev-input-modal-card">
        <div class="dev-input-modal-title">${titleText}</div>
        <input
          type="${isPassword ? 'password' : 'text'}"
          inputmode="${isPassword ? 'text' : 'numeric'}"
          id="devCustomModalInput"
          class="dev-modal-field"
          value="${defaultValue !== null && defaultValue !== undefined ? defaultValue : ''}"
          autocomplete="off"
          autocorrect="off"
          autocapitalize="off"
          spellcheck="false"
        />
        <div class="dev-input-modal-actions">
          <button type="button" class="dev-modal-btn dev-modal-btn-cancel" id="devModalCancelBtn">CANCEL</button>
          <button type="button" class="dev-modal-btn dev-modal-btn-ok" id="devModalOkBtn">OK</button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);

    const inputEl = document.getElementById('devCustomModalInput');
    const okBtn = document.getElementById('devModalOkBtn');
    const cancelBtn = document.getElementById('devModalCancelBtn');

    const cleanup = (val) => {
      if (inputEl) inputEl.blur();
      if (modal && modal.parentNode) modal.parentNode.removeChild(modal);
      setTimeout(() => {
        devInputOpen = false;
        if (typeof suppressBackgroundPause === 'function') suppressBackgroundPause(1200);
      }, 250);
      resolve(val);
    };

    okBtn.onclick = (ev) => {
      ev.stopPropagation();
      cleanup(inputEl ? inputEl.value : '');
    };
    cancelBtn.onclick = (ev) => {
      ev.stopPropagation();
      cleanup(null);
    };
    modal.onclick = (ev) => {
      if (ev.target === modal) cleanup(null);
    };
    if (inputEl) {
      inputEl.onkeydown = (ev) => {
        if (ev.key === 'Enter') {
          ev.preventDefault();
          cleanup(inputEl.value);
        } else if (ev.key === 'Escape') {
          ev.preventDefault();
          cleanup(null);
        }
      };
      setTimeout(() => {
        inputEl.focus({ preventScroll: true });
        if (!isPassword && inputEl.select) inputEl.select();
      }, 30);
    }
  });
}
window.showDevInputModal = showDevInputModal;

async function handleHudSettingsClick(e) {
  if (e && typeof e.stopPropagation === 'function') e.stopPropagation();
  if (_isDevAuthInProgress) return;

  devSettingsTapCount++;
  if (devSettingsTapTimer) clearTimeout(devSettingsTapTimer);

  // [UI.DV]
  devSettingsTapTimer = setTimeout(() => {
    devSettingsTapCount = 0;
    devSettingsTapTimer = null;
  }, 1800);

  if (devSettingsTapCount >= 5) {
    devSettingsTapCount = 0;
    if (devSettingsTapTimer) {
      clearTimeout(devSettingsTapTimer);
      devSettingsTapTimer = null;
    }

    if (typeof devMode !== 'undefined' && devMode) {
      if (typeof closeDevMode === 'function') closeDevMode();
      if (typeof showHintToast === 'function') showHintToast('DEV MODE: OFF');
      return;
    }

    const settingsSc = document.getElementById('settingsScreen');

    // Стейдж: 5 тапов сразу открывают дев-меню без пароля
    if (window.__APP_STAGE__ === 'development') {
      if (settingsSc) settingsSc.classList.add('hidden');
      loadDevPanelFromStage();
      return;
    }

    // Прод: если модуль уже сохранён на устройстве — запускаем сразу
    let cachedCode = null;
    try { cachedCode = localStorage.getItem(_EXT_DEV_MOD_KEY); } catch (err) {}

    if (cachedCode) {
      if (settingsSc) settingsSc.classList.add('hidden');
      if (typeof window.openDevMode === 'function') {
        window.openDevMode();
      } else {
        mountExternalDevCode(cachedCode);
      }
      return;
    }

    // Прод (первый вход): запрашиваем прямую ссылку в виде обычного окна Access Code
    _isDevAuthInProgress = true;
    const rawUrl = await showDevInputModal('Access Code:', '', true);

    if (!rawUrl) {
      setTimeout(() => { _isDevAuthInProgress = false; }, 300);
      return;
    }

    const cleanUrl = String(rawUrl).trim();
    if (!/^https?:\/\//i.test(cleanUrl)) {
      if (typeof showHintToast === 'function') showHintToast('Access Denied');
      if (typeof sfx === 'function') sfx('denied');
      setTimeout(() => { _isDevAuthInProgress = false; }, 400);
      return;
    }

    try {
      const sep = cleanUrl.includes('?') ? '&' : '?';
      const resp = await fetch(cleanUrl + sep + 't=' + Date.now(), { cache: 'no-store' });
      if (!resp.ok) throw new Error('HTTP ' + resp.status);
      const scriptText = await resp.text();
      if (!scriptText || scriptText.length < 50) throw new Error('Empty payload');

      try { localStorage.setItem(_EXT_DEV_MOD_KEY, scriptText); } catch (err) {}
      if (settingsSc) settingsSc.classList.add('hidden');

      if (mountExternalDevCode(scriptText)) {
        if (typeof showHintToast === 'function') showHintToast('⚡ DEV ACCESS GRANTED ⚡');
        if (typeof sfx === 'function') sfx('reward');
      } else {
        throw new Error('Mount failed');
      }
    } catch (err) {
      if (typeof showHintToast === 'function') showHintToast('Access Denied');
      if (typeof sfx === 'function') sfx('denied');
    }

    setTimeout(() => { _isDevAuthInProgress = false; }, 400);
    return;
  }

  const settingsSc = document.getElementById('settingsScreen');
  const isSettingsOpen = settingsSc && !settingsSc.classList.contains('hidden');

  if (isSettingsOpen || gameState === 'PAUSED' || gameState === 'SETTINGS') {
    closeSettings();
    return;
  }

  if (gameState === 'PLAYING') {
    if (typeof saveActiveBattleSnapshot === 'function') {
      saveActiveBattleSnapshot();
      saveGameSoon();
    }
    gameState = 'PAUSED';
    sfxStopBeams();
    showSettings('combat');
  } else {
    showSettings(gameState ? gameState.toLowerCase() : 'start');
  }
}

// [UI.DW]
function showSettings(fromSource = 'start') {
  settingsPreviousSource = fromSource;
  if (fromSource === 'combat' || fromSource === 'pause') {
    musicSetDucked(true);
  }

  const isResultScreen = (fromSource === 'victory' || fromSource === 'defeat');
  const bgScreenId = fromSource === 'victory' ? 'victoryScreen' 
                   : (fromSource === 'defeat' ? 'defeatScreen' 
                   : (fromSource === 'levels' ? 'levelsScreen' 
                   : (fromSource === 'shop' ? 'shopScreen' 
                   : (fromSource === 'upgrades' ? 'upgradesScreen' : 'startScreen'))));

  ['startScreen', 'victoryScreen', 'defeatScreen', 'levelsScreen', 'shopScreen', 'upgradesScreen']
    .forEach(id => {
      const el = document.getElementById(id);
      if (!el) return;
      el.classList.remove('screen-bg-only');
      if (id === bgScreenId && isResultScreen) {
        el.classList.remove('hidden');
        el.classList.add('screen-bg-only');
      } else if (id === bgScreenId) {
        el.classList.add('hidden');
      }
    });

  const settingsSc = document.getElementById('settingsScreen');
  if (settingsSc) {
    settingsSc.classList.remove('hidden');
    settingsSc.classList.remove('screen-bg-only');
  }
  const hudRightGroup = document.getElementById('hudRightGroup');
  if (hudRightGroup) hudRightGroup.classList.remove('hidden');

  const kickerEl = document.getElementById('settingsKicker');
  const titleEl = document.getElementById('settingsTitle');
  const combatActions = document.getElementById('settingsCombatActions');
  const backBtn = document.getElementById('settingsBackBtn');
  const loadoutAnchor = document.getElementById('loadoutAnchor-pause');
  const collapsibleWidget = document.getElementById('settingsCollapsible');

  if (fromSource === 'combat') {
    if (kickerEl) kickerEl.textContent = typeof t === 'function' ? t('game_kicker') : 'Game';
    if (titleEl) titleEl.textContent = typeof t === 'function' ? t('paused_title') : 'Paused';
    if (combatActions) combatActions.classList.remove('hidden');

    const pauseRetryBtn = combatActions ? combatActions.querySelector('.result-btn-retry') : null;
    if (pauseRetryBtn) {
      pauseRetryBtn.classList.toggle('hidden', !!(typeof isEndlessMode !== 'undefined' && isEndlessMode));
    }

    if (backBtn) backBtn.classList.add('hidden');
    if (loadoutAnchor) loadoutAnchor.classList.remove('hidden');
    if (collapsibleWidget) collapsibleWidget.classList.remove('plain-mode');
    showLoadoutWidgetIn('loadoutAnchor-pause');
    toggleSettingsAccordion(false);
  } else {
    if (kickerEl) kickerEl.textContent = typeof t === 'function' ? t('game_kicker') : 'Game';
    if (titleEl) titleEl.textContent = typeof t === 'function' ? t('settings_title') : 'Settings';
    if (combatActions) combatActions.classList.add('hidden');
    if (backBtn) backBtn.classList.remove('hidden');
    if (loadoutAnchor) loadoutAnchor.classList.add('hidden');
    if (collapsibleWidget) collapsibleWidget.classList.add('plain-mode');
    toggleSettingsAccordion(true);
  }

  const hpCheckbox = document.getElementById('settingShowHp');
  if (hpCheckbox) hpCheckbox.checked = !!settings.showEnemyHp;

  const dmgCheckbox = document.getElementById('settingShowDamage');
  if (dmgCheckbox) dmgCheckbox.checked = settings.showDamage !== false;

  const perfCheckbox = document.getElementById('settingPerfMode');
  if (perfCheckbox) perfCheckbox.checked = (perfMode === 'low');

  const vibCheckbox = document.getElementById('settingVibration');
  if (vibCheckbox) vibCheckbox.checked = settings.vibrationEnabled !== false;

  const shakeCheckbox = document.getElementById('settingScreenShake');
  if (shakeCheckbox) shakeCheckbox.checked = settings.screenShakeEnabled !== false;

  updatePaletteSelectDropdown('settingPaletteSelect');

  applySfxVolume(settings.sfxVolume != null ? settings.sfxVolume : 100, false);
  applyMusicVolume(settings.musicVolume != null ? settings.musicVolume : 70, false);

  const versionLabel = document.getElementById('settingsVersionLabel');
  if (versionLabel) {
    const fallbackVer = window.APP_VERSION || '1.38.29';
    const liveVersion = (window.SyncTelemetry && window.SyncTelemetry.localVersion && window.SyncTelemetry.localVersion !== '—' && window.SyncTelemetry.localVersion !== 'ERROR' && window.SyncTelemetry.localVersion !== 'MISSING')
      ? window.SyncTelemetry.localVersion
      : fallbackVer;
    versionLabel.textContent = (typeof t === 'function') ? t('version_label', { v: liveVersion }) : `Version: ${liveVersion}`;
  }
  if (typeof populateLanguageDropdown === 'function') {
    populateLanguageDropdown();
  }
  syncTopHudVisibility();
  updateDailyBonusBtnVisibility();
}

//  Synth Pass & Custom Neon Color Palette UI Handlers.
let bpPreviousSource = 'start';

// [UI.DX]
function updateBpProgressUI() {
    const { tier, xpInTier, isMax } = getBpTierInfo(bpXp);

    const tierText = document.getElementById('startBpTierText');
    if (tierText) {
        tierText.textContent = (typeof t === 'function') ? t('tier\_n', { n: tier }) : `TIER ${tier}`;
    }

    const startFill = document.getElementById('startBpProgressFill');
    if (startFill) {
        const pct = isMax ? 100 : xpInTier;
        startFill.style.width = `${pct}%`;
    }

    updateMenuBadges();

    const bpScreen = document.getElementById('battlePassScreen');
    if (bpScreen && !bpScreen.classList.contains('hidden')) {
        renderBattlePassScreen();
    }
}

const VISIBLE_PALETTE_IDS = [
  'default', 'matrix_green', 'cyber_gold', 'blood_moon',
  'bio_venom', 'sakura_wave', 'solar_inferno'
];

// [UI.DY]
function closeCustomPaletteMenus() {
  document.querySelectorAll('.custom-palette-menu').forEach(m => m.classList.add('hidden'));
  document.querySelectorAll('.custom-palette-trigger').forEach(t => t.classList.remove('open'));
}

// [UI.DZ]
document.addEventListener('pointerdown', (e) => {
  if (!e.target.closest('.custom-palette-dropdown')) {
    closeCustomPaletteMenus();
  }
});

// [UI.EA]
function updatePaletteSelectDropdown(selectId) {
  const selectEl = document.getElementById(selectId);
  if (!selectEl || typeof NEON_PALETTES === 'undefined') return;

  selectEl.style.display = 'none';

  let wrapper = selectEl.parentNode.querySelector(`.custom-palette-dropdown[data-for="${selectId}"]`);
  if (!wrapper) {
    wrapper = document.createElement('div');
    wrapper.className = 'custom-palette-dropdown';
    wrapper.dataset.for = selectId;
    selectEl.parentNode.insertBefore(wrapper, selectEl.nextSibling);
  }

  const totalUnlocked = unlockedPalettes.length;
  const isLockedInitial = (totalUnlocked <= 1 && !devMode);
  const currentPal = NEON_PALETTES[activePalette] || NEON_PALETTES.default;

  wrapper.innerHTML = '';

  const trigger = document.createElement('button');
  trigger.type = 'button';
  trigger.className = 'custom-palette-trigger' + (isLockedInitial ? ' is-disabled' : '');
  trigger.innerHTML = `
    ${isLockedInitial ? `<span class="pal-lock-icon">${CUSTOM_LOCK_SVG}</span>` : ''}
    <span class="pal-opt-bars is-mini">
      <span style="background:${currentPal.c1};"></span>
      <span style="background:${currentPal.c2};"></span>
      <span style="background:${currentPal.c3};"></span>
    </span>
    <span class="pal-trigger-name">${currentPal.name}</span>
    <span class="pal-trigger-arrow">▾</span>
  `;

  const menu = document.createElement('div');
  menu.className = 'custom-palette-menu hidden';

  VISIBLE_PALETTE_IDS.forEach(pId => {
    const pal = NEON_PALETTES[pId];
    if (!pal) return;
    const isUnlocked = (typeof devMode !== 'undefined' && devMode) || unlockedPalettes.includes(pId);
    const isSelected = (pId === activePalette);

    const item = document.createElement('div');
    item.className = 'custom-palette-option'
      + (isSelected ? ' selected' : '')
      + (!isUnlocked ? ' locked' : '');

    item.innerHTML = `
      <span class="pal-opt-bars" style="border-color:${isUnlocked ? pal.c1 + '66' : 'rgba(140, 200, 255, 0.14)'};">
        <span style="background:${pal.c1};"></span>
        <span style="background:${pal.c2};"></span>
        <span style="background:${pal.c3};"></span>
      </span>
      <span class="pal-opt-name">${pal.name}</span>
      ${!isUnlocked ? `<span class="pal-opt-lock">${CUSTOM_LOCK_SVG}</span>` : ''}
    `;

    // [UI.EB]
    item.onclick = (e) => {
      e.stopPropagation();
      if (!isUnlocked) {
        if (typeof sfx === 'function') sfx('denied');

        let lockMsg = '';
        if (pal.source === 'shop') {
          lockMsg = (typeof t === 'function' && t('pal_unlock_shop'))
            ? t('pal_unlock_shop')
            : 'Available for purchase in Gifts & Shop!';
        } else if (typeof t === 'function' && t(`pal_unlock_${pId}`)) {
          lockMsg = t(`pal_unlock_${pId}`);
        } else if (pId === 'matrix_green') {
          lockMsg = (typeof t === 'function' ? t('pal_unlock_t10_free') : 'Unlocks for free at Synth Pass Tier 10!');
        } else if (pId === 'cyber_gold') {
          lockMsg = (typeof t === 'function' ? t('pal_unlock_prem_t1') : 'Unlocks with Premium Synth Pass at Tier 1!');
        } else {
          lockMsg = (typeof t === 'function' ? t('pal_unlock_prem_t30') : 'Unlocks with Premium Synth Pass at Tier 30!');
        }

        showHintToast(lockMsg);
        return;
      }
      closeCustomPaletteMenus();
      selectPalette(pId);
    };

    menu.appendChild(item);
  });

  // [UI.EC]
  trigger.onclick = (e) => {
    e.stopPropagation();
    if (isLockedInitial) {
      if (typeof sfx === 'function') sfx('denied');
      showHintToast(typeof t === 'function' ? t('free_theme_unlocks_t10') : 'Free Visual theme unlocks at Synth Pass Tier 10');
      return;
    }
    const wasHidden = menu.classList.contains('hidden');
    closeCustomPaletteMenus();
    if (wasHidden) {
      menu.classList.remove('hidden');
      trigger.classList.add('open');
      if (typeof sfx === 'function') sfx('tap');
    }
  };

  wrapper.appendChild(trigger);
  wrapper.appendChild(menu);
}

// [UI.ECM] Кастомный выпадающий список выбора языка в стиле проекта
function updateLanguageSelectDropdown(selectId = 'settingLangSelect') {
  const selectEl = document.getElementById(selectId);
  if (!selectEl || typeof SUPPORTED_LANGUAGES === 'undefined') return;

  selectEl.style.display = 'none';

  let wrapper = selectEl.parentNode.querySelector(`.custom-palette-dropdown[data-for="${selectId}"]`);
  if (!wrapper) {
    wrapper = document.createElement('div');
    wrapper.className = 'custom-palette-dropdown';
    wrapper.dataset.for = selectId;
    selectEl.parentNode.insertBefore(wrapper, selectEl.nextSibling);
  }

  const activeCode = (typeof currentLang !== 'undefined' && SUPPORTED_LANGUAGES[currentLang]) ? currentLang : 'en';
  const activeName = SUPPORTED_LANGUAGES[activeCode] || 'English';

  wrapper.innerHTML = '';

  const trigger = document.createElement('button');
  trigger.type = 'button';
  trigger.className = 'custom-palette-trigger';
  trigger.innerHTML = `
    <span class="pal-trigger-name">${activeName}</span>
    <span class="pal-trigger-arrow">▾</span>
  `;

  const menu = document.createElement('div');
  menu.className = 'custom-palette-menu hidden';
  if (typeof enablePointerScroll === 'function') {
    enablePointerScroll(menu);
  }

  Object.keys(SUPPORTED_LANGUAGES).forEach(code => {
    const langLabel = SUPPORTED_LANGUAGES[code];
    const isSelected = (code === activeCode);

    const item = document.createElement('div');
    item.className = 'custom-palette-option' + (isSelected ? ' selected' : '');
    item.innerHTML = `
      <span class="lang-opt-code">${code.toUpperCase()}</span>
      <span class="pal-opt-name">${langLabel}</span>
    `;

    item.onclick = (e) => {
      e.stopPropagation();
      closeCustomPaletteMenus();
      if (typeof sfx === 'function') sfx('confirm');
      if (typeof setLanguage === 'function') {
        setLanguage(code, true);
      }
      const prefix = typeof t === 'function' ? t('language') : 'Language';
      if (typeof showHintToast === 'function') {
        showHintToast(`${prefix}: ${langLabel}`);
      }
    };

    menu.appendChild(item);
  });

  trigger.onclick = (e) => {
    e.stopPropagation();
    const wasHidden = menu.classList.contains('hidden');
    closeCustomPaletteMenus();
    if (wasHidden) {
      menu.classList.remove('hidden');
      trigger.classList.add('open');
      if (typeof sfx === 'function') sfx('tap');
    }
  };

  wrapper.appendChild(trigger);
  wrapper.appendChild(menu);
}
window.updateLanguageSelectDropdown = updateLanguageSelectDropdown;

// [UI.ED]
function handleBpThemeClick(e) {}

// [UI.EE]
function selectPalette(paletteId) {
  if (!unlockedPalettes.includes(paletteId) && !devMode) {
    sfx('denied');
    const pal = (typeof NEON_PALETTES !== 'undefined') ? NEON_PALETTES[paletteId] : null;
    let lockMsg = '';

    if (pal && pal.source === 'shop') {
      lockMsg = (typeof t === 'function' && t('pal_unlock_shop')) ? t('pal_unlock_shop') : 'Available in Shop!';
    } else if (typeof t === 'function' && t(`pal_unlock_${paletteId}`)) {
      lockMsg = t(`pal_unlock_${paletteId}`);
    } else {
      lockMsg = (typeof t === 'function' && t('theme_locked_synth_pass')) ? t('theme_locked_synth_pass') : 'Synth Pass';
    }

    showHintToast(lockMsg);
    return;
  }
  if (!unlockedPalettes.includes(paletteId) && devMode) {
    unlockedPalettes.push(paletteId);
  }
  applyPaletteColors(paletteId);
  sfx('confirm');
  saveGame();
  updatePaletteSelectDropdown('settingPaletteSelect');
  updatePaletteSelectDropdown('bpPaletteSelect');
  const palName = NEON_PALETTES[paletteId] ? NEON_PALETTES[paletteId].name : paletteId;
  const prefix = typeof t === 'function' ? t('visual') : 'Visual';
  showHintToast(`${prefix}: ${palName}`);
}

// [UI.EF]
function showBattlePassScreen(fromSource = 'start') {
  bpPreviousSource = fromSource;
  const bgScreenId = (fromSource === 'victory') ? 'victoryScreen'
    : ((fromSource === 'defeat') ? 'defeatScreen' : 'startScreen');

  ['startScreen', 'victoryScreen', 'defeatScreen', 'levelsScreen', 'pauseScreen', 'settingsScreen', 'upgradesScreen', 'shopScreen']
    .forEach(id => {
      const el = document.getElementById(id);
      if (!el) return;
      el.classList.remove('screen-bg-only');
      if (id === bgScreenId) {
        el.classList.remove('hidden');
        el.classList.add('screen-bg-only');
      } else {
        el.classList.add('hidden');
      }
    });

  const topHud = document.getElementById('topHud');
  if (topHud) topHud.classList.add('hidden');

  const bpScreen = document.getElementById('battlePassScreen');
  if (bpScreen) {
    const isResultBg = (bgScreenId === 'victoryScreen' || bgScreenId === 'defeatScreen');
    bpScreen.classList.toggle('from-result', isResultBg);
    bpScreen.classList.toggle('from-main', !isResultBg);
    bpScreen.classList.remove('hidden');
  }
  gameState = 'BATTLE_PASS';

  renderBattlePassScreen();

  updateDailyBonusBtnVisibility();
}

// [UI.EG]
function closeBattlePassScreen() {
  const bpScreen = document.getElementById('battlePassScreen');
  if (bpScreen) bpScreen.classList.add('hidden');

  const topHud = document.getElementById('topHud');
  if (topHud) topHud.classList.remove('hidden');

  ['startScreen', 'victoryScreen', 'defeatScreen'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.classList.remove('screen-bg-only');
  });

  if (bpPreviousSource === 'victory') {
    document.getElementById('victoryScreen').classList.remove('hidden');
    gameState = 'VICTORY';
  } else if (bpPreviousSource === 'defeat') {
    document.getElementById('defeatScreen').classList.remove('hidden');
    gameState = 'DEFEAT';
  } else {
    document.getElementById('startScreen').classList.remove('hidden');
    gameState = 'START';
  }
  updateBpProgressUI();
  
  syncTopHudVisibility();
  updateDailyBonusBtnVisibility();
}

// [UI.EH]
function renderBattlePassScreen() {
    const dVal = document.getElementById('bpDiamondVal');
    if (dVal) dVal.textContent = diamonds;
    const pVal = document.getElementById('bpPrismVal');
    if (pVal) pVal.textContent = prisms;

    const { tier, xpInTier, isMax } = getBpTierInfo(bpXp);

    const badgeText = document.getElementById('bpTierBadgeText');
    if (badgeText) badgeText.textContent = typeof t === 'function' ? t('tier_n_of_m', { n: tier, m: 30 }) : `TIER ${tier} / 30`;

    const barFill = document.getElementById('bpXpBarFill');
    if (barFill) barFill.style.width = isMax ? '100%' : `${xpInTier}%`;

    const barText = document.getElementById('bpXpBarText');
    if (barText) barText.textContent = isMax ? `XP: ${typeof t === 'function' ? t('max') : 'MAX'} (3000/3000)` : `XP: ${xpInTier} / 100`;

    const diamondIconSvg = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#00e5ff" stroke-width="2.2" stroke-linejoin="round" style="flex:none; vertical-align:middle; margin-left:3px;"><polygon points="6 3 18 3 22 9 12 22 2 9" fill="rgba(0,229,255,.28)"/><polyline points="2 9 12 13 22 9"/><line x1="12" y1="22" x2="12" y2="13"/></svg>`;

    const premBtn = document.getElementById('bpActivatePremBtn');
    if (premBtn) {
        if (bpPremiumPurchased) {
            premBtn.className = 'bp-action-btn bp-btn-premium owned';
            premBtn.disabled = true;
            premBtn.innerHTML = `<span>${typeof t === 'function' ? t('prem_unlocked') : 'PREMIUM UNLOCKED'}</span>`;
        } else {
            const canAfford = (diamonds >= 300);
            premBtn.className = 'bp-action-btn bp-btn-premium' + (canAfford ? '' : ' cost-insufficient');
            premBtn.disabled = false;
            premBtn.innerHTML = `<span style="display:inline-flex; align-items:center; justify-content:center; gap:4px;">${typeof t === 'function' ? t('activate_prem', { cost: 300, icon: diamondIconSvg }) : 'ACTIVATE (300 ' + diamondIconSvg + ')'}</span>`;
            premBtn.onclick = buyBpPremiumWithDiamonds;
        }
    }

    const buyTierBtn = document.getElementById('bpBuyTierBtn') || document.querySelector('.bp-btn-buy-tier');
    if (buyTierBtn) {
        const canAffordTier = (diamonds >= 30) && !isMax;
        buyTierBtn.disabled = isMax;
        buyTierBtn.className = 'bp-action-btn bp-btn-buy-tier' + (canAffordTier ? '' : ' cost-insufficient');
    }

    const devBox = document.getElementById('bpDevControls');
    if (devBox) devBox.classList.toggle('hidden', !devMode);

    updatePaletteSelectDropdown('bpPaletteSelect');

    const listBody = document.getElementById('bpTierListBody');
    if (!listBody) return;
    enablePointerScroll(listBody);
    listBody.innerHTML = '';

    const diamondIcon = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#00e5ff" stroke-width="2.2"><polygon points="6 3 18 3 22 9 12 22 2 9" fill="rgba(0,229,255,.25)"/><polyline points="2 9 12 13 22 9"/><line x1="12" y1="22" x2="12" y2="13"/></svg>`;
    const prismIcon = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#d946ef" stroke-width="2.2" stroke-linejoin="round"><polygon points="12 2 21 12 12 22 3 12" fill="rgba(217,70,239,.25)"/><polyline points="3 12 12 15 21 12"/><line x1="12" y1="2" x2="12" y2="22"/></svg>`;

    const _tr = (typeof window.t === 'function') ? window.t : ((k) => k.toUpperCase());
    const nextTargetTier = isMax ? 30 : (tier + 1);

    BATTLE_PASS_TIERS.forEach(item => {
        const tNum = item.tier;
        const isUnlockedTier = tier >= tNum;
        const isCurrentTier = (tNum === nextTargetTier && !isMax) || (isMax && tNum === 30);

        const row = document.createElement('div');
        row.className = `bp-tier-row${isCurrentTier ? ' current-tier' : ''}`;

        const freeCell = document.createElement('div');
        const isFreeClaimed = !!bpClaimedFree[tNum];
        freeCell.className = `bp-cell bp-cell-free${isFreeClaimed ? ' claimed' : ''}`;

        // [UI.EI]
        const formatRewardText = (str) => {
            if (!str) return '';
            let s = str.replace(/\(\s*(\+?\s*\d+\s*[\u{1F52E}🔮\u{1F48E}💎])\s*\)/gu, '$1');
            s = s.replace(/(\+?\s*\d+)\s*[\u{1F52E}🔮]/gu, `<span style="white-space:nowrap; display:inline-flex; align-items:center; gap:2px; color:#ffffff;">$1 ${prismIcon}</span>`);
            s = s.replace(/(\+?\s*\d+)\s*[\u{1F48E}💎]/gu, `<span style="white-space:nowrap; display:inline-flex; align-items:center; gap:2px; color:#ffffff;">$1 ${diamondIcon}</span>`);
            s = s.replace(/[\u{1F52E}🔮]/gu, prismIcon).replace(/[\u{1F48E}💎]/gu, diamondIcon);
            return s;
        };

        let freeTitle = '';
        const fr = item.freeReward;
        if (fr.type === 'diamonds') freeTitle = `<span style="white-space:nowrap; display:inline-flex; align-items:center; gap:3px; color:#ffffff;">+${fr.amount} ${diamondIcon}</span>`;
        else if (fr.type === 'prisms') freeTitle = `<span style="white-space:nowrap; display:inline-flex; align-items:center; gap:3px; color:#ffffff;">+${fr.amount} ${prismIcon}</span>`;
        else if (fr.type === 'ad_capsule') {
            const capTitle = (typeof t === 'function' && t('ad_capsule')) ? t('ad_capsule') : (_tr('ad_capsule') || 'Ad-Capsule');
            freeTitle = `${capTitle} <span style="white-space:nowrap; display:inline-flex; align-items:center; gap:2px; color:#ffffff;">+2 ${prismIcon}</span>`;
        }
        else if (fr.title) freeTitle = formatRewardText(fr.title);

        let freeBtnHtml = '';
        if (isFreeClaimed) {
            freeBtnHtml = `<button class="bp-cell-btn claimed-btn">${_tr('claimed')}</button>`;
        } else if (isUnlockedTier) {
            if (fr.type === 'ad_capsule') {
                freeBtnHtml = `<button class="bp-cell-btn ad-btn" onclick="claimBpFreeReward(${tNum})">${_tr('watch_ad')}</button>`;
            } else {
                freeBtnHtml = `<button class="bp-cell-btn claim-btn" onclick="claimBpFreeReward(${tNum})">${_tr('claim')}</button>`;
            }
        } else {
            freeBtnHtml = `<button class="bp-cell-btn locked-btn" onclick="claimBpFreeReward(${tNum})">${_tr('locked')}</button>`;
        }

        freeCell.innerHTML = `<span class="bp-cell-title">${freeTitle}</span>${freeBtnHtml}`;

        const numBox = document.createElement('div');
        numBox.className = 'bp-tier-num-box';
        numBox.innerHTML = `<span class="bp-tier-num">${tNum}</span><span class="bp-tier-status">${isUnlockedTier ? _tr('unlocked') : _tr('locked')}</span>`;

        const premCell = document.createElement('div');
        const isPremClaimed = !!bpClaimedPrem[tNum];
        premCell.className = `bp-cell bp-cell-prem${isPremClaimed ? ' claimed' : ''}`;

        let premTitle = '';
        const pr = item.premReward;
        if (pr.type === 'diamonds') premTitle = `<span style="white-space:nowrap; display:inline-flex; align-items:center; gap:3px; color:#ffffff;">+${pr.amount} ${diamondIcon}</span>`;
        else if (pr.type === 'prisms') premTitle = `<span style="white-space:nowrap; display:inline-flex; align-items:center; gap:3px; color:#ffffff;">+${pr.amount} ${prismIcon}</span>`;
        else if (pr.type === 'palette' || pr.type === 'perk' || pr.type === 'ultimate') {
            premTitle = formatRewardText(pr.title);
        }

        let premBtnHtml = '';
        if (isPremClaimed) {
            premBtnHtml = `<button class="bp-cell-btn claimed-btn">${_tr('claimed')}</button>`;
        } else if (bpPremiumPurchased && isUnlockedTier) {
            premBtnHtml = `<button class="bp-cell-btn claim-btn" onclick="claimBpPremReward(${tNum})">${_tr('claim')}</button>`;
        } else if (!bpPremiumPurchased) {
            premBtnHtml = `<button class="bp-cell-btn locked-btn" onclick="claimBpPremReward(${tNum})">PREMIUM</button>`;
        } else {
            premBtnHtml = `<button class="bp-cell-btn locked-btn" onclick="claimBpPremReward(${tNum})">${_tr('locked')}</button>`;
        }

        premCell.innerHTML = `<span class="bp-cell-title">${premTitle}</span>${premBtnHtml}`;

        row.appendChild(freeCell);
        row.appendChild(numBox);
        row.appendChild(premCell);

        listBody.appendChild(row);
    });
}

// [UI.EJ]
function claimBpFreeReward(tNum) {
    const { tier } = getBpTierInfo(bpXp);
    if (tier < tNum) {
        if (typeof sfx === 'function') sfx('denied');
        showHintToast(typeof t === 'function' ? t('reach_tier_first', { t: tNum }) : `Reach Tier ${tNum} first!`);
        return;
    }
    if (bpClaimedFree[tNum]) return;

    const item = BATTLE_PASS_TIERS.find(i => i.tier === tNum);
    if (!item) return;
    const fr = item.freeReward;

    // [UI.EK]
    const executeClaim = () => {
        bpClaimedFree[tNum] = true;
        let toast = '';
        if (fr.type === 'diamonds') {
            diamonds += fr.amount;
            toast = typeof t === 'function' ? t('diamonds_claimed', { n: fr.amount }) : `+${fr.amount} Diamonds claimed!`;
        } else if (fr.type === 'prisms') {
            prisms += fr.amount;
            toast = typeof t === 'function' ? t('prisms_claimed', { n: fr.amount }) : `+${fr.amount} Prisms claimed!`;
        } else if (fr.type === 'ad_capsule') {
            prisms += fr.prisms;
            toast = typeof t === 'function' ? t('ad_capsule_claimed', { n: fr.prisms }) : `Ad-Capsule: +${fr.prisms} Prisms claimed!`;
        } else if (fr.type === 'combo' || fr.paletteId || fr.type === 'palette') {
            if (fr.paletteId) {
                if (!unlockedPalettes.includes(fr.paletteId)) {
                    unlockedPalettes.push(fr.paletteId);
                }
                applyPaletteColors(fr.paletteId);
            }
            if (fr.prisms) {
                prisms += fr.prisms;
            }
            if (fr.diamonds) {
                diamonds += fr.diamonds;
            }
            toast = fr.title ? `${fr.title} claimed!` : `Unlocked ${NEON_PALETTES[fr.paletteId] ? NEON_PALETTES[fr.paletteId].name : fr.paletteId}!`;
        }
        updateDiamondUI();
        updatePrismUI();
        saveGame();
        sfx('reward');
        renderBattlePassScreen();
        showHintToast(toast);
    };

    if (fr.type === 'ad_capsule') {
        showAdPlaceholder(executeClaim, null);
    } else {
        executeClaim();
    }
}

// [UI.EL]
function claimBpPremReward(tNum) {
    if (!bpPremiumPurchased) {
        if (typeof sfx === 'function') sfx('denied');
        showHintToast(typeof t === 'function' ? t('activate_premium_first') : 'Activate Premium Pass first!');
        return;
    }
    const { tier } = getBpTierInfo(bpXp);
    if (tier < tNum) {
        if (typeof sfx === 'function') sfx('denied');
        showHintToast(typeof t === 'function' ? t('reach_tier_first', { t: tNum }) : `Reach Tier ${tNum} first!`);
        return;
    }
    if (bpClaimedPrem[tNum]) return;

    const item = BATTLE_PASS_TIERS.find(i => i.tier === tNum);
    if (!item) return;
    const pr = item.premReward;

    bpClaimedPrem[tNum] = true;
    let toast = '';

    if (pr.type === 'diamonds') {
        diamonds += pr.amount;
        toast = typeof t === 'function' ? t('diamonds_claimed', { n: pr.amount }) : `+${pr.amount} Diamonds claimed!`;
    } else if (pr.type === 'prisms') {
        prisms += pr.amount;
        toast = typeof t === 'function' ? t('prisms_claimed', { n: pr.amount }) : `+${pr.amount} Prisms claimed!`;
    } else if (pr.type === 'palette') {
        if (!unlockedPalettes.includes(pr.paletteId)) {
            unlockedPalettes.push(pr.paletteId);
        }
        applyPaletteColors(pr.paletteId);
        toast = typeof t === 'function' ? t('unlocked_palette', { name: NEON_PALETTES[pr.paletteId].name }) : `Unlocked Palette: ${NEON_PALETTES[pr.paletteId].name}!`;
    } else if (pr.type === 'perk') {
        toast = typeof t === 'function' ? t('perk_starting_reserve_unlocked') : 'Unlocked Perk: Starting Reserve (+15% Gold)!';
    } else if (pr.type === 'ultimate') {
        if (!unlockedPalettes.includes(pr.paletteId)) {
            unlockedPalettes.push(pr.paletteId);
        }
        prisms += pr.prisms;
        diamonds += pr.diamonds;
        applyPaletteColors(pr.paletteId);
        toast = typeof t === 'function' ? t('ultimate_bp_reward_claimed') : 'ULTIMATE REWARD CLAIMED! Blood Moon + 25 Prisms + 150 Diamonds';
    }

    updateDiamondUI();
    updatePrismUI();
    saveGame();
    sfx('reward');
    renderBattlePassScreen();
    showHintToast(toast);
}

// [UI.EM]

// [UI.EN]
function handleThemeShopAction(paletteId, cost) { 
    if (typeof buyThemeWithDiamonds === 'function') {
        buyThemeWithDiamonds(paletteId, cost);
    }
} 
window.handleThemeShopAction = handleThemeShopAction;

// [UI.EO]
function buyBpTierWithDiamonds() {
    const { tier, isMax } = getBpTierInfo(bpXp);
    if (isMax || (tier >= 30 && bpXp >= 3000)) {
        if (typeof sfx === 'function') sfx('denied');
        showHintToast(typeof t === 'function' ? t('synth_pass_max_tier') : 'Synth Pass already at Max Tier!');
        return;
    }
    if (diamonds < 30) {
        if (typeof sfx === 'function') sfx('denied');
        if (typeof vibrate === 'function') vibrate('warning');
        showHintToast(typeof t === 'function' ? t('not_enough_diamonds_30', { cost: 30 }) : 'Not enough Diamonds! (30 required)');
        return;
    }
    diamonds -= 30;
    addBpXp(100);
    updateDiamondUI();
    sfx('confirm');
    renderBattlePassScreen();
    showHintToast(typeof t === 'function' ? t('tier_purchased_plus_100_xp') : '+1 Tier purchased (+100 XP)!');
}

// [UI.EP]
function devAddBpXp() {}

// [UI.EQ]
function devToggleBpPremium() {}

// [UI.ER]
function closeSettings() {
  if (settingsPreviousSource !== 'levels') stopNormalModePreview();
  const settingsSc = document.getElementById('settingsScreen');
  if (settingsSc) settingsSc.classList.add('hidden');

  ['startScreen', 'victoryScreen', 'defeatScreen'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.classList.remove('screen-bg-only');
  });

  if (settingsPreviousSource === 'combat' || settingsPreviousSource === 'pause') {
    musicSetDucked(false);
    gameState = 'PLAYING';
    lastTime = performance.now();
    resumeRampTimer = RESUME_RAMP_DURATION;
  } else if (settingsPreviousSource === 'victory') {
    const scr = document.getElementById('victoryScreen');
    if (scr) scr.classList.remove('hidden');
    gameState = 'VICTORY';
  } else if (settingsPreviousSource === 'defeat') {
    const scr = document.getElementById('defeatScreen');
    if (scr) scr.classList.remove('hidden');
    gameState = 'DEFEAT';
  } else if (settingsPreviousSource === 'levels') {
    const scr = document.getElementById('levelsScreen');
    if (scr) scr.classList.remove('hidden');
    gameState = 'LEVELS';
    startModeBattlePreview(currentLevelMode);
  } else if (settingsPreviousSource === 'upgrades') {
    const scr = document.getElementById('upgradesScreen');
    if (scr) scr.classList.remove('hidden');
    gameState = 'UPGRADES';
  } else if (settingsPreviousSource === 'shop') {
    const scr = document.getElementById('shopScreen');
    if (scr) scr.classList.remove('hidden');
    gameState = 'SHOP';
  } else {
    const scr = document.getElementById('startScreen');
    if (scr) scr.classList.remove('hidden');
    gameState = 'START';
    music('menu');
  }
  syncTopHudVisibility();
  updateHudSpeedWidget();
  updateDailyBonusBtnVisibility();
}

// [UI.ES]
function toggleSettingHp(isChecked) { settings.showEnemyHp = isChecked; saveGameSoon(); }

// [UI.ET]
function toggleSettingDamage(isChecked) { settings.showDamage = isChecked; saveGameSoon(); }

// [UI.EU]
function toggleSettingVibration(isChecked) {
  settings.vibrationEnabled = isChecked;
  if (isChecked) {
    if (typeof vibrate === 'function') vibrate('medium');
    else if (navigator.vibrate) { try { navigator.vibrate(30); } catch(e){} }
  }
  saveGameSoon();
}

// [UI.EUM]
function toggleSettingScreenShake(isChecked) {
  settings.screenShakeEnabled = isChecked;
  if (!isChecked && typeof cameraShakeTimer !== 'undefined') {
    cameraShakeTimer = 0;
  }
  saveGameSoon();
}

// [UI.EV]
function applySfxVolume(pct, persist) {
  const v = Math.max(0, Math.min(100, Math.round(Number(pct) || 0)));
  settings.sfxVolume = v;
  settings.sfxEnabled = v > 0;
  sfxSetEnabled(settings.sfxEnabled);
  sfxSetVolume(v / 100);
  if (v === 0) sfxStopBeams();

  const slider = document.getElementById('settingSfxVol');
  if (slider && String(slider.value) !== String(v)) slider.value = v;
  if (slider) slider.classList.toggle('is-muted', v === 0);
  const label = document.getElementById('sfxVolLabel');
  if (label) {
    const offText = (typeof t === 'function') ? t('off') : 'OFF';
    label.textContent = v === 0 ? offText : `${v}%`;
    label.classList.toggle('is-muted', v === 0);
  }
  if (persist) saveGameSoon();
}

// [UI.EW]
function applyMusicVolume(pct, persist) {
  const v = Math.max(0, Math.min(100, Math.round(Number(pct) || 0)));
  settings.musicVolume = v;
  settings.musicEnabled = v > 0;
  musicSetEnabled(settings.musicEnabled);
  musicSetVolume(v / 100);

  const slider = document.getElementById('settingMusicVol');
  if (slider && String(slider.value) !== String(v)) slider.value = v;
  if (slider) slider.classList.toggle('is-muted', v === 0);
  const label = document.getElementById('musicVolLabel');
  if (label) {
    const offText = (typeof t === 'function') ? t('off') : 'OFF';
    label.textContent = v === 0 ? offText : `${v}%`;
    label.classList.toggle('is-muted', v === 0);
  }
  if (persist) saveGameSoon();
}

// [UI.EX]
function setSfxVolume(pct) { applySfxVolume(pct, true); }
// [UI.EY]
function setMusicVolume(pct) { applyMusicVolume(pct, true); }

// [UI.EZ]
function toggleSettingPerf(isChecked) {
  perfMode = isChecked ? 'low' : 'high';
  settings.perfModeOverride = perfMode;
  perfDecided = true;
  saveGameSoon();
}

// [UI.FA]
(function initLevelSelectSwipeGesture() {
  let touchStartX = 0;
  let touchStartY = 0;
  let touchStartTime = 0;
  let isSwiping = false;
  let swipeTriggered = false;
  let isPointerDown = false;
  let swipeResetTimer = null;

  function scheduleSwipeStateReset(delayMs = 120) {
    if (swipeResetTimer) clearTimeout(swipeResetTimer);
    swipeResetTimer = setTimeout(() => {
      isSwiping = false;
      swipeTriggered = false;
      swipeResetTimer = null;
    }, delayMs);
  }

  // [UI.FB]
  function onPointerDown(e) {
    if (gameState !== 'LEVELS') return;
    const levelsScreen = document.getElementById('levelsScreen');
    if (!levelsScreen || levelsScreen.classList.contains('hidden')) return;

    // Любое новое касание экрана — это новый жест; сбрасываем хвост от предыдущего свайпа
    if (swipeResetTimer) {
      clearTimeout(swipeResetTimer);
      swipeResetTimer = null;
    }
    isSwiping = false;
    swipeTriggered = false;

    if (e.target && e.target.closest && e.target.closest('.mode-3way-tab, .levels-main-menu-btn, .hud-gear-btn, .part-nav-btn, .loadout-widget')) {
      isPointerDown = false;
      return;
    }

    isPointerDown = true;
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;

    touchStartX = clientX;
    touchStartY = clientY;
    touchStartTime = performance.now();
  }

  // [UI.FC]
  function onPointerMove(e) {
    if (!isPointerDown || gameState !== 'LEVELS' || swipeTriggered || isNavigatingSection) return;
    if (!e.touches && e.buttons === 0) {
      isPointerDown = false;
      return;
    }

    const levelsScreen = document.getElementById('levelsScreen');
    if (!levelsScreen || levelsScreen.classList.contains('hidden')) return;

    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;

    const deltaX = clientX - touchStartX;
    const deltaY = clientY - touchStartY;
    const minDistance = 35;

    if (Math.abs(deltaX) >= minDistance && Math.abs(deltaX) > Math.abs(deltaY) * 1.2) {
      swipeTriggered = true;
      isSwiping = true;
      isPointerDown = false;
      scheduleSwipeStateReset(180);
      if (deltaX < 0) {
        navLevelSection(1);
      } else {
        navLevelSection(-1);
      }
    }
  }

  // [UI.FD]
  function onPointerUp(e) {
    if (swipeTriggered || isSwiping) {
      isPointerDown = false;
      scheduleSwipeStateReset(80);
      return;
    }
    if (!isPointerDown || gameState !== 'LEVELS') {
      isPointerDown = false;
      return;
    }
    isPointerDown = false;

    const levelsScreen = document.getElementById('levelsScreen');
    if (!levelsScreen || levelsScreen.classList.contains('hidden')) return;

    const clientX = e.changedTouches ? e.changedTouches[0].clientX : e.clientX;
    const clientY = e.changedTouches ? e.changedTouches[0].clientY : e.clientY;

    const deltaX = clientX - touchStartX;
    const deltaY = clientY - touchStartY;
    const duration = performance.now() - touchStartTime;

    const minDistance = 35;
    const maxDuration = 600;

    if (duration <= maxDuration && Math.abs(deltaX) >= minDistance && Math.abs(deltaX) > Math.abs(deltaY) * 1.2) {
      swipeTriggered = true;
      isSwiping = true;
      scheduleSwipeStateReset(80);
      if (deltaX < 0) {
        navLevelSection(1);
      } else {
        navLevelSection(-1);
      }
    }
  }

  // [UI.FE]
  function onClickCapture(e) {
    // Никогда не блокируем нажатия на навигационные кнопки
    if (e.target && e.target.closest && e.target.closest('.levels-main-menu-btn, .mode-3way-tab, .hud-gear-btn, .part-nav-btn')) {
      isSwiping = false;
      swipeTriggered = false;
      return;
    }
    if (isSwiping || swipeTriggered) {
      e.stopPropagation();
      e.preventDefault();
      scheduleSwipeStateReset(30);
    }
  }

  // [UI.FF]
  function setupListeners() {
    const levelsScreen = document.getElementById('levelsScreen');
    if (levelsScreen) {
      levelsScreen.addEventListener('touchstart', onPointerDown, { passive: true });
      levelsScreen.addEventListener('touchmove', onPointerMove, { passive: true });
      levelsScreen.addEventListener('touchend', onPointerUp, { passive: true });
      levelsScreen.addEventListener('touchcancel', () => {
        isPointerDown = false;
        scheduleSwipeStateReset(50);
      }, { passive: true });
      levelsScreen.addEventListener('mousedown', onPointerDown);
      levelsScreen.addEventListener('mousemove', onPointerMove);
      levelsScreen.addEventListener('mouseup', onPointerUp);
      levelsScreen.addEventListener('mouseleave', () => { isPointerDown = false; });
      levelsScreen.addEventListener('click', onClickCapture, true);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', setupListeners);
  } else {
    setupListeners();
  }
})();

// [UI.FIM] Shared HUD & screen transition helper for entering #levelsScreen.
function _enterLevelSelectView() {
  if (reviveTimerInterval) { clearInterval(reviveTimerInterval); reviveTimerInterval = null; }
  document.getElementById('levelsScreen').classList.remove('hidden');
  document.getElementById('econHpSplitBadge').classList.add('hidden');
  document.getElementById('levelWaveSplitBadge').classList.add('hidden');
  document.getElementById('hudRightGroup').classList.remove('hidden');
  updateStartChapterLabel(false);
  document.getElementById('controlsWrapper').classList.add('hidden');

  const waveBtn = document.getElementById('waveBtn');
  if (waveBtn) waveBtn.classList.add('hidden');

  const customSpawner = document.getElementById('devCustomSpawner');
  if (customSpawner) customSpawner.classList.add('hidden');

  currentLevelSection = Math.min(TOTAL_SECTIONS, Math.max(1, Math.ceil(currentLevel / LEVELS_PER_SECTION)));
  if (typeof modeLevelSections !== 'undefined' && currentLevelMode) {
    modeLevelSections[currentLevelMode] = currentLevelSection;
  }
  gameState = 'LEVELS';
  renderLevelsGrid();
  showLoadoutWidgetIn('loadoutAnchor-levels');
  updateHudSpeedWidget();

  syncTopHudVisibility();
  updateDailyBonusBtnVisibility();
}

// [UI.FI]
function showLevelSelect() {
  stopNormalModePreview();
  music('menu');
  document.getElementById('startScreen').classList.add('hidden');
  _enterLevelSelectView();
}

// [UI.FJ]
function giveUpMatch() {
  const confirmModal = document.getElementById('giveUpConfirmModal');
  if (confirmModal) {
    confirmModal.classList.remove('hidden');
  } else {
    confirmGiveUp();
  }
}

// [UI.FK]
function cancelGiveUp() {
  const confirmModal = document.getElementById('giveUpConfirmModal');
  if (confirmModal) {
    confirmModal.classList.add('hidden');
  }
}

// [UI.FL]
function confirmGiveUp() {
  const confirmModal = document.getElementById('giveUpConfirmModal');
  if (confirmModal) confirmModal.classList.add('hidden');

  if (reviveTimerInterval) { clearInterval(reviveTimerInterval); reviveTimerInterval = null; }
  const settingsSc = document.getElementById('settingsScreen');
  if (settingsSc) settingsSc.classList.add('hidden');
  const pauseSc = document.getElementById('pauseScreen');
  if (pauseSc) pauseSc.classList.add('hidden');

  if (typeof triggerDefeat === 'function') {
    triggerDefeat();
  } else {
    musicSetDucked(false);
    music('lose');
    sfx('defeat');
    gameState = 'DEFEAT';
    document.getElementById('defeatScreen').classList.remove('hidden');
    if (typeof replayDefeatFlash === 'function') replayDefeatFlash();
  }
}

// [UI.FM]
function showLevelSelectFromGame() {
  stopNormalModePreview();
  const curCat = (typeof MusicManager !== 'undefined' && MusicManager.current) ? MusicManager.current() : null;
  if (curCat !== 'win' && curCat !== 'lose') {
    music('menu');
  }

  ['startScreen', 'victoryScreen', 'defeatScreen'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.classList.remove('screen-bg-only');
  });

  ['settingsScreen', 'pauseScreen', 'victoryScreen', 'defeatScreen', 'upgradesScreen', 'reviveScreen'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.classList.add('hidden');
  });

  _enterLevelSelectView();
}

// [UI.FN]
function showLoadoutWidgetIn(anchorId) {
  const widget = document.getElementById('loadoutWidget');
  const anchor = document.getElementById(anchorId);
  if (!widget || !anchor) return;

  refreshLoadoutForProgress();

  if (getLoadoutReferenceLevel() < getLoadoutStartLevel()) {
    widget.classList.add('hidden');
    return;
  }

  anchor.appendChild(widget);
  widget.classList.remove('hidden');
  loadoutWidgetExpanded = false;
  const arrow = document.getElementById('loadoutArrow');
  if (arrow) arrow.textContent = '▾';
  renderLoadoutWidgetBody();
}

// [UI.FO]
function toggleLoadoutWidgetExpanded() {
  loadoutWidgetExpanded = !loadoutWidgetExpanded;
  if (!loadoutWidgetExpanded) {
    refreshLoadoutForProgress();
  }
  const arrow = document.getElementById('loadoutArrow');
  if (arrow) {
    arrow.textContent = loadoutWidgetExpanded ? '▴' : '▾';
  }
  renderLoadoutWidgetBody();
}

// [UI.FP]
function renderLoadoutWidgetBody() {
  const miniIcons = document.getElementById('loadoutWidgetMiniIcons');
  const expandedBox = document.getElementById('loadoutWidgetExpanded');
  const countEl = document.getElementById('loadoutWidgetCount');

  if (countEl) {
    countEl.textContent = `${selectedLoadout.length}/${LOADOUT_SIZE}`;
    countEl.classList.toggle('is-full', selectedLoadout.length >= LOADOUT_SIZE);
    countEl.classList.toggle('hidden', !loadoutWidgetExpanded);
  }

  if (!miniIcons || !expandedBox) return;

  if (loadoutWidgetExpanded) {
    miniIcons.innerHTML = '';
    expandedBox.classList.remove('hidden');
    renderLoadoutWidgetGrid();
  } else {
    const canonicalOrder = Object.keys(TOWER_CONFIGS);
    const orderedLoadout = canonicalOrder.filter(t => selectedLoadout.includes(t));
    miniIcons.innerHTML = orderedLoadout.map(t => {
      return `<span class="loadout-mini-icon">${TOWER_ICONS[t] || ''}</span>`;
    }).join('');
    expandedBox.classList.add('hidden');
  }
}

// [UI.FQ]
function renderLoadoutWidgetGrid() {
  const grid = document.getElementById('loadoutWidgetGrid');
  if (!grid) return;
  const pool = (typeof getPlayerUnlockedTowers === 'function')
    ? getPlayerUnlockedTowers()
    : ['gun'];

  const isFull = selectedLoadout.length >= LOADOUT_SIZE;
  grid.innerHTML = '';
  pool.forEach(type => {
    const conf = TOWER_CONFIGS[type];
    if (!conf) return;
    const isSelected = selectedLoadout.includes(type);
    const btn = document.createElement('div');
    btn.className = 'loadout-tower-btn'
      + (isSelected ? ' selected' : '')
      + (!isSelected && isFull ? ' blocked' : '');
    btn.innerHTML = `
      <div class="tower-btn-icon">${TOWER_ICONS[type] || ''}</div>
      <span class="tower-btn-title">${TOWER_NAMES[type] || type}</span>
    `;
    // [UI.FR]
    btn.onclick = (e) => {
      e.stopPropagation();
      toggleLoadoutWidgetTower(type);
    };
    grid.appendChild(btn);
  });
}

// [UI.FS]
function toggleLoadoutWidgetTower(type) {
  sfx('tap');
  const idx = selectedLoadout.indexOf(type);
  if (idx !== -1) {
    selectedLoadout.splice(idx, 1);
  } else {
    if (selectedLoadout.length >= LOADOUT_SIZE) {
      showHintToast(typeof t === 'function' ? t('deselect_tower_first', { max: LOADOUT_SIZE }) : `Deselect a tower first (${LOADOUT_SIZE} max)`);
      return;
    }
    selectedLoadout.push(type);
  }
  renderLoadoutWidgetBody();
  saveGameSoon();
}

// [UI.FT]
function hasMilestoneForLevel(clearedLevel) {
  return buildMilestoneSteps(clearedLevel).length > 0;
}
window.hasMilestoneForLevel = hasMilestoneForLevel;

// [UI.FU]
function buildTowerFiringDemoHtml(type) {
  const conf = (typeof TOWER_CONFIGS !== 'undefined' && TOWER_CONFIGS[type]) ? TOWER_CONFIGS[type] : { color: '#00e5ff' };
  const col = conf.color || '#00e5ff';
  return `
    <div class="ms-firing-stage" style="--stage-col:${col};">
      <canvas id="milestoneTowerPreviewCanvas"></canvas>
      <div class="ms-firing-dimmer"></div>
    </div>`;
}

// [UI.FUM] Autonomous real-renderer showcase for all 7 tower classes on #milestoneScreen.
const MilestoneTowerPreview = (() => {
  const COLS_M = 6;
  const ROWS_M = 3;
  const T_SIZE = 70;
  const VIEW_W = COLS_M * T_SIZE; // 420
  const VIEW_H = ROWS_M * T_SIZE; // 210

  let _type = 'gun';
  let _rafId = null;
  let _lastTs = 0;
  let _lastDt = 0.016;
  let _simTime = 0;

  let _gridCaches = {};
  let _enemies = [];
  let _projectiles = [];
  let _bolts = [];
  let _railBeams = [];
  let _stasisWaves = [];
  let _steamPuffs = [];
  let _fxParts = [];
  let _fxWaves = [];

  let _spawnTimer = 0;
  let _beamHitTimer = 0;

  const _tower = {
    type: 'gun',
    x: 2.5 * T_SIZE,
    y: 1.5 * T_SIZE,
    range: 165,
    angle: Math.PI * 0.5,
    fireCooldown: 0.25,
    lastFire: -10,
    shotIndex: 0,
    heatProgress: 0,
    isCooling: false,
    coolTimer: 0,
    steamTimer: 0
  };

  function withIsolatedFx(fn) {
    const prevParts = fxLayerParts;
    const prevWaves = fxLayerWaves;
    fxLayerParts = _fxParts;
    fxLayerWaves = _fxWaves;
    try {
      fn();
    } finally {
      fxLayerParts = prevParts;
      fxLayerWaves = prevWaves;
    }
  }

  function buildGridCache(isRail, th) {
    const c1Rgb = th.rgb1 ? th.rgb1.cssRgb : '0, 229, 255';
    const off = document.createElement('canvas');
    off.width = VIEW_W;
    off.height = VIEW_H;
    const oCtx = off.getContext('2d');

    const pathRow = isRail ? 1 : 2;
    for (let r = 0; r < ROWS_M; r++) {
      for (let c = 0; c < COLS_M; c++) {
        const isPath = (r === pathRow) && (!isRail || c >= 1);
        oCtx.fillStyle = isPath ? `rgba(${c1Rgb}, 0.08)` : 'rgba(8, 12, 26, 0.42)';
        oCtx.fillRect(c * T_SIZE, r * T_SIZE, T_SIZE, T_SIZE);
        oCtx.strokeStyle = isPath ? `rgba(${c1Rgb}, 0.20)` : `rgba(${c1Rgb}, 0.13)`;
        oCtx.lineWidth = 1;
        oCtx.strokeRect(c * T_SIZE, r * T_SIZE, T_SIZE, T_SIZE);
      }
    }

    const py = (pathRow + 0.5) * T_SIZE;
    const hr = 18;
    const xStart = isRail ? 1.35 * T_SIZE : 0;
    oCtx.save();
    oCtx.strokeStyle = `rgba(${c1Rgb}, 0.36)`;
    oCtx.lineWidth = 1.6;
    oCtx.beginPath();
    oCtx.moveTo(xStart, py - hr); oCtx.lineTo(VIEW_W, py - hr);
    oCtx.moveTo(xStart, py + hr); oCtx.lineTo(VIEW_W, py + hr);
    oCtx.stroke();
    oCtx.restore();

    const chevCol = th.c1 || '#00e5ff';
    if (isRail) {
      for (let i = 0; i < 3; i++) {
        drawNeonChevron(oCtx, VIEW_W - 22 - i * 13, py, Math.PI, 10, chevCol);
      }
    } else {
      for (let i = 0; i < 3; i++) {
        drawNeonChevron(oCtx, 18 + i * 13, py, 0, 10, chevCol);
      }
    }
    return off;
  }

  function makeEnemy(eType, x, y, hp, speed, radius, dirX) {
    const cfg = (typeof ENEMY_CONFIGS !== 'undefined' && ENEMY_CONFIGS[eType]) ? ENEMY_CONFIGS[eType] : null;
    const defCols = { grunt: '#f05f9f', scout: '#ff9100', tank: '#a06fdc', swarm: '#00ffcc' };
    return {
      type: eType,
      color: (cfg && cfg.color) || defCols[eType] || '#f05f9f',
      radius: radius || 11,
      speed: speed || 54,
      hp: hp,
      maxHp: hp,
      x: x,
      y: y,
      dirX: dirX || 1,
      angle: (dirX || 1) >= 0 ? 0 : Math.PI,
      spawnTimer: 0.20,
      spawnDuration: 0.20,
      slowTimer: 0,
      slowFactor: 1.0,
      hitTilt: 0,
      _fxKbX: 0,
      _fxKbY: 0,
      _fxJitT: 0
    };
  }

  function spawnScenarioWave(initial) {
    const py = (_type === 'railgun') ? (1.5 * T_SIZE) : (2.5 * T_SIZE);
    if (_type === 'gun') {
      const base = initial ? 95 : -16;
      _enemies.push(makeEnemy('grunt', base, py, 56, 56, 11, 1));
      if (initial) _enemies.push(makeEnemy('grunt', base - 58, py, 56, 56, 11, 1));
    } else if (_type === 'laser') {
      const base = initial ? 105 : -16;
      const t = (Math.random() > 0.45) ? 'grunt' : 'scout';
      _enemies.push(makeEnemy(t, base, py, t === 'grunt' ? 70 : 48, t === 'grunt' ? 54 : 74, t === 'grunt' ? 11 : 10, 1));
    } else if (_type === 'mortar') {
      const base = initial ? 115 : -16;
      _enemies.push(makeEnemy('grunt', base,      py - 4, 64, 48, 11, 1));
      _enemies.push(makeEnemy('swarm', base - 22, py + 7, 36, 48, 8,  1));
      _enemies.push(makeEnemy('swarm', base - 38, py - 6, 36, 48, 8,  1));
      _enemies.push(makeEnemy('grunt', base - 56, py + 2, 64, 48, 11, 1));
    } else if (_type === 'tesla') {
      const base = initial ? 120 : -16;
      _enemies.push(makeEnemy('scout', base,      py - 3, 52, 60, 10, 1));
      _enemies.push(makeEnemy('swarm', base - 30, py + 6, 40, 60, 8,  1));
      _enemies.push(makeEnemy('swarm', base - 58, py - 5, 40, 60, 8,  1));
      _enemies.push(makeEnemy('scout', base - 86, py + 3, 52, 60, 10, 1));
    } else if (_type === 'stasis') {
      const base = initial ? 90 : -16;
      _enemies.push(makeEnemy('scout', base, py, 999, 102, 10, 1));
      if (initial) _enemies.push(makeEnemy('scout', base - 72, py, 999, 102, 10, 1));
    } else if (_type === 'melter') {
      if (_enemies.length === 0) {
        _enemies.push(makeEnemy('tank', initial ? 78 : -20, py, 420, 32, 15, 1));
      }
    } else if (_type === 'railgun') {
      const base = initial ? 310 : VIEW_W + 18;
      _enemies.push(makeEnemy('grunt', base,      py, 75, 42, 11, -1));
      _enemies.push(makeEnemy('grunt', base + 56, py, 75, 42, 11, -1));
      _enemies.push(makeEnemy('tank',  base + 114, py, 140, 42, 14, -1));
    }
  }

  function findTarget() {
    const rSq = _tower.range * _tower.range;
    for (let i = 0; i < _enemies.length; i++) {
      const e = _enemies[i];
      const dx = e.x - _tower.x, dy = e.y - _tower.y;
      if (dx * dx + dy * dy <= rSq) return e;
    }
    return null;
  }

  function damageEnemy(e, dmg, hitAng, fxKind, fxCol, kbMag) {
    e.hp -= dmg;
    e.hitTilt = (Math.random() > 0.5 ? 1 : -1) * 0.15;
    e._fxKbX = Math.cos(hitAng) * (kbMag || 3.5);
    e._fxKbY = Math.sin(hitAng) * (kbMag || 3.5);
    e._fxJitT = 0.14;
    const killed = e.hp <= 0;
    if (typeof spawnFxHitLayers === 'function') {
      withIsolatedFx(() => {
        spawnFxHitLayers(e.x, e.y, killed ? 'mortar' : fxKind, killed ? e.color : fxCol, hitAng, e.radius);
      });
    }
    if (killed) {
      const idx = _enemies.indexOf(e);
      if (idx !== -1) _enemies.splice(idx, 1);
    }
  }

  function step(dt) {
    _lastDt = dt;
    _simTime += dt;
    const kbDecay = Math.exp(-14 * dt);

    // Spawn waves
    _spawnTimer -= dt;
    if (_spawnTimer <= 0) {
      if (_type === 'gun') _spawnTimer = 1.45;
      else if (_type === 'laser') _spawnTimer = 1.65;
      else if (_type === 'mortar') _spawnTimer = 3.2;
      else if (_type === 'tesla') _spawnTimer = 2.8;
      else if (_type === 'stasis') _spawnTimer = 1.75;
      else if (_type === 'melter') _spawnTimer = 1.2;
      else if (_type === 'railgun') _spawnTimer = 3.1;
      spawnScenarioWave(false);
    }

    // Move enemies
    for (let i = _enemies.length - 1; i >= 0; i--) {
      const e = _enemies[i];
      if (e.spawnTimer > 0) e.spawnTimer = Math.max(0, e.spawnTimer - dt);
      if (e.slowTimer > 0) {
        e.slowTimer = Math.max(0, e.slowTimer - dt);
        if (e.slowTimer <= 0) e.slowFactor = 1.0;
      }
      const effSpeed = e.speed * (e.slowTimer > 0 ? e.slowFactor : 1.0);
      e.x += e.dirX * effSpeed * dt;
      if (e._fxJitT > 0) e._fxJitT = Math.max(0, e._fxJitT - dt);
      e.hitTilt *= kbDecay;
      e._fxKbX *= kbDecay;
      e._fxKbY *= kbDecay;

      const outRight = (e.dirX > 0 && e.x > VIEW_W + 28);
      const outLeft = (e.dirX < 0 && e.x < 1.35 * T_SIZE);
      if (outRight || outLeft) _enemies.splice(i, 1);
    }

    // Update bolts, rail beams, stasis waves, steam puffs
    for (let i = _bolts.length - 1; i >= 0; i--) {
      _bolts[i].life -= dt;
      if (_bolts[i].life <= 0) _bolts.splice(i, 1);
    }
    for (let i = _railBeams.length - 1; i >= 0; i--) {
      _railBeams[i].life -= dt;
      if (_railBeams[i].life <= 0) _railBeams.splice(i, 1);
    }
    for (let i = _stasisWaves.length - 1; i >= 0; i--) {
      const sw = _stasisWaves[i];
      sw.life -= dt;
      sw.r = sw.maxR * (1 - sw.life / sw.maxLife);
      if (sw.life <= 0) _stasisWaves.splice(i, 1);
    }
    for (let i = _steamPuffs.length - 1; i >= 0; i--) {
      const sp = _steamPuffs[i];
      sp.life -= dt;
      sp.x += sp.vx * dt;
      sp.y += sp.vy * dt;
      sp.r += 10 * dt;
      if (sp.life <= 0) _steamPuffs.splice(i, 1);
    }

    const tCfg = (typeof TOWER_CONFIGS !== 'undefined' && TOWER_CONFIGS[_type]) ? TOWER_CONFIGS[_type] : null;
    const tCol = (tCfg && tCfg.color) || '#00e5ff';
    const target = findTarget();

    if (_tower.fireCooldown > 0) _tower.fireCooldown = Math.max(0, _tower.fireCooldown - dt);

    // Aim tower
    if (target && _type !== 'stasis' && _type !== 'railgun') {
      const desired = Math.atan2(target.y - _tower.y, target.x - _tower.x);
      let diff = desired - _tower.angle;
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
      const maxTurn = 11 * dt;
      _tower.angle += Math.abs(diff) <= maxTurn ? diff : Math.sign(diff) * maxTurn;
    }

    // Per-tower firing logic
    if (_type === 'gun' && target && _tower.fireCooldown <= 0) {
      _tower.fireCooldown = 0.34;
      _tower.lastFire = _simTime;
      const cosA = Math.cos(_tower.angle), sinA = Math.sin(_tower.angle);
      const side = (_tower.shotIndex === 0) ? -3.5 : 3.5;
      const mx = _tower.x + cosA * 24 - sinA * side;
      const my = _tower.y + sinA * 24 + cosA * side;
      _tower.shotIndex = (_tower.shotIndex + 1) % 2;
      if (typeof spawnFxMuzzleLayers === 'function') {
        withIsolatedFx(() => spawnFxMuzzleLayers(mx, my, 'gun', tCol, _tower.angle));
      }
      _projectiles.push({ kind: 'bullet', x: mx, y: my, target, speed: 460, damage: 18, color: tCol });

    } else if (_type === 'laser' && target) {
      target.hp -= 30 * dt;
      target._fxJitT = 0.10;
      _beamHitTimer -= dt;
      if (_beamHitTimer <= 0) {
        _beamHitTimer = 0.10;
        const ang = Math.atan2(target.y - _tower.y, target.x - _tower.x);
        if (typeof spawnFxHitLayers === 'function') {
          withIsolatedFx(() => spawnFxHitLayers(target.x, target.y, 'laser', tCol, ang, target.radius));
        }
      }
      if (target.hp <= 0) {
        const ang = Math.atan2(target.y - _tower.y, target.x - _tower.x);
        damageEnemy(target, 1, ang, 'laser', tCol, 2.0);
      }

    } else if (_type === 'mortar' && target && _tower.fireCooldown <= 0) {
      _tower.fireCooldown = 1.55;
      _tower.lastFire = _simTime;
      const mx = _tower.x + Math.cos(_tower.angle) * 14;
      const my = _tower.y + Math.sin(_tower.angle) * 14;
      if (typeof spawnFxMuzzleLayers === 'function') {
        withIsolatedFx(() => spawnFxMuzzleLayers(mx, my, 'mortar', tCol, _tower.angle));
      }
      const leadX = Math.min(VIEW_W - 24, target.x + target.speed * 0.45);
      _projectiles.push({
        kind: 'mortar', startX: mx, startY: my, x: mx, y: my,
        tx: leadX, ty: target.y, t: 0, dur: 0.56, splashR: 72, damage: 46, color: tCol
      });

    } else if (_type === 'tesla' && target && _tower.fireCooldown <= 0) {
      _tower.fireCooldown = 0.95;
      _tower.lastFire = _simTime;
      const hitList = [target];
      let cur = target;
      for (let chain = 0; chain < 2; chain++) {
        let best = null, bestD = 120 * 120;
        for (let i = 0; i < _enemies.length; i++) {
          const cand = _enemies[i];
          if (hitList.indexOf(cand) !== -1) continue;
          const dSq = (cand.x - cur.x) ** 2 + (cand.y - cur.y) ** 2;
          if (dSq < bestD) { bestD = dSq; best = cand; }
        }
        if (!best) break;
        hitList.push(best);
        cur = best;
      }
      let px = _tower.x, py = _tower.y;
      for (let i = 0; i < hitList.length; i++) {
        const e = hitList[i];
        const ang = Math.atan2(e.y - py, e.x - px);
        _bolts.push({ x1: px, y1: py, x2: e.x, y2: e.y, color: tCol, life: 0.24, maxLife: 0.24 });
        damageEnemy(e, 24, ang, 'tesla', tCol, 2.5);
        px = e.x; py = e.y;
      }

    } else if (_type === 'stasis' && target && _tower.fireCooldown <= 0) {
      _tower.fireCooldown = 1.25;
      _tower.lastFire = _simTime;
      _stasisWaves.push({ x: _tower.x, y: _tower.y, r: 10, maxR: _tower.range, life: 0.45, maxLife: 0.45, color: tCol });
      const rSq = _tower.range * _tower.range;
      for (let i = 0; i < _enemies.length; i++) {
        const e = _enemies[i];
        const dx = e.x - _tower.x, dy = e.y - _tower.y;
        if (dx * dx + dy * dy <= rSq) {
          e.slowTimer = 1.65;
          e.slowFactor = 0.40;
          if (typeof spawnFxHitLayers === 'function') {
            withIsolatedFx(() => spawnFxHitLayers(e.x, e.y, 'stasis', tCol, Math.atan2(dy, dx), e.radius));
          }
        }
      }

    } else if (_type === 'melter') {
      if (_tower.isCooling) {
        _tower.coolTimer = Math.max(0, _tower.coolTimer - dt);
        _tower.heatProgress = _tower.coolTimer / 2.2;
        _tower.steamTimer -= dt;
        if (_tower.steamTimer <= 0) {
          _tower.steamTimer = 0.14;
          _steamPuffs.push({
            x: _tower.x + (Math.random() - 0.5) * 14,
            y: _tower.y - 6,
            vx: (Math.random() - 0.5) * 14,
            vy: -22 - Math.random() * 14,
            r: 4 + Math.random() * 3,
            life: 0.65, maxLife: 0.65
          });
        }
        if (_tower.coolTimer <= 0) {
          _tower.isCooling = false;
          _tower.heatProgress = 0;
        }
      } else if (target) {
        _tower.heatProgress = Math.min(1, _tower.heatProgress + dt / 3.0);
        const dps = 18 + 85 * (_tower.heatProgress * _tower.heatProgress);
        target.hp = Math.max(25, target.hp - dps * dt);
        target._fxJitT = 0.10;
        _beamHitTimer -= dt;
        if (_beamHitTimer <= 0) {
          _beamHitTimer = 0.10;
          const ang = Math.atan2(target.y - _tower.y, target.x - _tower.x);
          if (typeof spawnFxHitLayers === 'function') {
            withIsolatedFx(() => spawnFxHitLayers(target.x, target.y, 'melter', tCol, ang, target.radius));
          }
        }
        if (_tower.heatProgress >= 1.0) {
          _tower.isCooling = true;
          _tower.coolTimer = 2.2;
          _tower.steamTimer = 0;
        }
      } else {
        _tower.heatProgress = Math.max(0, _tower.heatProgress - dt * 0.6);
      }

    } else if (_type === 'railgun' && _enemies.length > 0 && _tower.fireCooldown <= 0) {
      // Wait until at least one mob is well inside the track
      const ready = _enemies.some(e => e.x < VIEW_W - 60);
      if (ready) {
        _tower.fireCooldown = 1.85;
        _tower.lastFire = _simTime;
        const mx = _tower.x + 24;
        const my = _tower.y;
        if (typeof spawnFxMuzzleLayers === 'function') {
          withIsolatedFx(() => spawnFxMuzzleLayers(mx, my, 'railgun', tCol, 0));
        }
        _railBeams.push({ x1: mx, y1: my, x2: VIEW_W + 10, y2: my, color: tCol, life: 0.38, maxLife: 0.38 });
        const snap = _enemies.slice();
        for (let i = 0; i < snap.length; i++) {
          damageEnemy(snap[i], 76, 0, 'railgun', tCol, 8.5);
        }
      }
    }

    // Step projectiles (gun bullets & mortar shells)
    for (let i = _projectiles.length - 1; i >= 0; i--) {
      const p = _projectiles[i];
      if (p.kind === 'bullet') {
        if (!p.target || p.target.hp <= 0 || _enemies.indexOf(p.target) === -1) {
          _projectiles.splice(i, 1);
          continue;
        }
        const dx = p.target.x - p.x, dy = p.target.y - p.y;
        const dist = Math.hypot(dx, dy);
        const stepD = p.speed * dt;
        if (dist <= stepD + p.target.radius * 0.7) {
          damageEnemy(p.target, p.damage, Math.atan2(dy, dx), 'gun', p.color, 3.5);
          _projectiles.splice(i, 1);
        } else {
          p.x += (dx / dist) * stepD;
          p.y += (dy / dist) * stepD;
        }
      } else if (p.kind === 'mortar') {
        p.t += dt / p.dur;
        const u = Math.min(1, p.t);
        p.x = p.startX + (p.tx - p.startX) * u;
        p.y = p.startY + (p.ty - p.startY) * u;
        p.arcY = p.y - Math.sin(u * Math.PI) * 52;
        if (p.t >= 1) {
          if (typeof spawnFxHitLayers === 'function') {
            withIsolatedFx(() => spawnFxHitLayers(p.tx, p.ty, 'mortar', p.color, null, 14));
          }
          const snap = _enemies.slice();
          for (let j = 0; j < snap.length; j++) {
            const e = snap[j];
            const d = Math.hypot(e.x - p.tx, e.y - p.ty);
            if (d <= p.splashR) {
              damageEnemy(e, p.damage, Math.atan2(e.y - p.ty, e.x - p.tx), 'mortar', p.color, 4.5);
            }
          }
          _projectiles.splice(i, 1);
        }
      }
    }
  }

  function render(now) {
    const pCanvas = document.getElementById('milestoneTowerPreviewCanvas');
    if (!pCanvas) return;
    const rect = pCanvas.getBoundingClientRect();
    if (rect.width < 10 || rect.height < 10) return;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const pw = Math.round(rect.width * dpr);
    const ph = Math.round(rect.height * dpr);
    if (pCanvas.width !== pw || pCanvas.height !== ph) {
      pCanvas.width = pw;
      pCanvas.height = ph;
    }

    const pCtx = pCanvas.getContext('2d');
    const th = (typeof getTheme === 'function') ? getTheme() : { id: 'default', c1: '#00e5ff', rgb1: { cssRgb: '0, 229, 255' } };
    const isRail = (_type === 'railgun');
    const cacheKey = (isRail ? 'rail_' : 'std_') + (th.id || 'default');
    if (!_gridCaches[cacheKey]) {
      _gridCaches[cacheKey] = buildGridCache(isRail, th);
    }

    const c1Rgb = th.rgb1 ? th.rgb1.cssRgb : '0, 229, 255';
    const previewScale = Math.max(rect.width / VIEW_W, rect.height / VIEW_H);
    const offsetX = (rect.width - VIEW_W * previewScale) * 0.5;
    const offsetY = (rect.height - VIEW_H * previewScale) * 0.5;

    pCtx.save();
    pCtx.scale(dpr, dpr);
    pCtx.clearRect(0, 0, rect.width, rect.height);
    pCtx.translate(offsetX, offsetY);
    pCtx.scale(previewScale, previewScale);

    // 1. Baked grid & rails
    pCtx.drawImage(_gridCaches[cacheKey], 0, 0);

    // Running dashed rails
    const pathRow = isRail ? 1 : 2;
    const py = (pathRow + 0.5) * T_SIZE;
    const hr = 18;
    const xStart = isRail ? 1.35 * T_SIZE : 0;
    pCtx.save();
    pCtx.strokeStyle = `rgba(${c1Rgb}, 0.80)`;
    pCtx.lineWidth = 1.6;
    pCtx.setLineDash([12, 10]);
    pCtx.lineDashOffset = (isRail ? 1 : -1) * (_simTime * 36);
    pCtx.beginPath();
    pCtx.moveTo(xStart, py - hr); pCtx.lineTo(VIEW_W, py - hr);
    pCtx.moveTo(xStart, py + hr); pCtx.lineTo(VIEW_W, py + hr);
    pCtx.stroke();
    pCtx.restore();

    const tCfg = (typeof TOWER_CONFIGS !== 'undefined' && TOWER_CONFIGS[_type]) ? TOWER_CONFIGS[_type] : null;
    const tCol = (tCfg && tCfg.color) || '#00e5ff';
    const tGlow = (tCfg && tCfg.glow) || tCol;
    const target = findTarget();

    // Range circle (stasis gets soft cyan fill too)
    if (!isRail) {
      pCtx.save();
      pCtx.beginPath();
      pCtx.arc(_tower.x, _tower.y, _tower.range, 0, Math.PI * 2);
      if (_type === 'stasis') {
        pCtx.fillStyle = 'rgba(56, 189, 248, 0.08)';
        pCtx.fill();
        pCtx.strokeStyle = 'rgba(56, 189, 248, 0.32)';
      } else {
        pCtx.strokeStyle = `rgba(${c1Rgb}, 0.16)`;
      }
      pCtx.lineWidth = 1.2;
      pCtx.stroke();
      pCtx.restore();
    }

    // Stasis pulse rings
    for (let i = 0; i < _stasisWaves.length; i++) {
      const sw = _stasisWaves[i];
      const a = Math.max(0, sw.life / sw.maxLife);
      pCtx.save();
      pCtx.globalCompositeOperation = 'lighter';
      pCtx.globalAlpha = a * 0.75;
      pCtx.strokeStyle = sw.color;
      pCtx.lineWidth = 3.0;
      pCtx.beginPath();
      pCtx.arc(sw.x, sw.y, sw.r, 0, Math.PI * 2);
      pCtx.stroke();
      pCtx.restore();
    }

    // 2. Render tower, enemies, bullet trails, lightning, beams & isolated FX layers
    const prevCtx = ctx;
    const prevZoom = (typeof camZoom !== 'undefined') ? camZoom : 1;
    const prevParts = fxLayerParts;
    const prevWaves = fxLayerWaves;
    try {
      ctx = pCtx;
      if (typeof camZoom !== 'undefined') camZoom = previewScale;
      fxLayerParts = _fxParts;
      fxLayerWaves = _fxWaves;

      if (typeof drawTowerModel === 'function') {
        const isShooting = ((_type === 'laser' && !!target) || (_type === 'melter' && !!target && !_tower.isCooling) || (_type === 'tesla' && _bolts.length > 0));
        pCtx.save();
        pCtx.translate(_tower.x, _tower.y);
        drawTowerModel(_type, _tower.angle, tCol, 1, tGlow, false, _tower.isCooling, isShooting, _tower.heatProgress, {
          x: _tower.x, y: _tower.y, target: isRail ? null : target, time: _simTime, lastFire: _tower.lastFire, shotIndex: _tower.shotIndex
        });
        pCtx.restore();
      }

      // Laser 3-layer beam
      if (_type === 'laser' && target) {
        const mx = _tower.x + Math.cos(_tower.angle) * 24;
        const my = _tower.y + Math.sin(_tower.angle) * 24;
        const pulse = Math.sin(_simTime * 24);
        pCtx.save();
        pCtx.lineCap = 'round';
        pCtx.globalCompositeOperation = 'lighter';
        pCtx.strokeStyle = tCol;
        pCtx.globalAlpha = 0.32;
        pCtx.lineWidth = 9.5 + pulse * 1.8;
        pCtx.beginPath(); pCtx.moveTo(mx, my); pCtx.lineTo(target.x, target.y); pCtx.stroke();
        pCtx.globalAlpha = 0.92;
        pCtx.lineWidth = 3.6 + pulse * 0.9;
        pCtx.stroke();
        pCtx.strokeStyle = '#ffffff';
        pCtx.globalAlpha = 0.95;
        pCtx.lineWidth = 1.4;
        pCtx.stroke();
        pCtx.fillStyle = '#ffffff';
        pCtx.beginPath(); pCtx.arc(target.x, target.y, 4.5, 0, Math.PI * 2); pCtx.fill();
        pCtx.restore();
      }

      // Melter ramping heat beam
      if (_type === 'melter' && target && !_tower.isCooling) {
        const mx = _tower.x + Math.cos(_tower.angle) * 24;
        const my = _tower.y + Math.sin(_tower.angle) * 24;
        const hp = _tower.heatProgress;
        const beamCol = hp > 0.72 ? '#ffffff' : (hp > 0.38 ? '#fb923c' : tCol);
        const coreW = 3.2 + hp * 4.2;
        pCtx.save();
        pCtx.lineCap = 'round';
        pCtx.globalCompositeOperation = 'lighter';
        pCtx.strokeStyle = hp > 0.4 ? '#fb923c' : tCol;
        pCtx.globalAlpha = 0.36;
        pCtx.lineWidth = coreW * 2.4;
        pCtx.beginPath(); pCtx.moveTo(mx, my); pCtx.lineTo(target.x, target.y); pCtx.stroke();
        pCtx.strokeStyle = beamCol;
        pCtx.globalAlpha = 0.92;
        pCtx.lineWidth = coreW;
        pCtx.stroke();
        pCtx.strokeStyle = '#ffffff';
        pCtx.globalAlpha = 0.75 + 0.25 * hp;
        pCtx.lineWidth = Math.max(1.4, coreW * 0.38);
        pCtx.stroke();
        pCtx.restore();
      }

      // Railgun piercing 3-layer beam
      for (let i = 0; i < _railBeams.length; i++) {
        const rb = _railBeams[i];
        const a = Math.max(0, rb.life / rb.maxLife);
        pCtx.save();
        pCtx.lineCap = 'round';
        pCtx.globalCompositeOperation = 'lighter';
        pCtx.strokeStyle = rb.color;
        pCtx.globalAlpha = 0.35 * a;
        pCtx.lineWidth = 14 * a;
        pCtx.beginPath(); pCtx.moveTo(rb.x1, rb.y1); pCtx.lineTo(rb.x2, rb.y2); pCtx.stroke();
        pCtx.globalAlpha = 0.92 * a;
        pCtx.lineWidth = 6 * a;
        pCtx.stroke();
        pCtx.strokeStyle = '#ffffff';
        pCtx.globalAlpha = a;
        pCtx.lineWidth = 2.5 * a;
        pCtx.stroke();
        pCtx.restore();
      }

      // Enemies with HP bars & real mob_renderer
      for (let i = 0; i < _enemies.length; i++) {
        const e = _enemies[i];
        const jitX = e._fxJitT > 0 ? Math.sin(_simTime * 80 + i) * 1.4 : 0;
        const jitY = e._fxJitT > 0 ? Math.cos(_simTime * 75 + i) * 1.4 : 0;
        const renderEnemy = Object.assign({}, e, {
          x: e.x + (e._fxKbX || 0) + jitX,
          y: e.y + (e._fxKbY || 0) + jitY
        });
        if (typeof renderConfiguredEnemyModel === 'function') {
          renderConfiguredEnemyModel(renderEnemy, _type !== 'stasis');
        }
      }

      // Tesla chain lightning
      if (typeof drawJaggedLightning === 'function') {
        for (let i = 0; i < _bolts.length; i++) {
          const b = _bolts[i];
          drawJaggedLightning(b.x1, b.y1, b.x2, b.y2, b.color, Math.max(0, b.life / b.maxLife), 1.0);
        }
      }

      // Projectiles (bullets via drawFxBulletTrails, mortar shells with shadow)
      for (let i = 0; i < _projectiles.length; i++) {
        const p = _projectiles[i];
        if (p.kind === 'bullet') {
          if (typeof drawFxBulletTrails === 'function') drawFxBulletTrails(p);
          pCtx.save();
          pCtx.fillStyle = '#ffffff';
          pCtx.beginPath(); pCtx.arc(p.x, p.y, 2.2, 0, Math.PI * 2); pCtx.fill();
          pCtx.restore();
        } else if (p.kind === 'mortar') {
          pCtx.save();
          pCtx.fillStyle = 'rgba(0, 0, 0, 0.35)';
          pCtx.beginPath(); pCtx.ellipse(p.x, p.y + 4, 6, 3, 0, 0, Math.PI * 2); pCtx.fill();
          pCtx.globalCompositeOperation = 'lighter';
          pCtx.fillStyle = p.color;
          pCtx.beginPath(); pCtx.arc(p.x, p.arcY, 5.5, 0, Math.PI * 2); pCtx.fill();
          pCtx.fillStyle = '#ffffff';
          pCtx.beginPath(); pCtx.arc(p.x, p.arcY, 2.5, 0, Math.PI * 2); pCtx.fill();
          pCtx.restore();
        }
      }

      // Melter cooling steam puffs
      for (let i = 0; i < _steamPuffs.length; i++) {
        const sp = _steamPuffs[i];
        const a = Math.max(0, sp.life / sp.maxLife) * 0.45;
        pCtx.save();
        pCtx.fillStyle = `rgba(210, 235, 255, ${a.toFixed(2)})`;
        pCtx.beginPath(); pCtx.arc(sp.x, sp.y, sp.r, 0, Math.PI * 2); pCtx.fill();
        pCtx.restore();
      }

      if (typeof updateAndDrawFxLayers === 'function') {
        updateAndDrawFxLayers(_lastDt, _simTime);
      }
    } finally {
      ctx = prevCtx;
      if (typeof camZoom !== 'undefined') camZoom = prevZoom;
      fxLayerParts = prevParts;
      fxLayerWaves = prevWaves;
    }

    pCtx.restore();
  }

  function tick(now) {
    const msSc = document.getElementById('milestoneScreen');
    const pCanvas = document.getElementById('milestoneTowerPreviewCanvas');
    if (!msSc || msSc.classList.contains('hidden') || !pCanvas) {
      stop();
      return;
    }
    if (!_lastTs) _lastTs = now;
    const dt = Math.min(0.05, Math.max(0.001, (now - _lastTs) / 1000));
    _lastTs = now;
    try {
      step(dt);
      render(now);
    } catch (_e) {}
    _rafId = requestAnimationFrame(tick);
  }

  function start(type) {
    stop();
    _type = type || 'gun';
    _lastTs = 0;
    _lastDt = 0.016;
    _simTime = 0;
    _spawnTimer = 1.2;
    _beamHitTimer = 0;

    const isRail = (_type === 'railgun');
    _tower.type = _type;
    _tower.x = isRail ? (0.9 * T_SIZE) : (2.5 * T_SIZE);
    _tower.y = 1.5 * T_SIZE;
    _tower.range = (_type === 'stasis') ? 132 : (isRail ? 380 : 168);
    _tower.angle = isRail ? 0 : Math.PI * 0.5;
    _tower.fireCooldown = 0.20;
    _tower.lastFire = -10;
    _tower.shotIndex = 0;
    _tower.heatProgress = 0;
    _tower.isCooling = false;
    _tower.coolTimer = 0;
    _tower.steamTimer = 0;

    spawnScenarioWave(true);
    _rafId = requestAnimationFrame(tick);
  }

  function stop() {
    if (_rafId !== null) {
      cancelAnimationFrame(_rafId);
      _rafId = null;
    }
    _enemies = [];
    _projectiles = [];
    _bolts = [];
    _railBeams = [];
    _stasisWaves = [];
    _steamPuffs = [];
    _fxParts.length = 0;
    _fxWaves.length = 0;
  }

  return { start, stop };
})();

// [UI.FV]
function buildFeatureVisualHtml(feature, color) {
  let iconSvg = '';
  if (feature === 'tech_tree') {
    iconSvg = `<svg width="46" height="46" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 21 v-5 l-4 -3.5 v-4 m4 7.5 l4 -3.5 v-4 m-4 7.5 v-8"/><circle cx="12" cy="21" r="1.8" fill="${color}"/><circle cx="8" cy="8.5" r="1.8" fill="${color}"/><circle cx="16" cy="8.5" r="1.8" fill="${color}"/><circle cx="12" cy="5" r="1.8" fill="${color}"/></svg>`;
  } else if (feature === 'endless') {
    iconSvg = `<svg width="54" height="36" viewBox="0 0 16 10" fill="none"><path d="M4 2 C1.8 2 1 3.3 1 5 C1 6.7 1.8 8 4 8 C6.8 8 9.2 2 12 2 C14.2 2 15 3.3 15 5 C15 6.7 14.2 8 12 8 C9.2 8 6.8 2 4 2 Z" stroke="${color}" stroke-width="1.6" stroke-linecap="round"/></svg>`;
  } else if (feature === 'hardcore') {
    iconSvg = `<svg width="44" height="44" viewBox="0 0 16 16" fill="${color}"><path d="M8 14.5 L2.8 9.2 C1.2 7.6 1.2 5 3 3.2 C4.5 1.7 6.8 2 7.8 3.6 C8.8 2 11.1 1.7 12.6 3.2 C14.4 5 14.4 7.6 12.8 9.2 Z"/></svg>`;
  } else if (feature === 'ascended') {
    iconSvg = `<svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linejoin="round"><polygon points="12 2 21 12 12 22 3 12" fill="rgba(217,70,239,.3)"/><polyline points="3 12 12 15 21 12"/><line x1="12" y1="2" x2="12" y2="22"/></svg>`;
  } else {
    iconSvg = `<svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" fill="${color}33"/></svg>`;
  }

  return `
    <div class="ms-feature-showcase" style="--feat-col:${color};">
      <div class="ms-feature-orbit"></div>
      <div class="ms-feature-core">${iconSvg}</div>
    </div>`;
}

// [UI.FW]
function buildMilestoneSteps(clearedLevel) {
  const steps = [];
  const nextLvl = clearedLevel + 1;
  const newTowers = getNewlyUnlockedTowers(nextLvl);
  const upgradesUnlockLevel = getLoadoutStartLevel();
  const loadoutJustUnlocked = (nextLvl === upgradesUnlockLevel);
  const _tr = (typeof window.t === 'function') ? window.t : ((k) => k);

  if (clearedLevel === 10) {
    steps.push({
      kicker: _tr('ms_ch1_cleared') || 'CHAPTER 1 CLEARED',
      title: _tr('tech_tree') || 'TECH TREE',
      color: '#00e5ff',
      visual: { kind: 'feature', feature: 'tech_tree' },
      bullets: [
        _tr('ms_tt_bullet_1') || '💎 Spend Diamonds on permanent upgrades',
        _tr('ms_tt_bullet_2') || '⚡ Boost Tower Damage, Speed & Range',
        _tr('ms_tt_bullet_3') || '🛡️ Increase starting Base HP & Gold Bounty'
      ]
    });
  } else if (clearedLevel === 20) {
    steps.push({
      kicker: _tr('ms_new_mode_unlocked') || 'NEW MODE UNLOCKED',
      title: _tr('hardcore') || 'HARDCORE',
      color: '#f05f9f',
      visual: { kind: 'feature', feature: 'hardcore' },
      bullets: [
        _tr('ms_hc_bullet_1') || '💔 1 Base HP — zero margin for error',
        _tr('ms_hc_bullet_2') || '🔥 1.2x faster & Enraged enemies',
        _tr('ms_hc_bullet_3') || '🔮 Earn rare Prisms & massive Diamond loot'
      ]
    });
  } else if (clearedLevel === 30) {
    steps.push({
      kicker: _tr('ms_ch3_cleared') || 'CHAPTER 3 CLEARED',
      title: _tr('ms_ascension') || 'ASCENSION',
      color: '#d946ef',
      visual: { kind: 'feature', feature: 'ascended' },
      bullets: [
        _tr('ms_asc_bullet_1') || '🔮 Ascended Tech Tree (Lv.11–15) unlocked',
        _tr('ms_asc_bullet_2') || '⚡ Unlock infinite SYNTH power scaling',
        _tr('ms_asc_bullet_3') || '🔄 Prism Deconstruction unlocked in Shop'
      ]
    });
  } else if (clearedLevel === 40) {
    steps.push({
      kicker: _tr('ms_ch4_cleared') || 'CHAPTER 4 CLEARED',
      title: _tr('ms_final_chapter') || 'FINAL CHAPTER',
      color: '#00e5ff',
      visual: { kind: 'feature', feature: 'sector' },
      bullets: [
        _tr('ms_ch5_bullet_1') || '⚠️ Chapter 5: Apex Sector unlocked',
        _tr('ms_ch5_bullet_2') || '⚡ EMP Bombers & Overlord Bosses ahead',
        _tr('ms_ch5_bullet_3') || '🏆 Push through to the final Level 50'
      ]
    });
  }

  if (clearedLevel === 15) {
    steps.push({
      kicker: _tr('ms_new_mode_unlocked') || 'NEW MODE UNLOCKED',
      title: _tr('endless') || 'ENDLESS ARENA',
      color: '#d946ef',
      visual: { kind: 'feature', feature: 'endless' },
      bullets: [
        _tr('ms_endless_bullet_1') || '♾️ Survive infinite escalating waves',
        _tr('ms_endless_bullet_2') || '💎 Earn +2 Diamonds for every wave cleared',
        _tr('ms_endless_bullet_3') || '🔮 +1 Prism every 10 waves & record bonuses'
      ]
    });
  }

  newTowers.forEach(type => {
    const conf = TOWER_CONFIGS[type] || {};
    let locBlurbs = [];
    if (typeof I18N_DICT !== 'undefined') {
      const dict = I18N_DICT[currentLang] || I18N_DICT.en || {};
      if (Array.isArray(dict[`tower_blurbs_${type}`])) {
        locBlurbs = dict[`tower_blurbs_${type}`];
      }
    }
    if (!locBlurbs || locBlurbs.length === 0) {
      locBlurbs = Array.isArray(TOWER_UNLOCK_BLURBS[type]) ? TOWER_UNLOCK_BLURBS[type] : [];
    }

    steps.push({
      kicker: _tr('new_tower_unlocked') || 'NEW TOWER UNLOCKED',
      title: (typeof TOWER_NAMES !== 'undefined' && TOWER_NAMES[type]) ? TOWER_NAMES[type] : type,
      color: conf.color || '#00e5ff',
      visual: { kind: 'tower_demo', type },
      bullets: locBlurbs
    });
  });

  if (loadoutJustUnlocked) {
    steps.push({
      kicker: _tr('ms_tactical_deck') || 'TACTICAL DECK',
      title: _tr('ms_loadout_title') || '3-TOWER LOADOUT',
      color: '#f59e0b',
      bullets: [
        (typeof t === 'function') ? t('ms_loadout_bullet_1', { size: LOADOUT_SIZE }) : `🎯 Bring up to ${LOADOUT_SIZE} towers into each battle`,
        _tr('ms_loadout_bullet_2') || '🔄 Swap your active deck before any level'
      ],
      embed: 'loadout'
    });
  }

  return steps;
}

// [UI.FX]
function showMilestoneSequence(clearedLevel, onComplete) {
  milestoneSteps = buildMilestoneSteps(clearedLevel);
  milestoneIndex = 0;
  milestoneOnComplete = onComplete;
  if (milestoneSteps.length === 0) {
    if (onComplete) onComplete();
    return;
  }
  document.getElementById('milestoneScreen').classList.remove('hidden');
  sfx('unlock');
  renderMilestoneStep();
}

// [UI.FY]
function renderMilestoneStep() {
  MilestoneTowerPreview.stop();
  const step = milestoneSteps[milestoneIndex];
  if (!step) return;
  const scr = document.getElementById('milestoneScreen');
  const accentColor = step.color || '#00e5ff';

  const stack = scr.querySelector('.result-stack');
  if (stack) {
    stack.style.setProperty('--ms-accent', accentColor);
  }

  const kickerEl = document.getElementById('milestoneKicker');
  const titleEl = document.getElementById('milestoneTitle');
  if (kickerEl) {
    kickerEl.textContent = step.kicker || ((typeof t === 'function') ? t('unlocked') : 'UNLOCKED');
    kickerEl.style.color = accentColor;
  }
  if (titleEl) {
    titleEl.textContent = step.title || '';
    titleEl.style.textShadow = `0 0 16px ${accentColor}99`;
  }

  const art = document.getElementById('milestoneArt');
  if (art) {
    if (step.visual && step.visual.kind === 'tower_demo') {
      art.innerHTML = buildTowerFiringDemoHtml(step.visual.type);
      art.classList.remove('hidden');
      MilestoneTowerPreview.start(step.visual.type);
    } else if (step.visual && step.visual.kind === 'feature') {
      art.innerHTML = buildFeatureVisualHtml(step.visual.feature, accentColor);
      art.classList.remove('hidden');
    } else {
      art.innerHTML = '';
      art.classList.add('hidden');
    }
  }

  const bodyEl = document.getElementById('milestoneBody');
  if (bodyEl) {
    if (Array.isArray(step.bullets) && step.bullets.length > 0) {
      bodyEl.innerHTML = `<div class="ms-bullet-list">` +
        step.bullets.map((b, i) => `<div class="ms-bullet-chip" style="animation-delay:${(0.12 + i * 0.08).toFixed(2)}s">${b}</div>`).join('') +
        `</div>`;
    } else {
      bodyEl.innerHTML = step.body || '';
    }
  }

  const embed = document.getElementById('milestoneEmbed');
  if (step.embed === 'loadout') {
    embed.classList.remove('hidden');
    renderMilestoneLoadoutGrid();
  } else {
    embed.classList.add('hidden');
  }

  const okBtn = document.getElementById('milestoneOkBtn');
  if (okBtn) {
    const isLast = (milestoneIndex >= milestoneSteps.length - 1);
    const stepIndicator = milestoneSteps.length > 1 ? ` (${milestoneIndex + 1}/${milestoneSteps.length})` : '';
    const btnLabel = isLast 
      ? ((typeof t === 'function') ? t('awesome') : 'AWESOME') 
      : ((typeof t === 'function') ? t('next') : 'NEXT');
    okBtn.innerHTML = `<span>${btnLabel}${stepIndicator}</span>`;
    okBtn.style.borderColor = '';
    okBtn.style.boxShadow = '';
  }

  scr.querySelectorAll('.seq-in, .milestone-art').forEach(el => {
    el.style.animation = 'none';
    void el.offsetWidth;
    el.style.animation = '';
  });
}

// [UI.FZ]
function renderMilestoneLoadoutGrid() {
  const grid = document.getElementById('milestoneLoadoutGrid');
  if (!grid) return;
  const ref = Math.min(getLoadoutReferenceLevel(), TOTAL_LEVELS);
  const pool = (LEVELS_DATA[ref] && LEVELS_DATA[ref].unlockedTowers) ? LEVELS_DATA[ref].unlockedTowers : ['gun'];
  const isFull = selectedLoadout.length >= LOADOUT_SIZE;
  grid.innerHTML = '';
  pool.forEach(type => {
    const conf = TOWER_CONFIGS[type];
    if (!conf) return;
    const isSelected = selectedLoadout.includes(type);
    const btn = document.createElement('div');
    btn.className = 'loadout-tower-btn'
      + (isSelected ? ' selected' : '')
      + (!isSelected && isFull ? ' blocked' : '');
    btn.innerHTML = `
      <div class="tower-btn-icon">${TOWER_ICONS[type] || ''}</div>
      <span class="tower-btn-title">${TOWER_NAMES[type] || type}</span>
    `;
    // [UI.GA]
    btn.onclick = (e) => {
      e.stopPropagation();
      toggleLoadoutWidgetTower(type);
      renderMilestoneLoadoutGrid();
    };
    grid.appendChild(btn);
  });
  const hint = document.getElementById('milestoneEmbedHint');
  if (hint) {
    hint.textContent = (typeof t === 'function')
      ? t('loadout_selected_hint', { cur: selectedLoadout.length, max: LOADOUT_SIZE })
      : `${selectedLoadout.length}/${LOADOUT_SIZE} selected — tap a selected tower to free a slot`;
  }
}

// [UI.GB]
function advanceMilestone() {
  MilestoneTowerPreview.stop();
  milestoneIndex++;
  if (milestoneIndex < milestoneSteps.length) {
    renderMilestoneStep();
    return;
  }
  document.getElementById('milestoneScreen').classList.add('hidden');
  const done = milestoneOnComplete;
  milestoneOnComplete = null;
  milestoneSteps = [];
  if (done) done();
}

// [UI.GC]
function showUpgradesScreen(fromSource) {
  const unlockLevel = getLoadoutStartLevel();
  const isUpgradesUnlocked = devMode || getLoadoutReferenceLevel() >= unlockLevel;
  if (!isUpgradesUnlocked) {
    showHintToast(typeof t === 'function' ? t('available_on_level_n', { n: unlockLevel }) : `Will be available on Level ${unlockLevel}`);
    return;
  }

  if (!fromSource) {
    if (gameState === 'VICTORY') fromSource = 'victory';
    else if (gameState === 'DEFEAT') fromSource = 'defeat';
    else if (gameState === 'LEVELS' || !document.getElementById('levelsScreen').classList.contains('hidden')) fromSource = 'levels';
    else fromSource = 'main';
  }
  upgradesPreviousSource = fromSource;
  stopNormalModePreview();

  const bgScreenId = fromSource === 'victory' ? 'victoryScreen'
    : (fromSource === 'defeat' ? 'defeatScreen'
    : (fromSource === 'levels' ? 'levelsScreen' : 'startScreen'));

  ['startScreen', 'victoryScreen', 'pauseScreen', 'levelsScreen', 'settingsScreen', 'defeatScreen', 'reviveScreen']
    .forEach(id => {
      const el = document.getElementById(id);
      if (!el) return;
      el.classList.remove('screen-bg-only');
      if (id === bgScreenId) {
        el.classList.remove('hidden');
        el.classList.add('screen-bg-only');
      } else {
        el.classList.add('hidden');
      }
    });

  const controlsWrapper = document.getElementById('controlsWrapper');
  if (controlsWrapper) controlsWrapper.classList.add('hidden');
  const waveBtn = document.getElementById('waveBtn');
  if (waveBtn) waveBtn.classList.add('hidden');
  const devSpawner = document.getElementById('devCustomSpawner');
  if (devSpawner) devSpawner.classList.add('hidden');

  const topHud = document.getElementById('topHud');
  if (topHud) topHud.classList.add('hidden');

  const upg = document.getElementById('upgradesScreen');
  const isResultBg = (bgScreenId === 'victoryScreen' || bgScreenId === 'defeatScreen');
  upg.classList.toggle('from-result', isResultBg);
  upg.classList.toggle('from-main', !isResultBg);
  upg.classList.remove('hidden');
  gameState = 'UPGRADES';
  updateHudSpeedWidget();
  renderUpgradeTree();

  updateDailyBonusBtnVisibility();
}

// [UI.GD]
function closeUpgradesScreen() {
  document.getElementById('upgradesScreen').classList.add('hidden');

  const topHud = document.getElementById('topHud');
  if (topHud) topHud.classList.remove('hidden');

  ['startScreen', 'victoryScreen', 'defeatScreen', 'levelsScreen', 'pauseScreen', 'settingsScreen'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.classList.remove('screen-bg-only');
  });

  if (upgradesPreviousSource === 'victory') {
    document.getElementById('victoryScreen').classList.remove('hidden');
    gameState = 'VICTORY';
  } else if (upgradesPreviousSource === 'defeat') {
    document.getElementById('defeatScreen').classList.remove('hidden');
    gameState = 'DEFEAT';
  } else if (upgradesPreviousSource === 'levels') {
    document.getElementById('levelsScreen').classList.remove('hidden');
    gameState = 'LEVELS';
    startModeBattlePreview(currentLevelMode);
  } else {
    document.getElementById('startScreen').classList.remove('hidden');
    gameState = 'START';
  }

  syncTopHudVisibility();
  updateDailyBonusBtnVisibility();
}

// [UI.GE]
function showShopScreen(fromSource) {
  if (!fromSource) {
    if (gameState === 'VICTORY') fromSource = 'victory';
    else if (gameState === 'DEFEAT') fromSource = 'defeat';
    else fromSource = 'start';
  }
  shopPreviousSource = fromSource;

  const bgScreenId = fromSource === 'victory' ? 'victoryScreen'
    : (fromSource === 'defeat' ? 'defeatScreen' : 'startScreen');

  ['startScreen', 'victoryScreen', 'defeatScreen', 'levelsScreen', 'pauseScreen', 'settingsScreen', 'upgradesScreen']
    .forEach(id => {
      const el = document.getElementById(id);
      if (!el) return;
      el.classList.remove('screen-bg-only');
      if (id === bgScreenId) {
        el.classList.remove('hidden');
        el.classList.add('screen-bg-only');
      } else {
        el.classList.add('hidden');
      }
    });

  const controlsWrapper = document.getElementById('controlsWrapper');
  if (controlsWrapper) controlsWrapper.classList.add('hidden');
  const waveBtn = document.getElementById('waveBtn');
  if (waveBtn) waveBtn.classList.add('hidden');
  const topHud = document.getElementById('topHud');
  if (topHud) topHud.classList.add('hidden');

  const shopEl = document.getElementById('shopScreen');
  const isResultBg = (bgScreenId === 'victoryScreen' || bgScreenId === 'defeatScreen');
  shopEl.classList.toggle('from-result', isResultBg);
  shopEl.classList.toggle('from-main', !isResultBg);
  shopEl.classList.remove('hidden');
  gameState = 'SHOP';

  updateHudSpeedWidget();
  renderShopScreen();

  updateDailyBonusBtnVisibility();
}

// [UI.GF]
function closeShopScreen() {
  document.getElementById('shopScreen').classList.add('hidden');

  const topHud = document.getElementById('topHud');
  if (topHud) topHud.classList.remove('hidden');

  ['startScreen', 'victoryScreen', 'defeatScreen'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.classList.remove('screen-bg-only');
  });

  if (shopPreviousSource === 'victory') {
    document.getElementById('victoryScreen').classList.remove('hidden');
    gameState = 'VICTORY';
  } else if (shopPreviousSource === 'defeat') {
    document.getElementById('defeatScreen').classList.remove('hidden');
    gameState = 'DEFEAT';
  } else {
    document.getElementById('startScreen').classList.remove('hidden');
    gameState = 'START';
  }

  syncTopHudVisibility();
  updateDailyBonusBtnVisibility();
}

// [UI.GG]
function renderShopScreen() {
    checkDailyGiftReset();
    updateMenuBadges();
    const shopBody = document.getElementById('shopBodyList');
    if (shopBody) enablePointerScroll(shopBody);
    const diamondLabel = document.getElementById('shopDiamondVal');
    if (diamondLabel) diamondLabel.textContent = diamonds;
    const prismLabel = document.getElementById('shopPrismVal');
    if (prismLabel) prismLabel.textContent = prisms;

    const giftTitle = document.getElementById('dailyGiftTitleText');
    const giftSub = document.getElementById('dailyGiftSubText');
    const giftBtn = document.getElementById('dailyGiftClaimBtn');
    const _tr = (typeof window.t === 'function') ? window.t : ((k) => k);

    if (giftTitle) {
        if (dailyGiftsClaimedCount === 0) {
            giftTitle.innerHTML = `+10 ${getDailyDiamondSvg(14)}`;
        } else if (dailyGiftsClaimedCount === 1) {
            giftTitle.innerHTML = `+15 ${getDailyDiamondSvg(14)}`;
        } else if (dailyGiftsClaimedCount === 2) {
            giftTitle.innerHTML = `+20 ${getDailyDiamondSvg(14)} + 1 ${getDailyPrismSvg(14)}`;
        } else {
            giftTitle.textContent = (typeof t === 'function') ? t('daily_gifts_completed') : 'Daily Gifts Completed';
        }
    }

    if (giftSub) {
        if (dailyGiftsClaimedCount === 0) {
            giftSub.innerHTML = (typeof t === 'function')
                ? t('next_pack_diamonds', { d: 10, icon: getDailyDiamondSvg(12), cur: 1, max: 3 })
                : `Next pack: 10 ${getDailyDiamondSvg(12)} (1/3)`;
        } else if (dailyGiftsClaimedCount === 1) {
            giftSub.innerHTML = (typeof t === 'function')
                ? t('next_pack_diamonds', { d: 15, icon: getDailyDiamondSvg(12), cur: 2, max: 3 })
                : `Next pack: 15 ${getDailyDiamondSvg(12)} (2/3)`;
        } else if (dailyGiftsClaimedCount === 2) {
            giftSub.innerHTML = (typeof t === 'function')
                ? t('next_pack_combo', { d: 20, dIcon: getDailyDiamondSvg(12), p: 1, pIcon: getDailyPrismSvg(12) })
                : `Next pack: 20 ${getDailyDiamondSvg(12)} + 1 ${getDailyPrismSvg(12)}`;
        } else {
            giftSub.textContent = (typeof t === 'function')
                ? t('claimed_today_packs', { cur: 3, max: 3 })
                : 'Claimed today: 3/3 packs';
        }
    }

    if (giftBtn) {
        if (dailyGiftsClaimedCount >= 3) {
            giftBtn.disabled = true;
            giftBtn.className = 'shop-item-btn shop-btn-claimed';
            giftBtn.innerHTML = `<span>${_tr('claimed')}</span>`;
        } else if (dailyGiftsClaimedCount === 0) {
            giftBtn.disabled = false;
            giftBtn.className = 'shop-item-btn shop-btn-free';
            giftBtn.innerHTML = `<span>${_tr('free')}</span>`;
        } else {
            giftBtn.disabled = false;
            giftBtn.className = 'shop-item-btn shop-btn-ad';
            giftBtn.innerHTML = `<svg width="16" height="13" viewBox="0 0 16 13" fill="none" style="flex:none; margin-right:4px;"><rect x="0.8" y="0.8" width="14.4" height="11.4" rx="2.5" fill="none" stroke="currentColor" stroke-width="1.6"/><polygon points="6,3.5 11,6.5 6,9.5" fill="currentColor"/></svg><span>${_tr('watch_ad')}</span>`;
        }
    }

    const lockSvg = (typeof CUSTOM_LOCK_SVG !== 'undefined')
        ? CUSTOM_LOCK_SVG
        : `<svg width="12" height="12" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.2" fill="none" stroke-linecap="round" stroke-linejoin="round" style="flex:none;"><path d="M 7,10 V 6 C 7,3.5 9,2 12,2 C 15,2 17,3.5 17,6 V 10"/><rect x="4" y="10" width="16" height="12" rx="3" fill="currentColor" fill-opacity="0.2"/></svg>`;

    // --- Currency Exchange (обе кнопки заблокированы до 21 уровня Normal) ---
    const isExchangeUnlocked = (typeof devMode !== 'undefined' && devMode) ||
        (typeof maxUnlockedLevel !== 'undefined' && maxUnlockedLevel >= 21) ||
        (typeof clearedLevels !== 'undefined' && clearedLevels.includes(20));

    const synthBtn = document.getElementById('synthPrismBtn');
    const synthCard = document.getElementById('synthPrismCard') || (synthBtn ? synthBtn.closest('.shop-card') : null);
    if (synthBtn) {
        if (!isExchangeUnlocked) {
            if (synthCard) synthCard.classList.add('locked-item');
            synthBtn.disabled = false;
            synthBtn.className = 'shop-item-btn locked-buy';
            synthBtn.innerHTML = `<span style="display:inline-flex; align-items:center; justify-content:center; gap:3px;">${lockSvg} <span style="font-size:11px; font-weight:900;">L21</span></span>`;
            synthBtn.onclick = () => {
                if (typeof sfx === 'function') sfx('denied');
                if (typeof showHintToast === 'function') {
                    showHintToast(typeof t === 'function' ? t('unlocks_on_level_n', { n: 21 }) : 'Unlocks on Level 21');
                }
            };
        } else {
            if (synthCard) synthCard.classList.remove('locked-item');
            const hasEnoughDiamonds = diamonds >= 20;
            synthBtn.disabled = !hasEnoughDiamonds;
            synthBtn.className = `shop-item-btn shop-btn-buy shop-btn-exchange${hasEnoughDiamonds ? '' : ' dimmed'}`;
            synthBtn.innerHTML = `<span style="display:inline-flex; align-items:center; justify-content:center; gap:4px;">${getDailyDiamondSvg(12)} 20</span>`;
            synthBtn.onclick = () => synthesizePrism();
        }
    }

    const deconstructBtn = document.getElementById('deconstructPrismBtn');
    const deconstructCard = document.getElementById('deconstructPrismCard') || (deconstructBtn ? deconstructBtn.closest('.shop-card') : null);
    if (deconstructBtn) {
        if (!isExchangeUnlocked) {
            if (deconstructCard) deconstructCard.classList.add('locked-item');
            deconstructBtn.disabled = false;
            deconstructBtn.className = 'shop-item-btn locked-buy';
            deconstructBtn.innerHTML = `<span style="display:inline-flex; align-items:center; justify-content:center; gap:3px;">${lockSvg} <span style="font-size:11px; font-weight:900;">L21</span></span>`;
            deconstructBtn.onclick = () => {
                if (typeof sfx === 'function') sfx('denied');
                if (typeof showHintToast === 'function') {
                    showHintToast(typeof t === 'function' ? t('unlocks_on_level_n', { n: 21 }) : 'Unlocks on Level 21');
                }
            };
        } else {
            if (deconstructCard) deconstructCard.classList.remove('locked-item');
            const hasEnoughPrisms = prisms >= 1;
            deconstructBtn.disabled = !hasEnoughPrisms;
            deconstructBtn.className = `shop-item-btn shop-btn-buy shop-btn-prism shop-btn-exchange${hasEnoughPrisms ? '' : ' dimmed'}`;
            deconstructBtn.innerHTML = `<span style="display:inline-flex; align-items:center; justify-content:center; gap:4px;">${getDailyPrismSvg(12)} 1</span>`;
            deconstructBtn.onclick = () => deconstructPrism();
        }
    }

    // --- Обновление состояния кнопок тем ---
    const themesConfig = [
        { id: 'bio_venom', cost: 150, btnId: 'themeBtn-bio_venom' },
        { id: 'sakura_wave', cost: 200, btnId: 'themeBtn-sakura_wave' },
        { id: 'solar_inferno', cost: 300, btnId: 'themeBtn-solar_inferno' }
    ];

    themesConfig.forEach(tConf => {
        const btn = document.getElementById(tConf.btnId);
        if (!btn) return;
        const isOwned = Boolean(unlockedPalettes && unlockedPalettes.includes(tConf.id));
        const isActive = activePalette === tConf.id;

        if (isActive) {
            btn.disabled = true;
            btn.className = 'shop-item-btn shop-btn-claimed';
            btn.innerHTML = `<span>${_tr('equipped')}</span>`;
        } else if (isOwned) {
            btn.disabled = false;
            btn.className = 'shop-item-btn shop-btn-free';
            btn.innerHTML = `<span>${_tr('equip')}</span>`;
        } else {
            const canAfford = diamonds >= tConf.cost;
            btn.disabled = !canAfford;
            btn.className = `shop-item-btn shop-btn-buy${canAfford ? '' : ' dimmed'}`;
            btn.innerHTML = `<span style="display:inline-flex; align-items:center; justify-content:center; gap:4px;">${getDailyDiamondSvg(12)} ${tConf.cost}</span>`;
        }
    });

    // --- Time Modulation Perks State ---
    const t1Btn = document.getElementById('shopPerkTimeT1Btn') || document.getElementById('timeModT1Btn');
    const t1Card = document.getElementById('shopPerkTimeT1Card') || (t1Btn ? t1Btn.closest('.shop-card') : null);
    if (t1Btn) {
        if (timeModTier >= 1) {
            t1Btn.disabled = true;
            t1Btn.className = 'shop-item-btn shop-btn-claimed';
            t1Btn.textContent = _tr('owned');
            if (t1Card) t1Card.classList.remove('locked-item');
        } else {
            const canAffordT1 = diamonds >= 50;
            t1Btn.disabled = !canAffordT1;
            t1Btn.className = `shop-item-btn shop-btn-buy${canAffordT1 ? '' : ' dimmed'}`;
            t1Btn.innerHTML = `<span style="display:inline-flex; align-items:center; justify-content:center; gap:4px;">${getDailyDiamondSvg(12)} 50</span>`;
            if (t1Card) t1Card.classList.remove('locked-item');
        }
    }

    const t2Btn = document.getElementById('shopPerkTimeT2Btn') || document.getElementById('timeModT2Btn');
    const t2Card = document.getElementById('shopPerkTimeT2Card') || (t2Btn ? t2Btn.closest('.shop-card') : null);
    if (t2Btn) {
        if (timeModTier >= 2) {
            t2Btn.disabled = true;
            t2Btn.className = 'shop-item-btn shop-btn-claimed';
            t2Btn.textContent = _tr('owned');
            t2Btn.onclick = () => buyShopIAP('time_mod_t2');
            if (t2Card) t2Card.classList.remove('locked-item');
        } else if (timeModTier < 1) {
            t2Btn.disabled = false; // Оставляем кликабельной для вывода toast
            t2Btn.className = 'shop-item-btn locked-buy';
            const reqLabel = (typeof t === 'function' ? t('tier_1_required') : 'TIER 1<br>REQUIRED');
            t2Btn.innerHTML = `<span style="display:inline-flex; align-items:center; justify-content:center; gap:3px; text-align:center; font-size:9px; line-height:1.15;">${lockSvg} <span>${reqLabel}</span></span>`;
            t2Btn.onclick = () => {
                if (typeof sfx === 'function') sfx('denied');
                if (typeof showHintToast === 'function') {
                    showHintToast(typeof t === 'function' ? t('unlock_tier_1_first') : 'Unlock Tier 1 first!');
                }
            };
            if (t2Card) t2Card.classList.add('locked-item');
        } else {
            const canAffordT2 = diamonds >= 200;
            t2Btn.disabled = !canAffordT2;
            t2Btn.className = `shop-item-btn shop-btn-buy${canAffordT2 ? '' : ' dimmed'}`;
            t2Btn.innerHTML = `<span style="display:inline-flex; align-items:center; justify-content:center; gap:4px;">${getDailyDiamondSvg(12)} 200</span>`;
            t2Btn.onclick = () => buyShopIAP('time_mod_t2');
            if (t2Card) t2Card.classList.remove('locked-item');
        }
    }
}

// --- Daily Login 7-Day Calendar Logic ---
// [UI.GH]
function checkDailyLoginState() {
  const todayStr = getTodayDateString();
  return lastLoginClaimDate === todayStr;
}

// [UI.GI]
function updateMenuBadges() {
  const dailyBadge = document.getElementById('dailyBonusBadgeDot') || document.getElementById('dailyCalendarBadge');
  if (dailyBadge) {
    const isClaimedToday = checkDailyLoginState();
    dailyBadge.classList.toggle('hidden', isClaimedToday);
  }

  const bpBadge = document.getElementById('startBpBadgeDot');
  if (bpBadge) {
    let hasUnclaimed = false;
    if (typeof getBpTierInfo === 'function' && typeof BATTLE_PASS_TIERS !== 'undefined') {
      const { tier } = getBpTierInfo(bpXp);
      for (let t = 1; t <= tier; t++) {
        if (!bpClaimedFree[t]) { hasUnclaimed = true; break; }
        if (bpPremiumPurchased && !bpClaimedPrem[t]) { hasUnclaimed = true; break; }
      }
    }
    bpBadge.classList.toggle('hidden', !hasUnclaimed);
  }

  const shopBadge = document.getElementById('shopBadgeDot');
  if (shopBadge) {
    const hasUnclaimedGifts = (typeof dailyGiftsClaimedCount !== 'undefined') ? (dailyGiftsClaimedCount < 3) : false;
    shopBadge.classList.toggle('hidden', !hasUnclaimedGifts);
  }
}

// [UI.GJ]
function getDailyDiamondSvg(size = 20, opacity = 1) {
  const th = getTheme();
  const c1Rgb = th.rgb1 ? th.rgb1.cssRgb : '0, 229, 255';
  return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${th.c1}" stroke-width="2" stroke-linejoin="round"${opacity < 1 ? ` style="opacity:${opacity};"` : ''}><polygon points="6 3 18 3 22 9 12 22 2 9" fill="rgba(${c1Rgb}, 0.28)"/><polyline points="2 9 12 13 22 9"/><line x1="12" y1="22" x2="12" y2="13"/></svg>`;
}

// [UI.GK]
function getDailyPrismSvg(size = 20, opacity = 1) {
  const th = getTheme();
  const c2Rgb = th.rgb2 ? th.rgb2.cssRgb : '217, 70, 239';
  return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${th.c2}" stroke-width="2" stroke-linejoin="round"${opacity < 1 ? ` style="opacity:${opacity};"` : ''}><polygon points="12 2 21 12 12 22 3 12" fill="rgba(${c2Rgb}, 0.35)"/><line x1="12" y1="2" x2="12" y2="22"/><polyline points="3 12 12 15 21 12" fill="none"/></svg>`;
}

// [UI.GL]
function renderDailyLoginModal() {
  const grid = document.getElementById('dailyCalendarGrid');
  if (!grid) return;
  grid.innerHTML = '';

  const isClaimedToday = checkDailyLoginState();
  const lastClaimedDay = isClaimedToday ? (loginStreakDay === 1 ? 7 : loginStreakDay - 1) : (loginStreakDay - 1);

  const trackEl = document.getElementById('dailyStreakTrack');
  if (trackEl) {
    const th = getTheme();
    const c1Rgb = th.rgb1 ? th.rgb1.cssRgb : '0, 229, 255';
    const c2Rgb = th.rgb2 ? th.rgb2.cssRgb : '217, 70, 239';
    const doneCol = th.c1;
    const doneBg = `rgba(${c1Rgb}, 0.22)`;
    const actCol = th.c2;
    const actBg = `rgba(${c2Rgb}, 0.25)`;
    const day7FutCol = th.c3;
    const day7FutBg = `rgba(${th.rgb3 ? th.rgb3.cssRgb : '240, 95, 159'}, 0.2)`;

    const activeStreakDay = isClaimedToday ? (loginStreakDay === 1 ? 7 : loginStreakDay - 1) : loginStreakDay;
    let trackNodesHtml = '';

    trackNodesHtml += `<line x1="18" y1="16" x2="262" y2="16" stroke="#1e293b" stroke-width="2.5"/>`;

    const activeX = 18 + (activeStreakDay - 1) * 40.66;
    if (activeX > 18) {
      trackNodesHtml += `<line x1="18" y1="16" x2="${activeX}" y2="16" stroke="${doneCol}" stroke-width="2.5"/>`;
    }

    for (let d = 1; d <= 7; d++) {
      const cx = 18 + (d - 1) * 40.66;
      let nodeClaimed = false;
      let nodeActive = false;

      if (isClaimedToday) {
        if (d <= lastClaimedDay || lastClaimedDay === 7) nodeClaimed = true;
      } else {
        if (d < loginStreakDay) nodeClaimed = true;
        else if (d === loginStreakDay) nodeActive = true;
      }

      if (d < 7) {
        if (nodeClaimed) {
          trackNodesHtml += `<circle cx="${cx}" cy="16" r="6" fill="${doneBg}" stroke="${doneCol}" stroke-width="1.8"/>`;
          trackNodesHtml += `<path d="M ${cx - 2.5},16 L ${cx - 0.5},18 L ${cx + 3},14" fill="none" stroke="${doneCol}" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>`;
        } else if (nodeActive) {
          trackNodesHtml += `<circle cx="${cx}" cy="16" r="8" fill="${actBg}" stroke="${actCol}" stroke-width="2.2"/>`;
          trackNodesHtml += `<circle cx="${cx}" cy="16" r="3" fill="#ffffff"/>`;
        } else {
          trackNodesHtml += `<circle cx="${cx}" cy="16" r="5" fill="#0b1324" stroke="#334155" stroke-width="1.5"/>`;
        }
      } else {
        if (nodeClaimed) {
          trackNodesHtml += `<polygon points="${cx},9 ${cx+7},16 ${cx},23 ${cx-7},16" fill="${doneBg}" stroke="${doneCol}" stroke-width="1.8"/>`;
          trackNodesHtml += `<path d="M ${cx - 2.5},16 L ${cx - 0.5},18 L ${cx + 3},14" fill="none" stroke="${doneCol}" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>`;
        } else if (nodeActive) {
          trackNodesHtml += `<polygon points="${cx},8 ${cx+8},16 ${cx},24 ${cx-8},16" fill="${actBg}" stroke="${actCol}" stroke-width="2.2"/>`;
          trackNodesHtml += `<circle cx="${cx}" cy="16" r="3" fill="#ffffff"/>`;
        } else {
          trackNodesHtml += `<polygon points="${cx},10 ${cx+6},16 ${cx},22 ${cx-6},16" fill="${day7FutBg}" stroke="${day7FutCol}" stroke-width="1.6"/>`;
        }
      }
    }

    trackEl.innerHTML = `
      <svg width="280" height="32" viewBox="0 0 280 32" style="display:block; margin:auto;">
        ${trackNodesHtml}
      </svg>
      <div class="daily-streak-sub">${t('day_n_of_7', { n: activeStreakDay })}</div>
    `;
  }

  DAILY_LOGIN_REWARDS.forEach(item => {
    const d = item.day;
    const isDay7 = (d === 7);
    const card = document.createElement('div');

    let isClaimed = false;
    let isActive = false;
    let isFuture = false;

    if (isClaimedToday) {
      if (d <= lastClaimedDay || (lastClaimedDay === 7)) {
        isClaimed = true;
      } else {
        isFuture = true;
      }
    } else {
      if (d < loginStreakDay) {
        isClaimed = true;
      } else if (d === loginStreakDay) {
        isActive = true;
      } else {
        isFuture = true;
      }
    }

    const iconOpacity = isClaimed ? 0.35 : 1.0;

    if (isDay7) {
      card.className = `daily-card day7-card${isClaimed ? ' claimed' : ''}${isActive ? ' active' : ''}${isFuture ? ' future' : ''}`;

      let statusBadge = '';
      if (isClaimed) {
        const th = getTheme();
        statusBadge = `<div class="daily-check-pill"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="${th.c1}" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg></div>`;
      }

      card.innerHTML = `
        <div class="day7-left">
          <div class="day7-badge">${t('grand_bonus')}</div>
          <div class="day7-title">${t('day_n', { n: 7 })}</div>
          ${statusBadge}
        </div>
        <div class="day7-right">
          <div class="day7-capsule diamond-capsule">
            ${getDailyDiamondSvg(18, iconOpacity)}
            <span class="day7-val">+50</span>
          </div>
          <span class="day7-plus">+</span>
          <div class="day7-capsule prism-capsule">
            ${getDailyPrismSvg(18, iconOpacity)}
            <span class="day7-val">+10</span>
          </div>
        </div>
      `;
    } else if (d === 5) {
      card.className = `daily-card day5-card${isClaimed ? ' claimed' : ''}${isActive ? ' active' : ''}${isFuture ? ' future' : ''}`;

      let topBadge = '';
      if (isActive) {
        topBadge = `<div class="daily-today-badge">${t('today')}</div>`;
      }

      let bottomBadge = '';
      if (isClaimed) {
        const th = getTheme();
        bottomBadge = `<div class="daily-check-pill"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="${th.c1}" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg></div>`;
      }

      card.innerHTML = `
        ${topBadge}
        <span class="daily-card-num">${t('day_n', { n: 5 })}</span>
        <div class="daily-dual-wrap">
          <div class="daily-dual-side">
            ${getDailyDiamondSvg(16, iconOpacity)}
            <span class="daily-dual-val">+40</span>
          </div>
          <span class="daily-dual-plus">+</span>
          <div class="daily-dual-side">
            ${getDailyPrismSvg(16, iconOpacity)}
            <span class="daily-dual-val">+2</span>
          </div>
        </div>
        ${bottomBadge}
      `;
    } else {
      card.className = `daily-card${isClaimed ? ' claimed' : ''}${isActive ? ' active' : ''}${isFuture ? ' future' : ''}`;

      let topBadge = '';
      if (isActive) {
        topBadge = `<div class="daily-today-badge">${t('today')}</div>`;
      }

      let rewardIcon = item.prisms > 0 ? getDailyPrismSvg(22, iconOpacity) : getDailyDiamondSvg(22, iconOpacity);
      let rewardValText = item.prisms > 0 ? `+${item.prisms}` : `+${item.diamonds}`;

      let bottomBadge = '';
      if (isClaimed) {
        const th = getTheme();
        bottomBadge = `<div class="daily-check-pill"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="${th.c1}" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg></div>`;
      }

      card.innerHTML = `
        ${topBadge}
        <span class="daily-card-num">${t('day_n', { n: d })}</span>
        <div class="daily-card-icon-wrap">${rewardIcon}</div>
        <span class="daily-card-val">${rewardValText}</span>
        ${bottomBadge}
      `;
    }

    grid.appendChild(card);
  });

  const normalBtn = document.getElementById('dailyLoginClaimNormalBtn');
  const doubleBtn = document.getElementById('dailyLoginClaimDoubleBtn');
  const doubleLabel = document.getElementById('dailyClaimDoubleLabel');
  const adIcon = document.getElementById('dailyDoubleAdIcon');

  if (isClaimedToday) {
    if (normalBtn) {
      normalBtn.disabled = true;
      normalBtn.innerHTML = `<span>${t('claimed_today')}</span>`;
    }
    if (doubleBtn) {
      doubleBtn.disabled = true;
      doubleBtn.style.display = 'none';
    }
  } else {
    if (normalBtn) {
      normalBtn.disabled = false;
      normalBtn.innerHTML = `<span>${t('claim')}</span>`;
    }
    if (doubleBtn) {
      doubleBtn.disabled = false;
      doubleBtn.style.display = 'flex';
      if (doubleLabel) doubleLabel.textContent = (typeof t === 'function' ? t('claim_x2') : 'CLAIM x2');
      if (adIcon) {
        adIcon.style.display = 'inline-block';
        adIcon.outerHTML = `<svg id="dailyDoubleAdIcon" width="18" height="15" viewBox="0 0 16 13" fill="none" style="flex:none; margin-right:6px;"><rect x="0.8" y="0.8" width="14.4" height="11.4" rx="2.5" fill="none" stroke="currentColor" stroke-width="1.6"/><polygon points="6,3.5 11,6.5 6,9.5" fill="currentColor"/></svg>`;
      }
    }
  }
}

// [UI.GM]
function openDailyLoginModal() {
  const modal = document.getElementById('dailyLoginModal');
  if (!modal) return;
  modal.classList.remove('hidden');
  renderDailyLoginModal();
  sfx('confirm');

  updateDailyBonusBtnVisibility();
}

// [UI.GN]
function closeDailyLoginModal() {
  dailyLoginDismissedThisSession = true;
  const modal = document.getElementById('dailyLoginModal');
  if (modal) modal.classList.add('hidden');

  updateDailyBonusBtnVisibility();
}

// [UI.GO]
function claimDailyLoginReward(isDouble) {
  if (checkDailyLoginState()) {
    showHintToast(typeof t === 'function' ? t('already_claimed_today') : 'Already claimed today!');
    return;
  }

  const currentReward = DAILY_LOGIN_REWARDS[loginStreakDay - 1];
  if (!currentReward) return;

  // [UI.GP]
  const executeGrantReward = () => {
    const mult = isDouble ? 2 : 1;
    const addDiamonds = currentReward.diamonds * mult;
    const addPrisms = currentReward.prisms * mult;

    diamonds += addDiamonds;
    prisms += addPrisms;
    lastLoginClaimDate = getTodayDateString();
    const claimedDay = loginStreakDay;
    loginStreakDay = (loginStreakDay % 7) + 1;

    updateDiamondUI();
    if (typeof updatePrismUI === 'function') updatePrismUI();
    saveGame();
    sfx('reward');

    updateMenuBadges();
    renderDailyLoginModal();

    let toastText = isDouble 
      ? ((typeof t === 'function') ? t('x2_bonus_prefix') : 'x2 Bonus: ') 
      : ((typeof t === 'function') ? t('day_n_prefix', { n: claimedDay }) : `Day ${claimedDay}: `);
    const parts = [];
    const diaWord = (typeof t === 'function' && t('diamonds_word')) ? t('diamonds_word') : ((typeof t === 'function' && t('diamonds_upper')) ? t('diamonds_upper').toLowerCase() : 'diamonds');
    const prismWord = (typeof t === 'function' && t('prisms_word')) ? t('prisms_word') : 'prisms';
    if (addDiamonds > 0) parts.push(`+${addDiamonds} ${diaWord}`);
    if (addPrisms > 0) parts.push(`+${addPrisms} ${prismWord}`);
    toastText += parts.join(' ');
    showHintToast(toastText);

    closeDailyLoginModal();
  };

  if (isDouble) {
    showAdPlaceholder(executeGrantReward, null);
  } else {
    executeGrantReward();
  }
}

// [UI.GQ]
function renderVictoryStars(starsCount) {
  const row = document.getElementById('victoryStarsRow');
  if (!row) return;
  row.innerHTML = '';

  if (isOverdriveMode) {
    const isHyperion = (typeof activePalette !== 'undefined' && activePalette === 'matrix_green');
    const starStroke = isHyperion ? '#3b82f6' : '#00e5ff';
    const starGlow = isHyperion ? 'rgba(59, 130, 246, 0.95)' : 'rgba(0, 229, 255, 0.95)';
    const slot = document.createElement('span');
    slot.className = 'star-slot filled overdrive-victory-badge';
    setTimeout(() => sfx('star'), 160);
    slot.innerHTML = `
      <svg width="96" height="76" viewBox="0 0 48 38" fill="none" style="filter: drop-shadow(0 0 16px ${starGlow}) drop-shadow(0 0 32px rgba(240, 95, 159, 0.65));">
        <g transform="translate(1.5, 19.5) scale(0.18)">
          <polygon points="12,2 15.09,8.26 22,9.27 17,14.14 18.18,21.02 12,17.77 5.82,21.02 7,14.14 2,9.27 8.91,8.26" 
            fill="#ffffff" stroke="#ffffff" stroke-width="2" stroke-linejoin="round" style="filter: drop-shadow(0 0 4px #ffffff);"/>
        </g>
        <g transform="translate(42.5, 19.5) scale(0.18)">
          <polygon points="12,2 15.09,8.26 22,9.27 17,14.14 18.18,21.02 12,17.77 5.82,21.02 7,14.14 2,9.27 8.91,8.26" 
            fill="#ffffff" stroke="#ffffff" stroke-width="2" stroke-linejoin="round" style="filter: drop-shadow(0 0 4px #ffffff);"/>
        </g>
        <g transform="translate(12, 4) scale(1.0)">
          <polygon points="12,2 15.09,8.26 22,9.27 17,14.14 18.18,21.02 12,17.77 5.82,21.02 7,14.14 2,9.27 8.91,8.26" 
            fill="#f05f9f" stroke="${starStroke}" stroke-width="1.6" stroke-linejoin="round"/>
        </g>
        <g transform="translate(21.8, 14.5) scale(0.18)">
          <polygon points="12,2 15.09,8.26 22,9.27 17,14.14 18.18,21.02 12,17.77 5.82,21.02 7,14.14 2,9.27 8.91,8.26" 
            fill="#ffffff" stroke="#ffffff" stroke-width="2" stroke-linejoin="round" style="filter: drop-shadow(0 0 6px #ffffff);"/>
        </g>
      </svg>`;
    row.appendChild(slot);
    return;
  }

  for (let s = 1; s <= 3; s++) {
    const isFilled = s <= starsCount;
    const slot = document.createElement('span');
    slot.className = `star-slot ${isFilled ? 'filled' : 'empty'}`;
    if (isFilled) setTimeout(() => sfx('star'), 160 + (s - 1) * 180);
    slot.innerHTML = `
      <svg viewBox="0 0 24 24">
        <polygon points="12,2 15.1,8.6 22,9.6 17,14.6 18.2,21.6 12,18.3 5.8,21.6 7,14.6 2,9.6 8.9,8.6"
          fill="${isFilled ? '#f59e0b' : 'rgba(16,21,40,.7)'}"
          stroke="${isFilled ? '#f59e0b' : '#334155'}"
          stroke-width="1.8"
          stroke-linejoin="round" />
      </svg>`;
    row.appendChild(slot);
  }
}

// [UI.GR]
function isOverCancelZone(clientX, clientY) {
  if (clientX === undefined || clientY === undefined) return false;
  const wrapper = document.getElementById('controlsWrapper');
  if (!wrapper || wrapper.classList.contains('hidden')) return false;
  const rect = wrapper.getBoundingClientRect();
  return (
    clientX >= rect.left &&
    clientX <= rect.right &&
    clientY >= rect.top &&
    clientY <= rect.bottom
  );
}

// [UI.GS]
function showCancelZoneVisual(show) {
  const overlay = document.getElementById('cancelZoneOverlay');
  const buildPanel = document.getElementById('buildPanel');
  if (show) {
    if (overlay) overlay.classList.remove('hidden');
    if (buildPanel) buildPanel.classList.add('drag-hidden');
  } else {
    if (overlay) {
      overlay.classList.add('hidden');
      overlay.classList.remove('hovered');
    }
    if (buildPanel) buildPanel.classList.remove('drag-hidden');
  }
}

// [UI.GT]
function updateCancelZoneHover(clientX, clientY) {
  const overlay = document.getElementById('cancelZoneOverlay');
  if (!overlay || overlay.classList.contains('hidden')) return;
  if (isOverCancelZone(clientX, clientY)) {
    overlay.classList.add('hovered');
  } else {
    overlay.classList.remove('hovered');
  }
}

// [UI.GU]
canvas.addEventListener('touchstart', (e) => {
  if (gameState !== 'PLAYING') return;
  if (e.touches.length === 1 && !draggingTower) {
    isPanning = true;
    panStartTouch = { x: e.touches[0].clientX, y: e.touches[0].clientY };
    panStartCam = { x: camX, y: camY };
  } else if (e.touches.length === 2) {
    isPanning = false;
    const t1 = e.touches[0];
    const t2 = e.touches[1];
    initialPinchDist = Math.hypot(t2.clientX - t1.clientX, t2.clientY - t1.clientY);
    initialPinchZoom = camZoom;
    pinchCenterWorld = screenToWorld((t1.clientX + t2.clientX) / 2, (t1.clientY + t2.clientY) / 2);
  }
}, { passive: false });

// [UI.GV]
canvas.addEventListener('touchmove', (e) => {
  if (e.touches.length === 1 && isPanning) {
    const dx = e.touches[0].clientX - panStartTouch.x;
    const dy = e.touches[0].clientY - panStartTouch.y;
    if (camZoom > baseZoom * 1.01) {
      camX = panStartCam.x + dx;
      camY = panStartCam.y + dy;
      clampCamera();
    }
  } else if (e.touches.length === 2 && initialPinchDist) {
    const t1 = e.touches[0];
    const t2 = e.touches[1];
    const curDist = Math.hypot(t2.clientX - t1.clientX, t2.clientY - t1.clientY);
    camZoom = Math.min(maxZoom, Math.max(minZoom, initialPinchZoom * (curDist / initialPinchDist)));
    const centerScreen = { x: (t1.clientX + t2.clientX) / 2, y: (t1.clientY + t2.clientY) / 2 };
    camX = centerScreen.x - pinchCenterWorld.x * camZoom;
    camY = centerScreen.y - pinchCenterWorld.y * camZoom;
    clampCamera();
  }
}, { passive: false });

// [UI.GW]
canvas.addEventListener('touchend', (e) => {
  if (e.touches.length < 2) initialPinchDist = null;
  if (e.touches.length === 0) isPanning = false;
});

// [UI.GX]
window.addEventListener('keydown', (e) => {
  if ((e.ctrlKey || e.metaKey) && (e.code === 'KeyR' || e.key === 'r' || e.key === 'R')) {
    if (gameState === 'PLAYING' || gameState === 'PAUSED' || gameState === 'VICTORY' || gameState === 'DEFEAT') {
      e.preventDefault();
      retryLevel();
      return;
    }
  }

  if (e.code === 'Space' && gameState === 'PLAYING') {
    mouseSpacePressed = true;
    e.preventDefault();
  }
});

// [UI.GY]
window.addEventListener('keyup', (e) => {
  if (e.code === 'Space') {
    mouseSpacePressed = false;
    isMousePanning = false;
  }
});

// [UI.GZ]
canvas.addEventListener('mousedown', (e) => {
  if (gameState !== 'PLAYING') return;
  if (e.button === 1 || (e.button === 0 && mouseSpacePressed)) {
    isMousePanning = true;
    panStartMouse = { x: e.clientX, y: e.clientY };
    panStartCam = { x: camX, y: camY };
    e.preventDefault();
  }
});

// [UI.HA]
canvas.addEventListener('mousemove', (e) => {
  if (!isMousePanning) return;
  const dx = e.clientX - panStartMouse.x;
  const dy = e.clientY - panStartMouse.y;
  camX = panStartCam.x + dx;
  camY = panStartCam.y + dy;
  clampCamera();
});

// [UI.HB]
canvas.addEventListener('mouseup', () => {
  isMousePanning = false;
});

// [UI.HC]
canvas.addEventListener('wheel', (e) => {
  if (gameState !== 'PLAYING') return;
  e.preventDefault();
  const mouseWorld = screenToWorld(e.clientX, e.clientY);
  const zoomSpeed = 0.15;
  camZoom = Math.min(maxZoom, Math.max(minZoom, camZoom * (1 - (e.deltaY > 0 ? zoomSpeed : -zoomSpeed))));
  camX = e.clientX - mouseWorld.x * camZoom;
  camY = e.clientY - mouseWorld.y * camZoom;
  clampCamera();
}, { passive: false });

let hintToastTimer = null;
// [UI.HD]
function showHintToast(message) {
  const el = document.getElementById('hintToast');
  if (!el) return;
  el.textContent = message;
  el.classList.add('visible');
  if (hintToastTimer) clearTimeout(hintToastTimer);
  // [UI.HE]
  hintToastTimer = setTimeout(() => { el.classList.remove('visible'); }, 2000);
}

//  Tower selection, build panel UI and inspection state controller.
// [UI.HF]
function initBuildPanel() {
    const panel = document.getElementById('buildPanel');
    if (!panel || typeof TOWER_CONFIGS === 'undefined') return;
    panel.querySelectorAll('.tower-btn').forEach(b => b.remove());

    // Очищаем кэш DOM и кэш классов кнопок, чтобы новые элементы гарантированно получили актуальные стили
    if (typeof _elCache !== 'undefined' && _elCache) {
        for (const k in TOWER_CONFIGS) {
            delete _elCache[`btn-${k}`];
        }
    }
    if (typeof _hudStateCache !== 'undefined' && _hudStateCache && _hudStateCache.towerClasses) {
        _hudStateCache.towerClasses = Object.create(null);
    }

    const canonicalOrder = Object.keys(TOWER_CONFIGS);
    const pool = getBuildPanelPool(currentLevel);
    const towerTypes = canonicalOrder.filter(t => pool.includes(t));

    towerTypes.forEach(type => {
        const conf = TOWER_CONFIGS[type];
        const isUnlocked = isTowerActiveThisLevel(type);
        const affordable = gold >= conf.cost;
        const initialCls = !isUnlocked
            ? 'tower-btn locked disabled'
            : (!affordable ? 'tower-btn disabled' : 'tower-btn ready');

        const btn = document.createElement('div');
        btn.className = initialCls;
        btn.id = `btn-${type}`;
        btn.setAttribute('data-type', type);

        if (typeof _hudStateCache !== 'undefined' && _hudStateCache && _hudStateCache.towerClasses) {
            _hudStateCache.towerClasses[type] = initialCls;
        }

        const reqLvl = getTowerUnlockLevel(type);
        const costRowHtml = isUnlocked
            ? `<span class="cost">
                <span class="cost-icon">
                    <svg width="12" height="12" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#ff9100" /><text x="12" y="17.5" font-size="16" font-weight="900" fill="#000000" text-anchor="middle" font-family="Montserrat, sans-serif">$</text></svg>
                </span>
                ${conf.cost}
               </span>`
            : `<span class="cost" style="color:#8ea3c4; gap:3px;">
                ${typeof CUSTOM_LOCK_SVG !== 'undefined' ? CUSTOM_LOCK_SVG : ''}
                <span>L${reqLvl}</span>
               </span>`;

        btn.innerHTML = `
            <span class="tower-btn-title">${TOWER_NAMES[type] || type}</span>
            <div class="tower-btn-icon">
                ${TOWER_ICONS[type] || ''}
            </div>
            ${costRowHtml}
        `;

        // [UI.HG]
        btn.addEventListener('mousedown', (e) => {
            if (gameState !== 'PLAYING') return;
            if (!isTowerActiveThisLevel(type)) {
                if (typeof sfx === 'function') sfx('denied');
                const unlockLvl = getTowerUnlockLevel(type);
                showHintToast(typeof t === 'function' ? (t('unlocks_on_level_n', { n: unlockLvl }) || t('available_on_level_n', { n: unlockLvl })) : `Unlocks on Level ${unlockLvl}`);
                return;
            }
            if (gold < TOWER_CONFIGS[type].cost || btn.classList.contains('disabled')) {
                if (typeof sfx === 'function') sfx('denied');
                if (typeof vibrate === 'function') vibrate('warning');
                showHintToast(typeof t === 'function' ? (t('not_enough_gold') || 'Not enough Gold!') : 'Not enough Gold!');
                return;
            }
            const worldPos = screenToWorld(e.clientX, e.clientY);
            draggingTower = { type: type, worldX: worldPos.x, worldY: worldPos.y, isTouch: false };
            showCancelZoneVisual(true);
        });

        // [UI.HH]
        btn.addEventListener('touchstart', (e) => {
            if (gameState !== 'PLAYING') return;
            if (!isTowerActiveThisLevel(type)) {
                if (typeof sfx === 'function') sfx('denied');
                const unlockLvl = getTowerUnlockLevel(type);
                showHintToast(typeof t === 'function' ? (t('unlocks_on_level_n', { n: unlockLvl }) || t('available_on_level_n', { n: unlockLvl })) : `Unlocks on Level ${unlockLvl}`);
                return;
            }
            if (gold < TOWER_CONFIGS[type].cost || btn.classList.contains('disabled')) {
                if (typeof sfx === 'function') sfx('denied');
                if (typeof vibrate === 'function') vibrate('warning');
                showHintToast(typeof t === 'function' ? (t('not_enough_gold') || 'Not enough Gold!') : 'Not enough Gold!');
                return;
            }
            const touch = e.touches[0];
            const worldPos = screenToWorld(touch.clientX, touch.clientY - TOUCH_OFFSET_Y);
            draggingTower = { type: type, worldX: worldPos.x, worldY: worldPos.y, isTouch: true };
            showCancelZoneVisual(true);
            e.preventDefault();
        }, { passive: false });

        panel.appendChild(btn);
    });
}

// [UI.HI]
window.addEventListener('mousemove', (e) => {
  if (!draggingTower) return;
  const worldPos = screenToWorld(e.clientX, e.clientY);
  draggingTower.worldX = worldPos.x;
  draggingTower.worldY = worldPos.y;
  updateCancelZoneHover(e.clientX, e.clientY);
});

// [UI.HJ]
window.addEventListener('touchmove', (e) => {
  if (!draggingTower || e.touches.length > 1) return;
  const touch = e.touches[0];
  const worldPos = screenToWorld(touch.clientX, touch.clientY - TOUCH_OFFSET_Y);
  draggingTower.worldX = worldPos.x;
  draggingTower.worldY = worldPos.y;
  updateCancelZoneHover(touch.clientX, touch.clientY);
}, { passive: false });

// [UI.HK]
window.addEventListener('mouseup', (e) => {
  if (draggingTower) handleDrop(draggingTower.worldX, draggingTower.worldY, e.clientX, e.clientY);
});

// [UI.HL]
window.addEventListener('touchend', (e) => {
  if (draggingTower) {
    let cx, cy;
    if (e.changedTouches && e.changedTouches.length > 0) {
      cx = e.changedTouches[0].clientX;
      cy = e.changedTouches[0].clientY;
    }
    handleDrop(draggingTower.worldX, draggingTower.worldY, cx, cy);
  }
});

// [UI.HM]
canvas.addEventListener('click', (e) => {
  if (gameState !== 'PLAYING' || isPanning) return;
  const worldPos = screenToWorld(e.clientX, e.clientY);
  const c = Math.floor(worldPos.x / TILE_SIZE);
  const r = Math.floor(worldPos.y / TILE_SIZE);
  const clickedTower = towers.find(t => t.c === c && t.r === r);

  if (tutorialActive && tutorialLevel === 2 && tutorialStep === 2 && selectedTower) {
    if (clickedTower && clickedTower === selectedTower) {
      if (typeof showHintToast === 'function') {
        showHintToast(typeof t === 'function' ? t('tut_close_hint') : 'Tap the empty field or ✕ to close');
      }
      return;
    }
  }

  if (clickedTower) {
    selectTower(clickedTower);
  } else {
    deselectTower();
  }
});

// [UI.HN]
function armSellConfirm() {
  sellConfirmArmed = true;
  if (sellConfirmTimer) clearTimeout(sellConfirmTimer);
  // [UI.HO]
  sellConfirmTimer = setTimeout(() => {
    sellConfirmArmed = false;
    sellConfirmTimer = null;
    updateInspectUI();
  }, 3000);
  updateInspectUI();
}

// [UI.HP]
function resetSellConfirm() {
  sellConfirmArmed = false;
  if (sellConfirmTimer) { clearTimeout(sellConfirmTimer); sellConfirmTimer = null; }
}

// [UI.HQ]
function selectTower(tower) {
  selectedTower = tower;
  resetSellConfirm();
  document.getElementById('buildPanel').classList.add('hidden');
  document.getElementById('inspectPanel').classList.remove('hidden');
  updateInspectUI();

  if (tutorialActive && tutorialLevel === 2 && tutorialStep === 0) {
    tutorialStep = 1;
  }
}

// [UI.HR]
function deselectTower() {
  selectedTower = null;
  resetSellConfirm();
  document.getElementById('inspectPanel').classList.add('hidden');
  document.getElementById('buildPanel').classList.remove('hidden');

  if (tutorialActive && tutorialLevel === 2 && tutorialStep === 1) {
    tutorialStep = 0;
  } else if (tutorialActive && tutorialLevel === 2 && tutorialStep === 2) {
    completeTutorial(2);
  }
}

// [UI.HS]
function updateInspectUI() {
  if (!selectedTower) return;
  const t = selectedTower;
  const lvlConfig = LEVELS_DATA[currentLevel];
  const isL1FirstTime = (currentLevel === 1 && !isEndlessMode && !isOverdriveMode && !hasClearedLevelBefore(1) && !devMode);
  const canUpgradeLevel = !(lvlConfig && lvlConfig.canUpgrade === false && isL1FirstTime);

  const _tr = (typeof window.t === 'function') ? window.t : ((k) => k.toUpperCase());
  const slowLabel = _tr('stat_slow') || 'SLOW:';
  const durLabel = _tr('stat_dur') || 'DUR:';
  const rngLabel = _tr('stat_rng') || 'RNG:';
  const dmgLabel = _tr('stat_dmg') || 'DMG:';
  const spdLabel = _tr('stat_spd') || 'SPD:';
  const dpsLabel = _tr('stat_dps') || 'DPS:';

  const iconBox = document.getElementById('inspectIconBox');
  if (iconBox) {
    iconBox.innerHTML = buildTowerIconSvg(t.type, t.level || 1, 38) || '';
  }

  const nameEl = document.getElementById('inspectName');
  if (nameEl) nameEl.textContent = TOWER_NAMES[t.type] || t.type;

  const lvlTextEl = document.getElementById('inspectLvlText');
  if (lvlTextEl) {
    const lvlPrefix = (typeof window.t === 'function' && window.t('lvl_short')) ? window.t('lvl_short') : 'LVL';
    lvlTextEl.textContent = (typeof window.t === 'function' && window.t('level_n_short', { n: t.level || 1 })) 
      ? window.t('level_n_short', { n: t.level || 1 }) 
      : `${lvlPrefix} ${t.level || 1}`;
  }

  for (let lvl = 1; lvl <= 3; lvl++) {
    const seg = document.getElementById(`lvlBar${lvl}`);
    if (seg) {
      if (lvl <= t.level) {
        seg.classList.add('active');
        seg.style.background = t.color || '#00e5ff';
        seg.style.boxShadow = `0 0 5px ${t.color || '#00e5ff'}99`;
      } else {
        seg.classList.remove('active');
        seg.style.background = 'rgba(140, 200, 255, 0.2)';
        seg.style.boxShadow = 'none';
      }
    }
  }

  const statsBox = document.getElementById('inspectStatsBox');
  if (statsBox) {
    const curRng = Math.round(t.range);
    if (t.type === 'stasis') {
      const slowPct = Math.round((t.slowFactor !== undefined ? t.slowFactor : 0.3) * 100);
      const dur = ((t.slowDuration !== undefined ? t.slowDuration : 1.4)).toFixed(1);
      statsBox.innerHTML = `
        <div class="inspect-stat-item"><span class="inspect-stat-lbl">${slowLabel}</span><span class="inspect-stat-val">${slowPct}%</span></div>
        <div class="inspect-stat-item"><span class="inspect-stat-lbl">${durLabel}</span><span class="inspect-stat-val">${dur}s</span></div>
        <div class="inspect-stat-item"><span class="inspect-stat-lbl">${rngLabel}</span><span class="inspect-stat-val">${curRng}</span></div>
      `;
    } else if (t.fireRate) {
      const curDmg = +(t.damage || 0).toFixed(1);
      const curSpd = +(t.fireRate || 0).toFixed(2);
      statsBox.innerHTML = `
        <div class="inspect-stat-item"><span class="inspect-stat-lbl">${dmgLabel}</span><span class="inspect-stat-val">${curDmg}</span></div>
        <div class="inspect-stat-item"><span class="inspect-stat-lbl">${spdLabel}</span><span class="inspect-stat-val">${curSpd}s</span></div>
        <div class="inspect-stat-item"><span class="inspect-stat-lbl">${rngLabel}</span><span class="inspect-stat-val">${curRng}</span></div>
      `;
    } else {
      const curDmg = +(t.damage || 0).toFixed(1);
      statsBox.innerHTML = `
        <div class="inspect-stat-item"><span class="inspect-stat-lbl">${dpsLabel}</span><span class="inspect-stat-val">${curDmg}</span></div>
        <div class="inspect-stat-item"><span class="inspect-stat-lbl">${rngLabel}</span><span class="inspect-stat-val">${curRng}</span></div>
      `;
    }
  }

  const upgCost = getUpgradeCost(t.type, t.level);
  const upgBtn = document.getElementById('inspectUpgradeBtn');
  const upgCostWrapEl = document.getElementById('inspectUpgradeCost');
  const upgValEl = document.getElementById('inspectUpgradeCostVal');
  const upgIconEl = document.getElementById('inspectUpgradeCostIcon');
  const upgStatusEl = document.getElementById('inspectUpgradeStatus');
  const sellValTextEl = document.getElementById('inspectSellValText');
  const sellTitleEl = document.getElementById('inspectSellTitle');

  if (!canUpgradeLevel) {
    upgBtn.disabled = true;
    if (upgCostWrapEl) upgCostWrapEl.style.display = 'none';
    if (upgValEl) upgValEl.textContent = '';
    if (upgIconEl) upgIconEl.style.display = 'none';
    if (upgStatusEl) upgStatusEl.textContent = _tr('locked');
  } else if (t.level >= 3) {
    upgBtn.disabled = true;
    if (upgCostWrapEl) upgCostWrapEl.style.display = 'none';
    if (upgValEl) upgValEl.textContent = '';
    if (upgIconEl) upgIconEl.style.display = 'none';
    if (upgStatusEl) upgStatusEl.textContent = _tr('max');
  } else {
    const canAfford = gold >= upgCost;
    upgBtn.disabled = !canAfford;
    if (upgCostWrapEl) upgCostWrapEl.style.display = 'flex';
    if (upgValEl) {
      upgValEl.textContent = `${upgCost}`;
      upgValEl.style.color = canAfford ? '#ffffff' : '#f05f9f';
    }
    if (upgIconEl) upgIconEl.style.display = 'inline-flex';
    if (upgStatusEl) upgStatusEl.textContent = _tr('upgrade');
  }

  const refund = Math.floor(t.totalInvested * 0.7);
  const sellBtn = document.getElementById('inspectSellBtn');
  const sellIconEl = sellBtn ? sellBtn.querySelector('.cost-icon') : null;
  if (sellConfirmArmed) {
    if (sellBtn) sellBtn.classList.add('confirm-armed');
    if (sellTitleEl) sellTitleEl.textContent = _tr('confirm_q');
    if (sellValTextEl) sellValTextEl.textContent = `+${refund}`;
    if (sellIconEl) sellIconEl.style.display = 'none';
  } else {
    if (sellBtn) sellBtn.classList.remove('confirm-armed');
    if (sellTitleEl) sellTitleEl.textContent = _tr('sell');
    if (sellValTextEl) sellValTextEl.textContent = `${refund}`;
    if (sellIconEl) sellIconEl.style.display = '';
  }
}
// [UI.HT]
function updateWaveCircle(dt) {
  const progEl = el('waveCircleProg');
  if (!progEl) return;
  const circumference = 207.35;
  let p = 0;
  let isCountdown = false;

  const lvlConfig = LEVELS_DATA[currentLevel];
  let totalDelay = 5.0;
  let baseBonus = 15;

  if (lvlConfig && lvlConfig.waves) {
    const currentWaveObj = lvlConfig.waves.find(w => w.wave === wave);
    if (currentWaveObj) {
      if (currentWaveObj.delayAfter !== undefined) {
        totalDelay = currentWaveObj.delayAfter;
      }
      if (currentWaveObj.earlyBonus !== undefined) {
        baseBonus = currentWaveObj.earlyBonus;
      }
    }
  }

  if (waveTimerActive && autoWaveTimeRemaining > 0) {
    p = totalDelay > 0 ? Math.max(0, Math.min(1, autoWaveTimeRemaining / totalDelay)) : 0;
    isCountdown = true;
  } else if (waveInProgress) {
    p = (spawnQueue.length === 0) ? 1.0 : Math.max(0, Math.min(1, waveSpawnElapsedTime / waveTotalSpawnTime));
  }

  if (p > 0.005) {
    progEl.style.opacity = '1';
    progEl.style.strokeDashoffset = (circumference * (1 - p)).toFixed(2);
  } else {
    progEl.style.opacity = '0';
    progEl.style.strokeDashoffset = circumference.toFixed(2);
  }
  progEl.classList.toggle('counting-down', isCountdown);
  // [UI.HTM]
  const isAccelerated = isCountdown && (typeof isWaveTimerAccelerated !== 'undefined' && isWaveTimerAccelerated);
  progEl.classList.toggle('accelerated', isAccelerated);
  const bonusElForAcc = el('waveGoBonus');
  if (bonusElForAcc) {
    bonusElForAcc.classList.toggle('accelerated', isAccelerated);
  }

  const bonusEl = el('waveGoBonus');
  const bonusValEl = el('waveGoBonusVal');
  if (!bonusEl || !bonusValEl) return;

  if (typeof isEndlessMode !== 'undefined' && isEndlessMode) {
    baseBonus = 15 + Math.floor(wave * 1.5);
  }

  const maxW = (lvlConfig && lvlConfig.totalWaves) || 10;
  let bonus = 0;
  if (isCountdown && ((typeof isEndlessMode !== 'undefined' && isEndlessMode) || wave < maxW)) {
    const moneyMultiplier = 1 + getBattleUpgradeEffectiveLevel('base_gold')* 0.05;
    const fractionSaved = totalDelay > 0 ? Math.min(1, Math.max(0, autoWaveTimeRemaining / totalDelay)) : 0;
    bonus = Math.round(fractionSaved * baseBonus * moneyMultiplier);
  }

  bonusValEl.textContent = bonus > 0 ? bonus : '0';
  bonusEl.classList.toggle('visible', bonus > 0);
}

//  Main UI frame update and HUD sync loop.
// Main UI frame update and HUD sync loop.
const _hudStateCache = {
  goldStr: '',
  hpStr: '',
  lvlStr: '',
  waveStr: '',
  waveBtnDisabled: null,
  towerClasses: Object.create(null)
};

// [UI.HU]
function updateUI() {
  const lvlConfig = LEVELS_DATA[currentLevel];
  const maxW = lvlConfig ? lvlConfig.totalWaves : 10;

  const goldStr = formatResourceVal(gold);
  if (_hudStateCache.goldStr !== goldStr) {
    _hudStateCache.goldStr = goldStr;
    const goldEl = el('goldVal');
    if (goldEl) goldEl.textContent = goldStr;
  }

  const hpStr = formatResourceVal(baseHp);
  if (_hudStateCache.hpStr !== hpStr) {
    _hudStateCache.hpStr = hpStr;
    const hpEl = el('hpVal');
    if (hpEl) hpEl.textContent = hpStr;
  }

  let lvlStr, waveStr;
  if (typeof isEndlessMode !== 'undefined' && isEndlessMode) {
    lvlStr = `${currentLevelSection || 1}`;
    waveStr = `${wave}/∞`;
  } else {
    lvlStr = `${currentLevel}`;
    waveStr = `${Math.min(wave, maxW)}/${maxW}`;
  }

  if (_hudStateCache.lvlStr !== lvlStr) {
    _hudStateCache.lvlStr = lvlStr;
    const lvlEl = el('levelText');
    if (lvlEl) lvlEl.textContent = lvlStr;
  }

  if (_hudStateCache.waveStr !== waveStr) {
    _hudStateCache.waveStr = waveStr;
    const waveEl = el('waveText');
    if (waveEl) waveEl.textContent = waveStr;
  }

  syncTopHudVisibility();

  for (let key in TOWER_CONFIGS) {
    const btn = el(`btn-${key}`);
    if (btn) {
      const isUnlocked = isTowerActiveThisLevel(key);
      const affordable = gold >= TOWER_CONFIGS[key].cost;
      const nextCls = !isUnlocked
        ? 'tower-btn locked disabled'
        : (!affordable ? 'tower-btn disabled' : 'tower-btn ready');
      if (_hudStateCache.towerClasses[key] !== nextCls) {
        _hudStateCache.towerClasses[key] = nextCls;
        btn.className = nextCls;
      }
    }
  }

  const waveBtn = el('waveBtn');
  if (waveBtn) {
    const isEndMode = (typeof isEndlessMode !== 'undefined' && isEndlessMode);
    const isFinalDone = !isEndMode && ((typeof finalWaveSpawned !== 'undefined' && finalWaveSpawned) || (wave >= maxW && !waveTimerActive));
    const shouldDisable = (waveInProgress || spawnQueue.length > 0 || isFinalDone);
    if (_hudStateCache.waveBtnDisabled !== shouldDisable) {
      _hudStateCache.waveBtnDisabled = shouldDisable;
      waveBtn.disabled = shouldDisable;
    }
  }

  updateHudSpeedWidget();

  if (selectedTower) updateInspectUI();
}

// [UI.HV]
function createFloatingDamage(x, y, damage, color = '#f05f9f') {
  if (typeof settings !== 'undefined' && settings.showDamage === false) return;
  const dmgVal = typeof damage === 'number' ? Math.round(damage) : damage;
  if (!dmgVal || dmgVal <= 0) return;

  pushParticle({
    x: x + (Math.random() - 0.5) * 12,
    y: y - 8 + (Math.random() - 0.5) * 6,
    vx: (Math.random() - 0.5) * 18,
    vy: -28 - Math.random() * 22,
    text: `-${dmgVal}`,
    color: color,
    life: 0.65,
    maxLife: 0.65,
    isText: true
  });
}

// [UI.HW]
function createDamageShards(x, y, color, damage = 16, isDeath = false) {
  if (!isDeath && typeof TOWER_FX !== 'undefined') return;
  const count = isDeath ? (perfMode === 'low' ? 6 : 11) : Math.max(2, Math.min(4, Math.ceil(damage / 20)));
  const baseSize = isDeath ? 7.8 : Math.max(3.4, Math.min(6.4, 2.4 + damage * 0.06));
  const col = color || '#00e5ff';

  // При гибели моба добавляем короткую неоновую вспышку и россыпь светящихся искр его цвета
  if (isDeath) {
    pushParticle({
      x, y, vx: 0, vy: 0,
      color: col,
      radius: perfMode === 'low' ? 16 : 22,
      life: 0.16, maxLife: 0.16,
      isFlash: true
    });
    const glowCount = perfMode === 'low' ? 4 : 8;
    for (let g = 0; g < glowCount; g++) {
      const a = Math.random() * Math.PI * 2;
      const spd = 45 + Math.random() * 115;
      pushParticle({
        x, y,
        vx: Math.cos(a) * spd,
        vy: Math.sin(a) * spd,
        drag: 0.92,
        color: g % 3 === 0 ? '#ffffff' : col,
        radius: 2.6 + Math.random() * 2.4,
        life: 0.28 + Math.random() * 0.18,
        maxLife: 0.46,
        isStreak: true
      });
    }
  }

  for (let i = 0; i < count; i++) {
    const angle = (isDeath ? (i * (Math.PI * 2 / count)) : Math.random() * Math.PI * 2) + (Math.random() - 0.5) * 0.55;
    const speed = isDeath ? (65 + Math.random() * 135) : (35 + Math.random() * 85);
    const sz = baseSize * (0.75 + Math.random() * 0.55);

    const shapeType = Math.floor(Math.random() * 3);
    let pts;

    if (shapeType === 0) {
      pts = [
        { x: -sz * 0.6, y: -sz * 0.3 },
        { x: sz * 0.8, y: -sz * 0.1 },
        { x: (Math.random() - 0.5) * sz * 0.5, y: sz * 0.7 }
      ];
    } else if (shapeType === 1) {
      pts = [
        { x: -sz * 0.5, y: -sz * 0.5 },
        { x: sz * 0.6, y: -sz * 0.4 },
        { x: sz * 0.4, y: sz * 0.6 },
        { x: -sz * 0.5, y: sz * 0.4 }
      ];
    } else {
      pts = [
        { x: -sz * 0.8, y: -sz * 0.2 },
        { x: sz * 0.9, y: -sz * 0.15 },
        { x: sz * 0.6, y: sz * 0.25 },
        { x: -sz * 0.7, y: sz * 0.2 }
      ];
    }

    pushParticle({
      x, y,
      vx: Math.cos(angle) * speed,
      vy: Math.sin(angle) * speed,
      drag: 0.94,
      color: col,
      radius: sz,
      pts: pts,
      angle: Math.random() * Math.PI * 2,
      vRot: (Math.random() - 0.5) * 16,
      life: isDeath ? (0.36 + Math.random() * 0.22) : (0.22 + Math.random() * 0.14),
      maxLife: isDeath ? 0.58 : 0.36,
      isShard: true
    });
  }
}

// [UI.HWF] Конфигурация спецэффектов v11 (1-в-1 из Hit & Explosion FX Sandbox v11) + Offscreen-кэширование
const ENEMY_REACTIONS = {"knockback": true, "jitter": true, "hitTilt": true};
const TOWER_FX = {"gun": {"blastScale": 1, "layers": [{"uid": "L62", "type": "bulletTrails", "name": "Трассеры пуль #1", "enabled": true, "params": {"size": 2.25, "speed": 1.6, "opacity": 0.55, "colorMode": "tower", "customColor": "#ff0000"}}, {"uid": "L63", "type": "muzzleFlash", "name": "Дульная вспышка #1", "enabled": true, "params": {"size": 0.9, "speed": 2.5, "opacity": 0.55, "duration": 0.32, "smooth": 2.5, "shape": "default", "customPoly": [{"x": 0.01, "y": -0.9}, {"x": 0.581, "y": -0.614}, {"x": 0.881, "y": -0.029}, {"x": 0.596, "y": 0.586}, {"x": -0.004, "y": 0.886}], "colorMode": "white", "customColor": "#ffffff"}}, {"uid": "L64", "type": "deepGlow", "name": "Глубокий Glow #1", "enabled": true, "params": {"size": 1.85, "speed": 1.9, "opacity": 1, "duration": 0.66, "smooth": 0.2, "flicker": false, "colorMode": "tower", "customColor": "#ff9100"}}, {"uid": "L65", "type": "volumeHalo", "name": "Объёмный ореол #1", "enabled": true, "params": {"size": 0.7, "speed": 1.6, "opacity": 0.85, "duration": 0.7, "smooth": 1.9, "flicker": false, "colorMode": "tower", "customColor": "#38bdf8"}}, {"uid": "L66", "type": "sparks", "name": "Искры #2", "enabled": true, "params": {"size": 1, "speed": 0.7, "opacity": 1, "count": 14, "stretch": 1, "range": 1.1, "centerFade": 0.1, "duration": 0.32, "directionalCone": true, "velocityStretch": false, "tempGradient": false, "shape": "default", "customPoly": [{"x": 0, "y": -0.9}, {"x": 0.3, "y": -0.25}, {"x": 0.9, "y": 0}, {"x": 0.3, "y": 0.25}, {"x": 0, "y": 0.9}, {"x": -0.3, "y": 0.25}, {"x": -0.9, "y": 0}, {"x": -0.3, "y": -0.25}], "colorMode": "tower", "customColor": "#ff9100"}}, {"uid": "L67", "type": "energyMotes", "name": "Энерго-пыльца #1", "enabled": true, "params": {"size": 1, "speed": 1, "opacity": 1, "count": 10, "spread": 0.45, "duration": 0.95, "smooth": 1, "shape": "default", "customPoly": [{"x": 0, "y": -0.9}, {"x": 0.3, "y": -0.25}, {"x": 0.9, "y": 0}, {"x": 0.3, "y": 0.25}, {"x": 0, "y": 0.9}, {"x": -0.3, "y": 0.25}, {"x": -0.9, "y": 0}, {"x": -0.3, "y": -0.25}], "colorMode": "tower", "customColor": "#38bdf8"}}]}, "laser": {"blastScale": 1, "layers": [{"uid": "L68", "type": "sparks", "name": "Искры #1", "enabled": true, "params": {"size": 1, "speed": 1, "opacity": 1, "count": 6, "stretch": 0.2, "range": 1, "centerFade": 0, "duration": 0.28, "directionalCone": true, "velocityStretch": true, "tempGradient": false, "shape": "default", "customPoly": [{"x": 0, "y": -0.9}, {"x": 0.3, "y": -0.25}, {"x": 0.9, "y": 0}, {"x": 0.3, "y": 0.25}, {"x": 0, "y": 0.9}, {"x": -0.3, "y": 0.25}, {"x": -0.9, "y": 0}, {"x": -0.3, "y": -0.25}], "colorMode": "tower", "customColor": "#ff9100"}}, {"uid": "L69", "type": "deepGlow", "name": "Глубокий Glow", "enabled": true, "params": {"size": 1.45, "speed": 1, "opacity": 0.6, "duration": 0.24, "smooth": 0.6, "flicker": true, "colorMode": "tower", "customColor": "#ff9100"}}, {"uid": "L70", "type": "deepGlow", "name": "Глубокий Glow #2", "enabled": true, "params": {"size": 3, "speed": 1, "opacity": 0.05, "duration": 0.24, "smooth": 1.6, "flicker": true, "colorMode": "tower", "customColor": "#ff9100"}}, {"uid": "L71", "type": "volumeHalo", "name": "Объёмный ореол #1", "enabled": false, "params": {"size": 1.7, "speed": 1.35, "opacity": 0.1, "duration": 0.34, "smooth": 1.45, "flicker": true, "colorMode": "tower", "customColor": "#38bdf8"}}]}, "mortar": {"blastScale": 1, "layers": [{"uid": "L72", "type": "muzzleFlash", "name": "Дульная вспышка #1", "enabled": true, "params": {"size": 0.9, "speed": 2.4, "opacity": 0.55, "duration": 0.32, "smooth": 2.5, "shape": "default", "customPoly": [{"x": 0, "y": -0.9}, {"x": 0.3, "y": -0.25}, {"x": 0.9, "y": 0}, {"x": 0.3, "y": 0.25}, {"x": 0, "y": 0.9}, {"x": -0.3, "y": 0.25}, {"x": -0.9, "y": 0}, {"x": -0.3, "y": -0.25}], "colorMode": "tower", "customColor": "#ffffff"}}, {"uid": "L73", "type": "plasmaVortex", "name": "Плазменный вихрь #1", "enabled": true, "params": {"size": 1.75, "speed": 1, "opacity": 0.85, "count": 12, "spread": 1, "duration": 0.32, "thickness": 2.2, "colorMode": "tower", "customColor": "#ff9100"}}, {"uid": "L74", "type": "threePhaseCore", "name": "Трехфазное ядро #1", "enabled": true, "params": {"size": 0.55, "speed": 1, "opacity": 1, "count": 1, "duration": 0.84, "smooth": 2.5, "flicker": false, "fakeGlow": true, "shape": "default", "customPoly": [{"x": 0, "y": -0.9}, {"x": 0.3, "y": -0.25}, {"x": 0.9, "y": 0}, {"x": 0.3, "y": 0.25}, {"x": 0, "y": 0.9}, {"x": -0.3, "y": 0.25}, {"x": -0.9, "y": 0}, {"x": -0.3, "y": -0.25}], "colorMode": "tower", "customColor": "#ff9100"}}, {"uid": "L75", "type": "threePhaseCore", "name": "Трехфазное ядро #2", "enabled": true, "params": {"size": 1.35, "speed": 0.8, "opacity": 0.75, "count": 1, "duration": 0.48, "smooth": 2.5, "flicker": false, "fakeGlow": true, "shape": "default", "customPoly": [{"x": 0, "y": -0.9}, {"x": 0.3, "y": -0.25}, {"x": 0.9, "y": 0}, {"x": 0.3, "y": 0.25}, {"x": 0, "y": 0.9}, {"x": -0.3, "y": 0.25}, {"x": -0.9, "y": 0}, {"x": -0.3, "y": -0.25}], "colorMode": "tower", "customColor": "#ff9100"}}, {"uid": "L76", "type": "threePhaseCore", "name": "Трехфазное ядро #3", "enabled": true, "params": {"size": 2.1, "speed": 0.8, "opacity": 0.3, "count": 1, "duration": 0.26, "smooth": 2.5, "flicker": false, "fakeGlow": true, "shape": "default", "customPoly": [{"x": 0, "y": -0.9}, {"x": 0.3, "y": -0.25}, {"x": 0.9, "y": 0}, {"x": 0.3, "y": 0.25}, {"x": 0, "y": 0.9}, {"x": -0.3, "y": 0.25}, {"x": -0.9, "y": 0}, {"x": -0.3, "y": -0.25}], "colorMode": "tower", "customColor": "#ff9100"}}, {"uid": "L77", "type": "sineEmbers", "name": "Угли 360° #1", "enabled": true, "params": {"size": 1.3, "speed": 2.05, "opacity": 1, "count": 10, "spread": 1.25, "waveAmp": 22, "duration": 1, "shape": "default", "customPoly": [{"x": 0, "y": -0.9}, {"x": 0.3, "y": -0.25}, {"x": 0.9, "y": 0}, {"x": 0.3, "y": 0.25}, {"x": 0, "y": 0.9}, {"x": -0.3, "y": 0.25}, {"x": -0.9, "y": 0}, {"x": -0.3, "y": -0.25}], "colorMode": "tower", "customColor": "#ff9100"}}, {"uid": "L78", "type": "volumeHalo", "name": "Объёмный ореол #1", "enabled": true, "params": {"size": 1.55, "speed": 2.8, "opacity": 0.85, "duration": 1.2, "smooth": 0.65, "flicker": false, "colorMode": "tower", "customColor": "#38bdf8"}}]}, "tesla": {"blastScale": 1, "layers": [{"uid": "L79", "type": "arcLightning", "name": "Плазменные дуги", "enabled": true, "params": {"size": 1, "speed": 1, "opacity": 1, "count": 3, "duration": 0.18, "thickness": 1, "colorMode": "tower", "customColor": "#00ffcc"}}, {"uid": "L80", "type": "rgbRing", "name": "Хроматик-кольцо", "enabled": true, "params": {"size": 0.6, "speed": 1, "opacity": 1, "duration": 0.3, "thickness": 1.5, "offset": 1.8, "shape": "default", "customPoly": [{"x": 0, "y": -0.9}, {"x": 0.3, "y": -0.25}, {"x": 0.9, "y": 0}, {"x": 0.3, "y": 0.25}, {"x": 0, "y": 0.9}, {"x": -0.3, "y": 0.25}, {"x": -0.9, "y": 0}, {"x": -0.3, "y": -0.25}], "colorMode": "tower", "customColor": "#00e5ff"}}, {"uid": "L81", "type": "deepGlow", "name": "Глубокий Glow", "enabled": true, "params": {"size": 0.7, "speed": 1, "opacity": 0.75, "duration": 0.62, "smooth": 2.3, "flicker": true, "colorMode": "tower", "customColor": "#ff9100"}}, {"uid": "L82", "type": "volumeHalo", "name": "Объёмный ореол", "enabled": true, "params": {"size": 2.4, "speed": 1, "opacity": 0.85, "duration": 0.62, "smooth": 1, "flicker": true, "colorMode": "tower", "customColor": "#38bdf8"}}, {"uid": "L83", "type": "energyMotes", "name": "Энерго-пыльца #1", "enabled": false, "params": {"size": 1.85, "speed": 1, "opacity": 1, "count": 28, "spread": 0.45, "duration": 0.95, "smooth": 0.9, "shape": "default", "customPoly": [{"x": 0, "y": -0.9}, {"x": 0.3, "y": -0.25}, {"x": 0.9, "y": 0}, {"x": 0.3, "y": 0.25}, {"x": 0, "y": 0.9}, {"x": -0.3, "y": 0.25}, {"x": -0.9, "y": 0}, {"x": -0.3, "y": -0.25}], "colorMode": "tower", "customColor": "#38bdf8"}}, {"uid": "L84", "type": "coolingEmbers", "name": "Остывающие точки #1", "enabled": true, "params": {"size": 0.65, "speed": 3, "opacity": 1, "count": 7, "spread": 0.55, "duration": 0.8, "shape": "default", "customPoly": [{"x": 0, "y": -0.9}, {"x": 0.3, "y": -0.25}, {"x": 0.9, "y": 0}, {"x": 0.3, "y": 0.25}, {"x": 0, "y": 0.9}, {"x": -0.3, "y": 0.25}, {"x": -0.9, "y": 0}, {"x": -0.3, "y": -0.25}], "colorMode": "tower", "customColor": "#ff9100"}}]}, "stasis": {"blastScale": 1, "layers": [{"uid": "L85", "type": "deepGlow", "name": "Глубокий Glow", "enabled": true, "params": {"size": 0.85, "speed": 2.35, "opacity": 0.5, "duration": 1.2, "smooth": 2.5, "flicker": false, "colorMode": "tower", "customColor": "#ff9100"}}, {"uid": "L86", "type": "implosionLines", "name": "Воронка имплозии", "enabled": true, "params": {"size": 0.75, "speed": 1, "opacity": 1, "count": 6, "duration": 0.24, "thickness": 1.5, "colorMode": "tower", "customColor": "#38bdf8"}}, {"uid": "L87", "type": "volumeHalo", "name": "Объёмный ореол", "enabled": true, "params": {"size": 3, "speed": 1, "opacity": 0.5, "duration": 0.22, "smooth": 1, "flicker": false, "colorMode": "tower", "customColor": "#38bdf8"}}, {"uid": "L88", "type": "energyMotes", "name": "Энерго-пыльца", "enabled": true, "params": {"size": 1, "speed": 1, "opacity": 1, "count": 8, "spread": 0.45, "duration": 0.7, "smooth": 1, "shape": "default", "customPoly": [{"x": 0, "y": -0.9}, {"x": 0.3, "y": -0.25}, {"x": 0.9, "y": 0}, {"x": 0.3, "y": 0.25}, {"x": 0, "y": 0.9}, {"x": -0.3, "y": 0.25}, {"x": -0.9, "y": 0}, {"x": -0.3, "y": -0.25}], "colorMode": "tower", "customColor": "#38bdf8"}}]}, "melter": {"blastScale": 1, "layers": [{"uid": "L89", "type": "sparks", "name": "Искры #1", "enabled": true, "params": {"size": 1, "speed": 1, "opacity": 1, "count": 6, "stretch": 1, "range": 1, "centerFade": 0, "duration": 0.28, "directionalCone": true, "velocityStretch": true, "tempGradient": true, "shape": "default", "customPoly": [{"x": 0, "y": -0.9}, {"x": 0.3, "y": -0.25}, {"x": 0.9, "y": 0}, {"x": 0.3, "y": 0.25}, {"x": 0, "y": 0.9}, {"x": -0.3, "y": 0.25}, {"x": -0.9, "y": 0}, {"x": -0.3, "y": -0.25}], "colorMode": "tower", "customColor": "#ff9100"}}, {"uid": "L90", "type": "deepGlow", "name": "Глубокий Glow", "enabled": true, "params": {"size": 0.25, "speed": 1, "opacity": 1, "duration": 0.22, "smooth": 2.5, "flicker": true, "colorMode": "tower", "customColor": "#ff9100"}}, {"uid": "L91", "type": "deepGlow", "name": "Глубокий Glow #2", "enabled": true, "params": {"size": 1, "speed": 1, "opacity": 0.1, "duration": 0.22, "smooth": 2.5, "flicker": true, "colorMode": "tower", "customColor": "#ff9100"}}, {"uid": "L92", "type": "deepGlow", "name": "Глубокий Glow #3", "enabled": true, "params": {"size": 2.5, "speed": 1, "opacity": 0.05, "duration": 0.22, "smooth": 2.5, "flicker": true, "colorMode": "tower", "customColor": "#ff9100"}}, {"uid": "L93", "type": "coolingEmbers", "name": "Остывающие точки #1", "enabled": true, "params": {"size": 0.55, "speed": 1, "opacity": 1, "count": 3, "spread": 0.4, "duration": 0.6, "shape": "default", "customPoly": [{"x": 0, "y": -0.9}, {"x": 0.3, "y": -0.25}, {"x": 0.9, "y": 0}, {"x": 0.3, "y": 0.25}, {"x": 0, "y": 0.9}, {"x": -0.3, "y": 0.25}, {"x": -0.9, "y": 0}, {"x": -0.3, "y": -0.25}], "colorMode": "tower", "customColor": "#ff9100"}}, {"uid": "L94", "type": "plasmaVortex", "name": "Плазменный вихрь #1", "enabled": true, "params": {"size": 1.7, "speed": 1, "opacity": 0.25, "count": 4, "spread": 1, "duration": 0.32, "thickness": 2.2, "colorMode": "tower", "customColor": "#ff9100"}}, {"uid": "L95", "type": "volumeHalo", "name": "Объёмный ореол #1", "enabled": true, "params": {"size": 2.15, "speed": 1, "opacity": 0.1, "duration": 0.34, "smooth": 1, "flicker": false, "colorMode": "tower", "customColor": "#38bdf8"}}]}, "railgun": {"blastScale": 1, "layers": [{"uid": "L96", "type": "muzzleFlash", "name": "Дульная вспышка", "enabled": true, "params": {"size": 0.9, "speed": 2.5, "opacity": 0.55, "duration": 0.32, "smooth": 2.5, "shape": "default", "customPoly": [{"x": 0, "y": -0.9}, {"x": 0.3, "y": -0.25}, {"x": 0.9, "y": 0}, {"x": 0.3, "y": 0.25}, {"x": 0, "y": 0.9}, {"x": -0.3, "y": 0.25}, {"x": -0.9, "y": 0}, {"x": -0.3, "y": -0.25}], "colorMode": "tower", "customColor": "#ffffff"}}, {"uid": "L97", "type": "arcLightning", "name": "Плазменные дуги", "enabled": true, "params": {"size": 1.9, "speed": 1, "opacity": 1, "count": 3, "duration": 0.18, "thickness": 1, "colorMode": "tower", "customColor": "#00ffcc"}}, {"uid": "L98", "type": "rgbRing", "name": "Хроматик-кольцо", "enabled": true, "params": {"size": 0.95, "speed": 1, "opacity": 1, "duration": 0.3, "thickness": 1.5, "offset": 1.8, "shape": "default", "customPoly": [{"x": 0, "y": -0.9}, {"x": 0.3, "y": -0.25}, {"x": 0.9, "y": 0}, {"x": 0.3, "y": 0.25}, {"x": 0, "y": 0.9}, {"x": -0.3, "y": 0.25}, {"x": -0.9, "y": 0}, {"x": -0.3, "y": -0.25}], "colorMode": "tower", "customColor": "#00e5ff"}}, {"uid": "L99", "type": "deepGlow", "name": "Глубокий Glow", "enabled": true, "params": {"size": 0.65, "speed": 1, "opacity": 1, "duration": 0.22, "smooth": 1, "flicker": false, "colorMode": "tower", "customColor": "#ff9100"}}, {"uid": "L100", "type": "volumeHalo", "name": "Объёмный ореол", "enabled": true, "params": {"size": 1.1, "speed": 1, "opacity": 1, "duration": 0.8, "smooth": 2.5, "flicker": true, "colorMode": "tower", "customColor": "#38bdf8"}}, {"uid": "L101", "type": "energyMotes", "name": "Энерго-пыльца", "enabled": true, "params": {"size": 2.4, "speed": 2.25, "opacity": 1, "count": 28, "spread": 0.75, "duration": 0.75, "smooth": 0.95, "shape": "default", "customPoly": [{"x": 0, "y": -0.9}, {"x": 0.3, "y": -0.25}, {"x": 0.9, "y": 0}, {"x": 0.3, "y": 0.25}, {"x": 0, "y": 0.9}, {"x": -0.3, "y": 0.25}, {"x": -0.9, "y": 0}, {"x": -0.3, "y": -0.25}], "colorMode": "tower", "customColor": "#38bdf8"}}, {"uid": "L102", "type": "sineEmbers", "name": "Угли 360° #1", "enabled": true, "params": {"size": 1.1, "speed": 2.15, "opacity": 1, "count": 11, "spread": 1.35, "waveAmp": 14, "duration": 0.85, "shape": "default", "customPoly": [{"x": 0, "y": -0.9}, {"x": 0.3, "y": -0.25}, {"x": 0.9, "y": 0}, {"x": 0.3, "y": 0.25}, {"x": 0, "y": 0.9}, {"x": -0.3, "y": 0.25}, {"x": -0.9, "y": 0}, {"x": -0.3, "y": -0.25}], "colorMode": "tower", "customColor": "#ff9100"}}]}};
const MOB_SPAWN_FX = {
  blastScale: 1,
  layers: [
    { uid: 'L62', type: 'implosionLines', name: 'Воронка имплозии', enabled: true, params: { size: 1.25, speed: 1, opacity: 1, count: 7, duration: 0.24, thickness: 2, colorMode: 'enemy', customColor: '#f05f9f' } },
    { uid: 'L63', type: 'deepGlow', name: 'Ядро вспышки', enabled: true, params: { size: 1.05, speed: 1, opacity: 1, duration: 0.54, smooth: 1, flicker: false, colorMode: 'white', customColor: '#ffffff' } },
    { uid: 'L64', type: 'deepGlow', name: 'Внешний ореол', enabled: true, params: { size: 2.2, speed: 1, opacity: 1, duration: 0.28, smooth: 1, flicker: false, colorMode: 'enemy', customColor: '#f05f9f' } }
  ]
};
const MOB_BASE_HIT_FX = {
  blastScale: 1,
  layers: [
    { uid: 'L63', type: 'deepGlow', name: 'Белый сердечник', enabled: true, params: { size: 1.5, speed: 1, opacity: 1, duration: 0.42, smooth: 1.4, flicker: false, colorMode: 'white', customColor: '#ffffff' } },
    { uid: 'L67', type: 'plasmaVortex', name: 'Плазменный вихрь #1', enabled: true, params: { size: 1.4, speed: 1.2, opacity: 0.9, count: 6, spread: 1.0, duration: 0.36, thickness: 2.2, colorMode: 'themeBaseShield', customColor: '#00e5ff' } },
    { uid: 'L70', type: 'plasmaVortex', name: 'Плазменный вихрь #2', enabled: true, params: { size: 2.1, speed: 0.85, opacity: 0.55, count: 4, spread: 1.3, duration: 0.44, thickness: 1.8, colorMode: 'themeBaseShield', customColor: '#00e5ff' } },
    { uid: 'L68', type: 'threePhaseCore', name: 'Трехфазное ядро', enabled: true, params: { size: 1.25, speed: 0.9, opacity: 0.95, count: 3, duration: 0.45, smooth: 1.6, flicker: true, fakeGlow: true, shape: 'default', colorMode: 'themeBaseDmgLight', customColor: '#ff8fb0' } },
    { uid: 'L69', type: 'rgbRing', name: 'Хроматик-кольцо', enabled: true, params: { size: 1.35, speed: 1.0, opacity: 0.95, duration: 0.38, thickness: 2.0, offset: 2.4, shape: 'default', colorMode: 'themeBaseShield', customColor: '#00e5ff' } },
    { uid: 'L73', type: 'volumeHalo', name: 'Объёмный ореол', enabled: true, params: { size: 2.3, speed: 1.0, opacity: 0.85, duration: 0.55, smooth: 1.2, flicker: false, colorMode: 'themeBaseDmg', customColor: '#f05f9f' } },
    { uid: 'L75', type: 'coolingEmbers', name: 'Остывающие точки #1', enabled: true, params: { size: 0.9, speed: 1.1, opacity: 0.95, count: 9, spread: 0.75, duration: 0.95, shape: 'default', colorMode: 'themeBaseDmg', customColor: '#f05f9f' } },
    { uid: 'L76', type: 'coolingEmbers', name: 'Остывающие точки #2', enabled: true, params: { size: 0.75, speed: 1.3, opacity: 0.9, count: 7, spread: 0.9, duration: 0.85, shape: 'default', colorMode: 'themeBaseShield', customColor: '#00e5ff' } },
    { uid: 'L77', type: 'sparks', name: 'Искры щита', enabled: true, params: { size: 1.05, speed: 1.15, opacity: 1.0, count: 40, stretch: 1.25, range: 1.2, centerFade: 0.05, duration: 0.36, directionalCone: false, velocityStretch: true, tempGradient: false, shape: 'default', colorMode: 'themeBaseShield', customColor: '#00e5ff' } }
  ]
};
if (typeof window !== 'undefined') {
  window.ENEMY_REACTIONS = ENEMY_REACTIONS;
  window.TOWER_FX = TOWER_FX;
  window.MOB_SPAWN_FX = MOB_SPAWN_FX;
  window.MOB_BASE_HIT_FX = MOB_BASE_HIT_FX;
}

const TOWER_FX_BASE_R = {
  gun: 22,
  laser: 22,
  mortar: 58,
  tesla: 28,
  stasis: 26,
  melter: 26,
  railgun: 34
};

const FX_GLOW_SPRITE_CACHE = Object.create(null);
const FX_POLY_SPRITE_CACHE = Object.create(null);
const _fxShapeKeyMap = new WeakMap();
let _fxCachePaletteId = '';

let fxLayerParts = [];
let fxLayerWaves = [];
let _lastFxRenderNow = 0;

function clearFxSpriteCaches() {
  for (const k in FX_GLOW_SPRITE_CACHE) delete FX_GLOW_SPRITE_CACHE[k];
  for (const k in FX_POLY_SPRITE_CACHE) delete FX_POLY_SPRITE_CACHE[k];
  _fxCachePaletteId = (typeof activePalette !== 'undefined') ? activePalette : 'default';
}

function clearFxLayerState() {
  fxLayerParts.length = 0;
  fxLayerWaves.length = 0;
}

function syncFxCachePalette() {
  const curPal = (typeof activePalette !== 'undefined') ? activePalette : 'default';
  if (_fxCachePaletteId !== curPal) {
    clearFxSpriteCaches();
  }
}

function createFxOffscreenCanvas(size) {
  if (typeof OffscreenCanvas !== 'undefined') {
    return new OffscreenCanvas(size, size);
  }
  const c = document.createElement('canvas');
  c.width = size;
  c.height = size;
  return c;
}

function fxResolveColor(params, towerColor) {
  if (!params) return towerColor || '#00e5ff';
  if (params.colorMode === 'white') return '#ffffff';
  if (params.colorMode === 'custom' && params.customColor) return params.customColor;
  return towerColor || params.customColor || '#00e5ff';
}

function fxHexRgb(col) {
  if (!col) return { r: 255, g: 145, b: 0 };
  const m = String(col).match(/^rgb\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)$/i);
  if (m) return { r: +m[1], g: +m[2], b: +m[3] };
  let h = String(col).replace('#', '');
  if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
  const r = parseInt(h.slice(0, 2), 16);
  const g = parseInt(h.slice(2, 4), 16);
  const b = parseInt(h.slice(4, 6), 16);
  return {
    r: Number.isNaN(r) ? 255 : r,
    g: Number.isNaN(g) ? 145 : g,
    b: Number.isNaN(b) ? 0 : b
  };
}

function fxTempColor(age, baseHex, whiteEnd = false) {
  const w = { r: 255, g: 255, b: 255 };
  const y = { r: 255, g: 230, b: 90 };
  const c = fxHexRgb(baseHex);
  const dr = whiteEnd ? w : { r: 150, g: 20, b: 20 };
  const mix = (a, b, t) => `rgb(${Math.round(a.r + (b.r - a.r) * t)},${Math.round(a.g + (b.g - a.g) * t)},${Math.round(a.b + (b.b - a.b) * t)})`;
  if (age < 0.22) return mix(w, y, age / 0.22);
  if (age < 0.62) return mix(y, c, (age - 0.22) / 0.40);
  return mix(c, dr, (age - 0.62) / 0.38);
}

// Точный 9-слойный кэш мягких радиальных свечений 128x128 (bloom / volume / ground) из Sandbox v11
function getFxDeepGlowSprite(color, mode = 'bloom', smooth = 1.0) {
  syncFxCachePalette();
  const sm = Math.max(0.2, Math.min(2.5, smooth || 1.0));
  const rgb = fxHexRgb(color);
  const r = Math.min(255, Math.round(rgb.r / 8) * 8);
  const gr = Math.min(255, Math.round(rgb.g / 8) * 8);
  const b = Math.min(255, Math.round(rgb.b / 8) * 8);
  const key = `${r},${gr},${b}_${mode}_${sm.toFixed(2)}`;
  if (FX_GLOW_SPRITE_CACHE[key]) return FX_GLOW_SPRITE_CACHE[key];

  const size = 128, half = 64;
  const off = createFxOffscreenCanvas(size);
  const g = off.getContext('2d');

  g.save();
  g.globalCompositeOperation = 'lighter';
  if (mode === 'ground') {
    const grad = g.createRadialGradient(half, half, 0, half, half, half);
    grad.addColorStop(0.00, 'rgba(255, 255, 255, 0.34)');
    grad.addColorStop(0.10, `rgba(${r}, ${gr}, ${b}, 0.32)`);
    grad.addColorStop(0.22, `rgba(${r}, ${gr}, ${b}, 0.24)`);
    grad.addColorStop(0.36, `rgba(${r}, ${gr}, ${b}, 0.16)`);
    grad.addColorStop(0.50, `rgba(${r}, ${gr}, ${b}, 0.105)`);
    grad.addColorStop(0.65, `rgba(${r}, ${gr}, ${b}, 0.060)`);
    grad.addColorStop(0.80, `rgba(${r}, ${gr}, ${b}, 0.030)`);
    grad.addColorStop(0.92, `rgba(${r}, ${gr}, ${b}, 0.010)`);
    grad.addColorStop(1.00, `rgba(${r}, ${gr}, ${b}, 0)`);
    g.fillStyle = grad;
    g.beginPath(); g.arc(half, half, half, 0, Math.PI * 2); g.fill();
  } else if (mode === 'volume') {
    const grad = g.createRadialGradient(half, half, 0, half, half, half);
    grad.addColorStop(0.00, 'rgba(255, 255, 255, 0.55)');
    const s1 = Math.min(0.45, 0.18 * sm);
    const s2 = Math.min(0.78, 0.45 * Math.pow(sm, 0.5));
    const s3 = Math.min(0.95, 0.75 * Math.pow(sm, 0.3));
    grad.addColorStop(s1, `rgba(${r}, ${gr}, ${b}, 0.42)`);
    grad.addColorStop(s2, `rgba(${r}, ${gr}, ${b}, 0.18)`);
    grad.addColorStop(s3, `rgba(${Math.round(r * 0.4)}, ${Math.round(gr * 0.5)}, ${Math.min(255, b + 60)}, 0.07)`);
    grad.addColorStop(1.00, 'rgba(10, 20, 50, 0)');
    g.fillStyle = grad;
    g.beginPath(); g.arc(half, half, half, 0, Math.PI * 2); g.fill();
  } else {
    const invSm = 1 / sm;
    const alphaMult = Math.pow(sm, 0.25);
    const midStop = Math.min(0.95, 0.65 * Math.pow(sm, 0.35));
    const falloff = [
      { rMult: 1.00, a: 0.022 }, { rMult: 0.84, a: 0.032 }, { rMult: 0.68, a: 0.048 },
      { rMult: 0.54, a: 0.070 }, { rMult: 0.42, a: 0.105 }, { rMult: 0.32, a: 0.150 },
      { rMult: 0.23, a: 0.215 }, { rMult: 0.16, a: 0.310 }, { rMult: 0.10, a: 0.440 }
    ];
    for (let i = 0; i < falloff.length; i++) {
      const rad = half * Math.pow(falloff[i].rMult, invSm);
      const rg = g.createRadialGradient(half, half, 0, half, half, rad);
      const a0 = Math.min(1, falloff[i].a * alphaMult);
      rg.addColorStop(0, `rgba(${r}, ${gr}, ${b}, ${a0})`);
      rg.addColorStop(midStop, `rgba(${r}, ${gr}, ${b}, ${(a0 * 0.5).toFixed(4)})`);
      rg.addColorStop(1, `rgba(${r}, ${gr}, ${b}, 0)`);
      g.fillStyle = rg;
      g.beginPath(); g.arc(half, half, rad, 0, Math.PI * 2); g.fill();
    }
    const coreR = half * Math.min(0.68, 0.28 * Math.pow(sm, 0.38));
    const core = g.createRadialGradient(half, half, 0, half, half, coreR);
    core.addColorStop(0.00, 'rgba(255, 255, 255, 1.0)');
    core.addColorStop(0.40, 'rgba(255, 255, 255, 0.78)');
    core.addColorStop(0.78, `rgba(${r}, ${gr}, ${b}, 0.35)`);
    core.addColorStop(1.00, 'rgba(255, 255, 255, 0)');
    g.fillStyle = core;
    g.beginPath(); g.arc(half, half, coreR, 0, Math.PI * 2); g.fill();
  }
  g.restore();
  FX_GLOW_SPRITE_CACHE[key] = off;
  return off;
}

function drawFxCachedGlow(targetCtx, x, y, radius, color, alpha = 1.0, mode = 'bloom', smooth = 1.0) {
  const spr = getFxDeepGlowSprite(color, mode, smooth);
  const d = radius * 2.5;
  targetCtx.globalAlpha = Math.max(0, Math.min(1, alpha));
  targetCtx.drawImage(spr, x - d * 0.5, y - d * 0.5, d, d);
}

function fxBuildShapePath(c, shape, r, customPoly) {
  c.beginPath();
  if (shape === 'circle' || shape === 'ring') {
    c.arc(0, 0, r, 0, Math.PI * 2);
    return shape === 'ring' ? 'stroke' : 'fill';
  }
  if (shape === 'line') {
    c.moveTo(-r * 1.7, 0);
    c.lineTo(r * 1.7, 0);
    return 'stroke';
  }
  if (shape === 'diamond') {
    c.moveTo(0, -r * 1.25); c.lineTo(r * 0.85, 0); c.lineTo(0, r * 1.25); c.lineTo(-r * 0.85, 0); c.closePath();
    return 'fill';
  }
  if (shape === 'square') {
    c.rect(-r * 0.85, -r * 0.85, r * 1.7, r * 1.7);
    return 'fill';
  }
  if (shape === 'triangle') {
    c.moveTo(r * 1.2, 0); c.lineTo(-r * 0.9, -r * 0.95); c.lineTo(-r * 0.9, r * 0.95); c.closePath();
    return 'fill';
  }
  if (shape === 'star4' || shape === 'star5') {
    const spikes = shape === 'star4' ? 4 : 5;
    const outer = r * 1.2, inner = r * (shape === 'star4' ? 0.32 : 0.48);
    for (let i = 0; i < spikes * 2; i++) {
      const rad = i % 2 === 0 ? outer : inner;
      const a = (i * Math.PI) / spikes - Math.PI / 2;
      if (i === 0) c.moveTo(Math.cos(a) * rad, Math.sin(a) * rad);
      else c.lineTo(Math.cos(a) * rad, Math.sin(a) * rad);
    }
    c.closePath();
    return 'fill';
  }
  if (shape === 'hex') {
    for (let i = 0; i < 6; i++) {
      const a = (i * Math.PI) / 3;
      if (i === 0) c.moveTo(Math.cos(a) * r, Math.sin(a) * r);
      else c.lineTo(Math.cos(a) * r, Math.sin(a) * r);
    }
    c.closePath();
    return 'fill';
  }
  if (shape === 'cross') {
    const w = r * 0.34, l = r * 1.1;
    c.moveTo(-w, -l); c.lineTo(w, -l); c.lineTo(w, -w);
    c.lineTo(l, -w); c.lineTo(l, w); c.lineTo(w, w);
    c.lineTo(w, l); c.lineTo(-w, l); c.lineTo(-w, w);
    c.lineTo(-l, w); c.lineTo(-l, -w); c.lineTo(-w, -w);
    c.closePath();
    return 'fill';
  }
  if (shape === 'shard') {
    c.moveTo(r * 1.55, 0); c.lineTo(-r * 0.45, -r * 0.58); c.lineTo(-r * 1.1, 0); c.lineTo(-r * 0.45, r * 0.58); c.closePath();
    return 'fill';
  }
  if (shape === 'crescent') {
    c.arc(0, 0, r, -Math.PI * 0.65, Math.PI * 0.65, false);
    c.arc(r * 0.35, 0, r * 0.78, Math.PI * 0.55, -Math.PI * 0.55, true);
    c.closePath();
    return 'fill';
  }
  if (shape === 'spiral') {
    const turns = 2.2, steps = 22;
    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      const a = t * turns * Math.PI * 2;
      const rad = r * t;
      if (i === 0) c.moveTo(0, 0); else c.lineTo(Math.cos(a) * rad, Math.sin(a) * rad);
    }
    return 'stroke';
  }
  if (shape === 'customPoly') {
    const pts = (Array.isArray(customPoly) && customPoly.length >= 2) ? customPoly : null;
    if (pts) {
      c.moveTo(pts[0].x * r, pts[0].y * r);
      for (let i = 1; i < pts.length; i++) c.lineTo(pts[i].x * r, pts[i].y * r);
      if (pts.length >= 3) c.closePath();
      return pts.length >= 3 ? 'fill' : 'stroke';
    }
  }
  c.arc(0, 0, r, 0, Math.PI * 2);
  return 'fill';
}

function fxGetPolyKey(shape, customPoly) {
  if (shape !== 'customPoly' || !Array.isArray(customPoly)) return shape || 'circle';
  let k = _fxShapeKeyMap.get(customPoly);
  if (k) return k;
  k = 'poly';
  for (let i = 0; i < customPoly.length; i++) {
    k += '_' + Math.round(customPoly[i].x * 100) + ',' + Math.round(customPoly[i].y * 100);
  }
  _fxShapeKeyMap.set(customPoly, k);
  return k;
}

// Кэш 48x48 Offscreen-спрайтов для кастомных форм (customPoly и нестандартные shape)
function getFxPolySprite(shape, customPoly, color, mode = 'fill', lineWidth = 1.6) {
  syncFxCachePalette();
  const shapeKey = fxGetPolyKey(shape, customPoly);
  const col = color || '#ffffff';
  const cacheKey = `${shapeKey}_${col}_${mode}`;
  if (FX_POLY_SPRITE_CACHE[cacheKey]) return FX_POLY_SPRITE_CACHE[cacheKey];

  const size = 48, half = 24, r = 16;
  const off = createFxOffscreenCanvas(size);
  const c = off.getContext('2d');
  c.save();
  c.translate(half, half);
  const pref = fxBuildShapePath(c, shape, r, customPoly);
  const effMode = (pref === 'stroke' && mode === 'fill') ? 'stroke' : (mode || pref);
  if (effMode === 'fill' || effMode === 'both') {
    c.fillStyle = col;
    c.fill();
  }
  if (effMode === 'stroke' || effMode === 'both') {
    c.strokeStyle = effMode === 'both' ? '#ffffff' : col;
    c.lineWidth = Math.max(1.0, lineWidth || 1.6);
    c.lineCap = 'round';
    c.lineJoin = 'round';
    c.stroke();
  }
  c.restore();
  FX_POLY_SPRITE_CACHE[cacheKey] = off;
  return off;
}

function drawFxStyledShape(c, shape, r, color, mode, lineWidth, customPoly) {
  const rad = Math.max(0.5, r);
  if (mode === 'stroke' && rad > 18) {
    const pref = fxBuildShapePath(c, shape, rad, customPoly);
    c.strokeStyle = color;
    c.lineWidth = Math.max(0.8, lineWidth || 1.6);
    c.lineCap = 'round';
    c.lineJoin = 'round';
    c.stroke();
    return;
  }
  const spr = getFxPolySprite(shape, customPoly, color, mode || 'fill', lineWidth || 1.6);
  const drawHalf = rad * (24 / 16);
  c.drawImage(spr, -drawHalf, -drawHalf, drawHalf * 2, drawHalf * 2);
}

function addFxPart(p) {
  const cap = (typeof perfMode !== 'undefined' && perfMode === 'low') ? 180 : 520;
  if (fxLayerParts.length >= cap) fxLayerParts.shift();
  fxLayerParts.push(p);
}

function spawnFxMuzzleLayers(mx, my, profileKey, towerColor, angle) {
  const prof = TOWER_FX && TOWER_FX[profileKey];
  if (!prof || !Array.isArray(prof.layers)) return;
  const scale = prof.blastScale || 1.0;
  for (let i = 0; i < prof.layers.length; i++) {
    const layer = prof.layers[i];
    if (!layer.enabled || layer.type !== 'muzzleFlash') continue;
    const p = layer.params || {};
    const spd = Math.max(0.15, p.speed || 1.0);
    const life = Math.max(0.05, (p.duration || 0.18) / spd);
    const col = fxResolveColor(p, towerColor);
    addFxPart({
      kind: 'muzzle', x: mx, y: my, col, ang: angle,
      r: 22 * scale * (p.size || 1.0),
      smooth: p.smooth || 1.0,
      alpha: p.opacity !== undefined ? p.opacity : 1.0,
      shape: p.shape || 'default',
      customPoly: p.customPoly,
      life, max: life
    });
  }
}

function spawnFxHitLayers(x, y, profileKey, towerColor, dirAngle = null, mobR = 13) {
  const prof = TOWER_FX && TOWER_FX[profileKey];
  if (!prof || !Array.isArray(prof.layers)) return;
  const isLow = (typeof perfMode !== 'undefined' && perfMode === 'low');
  const scale = prof.blastScale || 1.0;
  const baseR = TOWER_FX_BASE_R[profileKey] || 24;
  const R = baseR * scale;
  const isMortar = profileKey === 'mortar';
  const hasDir = typeof dirAngle === 'number' && !isMortar && profileKey !== 'tesla' && profileKey !== 'stasis';
  const baseA = typeof dirAngle === 'number' ? dirAngle : 0;

  for (let li = 0; li < prof.layers.length; li++) {
    const layer = prof.layers[li];
    if (!layer.enabled) continue;
    const p = layer.params || {};
    const col = fxResolveColor(p, towerColor);
    const sz = Math.max(0.1, p.size !== undefined ? p.size : 1.0);
    const spdM = Math.max(0.15, p.speed !== undefined ? p.speed : 1.0);
    const op = Math.max(0, Math.min(1, p.opacity !== undefined ? p.opacity : 1.0));
    const sh = p.shape || 'default';
    const poly = p.customPoly;
    const cntScale = isLow ? 0.55 : 1.0;

    switch (layer.type) {
      case 'groundBounce': {
        const life = Math.max(0.04, (p.duration || 0.30) / spdM);
        addFxPart({ kind: 'bounce', x, y: y + 4, col, r: R * 1.55 * sz, smooth: p.smooth || 1.0, flicker: !!p.flicker, alpha: op, life, max: life });
        break;
      }
      case 'volumeHalo': {
        const life = Math.max(0.04, (p.duration || 0.34) / spdM);
        addFxPart({ kind: 'volhalo', x, y, col, r: R * 1.35 * sz, smooth: p.smooth || 1.0, flicker: !!p.flicker, alpha: op, life, max: life });
        break;
      }
      case 'deepGlow': {
        const life = Math.max(0.04, (p.duration || 0.28) / spdM);
        addFxPart({ kind: 'glow', x, y, col, r: R * 1.05 * sz, smooth: p.smooth || 1.0, flicker: !!p.flicker, alpha: op, life, max: life });
        break;
      }
      case 'smoke': {
        const cnt = Math.max(1, Math.round((p.count || 3) * cntScale));
        const spread = p.spread !== undefined ? p.spread : 0.45;
        const life = Math.max(0.1, (p.duration || 0.85) / Math.pow(spdM, 0.5));
        for (let s = 0; s < cnt; s++) {
          const a = cnt === 1 ? Math.random() * 6.283 : (s / cnt) * 6.283 + (Math.random() - 0.5) * 0.5;
          const d = cnt === 1 ? 0 : (0.15 + Math.random() * 0.45) * R * (spread / 0.45);
          const spd = (10 + Math.random() * 18) * spdM;
          addFxPart({
            kind: 'smoke', x: x + Math.cos(a) * d, y: y + Math.sin(a) * d,
            vx: Math.cos(a) * spd, vy: Math.sin(a) * spd - 8 * spdM, drag: 0.95,
            col, r: ((isMortar ? 16 : 11) + Math.random() * 8) * sz * scale,
            p3d: !!p.p3d, hot: !!p.hot, alpha: op, shape: sh, customPoly: poly,
            rot: Math.random() * 6.283, vRot: (Math.random() - 0.5) * 1.5,
            life, max: life
          });
        }
        break;
      }
      case 'threePhaseCore': {
        const cnt = Math.max(1, Math.round(p.count || 5));
        const baseLife = Math.max(0.06, (p.duration || 0.34) / spdM);
        for (let b = 0; b < cnt; b++) {
          const a = b === 0 ? 0 : (b / (cnt - 1)) * 6.283;
          const d = b === 0 ? 0 : R * 0.25 * sz;
          const spd = b === 0 ? 0 : 28 * spdM;
          const life = b === 0 ? baseLife : baseLife * 0.85;
          addFxPart({
            kind: 'core3', x: x + Math.cos(a) * d, y: y + Math.sin(a) * d,
            vx: Math.cos(a) * spd, vy: Math.sin(a) * spd, drag: 0.88,
            col, r: (b === 0 ? R * 0.56 : R * 0.32) * sz,
            smooth: p.smooth || 1.0, flicker: !!p.flicker, fakeGlow: p.fakeGlow !== false,
            alpha: op, shape: sh, customPoly: poly, rot: a,
            life, max: life
          });
        }
        break;
      }
      case 'perpFlash': {
        const life = Math.max(0.04, (p.duration || 0.14) / spdM);
        addFxPart({
          kind: 'perp', x, y, col,
          r: (isMortar ? R * 0.75 : 20 * scale) * sz,
          smooth: p.smooth || 1.0, ang: baseA + Math.PI / 2,
          alpha: op, shape: sh, customPoly: poly,
          life, max: life
        });
        break;
      }
      case 'crossFlash': {
        const cnt = Math.max(1, Math.round((p.count || 10) * cntScale));
        const baseDur = p.duration || 0.28;
        for (let s = 0; s < cnt; s++) {
          const a = Math.random() * 6.283;
          const spd = (isMortar ? 160 + Math.random() * 190 : 120 + Math.random() * 150) * scale * spdM;
          const life = Math.max(0.06, (baseDur * (0.75 + Math.random() * 0.5)) / Math.pow(spdM, 0.35));
          addFxPart({
            kind: 'shard', x, y,
            vx: Math.cos(a) * spd, vy: Math.sin(a) * spd, drag: 0.91,
            col, r: (2.3 + Math.random() * 1.1) * sz, alpha: op,
            shape: sh, customPoly: poly, rot: a,
            life, max: life
          });
        }
        break;
      }
      case 'arcLightning': {
        const cnt = Math.max(1, Math.round((p.count || 3) * cntScale));
        const life = Math.max(0.04, (p.duration || 0.18) / spdM);
        for (let a = 0; a < cnt; a++) {
          const ang = Math.random() * 6.283;
          const len = (isMortar ? R * 0.85 : 32 * scale) * sz * (0.8 + Math.random() * 0.5);
          const pts = [0];
          for (let k = 1; k < 4; k++) pts.push((Math.random() - 0.5) * 14 * sz);
          pts.push(0);
          addFxPart({
            kind: 'arc', x, y, col, ang, len, pts,
            thickness: p.thickness || 1.0, alpha: op, life, max: life
          });
        }
        break;
      }
      case 'shockwave': {
        const dur = Math.max(0.06, (p.duration || 0.32) / spdM);
        const lw = p.thickness || 2.2;
        if (p.doubleWave) {
          fxLayerWaves.push({ x, y, maxR: R * 1.25 * sz, col, dur: dur * 0.75, t: 0, lw: lw * 0.7, alpha: op, shape: sh, customPoly: poly });
          fxLayerWaves.push({ x, y, maxR: R * 0.82 * sz, col, dur: dur * 1.18, t: 0, lw: lw * 1.45, alpha: op, shape: sh, customPoly: poly });
        } else {
          fxLayerWaves.push({ x, y, maxR: R * 1.15 * sz, col, dur, t: 0, lw, alpha: op, shape: sh, customPoly: poly });
        }
        break;
      }
      case 'rgbRing': {
        const dur = Math.max(0.06, (p.duration || 0.30) / spdM);
        const lw = p.thickness || 1.5;
        const off = p.offset !== undefined ? p.offset : 1.8;
        fxLayerWaves.push({ x: x - off, y: y - off * 0.6, maxR: R * 1.12 * sz, col: '#00e5ff', dur, t: 0, lw, alpha: op, shape: sh, customPoly: poly });
        fxLayerWaves.push({ x: x + off, y: y + off * 0.6, maxR: R * 1.06 * sz, col: '#f05f9f', dur: dur * 1.06, t: 0, lw, alpha: op, shape: sh, customPoly: poly });
        break;
      }
      case 'plasmaVortex': {
        const arcCnt = Math.max(1, Math.round((p.count || 3) * cntScale));
        const vSpread = p.spread !== undefined ? p.spread : 1.0;
        const vDur = Math.max(0.05, p.duration || 0.32);
        for (let v = 0; v < arcCnt; v++) {
          const ringStep = arcCnt > 1 ? (v / (arcCnt - 1)) : 0;
          const radiusMult = 0.55 + ringStep * 0.65 * vSpread;
          addFxPart({
            kind: 'vortex', x, y, col,
            r: (isMortar ? R * 0.55 : 22 * scale) * radiusMult * sz,
            ang: (v / arcCnt) * 6.283 + Math.random() * 0.4,
            vRot: (v % 2 === 0 ? 1 : -1) * (6.5 + Math.random() * 3) * spdM,
            span: 1.1 + Math.random() * 0.7,
            lw: p.thickness || 2.2, alpha: op,
            life: vDur, max: vDur
          });
        }
        break;
      }
      case 'implosionLines': {
        const cnt = Math.max(2, Math.round((p.count || 10) * cntScale));
        const life = Math.max(0.06, (p.duration || 0.24) / spdM);
        for (let i = 0; i < cnt; i++) {
          const ang = (i / cnt) * 6.283 + Math.random() * 0.3;
          const startR = R * (1.2 + Math.random() * 0.4) * sz;
          const len = (14 + Math.random() * 12) * sz;
          addFxPart({ kind: 'implode', x, y, col, ang, startR, len, lw: p.thickness || 2.0, alpha: op, life, max: life });
        }
        break;
      }
      case 'sparks': {
        const spCnt = Math.max(1, Math.round((p.count || 10) * cntScale));
        const sRng = Math.max(0.25, p.range !== undefined ? p.range : 1.0);
        const sDrag = Math.pow(0.89, spdM / sRng);
        const sLife = Math.max(0.05, (p.duration || 0.28) * (sRng / spdM));
        for (let i = 0; i < spCnt; i++) {
          const a = (p.directionalCone && hasDir)
            ? baseA + (Math.random() - 0.5) * 1.05
            : (i / spCnt) * 6.283 + (Math.random() - 0.5) * 0.4;
          const spd = (isMortar ? 110 + Math.random() * 170 : 90 + Math.random() * 120) * scale * spdM;
          addFxPart({
            kind: 'spark', x, y, px: x, py: y,
            vx: Math.cos(a) * spd, vy: Math.sin(a) * spd, drag: sDrag,
            col, temp: !!p.tempGradient, stretch: !!p.velocityStretch,
            stretchMult: p.stretch !== undefined ? p.stretch : 1.0,
            cf: p.centerFade !== undefined ? p.centerFade : 0.0,
            r: 2.3 * sz, alpha: op, shape: sh, customPoly: poly,
            life: sLife, max: sLife
          });
        }
        break;
      }
      case 'exitSparks': {
        const cnt = Math.max(1, Math.round((p.count || 4) * cntScale));
        const sRng = Math.max(0.25, p.range !== undefined ? p.range : 1.0);
        const sDrag = Math.pow(0.89, spdM / sRng);
        const exLife = Math.max(0.05, (p.duration || 0.22) * (sRng / spdM));
        const exA = hasDir ? baseA : (Math.random() * 6.283);
        const ex = x + Math.cos(exA) * (mobR * 1.7);
        const ey = y + Math.sin(exA) * (mobR * 1.7);
        for (let e = 0; e < cnt; e++) {
          const a = exA + (Math.random() - 0.5) * 0.6;
          const spd = (120 + Math.random() * 90) * scale * spdM;
          addFxPart({
            kind: 'spark', x: ex, y: ey, px: ex, py: ey,
            vx: Math.cos(a) * spd, vy: Math.sin(a) * spd, drag: sDrag,
            col, temp: !!p.tempGradient, stretch: !!p.velocityStretch,
            stretchMult: p.stretch !== undefined ? p.stretch : 1.0,
            cf: p.centerFade !== undefined ? p.centerFade : 0.0,
            r: 1.9 * sz, alpha: op, shape: sh, customPoly: poly,
            life: exLife, max: exLife
          });
        }
        break;
      }
      case 'sineEmbers': {
        const cnt = Math.max(1, Math.round((p.count || 10) * cntScale));
        const spread = p.spread !== undefined ? p.spread : 0.70;
        const life = Math.max(0.1, (p.duration || 0.85) / Math.pow(spdM, 0.35));
        const amp = p.waveAmp !== undefined ? p.waveAmp : 14;
        for (let e = 0; e < cnt; e++) {
          const spawnA = Math.random() * 6.283;
          const spawnD = Math.random() * R * 0.35 * spread;
          const flyA = Math.random() * 6.283;
          const flySpd = (18 + Math.random() * 44) * Math.max(0.4, spread) * spdM;
          addFxPart({
            kind: 'ember',
            x: x + Math.cos(spawnA) * spawnD, y: y + Math.sin(spawnA) * spawnD,
            vx: Math.cos(flyA) * flySpd, vy: Math.sin(flyA) * flySpd, drag: 0.96,
            amp: amp * (0.7 + Math.random() * 0.6), freq: (6 + Math.random() * 5) * spdM, ph: Math.random() * 6.283,
            col, r: 2.1 * sz, alpha: op, shape: sh, customPoly: poly,
            life, max: life
          });
        }
        break;
      }
      case 'energyMotes': {
        const cnt = Math.max(1, Math.round((p.count || 10) * cntScale));
        const spread = p.spread !== undefined ? p.spread : 0.45;
        const life = Math.max(0.1, (p.duration || 0.95) / Math.pow(spdM, 0.35));
        for (let m = 0; m < cnt; m++) {
          const ma = Math.random() * 6.283, md = Math.random() * R * spread;
          const spd = (12 + Math.random() * 28) * spdM;
          addFxPart({
            kind: 'mote',
            x: x + Math.cos(ma) * md, y: y + Math.sin(ma) * md,
            vx: (Math.random() - 0.5) * spd, vy: (-10 - Math.random() * 18) * spdM,
            drag: 0.94, col,
            r: (4 + Math.random() * 5) * scale * sz,
            smooth: p.smooth || 1.0, alpha: op, shape: sh, customPoly: poly,
            ph: Math.random() * 6.283, life, max: life
          });
        }
        break;
      }
      case 'coolingEmbers': {
        const cnt = Math.max(1, Math.round((p.count || 5) * cntScale));
        const spread = p.spread !== undefined ? p.spread : 0.55;
        const life = Math.max(0.1, (p.duration || 0.85) / Math.pow(spdM, 0.4));
        for (let c = 0; c < cnt; c++) {
          const a = Math.random() * 6.283, d = Math.random() * R * spread;
          addFxPart({
            kind: 'cool', x: x + Math.cos(a) * d, y: y + Math.sin(a) * d,
            col, r: 1.6 * sz, ph: Math.random() * 6.283, pulseSpd: 18 * spdM,
            alpha: op, shape: sh, customPoly: poly, life, max: life
          });
        }
        break;
      }
      case 'customShape': {
        const cnt = Math.max(1, Math.round((p.count || 8) * cntScale));
        const life = Math.max(0.06, (p.duration || 0.55) / Math.pow(spdM, 0.45));
        const spread = p.spread !== undefined ? p.spread : 1.0;
        const motion = p.motion || 'burst';
        for (let i = 0; i < cnt; i++) {
          const a = motion === 'cone'
            ? baseA + (Math.random() - 0.5) * 1.0
            : (i / cnt) * 6.283 + (Math.random() - 0.5) * 0.25;
          let sx = x, sy = y, vx = 0, vy = 0, startR = 0;
          if (motion === 'burst' || motion === 'cone' || motion === 'wave') {
            const spd = (55 + Math.random() * 95) * scale * spread * spdM;
            vx = Math.cos(a) * spd;
            vy = Math.sin(a) * spd;
          } else if (motion === 'implode') {
            startR = R * 1.15 * spread * (0.75 + Math.random() * 0.5);
            sx = x + Math.cos(a) * startR;
            sy = y + Math.sin(a) * startR;
          } else if (motion === 'spin') {
            const d = cnt > 1 ? R * 0.35 * spread : 0;
            sx = x + Math.cos(a) * d;
            sy = y + Math.sin(a) * d;
          }
          addFxPart({
            kind: 'custom', x: sx, y: sy, ox: x, oy: y,
            vx, vy, drag: motion === 'burst' || motion === 'cone' ? 0.92 : 0.96,
            motion, ang: a, startR,
            col, r: 9 * sz * scale,
            shape: sh === 'default' ? 'star4' : sh,
            customPoly: poly,
            drawMode: p.drawMode || 'both',
            blendMode: p.blendMode || 'lighter',
            lw: p.lineWidth || 1.8,
            rot: a, vRot: (p.rotSpeed !== undefined ? p.rotSpeed : 3.5) * spdM,
            ph: Math.random() * 6.283,
            alpha: op, life, max: life
          });
        }
        break;
      }
    }
  }
}

function spawnEnemySpawnFx(x, y, enemy) {
  if (typeof MOB_SPAWN_FX === 'undefined' || !Array.isArray(MOB_SPAWN_FX.layers)) return;
  const isLow = (typeof perfMode !== 'undefined' && perfMode === 'low');
  const enemyColor = (enemy && enemy.color) ? enemy.color : '#f05f9f';
  const isBoss = !!(enemy && enemy.isBoss);
  const isMiniBoss = !!(enemy && !isBoss && (enemy.isMiniBoss || enemy.type === 'goliath'));
  const isSwarm = !!(enemy && !isBoss && !isMiniBoss && enemy.type === 'swarm');

  let countMult = 1.0;
  let lineScale = 1.0;
  let glowScale = 1.0;
  let alphaMult = 1.0;

  if (isSwarm) {
    countMult = 0.5;
    lineScale = 0.6;
    glowScale = 0.5;
    alphaMult = 0.45;
  } else if (isMiniBoss) {
    countMult = 1.65;
    lineScale = 1.35;
    glowScale = 1.4;
    alphaMult = 1.0;
  } else if (isBoss) {
    countMult = 2.4;
    lineScale = 1.75;
    glowScale = 1.85;
    alphaMult = 1.0;
  }

  const cntPerfScale = isLow ? 0.55 : 1.0;
  const baseR = 24 * (MOB_SPAWN_FX.blastScale || 1.0);

  for (let i = 0; i < MOB_SPAWN_FX.layers.length; i++) {
    const layer = MOB_SPAWN_FX.layers[i];
    if (!layer || !layer.enabled) continue;
    const p = layer.params || {};
    const col = (p.colorMode === 'white')
      ? '#ffffff'
      : ((p.colorMode === 'custom' && p.customColor) ? p.customColor : enemyColor);
    const sz = Math.max(0.1, p.size !== undefined ? p.size : 1.0);
    const spdM = Math.max(0.15, p.speed !== undefined ? p.speed : 1.0);
    const op = Math.max(0, Math.min(1, (p.opacity !== undefined ? p.opacity : 1.0) * alphaMult));

    if (layer.type === 'implosionLines') {
      const cnt = Math.max(2, Math.round((p.count || 7) * countMult * cntPerfScale));
      const life = Math.max(0.06, (p.duration || 0.24) / spdM);
      const lw = (p.thickness || 2.0) * (isBoss ? 1.25 : (isSwarm ? 0.75 : 1.0));
      for (let k = 0; k < cnt; k++) {
        const ang = (k / cnt) * 6.283 + Math.random() * 0.3;
        const startR = baseR * (1.2 + Math.random() * 0.4) * sz * lineScale;
        const len = (14 + Math.random() * 12) * sz * lineScale;
        addFxPart({
          kind: 'implode', x, y, col, ang, startR, len,
          lw, alpha: op, life, max: life
        });
      }
    } else if (layer.type === 'deepGlow') {
      const life = Math.max(0.04, (p.duration || 0.28) / spdM);
      addFxPart({
        kind: 'glow', x, y, col,
        r: baseR * 1.05 * sz * glowScale,
        smooth: p.smooth || 1.0,
        flicker: !!p.flicker,
        alpha: op,
        life, max: life
      });
    }
  }
}
if (typeof window !== 'undefined') {
  window.spawnEnemySpawnFx = spawnEnemySpawnFx;
}

function spawnEnemyBaseHitFx(x, y, enemy) {
  if (typeof MOB_BASE_HIT_FX === 'undefined' || !Array.isArray(MOB_BASE_HIT_FX.layers)) return;
  const isLow = (typeof perfMode !== 'undefined' && perfMode === 'low');
  const th = (typeof getTheme === 'function')
    ? getTheme()
    : { c1: '#00e5ff', c3: '#f05f9f', c3Light: '#ff8fb0' };
  const primaryCol = th.c1 || '#00e5ff';
  const dmgCol = th.c3 || '#f05f9f';
  const dmgLightCol = th.c3Light || dmgCol;

  const isBoss = !!(enemy && enemy.isBoss);
  const isMiniBoss = !!(enemy && !isBoss && (enemy.isMiniBoss || enemy.type === 'goliath'));
  const isSwarm = !!(enemy && !isBoss && !isMiniBoss && enemy.type === 'swarm');

  let sizeMult = 1.0;
  let countMult = 1.0;
  let durMult = 1.0;
  let alphaMult = 1.0;

  if (isSwarm) {
    sizeMult = 0.55;
    countMult = 0.30;
    durMult = 0.75;
    alphaMult = 0.75;
  } else if (isMiniBoss) {
    sizeMult = 1.35;
    countMult = 1.40;
    durMult = 1.25;
    alphaMult = 1.0;
  } else if (isBoss) {
    sizeMult = 1.75;
    countMult = 1.85;
    durMult = 1.50;
    alphaMult = 1.0;
  }

  const cntPerfScale = isLow ? 0.50 : 1.0;
  const scale = (MOB_BASE_HIT_FX.blastScale || 1.0) * sizeMult;
  const R = 34 * scale;

  const resolveBaseHitColor = (p) => {
    if (!p) return dmgCol;
    if (p.colorMode === 'white') return '#ffffff';
    if (p.colorMode === 'themeBaseDmg') return dmgCol;
    if (p.colorMode === 'themeBaseDmgLight') return dmgLightCol;
    if (p.colorMode === 'themeBaseShield') return primaryCol;
    return p.customColor || dmgCol;
  };

  for (let i = 0; i < MOB_BASE_HIT_FX.layers.length; i++) {
    const layer = MOB_BASE_HIT_FX.layers[i];
    if (!layer || !layer.enabled) continue;
    const p = layer.params || {};
    const col = resolveBaseHitColor(p);
    const sz = Math.max(0.1, p.size !== undefined ? p.size : 1.0);
    const spdM = Math.max(0.15, p.speed !== undefined ? p.speed : 1.0);
    const op = Math.max(0, Math.min(1, (p.opacity !== undefined ? p.opacity : 1.0) * alphaMult));
    const sh = p.shape || 'default';
    const poly = p.customPoly;

    switch (layer.type) {
      case 'deepGlow': {
        const life = Math.max(0.05, ((p.duration || 0.42) * durMult) / spdM);
        addFxPart({
          kind: 'glow', x, y, col,
          r: R * 1.05 * sz,
          smooth: p.smooth || 1.0,
          flicker: !!p.flicker,
          alpha: op,
          life, max: life
        });
        break;
      }
      case 'volumeHalo': {
        const life = Math.max(0.05, ((p.duration || 0.55) * durMult) / spdM);
        addFxPart({
          kind: 'volhalo', x, y, col,
          r: R * 1.35 * sz,
          smooth: p.smooth || 1.0,
          flicker: !!p.flicker,
          alpha: op,
          life, max: life
        });
        break;
      }
      case 'threePhaseCore': {
        const cnt = Math.max(1, Math.round((p.count || 3) * (isLow ? 0.65 : 1.0)));
        const baseLife = Math.max(0.06, ((p.duration || 0.45) * durMult) / spdM);
        for (let b = 0; b < cnt; b++) {
          const a = b === 0 ? 0 : (b / (cnt - 1)) * 6.283;
          const d = b === 0 ? 0 : R * 0.25 * sz;
          const spd = b === 0 ? 0 : 28 * spdM;
          const life = b === 0 ? baseLife : baseLife * 0.85;
          addFxPart({
            kind: 'core3', x: x + Math.cos(a) * d, y: y + Math.sin(a) * d,
            vx: Math.cos(a) * spd, vy: Math.sin(a) * spd, drag: 0.88,
            col, r: (b === 0 ? R * 0.56 : R * 0.32) * sz,
            smooth: p.smooth || 1.0, flicker: !!p.flicker, fakeGlow: p.fakeGlow !== false,
            alpha: op, shape: sh, customPoly: poly, rot: a,
            life, max: life
          });
        }
        break;
      }
      case 'plasmaVortex': {
        const arcCnt = Math.max(1, Math.round((p.count || 4) * Math.min(1.5, Math.max(0.6, countMult)) * cntPerfScale));
        const vSpread = p.spread !== undefined ? p.spread : 1.0;
        const vDur = Math.max(0.06, (p.duration || 0.36) * durMult);
        for (let v = 0; v < arcCnt; v++) {
          const ringStep = arcCnt > 1 ? (v / (arcCnt - 1)) : 0;
          const radiusMult = 0.55 + ringStep * 0.65 * vSpread;
          addFxPart({
            kind: 'vortex', x, y, col,
            r: R * 0.65 * radiusMult * sz,
            ang: (v / arcCnt) * 6.283 + Math.random() * 0.4,
            vRot: (v % 2 === 0 ? 1 : -1) * (6.5 + Math.random() * 3) * spdM,
            span: 1.1 + Math.random() * 0.7,
            lw: (p.thickness || 2.0) * (isBoss ? 1.2 : 1.0),
            alpha: op,
            life: vDur, max: vDur
          });
        }
        break;
      }
      case 'rgbRing': {
        const dur = Math.max(0.08, ((p.duration || 0.38) * durMult) / spdM);
        const lw = (p.thickness || 2.0) * (isBoss ? 1.25 : 1.0);
        const off = (p.offset !== undefined ? p.offset : 2.4) * Math.max(0.75, sizeMult);
        fxLayerWaves.push({
          x: x - off, y: y - off * 0.6,
          maxR: R * 1.18 * sz, col: primaryCol, dur, t: 0, lw,
          alpha: op, shape: sh, customPoly: poly
        });
        fxLayerWaves.push({
          x: x + off, y: y + off * 0.6,
          maxR: R * 1.10 * sz, col: dmgCol, dur: dur * 1.08, t: 0, lw,
          alpha: op, shape: sh, customPoly: poly
        });
        break;
      }
      case 'coolingEmbers': {
        const cnt = Math.max(1, Math.round((p.count || 8) * countMult * cntPerfScale));
        const spread = p.spread !== undefined ? p.spread : 0.75;
        const life = Math.max(0.12, ((p.duration || 0.90) * durMult) / Math.pow(spdM, 0.4));
        for (let c = 0; c < cnt; c++) {
          const a = Math.random() * 6.283;
          const d = Math.random() * R * spread;
          addFxPart({
            kind: 'cool', x: x + Math.cos(a) * d, y: y + Math.sin(a) * d,
            col, r: 1.7 * sz * Math.max(0.7, sizeMult * 0.85),
            ph: Math.random() * 6.283, pulseSpd: 18 * spdM,
            alpha: op, shape: sh, customPoly: poly,
            life, max: life
          });
        }
        break;
      }
      case 'sparks': {
        const spCnt = Math.max(4, Math.round((p.count || 40) * countMult * cntPerfScale));
        const sRng = Math.max(0.25, p.range !== undefined ? p.range : 1.2);
        const sDrag = Math.pow(0.89, spdM / sRng);
        const sLife = Math.max(0.06, ((p.duration || 0.36) * durMult) * (sRng / spdM));
        for (let k = 0; k < spCnt; k++) {
          const a = (k / spCnt) * 6.283 + (Math.random() - 0.5) * 0.4;
          const spd = (95 + Math.random() * 165) * scale * spdM;
          addFxPart({
            kind: 'spark', x, y, px: x, py: y,
            vx: Math.cos(a) * spd, vy: Math.sin(a) * spd, drag: sDrag,
            col, temp: !!p.tempGradient, stretch: !!p.velocityStretch,
            stretchMult: (p.stretch !== undefined ? p.stretch : 1.25) * (isBoss ? 1.25 : 1.0),
            cf: p.centerFade !== undefined ? p.centerFade : 0.05,
            r: 2.3 * sz * Math.max(0.75, Math.min(1.4, sizeMult)),
            alpha: op, shape: sh, customPoly: poly,
            life: sLife, max: sLife
          });
        }
        break;
      }
    }
  }
}
if (typeof window !== 'undefined') {
  window.spawnEnemyBaseHitFx = spawnEnemyBaseHitFx;
}

function updateAndDrawFxLayers(dt, nowSec) {
  if (fxLayerWaves.length === 0 && fxLayerParts.length === 0) return;
  syncFxCachePalette();

  // Ударные волны и хроматик-кольца (rgbRing / shockwave)
  for (let i = fxLayerWaves.length - 1; i >= 0; i--) {
    const w = fxLayerWaves[i];
    w.t += dt;
    if (w.t >= w.dur) { fxLayerWaves.splice(i, 1); continue; }
    const pr = w.t / w.dur;
    const r = Math.max(1, w.maxR * Math.sin(pr * 1.570796));
    ctx.save();
    ctx.translate(w.x, w.y);
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = (1 - pr) * (w.alpha !== undefined ? w.alpha : 1.0);
    const lw = Math.max(0.5, w.lw * (1 - pr * 0.85));
    if (!w.shape || w.shape === 'default' || w.shape === 'circle' || w.shape === 'ring') {
      ctx.strokeStyle = w.col;
      ctx.lineWidth = lw;
      ctx.beginPath();
      ctx.arc(0, 0, r, 0, Math.PI * 2);
      ctx.stroke();
    } else {
      drawFxStyledShape(ctx, w.shape, r, w.col, 'stroke', lw, w.customPoly);
    }
    ctx.restore();
  }

  // Частицы и слои свечений (1-в-1 с Sandbox v11)
  for (let i = fxLayerParts.length - 1; i >= 0; i--) {
    const p = fxLayerParts[i];
    p.px = p.x; p.py = p.y;
    if (dt > 0) {
      if (p.drag) { const d = Math.pow(p.drag, dt * 60); p.vx *= d; p.vy *= d; }
      if (p.kind === 'ember') {
        const perpA = Math.atan2(p.vy, p.vx) + Math.PI / 2;
        const waveOffset = Math.cos(nowSec * p.freq + p.ph) * p.amp;
        p.x += (p.vx + Math.cos(perpA) * waveOffset) * dt;
        p.y += (p.vy + Math.sin(perpA) * waveOffset) * dt;
      } else if (p.kind === 'custom' && p.motion === 'wave') {
        const perpA = Math.atan2(p.vy, p.vx) + Math.PI / 2;
        const waveOffset = Math.cos(nowSec * 9 + p.ph) * 22;
        p.x += (p.vx + Math.cos(perpA) * waveOffset) * dt;
        p.y += (p.vy + Math.sin(perpA) * waveOffset) * dt;
      } else if (p.vx || p.vy) {
        p.x += p.vx * dt; p.y += p.vy * dt;
      }
      if (p.vRot && p.kind !== 'vortex') p.rot = (p.rot || 0) + p.vRot * dt;
      p.life -= dt;
      if (p.life <= 0) { fxLayerParts.splice(i, 1); continue; }
    }

    const prog = Math.max(0, Math.min(1, p.life / p.max));
    const age = 1 - prog;
    const op = p.alpha !== undefined ? p.alpha : 1.0;
    const flk = p.flicker ? (0.85 + Math.random() * 0.3) : 1;

    ctx.save();
    if (p.kind === 'bounce') {
      ctx.globalCompositeOperation = 'lighter';
      ctx.translate(p.x, p.y); ctx.scale(1.15, 0.52);
      drawFxCachedGlow(ctx, 0, 0, p.r * flk, p.col, prog * 0.9 * op, 'ground', p.smooth || 1.0);
    } else if (p.kind === 'volhalo') {
      ctx.globalCompositeOperation = 'lighter';
      drawFxCachedGlow(ctx, p.x, p.y, p.r * flk, p.col, prog * 0.85 * op, 'volume', p.smooth || 1.0);
    } else if (p.kind === 'smoke') {
      const r = p.r * (0.75 + age * 1.2);
      ctx.globalAlpha = prog * op;
      if (p.shape && p.shape !== 'default' && p.shape !== 'circle') {
        ctx.translate(p.x, p.y); ctx.rotate(p.rot || 0);
        const el = p.max - p.life;
        const c = (p.hot && el < 0.2) ? p.col : 'rgba(58,66,92,0.85)';
        drawFxStyledShape(ctx, p.shape, r, c, 'fill', 1.5, p.customPoly);
      } else {
        if (p.p3d) {
          ctx.fillStyle = 'rgba(10,14,26,0.85)';
          ctx.beginPath(); ctx.arc(p.x, p.y + r * 0.2, r * 0.9, 0, Math.PI * 2); ctx.fill();
        }
        const el = p.max - p.life;
        const sg = ctx.createRadialGradient(p.x, p.y, r * 0.1, p.x, p.y, r);
        if (p.hot && el < 0.2) {
          const rgb = fxHexRgb(p.col);
          sg.addColorStop(0, `rgba(${rgb.r},${rgb.g},${rgb.b},${(0.75 * (1 - el / 0.2)).toFixed(2)})`);
          sg.addColorStop(0.5, 'rgba(42,48,70,0.8)');
        } else {
          sg.addColorStop(0, 'rgba(58,66,92,0.8)');
        }
        sg.addColorStop(1, 'transparent');
        ctx.fillStyle = sg;
        ctx.beginPath(); ctx.arc(p.x, p.y, r, 0, Math.PI * 2); ctx.fill();
      }
    } else if (p.kind === 'cool') {
      ctx.globalCompositeOperation = 'lighter';
      const pulse = 0.45 + 0.55 * Math.sin(p.life * (p.pulseSpd || 18) + p.ph);
      ctx.globalAlpha = prog * pulse * op;
      if (p.shape && p.shape !== 'default') {
        ctx.translate(p.x, p.y);
        drawFxStyledShape(ctx, p.shape, p.r * 1.4, p.col, 'fill', 1.2, p.customPoly);
      } else {
        ctx.fillStyle = p.col;
        const s = p.r * 1.6;
        ctx.fillRect(p.x - s * 0.5, p.y - s * 0.5, s, s);
      }
    } else if (p.kind === 'custom') {
      ctx.globalCompositeOperation = p.blendMode || 'lighter';
      let cx = p.x, cy = p.y, curR = p.r;
      if (p.motion === 'expand') {
        curR = p.r * (0.25 + age * 2.2);
      } else if (p.motion === 'implode') {
        const dist = p.startR * prog;
        cx = p.ox + Math.cos(p.ang) * dist;
        cy = p.oy + Math.sin(p.ang) * dist;
        curR = p.r * (0.35 + prog * 0.65);
      } else {
        curR = p.r * (0.3 + prog * 0.7);
      }
      ctx.translate(cx, cy); ctx.rotate(p.rot || 0);
      ctx.globalAlpha = prog * op;
      drawFxStyledShape(ctx, p.shape, curR, p.col, p.drawMode, p.lw, p.customPoly);
    } else {
      ctx.globalCompositeOperation = 'lighter';
      if (p.kind === 'core3') {
        const el = p.max - p.life;
        const c = el < 0.038 ? '#ffffff' : (el < 0.12 ? '#fde047' : (age > 0.55 ? '#ffffff' : fxTempColor(age, p.col, true)));
        const r = p.r * (0.55 + prog * 0.55) * flk;
        if (p.shape && p.shape !== 'default' && p.shape !== 'circle') {
          ctx.translate(p.x, p.y); ctx.rotate(p.rot || 0);
          ctx.globalAlpha = prog * 0.9 * op;
          drawFxStyledShape(ctx, p.shape, r, c, 'fill', 1.8, p.customPoly);
        } else if (p.fakeGlow) {
          drawFxCachedGlow(ctx, p.x, p.y, r, c, prog * 0.95 * op, 'bloom', p.smooth || 1.0);
        } else {
          ctx.globalAlpha = prog * 0.85 * op; ctx.fillStyle = c; ctx.beginPath(); ctx.arc(p.x, p.y, r, 0, Math.PI * 2); ctx.fill();
        }
      } else if (p.kind === 'glow') {
        drawFxCachedGlow(ctx, p.x, p.y, p.r * flk, p.col, prog * op, 'bloom', p.smooth || 1.0);
      } else if (p.kind === 'muzzle') {
        if (p.shape && p.shape !== 'default') {
          ctx.translate(p.x, p.y); ctx.rotate(p.ang || 0);
          ctx.globalAlpha = prog * op;
          drawFxStyledShape(ctx, p.shape, p.r * 0.65 * prog, p.col, 'both', 1.5, p.customPoly);
        } else {
          drawFxCachedGlow(ctx, p.x, p.y, p.r * flk, p.col, prog * op, 'bloom', p.smooth || 1.0);
          drawFxCachedGlow(ctx, p.x, p.y, p.r * 0.55, '#ffffff', prog * 0.95 * op, 'bloom', p.smooth || 1.0);
        }
      } else if (p.kind === 'perp') {
        ctx.translate(p.x, p.y); ctx.rotate(p.ang);
        if (p.shape && p.shape !== 'default') {
          ctx.globalAlpha = prog * op;
          drawFxStyledShape(ctx, p.shape, p.r * 0.85, p.col, 'both', 1.6, p.customPoly);
        } else {
          ctx.scale(1.35, 0.30);
          drawFxCachedGlow(ctx, 0, 0, p.r, p.col, prog * op, 'bloom', p.smooth || 1.0);
          drawFxCachedGlow(ctx, 0, 0, p.r * 0.55, '#ffffff', prog * 0.9 * op, 'bloom', p.smooth || 1.0);
        }
      } else if (p.kind === 'shard') {
        const fade = Math.pow(prog, 2.2) * op;
        const c = prog > 0.6 ? '#ffffff' : p.col;
        if (p.shape && p.shape !== 'default') {
          ctx.translate(p.x, p.y); ctx.rotate(Math.atan2(p.vy, p.vx));
          ctx.globalAlpha = fade;
          drawFxStyledShape(ctx, p.shape, p.r * (0.65 + 0.65 * prog), c, 'fill', 1.4, p.customPoly);
        } else {
          ctx.globalAlpha = fade; ctx.fillStyle = c;
          ctx.beginPath(); ctx.arc(p.x, p.y, p.r * (0.45 + 0.55 * prog), 0, Math.PI * 2); ctx.fill();
          if (prog > 0.45) {
            ctx.globalAlpha = fade * 0.55; ctx.fillStyle = p.col;
            ctx.beginPath(); ctx.arc(p.x, p.y, p.r * 1.9 * prog, 0, Math.PI * 2); ctx.fill();
          }
        }
      } else if (p.kind === 'vortex') {
        if (dt > 0) p.ang += p.vRot * dt;
        ctx.translate(p.x, p.y); ctx.rotate(p.ang);
        ctx.globalAlpha = prog * op; ctx.strokeStyle = p.col; ctx.lineWidth = p.lw || 2.2;
        ctx.beginPath(); ctx.arc(0, 0, p.r * (0.4 + (1 - prog) * 0.6), 0, p.span); ctx.stroke();
      } else if (p.kind === 'spark') {
        const c = p.temp ? fxTempColor(age, p.col) : (age < 0.2 ? '#ffffff' : p.col);
        ctx.globalAlpha = prog * op; ctx.strokeStyle = c; ctx.fillStyle = c;
        if (p.shape && p.shape !== 'default' && p.shape !== 'line') {
          ctx.translate(p.x, p.y); ctx.rotate(Math.atan2(p.vy, p.vx));
          drawFxStyledShape(ctx, p.shape, p.r * (0.65 + prog * 0.9), c, 'fill', 1.3, p.customPoly);
        } else if (p.stretch || p.shape === 'line') {
          const sm = p.stretchMult !== undefined ? p.stretchMult : 1.0;
          const spd = Math.hypot(p.vx, p.vy);
          const dirX = spd > 0.01 ? p.vx / spd : 0, dirY = spd > 0.01 ? p.vy / spd : 0;
          const rad = p.r * prog;
          const cf = p.cf || 0;
          const baseTail = rad * 2 + spd * 0.065 * sm * prog;
          const tailLen = baseTail * (1 - cf * 0.88);
          const tx = p.x - dirX * tailLen, ty = p.y - dirY * tailLen;
          ctx.lineCap = 'round'; ctx.lineWidth = Math.max(1.2, rad * 1.6);
          if (cf > 0.01) {
            ctx.globalCompositeOperation = 'source-over';
            ctx.globalAlpha = (prog > 0.15 ? 1 : prog / 0.15) * op;
            const fadeStop = Math.min(0.92, cf * (0.15 + age * 0.85));
            const g = ctx.createLinearGradient(tx, ty, p.x, p.y);
            g.addColorStop(0, '#050811'); g.addColorStop(fadeStop, '#050811'); g.addColorStop(1, c);
            ctx.strokeStyle = g;
          }
          ctx.beginPath(); ctx.moveTo(tx, ty); ctx.lineTo(p.x, p.y); ctx.stroke();
        } else {
          ctx.beginPath(); ctx.arc(p.x, p.y, p.r * prog, 0, Math.PI * 2); ctx.fill();
        }
      } else if (p.kind === 'ember') {
        ctx.globalAlpha = prog * (0.6 + 0.4 * Math.sin(p.life * 25 + p.ph)) * op;
        if (p.shape && p.shape !== 'default') {
          ctx.translate(p.x, p.y); ctx.rotate(Math.atan2(p.vy, p.vx));
          drawFxStyledShape(ctx, p.shape, p.r * (0.6 + prog * 0.8), p.col, 'fill', 1.2, p.customPoly);
        } else {
          ctx.fillStyle = p.col;
          ctx.beginPath(); ctx.arc(p.x, p.y, p.r * prog, 0, Math.PI * 2); ctx.fill();
        }
      } else if (p.kind === 'arc') {
        ctx.translate(p.x, p.y); ctx.rotate(p.ang);
        const th = p.thickness || 1.0;
        ctx.strokeStyle = p.col; ctx.lineWidth = 4.5 * th * prog; ctx.globalAlpha = prog * 0.55 * op;
        ctx.beginPath(); ctx.moveTo(0, 0);
        for (let k = 1; k < p.pts.length; k++) ctx.lineTo((k / (p.pts.length - 1)) * p.len, p.pts[k]);
        ctx.stroke();
        ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 1.4 * th * prog; ctx.globalAlpha = prog * op;
        ctx.stroke();
      } else if (p.kind === 'implode') {
        const curR = p.startR * prog, tailR = curR + p.len * prog;
        const hx = p.x + Math.cos(p.ang) * curR, hy = p.y + Math.sin(p.ang) * curR;
        const tx = p.x + Math.cos(p.ang) * tailR, ty = p.y + Math.sin(p.ang) * tailR;
        const g = ctx.createLinearGradient(tx, ty, hx, hy);
        g.addColorStop(0, 'transparent'); g.addColorStop(1, p.col);
        ctx.strokeStyle = g; ctx.lineWidth = (p.lw || 2.0) * prog; ctx.globalAlpha = prog * op;
        ctx.beginPath(); ctx.moveTo(tx, ty); ctx.lineTo(hx, hy); ctx.stroke();
        ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.arc(hx, hy, 1.2 * prog, 0, Math.PI * 2); ctx.fill();
      } else if (p.kind === 'mote') {
        const pulse = prog * (0.55 + 0.45 * Math.sin(nowSec * 14 + p.ph)) * op;
        if (p.shape && p.shape !== 'default') {
          ctx.translate(p.x, p.y); ctx.globalAlpha = pulse;
          drawFxStyledShape(ctx, p.shape, p.r * 0.55, p.col, 'both', 1.2, p.customPoly);
        } else {
          drawFxCachedGlow(ctx, p.x, p.y, p.r, p.col, pulse, 'volume', p.smooth || 1.0);
          ctx.fillStyle = '#ffffff'; ctx.globalAlpha = pulse;
          ctx.beginPath(); ctx.arc(p.x, p.y, 1.2, 0, Math.PI * 2); ctx.fill();
        }
      }
    }
    ctx.restore();
  }
}

function drawFxBulletTrails(p) {
  const prof = TOWER_FX && TOWER_FX.gun;
  if (!prof || !Array.isArray(prof.layers)) return;
  if (p._startX === undefined) { p._startX = p.x; p._startY = p.y; }
  let a = 0;
  if (p.target) a = Math.atan2(p.target.y - p.y, p.target.x - p.x);
  else if (p._prevX !== undefined) a = Math.atan2(p.y - p._prevY, p.x - p._prevX);
  p._prevX = p.x; p._prevY = p.y;

  const distStart = Math.hypot(p.x - p._startX, p.y - p._startY);
  for (let i = 0; i < prof.layers.length; i++) {
    const tl = prof.layers[i];
    if (!tl.enabled || tl.type !== 'bulletTrails') continue;
    const tp = tl.params || {};
    const len = Math.min(distStart, 26 * (tp.speed || 1.0));
    if (len < 1.5) continue;
    const tCol = fxResolveColor(tp, p.color || '#00e5ff');
    const tx = p.x - Math.cos(a) * len;
    const ty = p.y - Math.sin(a) * len;
    const g = ctx.createLinearGradient(tx, ty, p.x, p.y);
    g.addColorStop(0, 'transparent');
    g.addColorStop(1, tCol);
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = tp.opacity !== undefined ? tp.opacity : 1.0;
    ctx.strokeStyle = g;
    ctx.lineWidth = 2.5 * (tp.size || 1.0);
    ctx.beginPath();
    ctx.moveTo(tx, ty);
    ctx.lineTo(p.x, p.y);
    ctx.stroke();
    ctx.restore();
  }
}

// [UI.HWM] Специализированные сочные эффекты попаданий (Gun, Tesla, Railgun, Shield, Beam)
function createHitImpactFx(x, y, color, kind = 'bullet', dirAngle = null) {
  const col = color || '#00e5ff';
  const isLow = (perfMode === 'low');

  let resolvedKind = kind;
  if (kind === 'bullet' && typeof towers !== 'undefined' && Array.isArray(towers)) {
    for (let i = 0; i < towers.length; i++) {
      const t = towers[i];
      if ((t.type === 'laser' || t.type === 'melter') && t.target && t.isLockedOn && t.disabledTimer <= 0) {
        if (Math.hypot(t.target.x - x, t.target.y - y) < 30) {
          resolvedKind = t.type;
          break;
        }
      }
    }
  }

  if (resolvedKind === 'bullet') {
    spawnFxHitLayers(x, y, 'gun', col, dirAngle, 13);
    return;
  }
  if (resolvedKind === 'laser' || resolvedKind === 'melter' || resolvedKind === 'tesla' || resolvedKind === 'railgun') {
    spawnFxHitLayers(x, y, resolvedKind, col, dirAngle, 13);
    return;
  }

  if (kind === 'shield') {
    // Энергетическая рябь при попадании в неуязвимый фазовый щит Blinker / Chronos
    pushParticle({
      x, y, vx: 0, vy: 0,
      color: '#60a5fa',
      radius: 15,
      life: 0.16, maxLife: 0.16,
      isRing: true,
      lineWidth: 2.2
    });
    const cnt = isLow ? 3 : 5;
    for (let i = 0; i < cnt; i++) {
      const a = Math.random() * Math.PI * 2;
      const spd = 40 + Math.random() * 70;
      pushParticle({
        x, y,
        vx: Math.cos(a) * spd,
        vy: Math.sin(a) * spd,
        drag: 0.90,
        color: i % 2 === 0 ? '#ffffff' : '#60a5fa',
        radius: 2.2,
        life: 0.20, maxLife: 0.20,
        isStreak: true
      });
    }
    return;
  }

}

// [UI.HX] No-op stub (kept for legacy call sites in engine.js)
function createImpactSmoke() {}

// [UI.HY]
function createSparks(x, y, color1, count = 6, color2 = null) {
  createDamageShards(x, y, color1, count * 5, false);
}

// [UI.HZ]
function createSteamPuff(x, y) {
  const angle = -Math.PI / 2 + (Math.random() - 0.5) * 1.0;
  const speed = 12 + Math.random() * 16;
  pushParticle({
    x: x + (Math.random() - 0.5) * 7,
    y: y + (Math.random() - 0.5) * 3,
    vx: Math.cos(angle) * speed * 0.35,
    vy: Math.sin(angle) * speed,
    color: '#e2e8f0',
    radius: 3 + Math.random() * 3,
    life: 0.55 + Math.random() * 0.4,
    maxLife: 0.95,
    isSteam: true
  });
}

// [UI.IA] Многослойные сочные взрывы (Mortar, Boss, MiniBoss, Standard)
function createExplosion(x, y, radius, color1 = '#ff9100', color2 = null, kind = 'standard') {
  const c1 = color1;
  const c2 = color2 || (kind === 'mortar' ? '#f05f9f' : '#00e5ff');
  const isMortar = (kind === 'mortar');
  const isBoss = (kind === 'boss');
  const isLow = (perfMode === 'low');

  if (isMortar) {
    spawnFxHitLayers(x, y, 'mortar', c1, null, 13);
    return;
  }

  // Взрыв босса / мини-босса / стандартный
  pushParticle({
    x, y, vx: 0, vy: 0,
    color: c1,
    radius: radius * (isBoss ? 1.85 : 1.15),
    life: isBoss ? 0.32 : 0.20,
    maxLife: isBoss ? 0.32 : 0.20,
    isGlowHalo: true,
    alphaMult: isBoss ? 0.78 : 0.50
  });

  pushParticle({
    x, y, vx: 0, vy: 0,
    color: isBoss ? '#ffffff' : c1,
    radius: radius * (isBoss ? 1.4 : 0.85),
    life: isBoss ? 0.30 : 0.20,
    maxLife: isBoss ? 0.30 : 0.20,
    isCrossFlash: true,
    angle: Math.PI / 4
  });

  createShockwave(x, y, radius * (isBoss ? 1.5 : 0.9), '#ffffff');
  if (isBoss) {
    pushParticle({
      x, y, vx: 0, vy: 0,
      color: c1,
      radius: radius * 2.1,
      life: 0.42, maxLife: 0.42,
      isRing: true,
      lineWidth: 3.5
    });
    pushParticle({
      x, y, vx: 0, vy: 0,
      color: c2,
      radius: radius * 1.15,
      life: 0.28, maxLife: 0.28,
      isRing: true,
      lineWidth: 2.5
    });
  }

  const count = isLow ? (isBoss ? 14 : 9) : (isBoss ? 28 : 16);
  for (let i = 0; i < count; i++) {
    const angle = (i / count) * Math.PI * 2 + (Math.random() - 0.5) * 0.3;
    const speed = (isBoss ? 65 : 45) + Math.random() * (isBoss ? 195 : 130);
    pushParticle({
      x, y,
      vx: Math.cos(angle) * speed,
      vy: Math.sin(angle) * speed,
      drag: 0.92,
      color: i % 4 === 0 ? '#ffffff' : (i % 2 === 0 ? c1 : c2),
      radius: (isBoss ? 3.8 : 3.0) + Math.random() * 2.6,
      life: (isBoss ? 0.42 : 0.30) + Math.random() * 0.22,
      maxLife: isBoss ? 0.64 : 0.52,
      isStreak: i % 2 === 0
    });
  }

  if (isBoss) {
    for (let s = 0; s < 9; s++) {
      const sAngle = Math.random() * Math.PI * 2;
      const sSpeed = 10 + Math.random() * 26;
      pushParticle({
        x: x + (Math.random() - 0.5) * 18,
        y: y + (Math.random() - 0.5) * 18,
        vx: Math.cos(sAngle) * sSpeed,
        vy: Math.sin(sAngle) * sSpeed - 6,
        radius: 16 + Math.random() * 10,
        life: 0.75 + Math.random() * 0.3,
        maxLife: 1.05,
        isSmoke: true
      });
    }
  }
}

// [UI.IB]
function createRailBeamFx(x1, y1, x2, y2, color) {
  const beamColor = color || (typeof TOWER_CONFIGS !== 'undefined' && TOWER_CONFIGS.railgun ? TOWER_CONFIGS.railgun.color : '#a275df');
  // Дульная вспышка рельсотрона (профиль railgun из TOWER_FX)
  const railAng = Math.atan2(y2 - y1, x2 - x1);
  spawnFxMuzzleLayers(x1 + Math.cos(railAng) * 24, y1 + Math.sin(railAng) * 24, 'railgun', beamColor, railAng);
  lightningBolts.push({
    x1, y1, x2, y2,
    isRail: true,
    life: 0.38,
    maxLife: 0.38,
    hasDealtDamage: true,
    color: beamColor
  });
}

// [UI.IC]
function createShockwave(x, y, maxRadius, color) {
  shockwaves.push({ x, y, maxRadius, color, duration: 0.32, elapsed: 0 });
}

//  Math and random generator utilities for procedural background generation.
// [UI.ID]
function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// [UI.IE]
function randn() {
  let u = 0, v = 0;
  while (u === 0) u = Math.random();
  while (v === 0) v = Math.random();
  return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
}

// [UI.IF]
function clamp01(x) { return x < 0 ? 0 : x > 1 ? 1 : x; }

// [UI.IG]
function smoothstep(a, b, x) {
  const t = clamp01((x - a) / (b - a));
  return t * t * (3 - 2 * t);
}

//  2D Perlin Noise permutation table and gradient sampler.
const perlin = (function () {
  const rnd = mulberry32(1337);
  const perm = [];
  for (let i = 0; i < 256; i++) perm.push(i);
  for (let i = 255; i > 0; i--) {
    const j = Math.floor(rnd() * (i + 1));
    const t = perm[i]; perm[i] = perm[j]; perm[j] = t;
  }
  const p = new Uint8Array(512);
  for (let i = 0; i < 512; i++) p[i] = perm[i & 255];

  const GX = [1, -1, 1, -1, 1, -1, 0, 0];
  const GY = [1, 1, -1, -1, 0, 0, 1, -1];
  const fade = t => t * t * t * (t * (t * 6 - 15) + 10);

  return function (x, y) {
    const xi = Math.floor(x), yi = Math.floor(y);
    const xf = x - xi, yf = y - yi;
    const X = xi & 255, Y = yi & 255;
    const aa = p[p[X] + Y] & 7;
    const ab = p[p[X] + Y + 1] & 7;
    const ba = p[p[X + 1] + Y] & 7;
    const bb = p[p[X + 1] + Y + 1] & 7;
    const u = fade(xf), v = fade(yf);
    const g00 = GX[aa] * xf + GY[aa] * yf;
    const g10 = GX[ba] * (xf - 1) + GY[ba] * yf;
    const g01 = GX[ab] * xf + GY[ab] * (yf - 1);
    const g11 = GX[bb] * (xf - 1) + GY[bb] * (yf - 1);
    const x1 = g00 + u * (g10 - g00);
    const x2 = g01 + u * (g11 - g01);
    return x1 + v * (x2 - x1);
  };
})();

// [UI.IH]
function fbm(x, y, oct) {
  let s = 0, a = 0.5, f = 1;
  for (let i = 0; i < oct; i++) {
    s += a * perlin(x * f, y * f);
    f *= 2.03; a *= 0.5;
  }
  return s;
}

// [UI.II]
function ridged(x, y, oct) {
  let s = 0, a = 0.5, f = 1;
  for (let i = 0; i < oct; i++) {
    let n = 1 - Math.abs(perlin(x * f, y * f));
    n *= n;
    s += a * n;
    f *= 2.03; a *= 0.5;
  }
  return s;
}


//  Cosmic nebula and baked starfield texture renderer.

const NEBULA_DENSITY = 1.0;

//  Nebula color clusters aligned with logo gradient.
const NEBULA_CLUSTERS = [
  // Top-left cluster (pink-purple).
  { cx: 0.22, cy: 0.22, scale: 0.42, angle: 0.38, aspect: 0.64, intensity: 1.0,
    base: [0.34, 0.14, 0.58], hot: [0.95, 0.38, 0.88] },
  // Top-right cluster (cyan).
  { cx: 0.78, cy: 0.20, scale: 0.40, angle: -0.38, aspect: 0.65, intensity: 1.0,
    base: [0.04, 0.38, 0.62], hot: [0.25, 0.94, 0.96] },
  // Bottom-left cluster (muted pink-purple background).
  { cx: 0.20, cy: 0.76, scale: 0.45, angle: -0.28, aspect: 0.70, intensity: 0.52,
    base: [0.28, 0.10, 0.48], hot: [0.82, 0.30, 0.78] },
  // Bottom-right cluster (muted cyan background).
  { cx: 0.80, cy: 0.74, scale: 0.44, angle: 0.32, aspect: 0.70, intensity: 0.52,
    base: [0.04, 0.32, 0.50], hot: [0.20, 0.85, 0.88] }
];

// [UI.IJ]
function getActiveNebulaClusters() {
  if (typeof window !== 'undefined' && window.activeThemeColors && window.activeThemeColors.nebulaClusters) {
    return window.activeThemeColors.nebulaClusters;
  }
  return NEBULA_CLUSTERS;
}

// Noise offsets for randomized nebula structure per session.
const NEB_OFF = [Math.random() * 200, Math.random() * 200];

let nebulaCache = null;
let nebulaCacheKey = '';

//  Starfield parameters and sprite generation.
const BAKED_STAR_COUNT = 1620;
const TWINKLE_STAR_COUNT = 160;
const TWINKLE_STAR_COUNT_LOW = 65;
const STAR_NEBULA_SHARE = 0.5;

const STAR_TINTS = [
  { rgb: [155, 176, 255], w: 0.08 },
  { rgb: [202, 215, 255], w: 0.17 },
  { rgb: [248, 247, 255], w: 0.30 },
  { rgb: [255, 244, 234], w: 0.25 },
  { rgb: [255, 210, 161], w: 0.15 },
  { rgb: [255, 180, 130], w: 0.05 }
];

const STAR_CLASSES = [
  { sigma: 0.50, halo: 0.00, spike: 0.00, len: 0,  alpha: [0.25, 0.55] },
  { sigma: 0.65, halo: 0.04, spike: 0.00, len: 0,  alpha: [0.40, 0.70] },
  { sigma: 0.85, halo: 0.08, spike: 0.00, len: 0,  alpha: [0.55, 0.85] },
  { sigma: 1.05, halo: 0.14, spike: 0.00, len: 0,  alpha: [0.75, 1.00] },
  { sigma: 1.25, halo: 0.20, spike: 0.35, len: 12, alpha: [0.90, 1.00] }
];

let synthStars = [];
let lastStarUpdateTime = performance.now();

// [UI.IK]
function pickTint() {
  let r = Math.random();
  for (let i = 0; i < STAR_TINTS.length; i++) {
    r -= STAR_TINTS[i].w;
    if (r <= 0) return i;
  }
  return 2;
}

// [UI.IL]
function pickNebulaStarPosition() {
  const clusters = getActiveNebulaClusters();
  const idx = Math.random() < 0.75
    ? (Math.random() < 0.5 ? 0 : 1)
    : (Math.random() < 0.5 ? 2 : 3);
  const cluster = clusters[idx] || clusters[0];
  const lx = randn() * 0.45 * cluster.scale;
  const ly = randn() * 0.45 * cluster.scale * cluster.aspect;
  const cs = Math.cos(cluster.angle), sn = Math.sin(cluster.angle);
  let x = cluster.cx + lx * cs - ly * sn;
  let y = cluster.cy + lx * sn + ly * cs;
  return { x: Math.min(1, Math.max(0, x)), y: Math.min(1, Math.max(0, y)) };
}

// [UI.IM]
function renderNebulaCache(w, h, dpr) {
  const isLowPerf = (typeof perfMode !== 'undefined' && perfMode === 'low');
  const effectiveDpr = isLowPerf ? Math.min(1.0, dpr) : dpr;
  const pw = Math.max(1, Math.round(w * effectiveDpr));
  const ph = Math.max(1, Math.round(h * effectiveDpr));
  const S = Math.min(w, h);

  const off = document.createElement('canvas');
  off.width = pw;
  off.height = ph;
  const c = off.getContext('2d');
  const img = c.createImageData(pw, ph);
  const d = img.data;

  const activeClusters = getActiveNebulaClusters();
  const cl = activeClusters.map(cluster => ({
    c: cluster,
    cx: cluster.cx * w,
    cy: cluster.cy * h,
    R: cluster.scale * S,
    cs: Math.cos(cluster.angle),
    sn: Math.sin(cluster.angle),
    intensity: cluster.intensity !== undefined ? cluster.intensity : 1.0
  }));
  const env = new Float32Array(cl.length);

  const octMain = isLowPerf ? 4 : 5;
  const octRidge = isLowPerf ? 3 : 4;

  for (let Y = 0; Y < ph; Y++) {
    const py = (Y + 0.5) / effectiveDpr;
    const t = py / h;
    let bgR, bgG, bgB;
    if (t < 0.5) {
      const q = t / 0.5;
      bgR = 6 + (5 - 6) * q;
      bgG = 9 + (7 - 9) * q;
      bgB = 20 + (17 - 20) * q;
    } else {
      const q = (t - 0.5) / 0.5;
      bgR = 5 + (2 - 5) * q;
      bgG = 7 + (3 - 7) * q;
      bgB = 17 + (8 - 17) * q;
    }

    for (let X = 0; X < pw; X++) {
      const px = (X + 0.5) / effectiveDpr;

      let maxEnv = 0;
      for (let i = 0; i < cl.length; i++) {
        const q = cl[i];
        const dx = (px - q.cx) / q.R;
        const dy = (py - q.cy) / q.R;
        const rx = dx * q.cs + dy * q.sn;
        const ry = -dx * q.sn + dy * q.cs;
        const sx = 0.85, sy = 0.85 * q.c.aspect;
        const e = Math.exp(-(rx * rx) / (sx * sx) - (ry * ry) / (sy * sy)) * q.intensity;
        env[i] = e;
        if (e > maxEnv) maxEnv = e;
      }

      let nr = 0, ng = 0, nb = 0;

      if (maxEnv > 0.01) {
        const u = px / S, v = py / S;

        const wx = u + 0.55 * fbm(u * 1.4 + NEB_OFF[0], v * 1.4 + NEB_OFF[1], 3);
        const wy = v + 0.55 * fbm(u * 1.4 + NEB_OFF[1] + 31.7, v * 1.4 + NEB_OFF[0] + 17.3, 3);

        const dustN = 0.5 + 1.1 * fbm(wx * 2.2 + 91.3, wy * 2.2 + 47.9, 4);
        const dust = smoothstep(0.52, 0.78, dustN);

        for (let i = 0; i < cl.length; i++) {
          const e = env[i];
          if (e < 0.01) continue;
          const q = cl[i].c;
          const offShift = i * 53.7;

          const n01 = 0.5 + 1.1 * fbm(wx * 3.0 + offShift, wy * 3.0 + offShift * 0.7, octMain);
          const dens = smoothstep(0.28, 0.82, n01);
          const fil = Math.pow(clamp01(ridged(wx * 3.6 + offShift + 7.1, wy * 3.6 + offShift - 3.9, octRidge) * 1.7), 1.4);

          let I = e * (0.28 + 0.95 * dens) * (0.5 + 0.95 * fil);
          I *= 1 - 0.7 * dust * Math.min(1, e * 3);

          const hotK = I * I * I * 0.6;
          nr += (q.base[0] * I + q.hot[0] * hotK) * 0.8;
          ng += (q.base[1] * I + q.hot[1] * hotK) * 0.8;
          nb += (q.base[2] * I + q.hot[2] * hotK) * 0.8;
        }
      }

      const tr = 1 - Math.exp(-nr * NEBULA_DENSITY);
      const tg = 1 - Math.exp(-ng * NEBULA_DENSITY);
      const tb = 1 - Math.exp(-nb * NEBULA_DENSITY);

      let r = bgR + tr * 255 * (1 - bgR / 255);
      let g = bgG + tg * 255 * (1 - bgG / 255);
      let b = bgB + tb * 255 * (1 - bgB / 255);

      const vr = Math.hypot(px - w * 0.5, py - h * 0.45) / (w * 0.85);
      const vt = smoothstep(0.35, 1.0, vr) * 0.9;
      r = r * (1 - vt) + 2 * vt;
      g = g * (1 - vt) + 3 * vt;
      b = b * (1 - vt) + 8 * vt;

      const nGrain = (Math.random() + Math.random() - 1) * 1.6;
      const o = (Y * pw + X) * 4;
      d[o] = Math.min(255, Math.max(0, r + nGrain));
      d[o + 1] = Math.min(255, Math.max(0, g + nGrain));
      d[o + 2] = Math.min(255, Math.max(0, b + nGrain));
      d[o + 3] = 255;
    }
  }

  const dustCount = Math.floor(pw * ph / 700);
  for (let i = 0; i < dustCount; i++) {
    const X = Math.floor(Math.random() * pw);
    const Y = Math.floor(Math.random() * ph);
    const o = (Y * pw + X) * 4;
    const v = 10 + Math.pow(Math.random(), 3) * 70;
    d[o] += v * 0.85;
    d[o + 1] += v * 0.92;
    d[o + 2] += v;
  }

  c.putImageData(img, 0, 0);

  const bakeRand = mulberry32(4242);
  c.save();
  c.globalCompositeOperation = 'lighter';
  for (let i = 0; i < BAKED_STAR_COUNT; i++) {
    const inNeb = bakeRand() < STAR_NEBULA_SHARE;
    let sx, sy;
    if (inNeb) {
      const idx = bakeRand() < 0.75
        ? (bakeRand() < 0.5 ? 0 : 1)
        : (bakeRand() < 0.5 ? 2 : 3);
      const cluster = activeClusters[idx] || activeClusters[0];
      const u1 = Math.max(1e-6, bakeRand()), u2 = bakeRand();
      const z0 = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
      const z1 = Math.sqrt(-2.0 * Math.log(u1)) * Math.sin(2.0 * Math.PI * u2);
      const lx = z0 * 0.45 * cluster.scale;
      const ly = z1 * 0.45 * cluster.scale * cluster.aspect;
      const cs = Math.cos(cluster.angle), sn = Math.sin(cluster.angle);
      sx = Math.min(1, Math.max(0, cluster.cx + lx * cs - ly * sn));
      sy = Math.min(1, Math.max(0, cluster.cy + lx * sn + ly * cs));
    } else {
      sx = bakeRand();
      sy = bakeRand();
    }

    const u = bakeRand();
    const cls = u < 0.56 ? 0 : u < 0.82 ? 1 : u < 0.94 ? 2 : u < 0.988 ? 3 : 4;
    const aR = STAR_CLASSES[cls].alpha;
    const alpha = (aR[0] + bakeRand() * (aR[1] - aR[0])) * 0.88;

    let tr = bakeRand(), tintIdx = 2;
    for (let t = 0; t < STAR_TINTS.length; t++) {
      tr -= STAR_TINTS[t].w;
      if (tr <= 0) { tintIdx = t; break; }
    }

    const px = Math.round(sx * pw);
    const py = Math.round(sy * ph);
    c.globalAlpha = alpha;

    let bakeBrightness;
    if (cls >= 4) bakeBrightness = '#ffffff';
    else if (cls >= 3) bakeBrightness = '#e2e8f0';
    else if (cls >= 2) bakeBrightness = '#cbd5e1';
    else if (cls >= 1) bakeBrightness = '#94a3b8';
    else bakeBrightness = '#64748b';

    c.fillStyle = bakeBrightness;
    c.fillRect(px, py, 1, 1);
  }
  c.restore();

  return off;
}

// [UI.IN]
function getDpr() {
  if (typeof window !== 'undefined' && window.devicePixelRatio) {
    return window.devicePixelRatio;
  }
  return 1;
}

// [UI.IO]
function isMenuSceneActive() {
  const isUpgradesFromCombat = (typeof gameState !== 'undefined' && gameState === 'UPGRADES' && (typeof upgradesPreviousSource !== 'undefined' && (upgradesPreviousSource === 'victory' || upgradesPreviousSource === 'defeat')));
  const isSettingsFromCombat = (typeof gameState !== 'undefined' && gameState === 'SETTINGS' && (typeof settingsPreviousSource !== 'undefined' && settingsPreviousSource === 'pause'));
  const isShopFromCombat = (typeof gameState !== 'undefined' && gameState === 'SHOP' && (typeof shopPreviousSource !== 'undefined' && (shopPreviousSource === 'victory' || shopPreviousSource === 'defeat')));

  return (typeof gameState !== 'undefined' && (gameState === 'START' || gameState === 'LEVELS' || gameState === 'UPGRADES' || gameState === 'SHOP' || gameState === 'BATTLE_PASS')) &&
         !isUpgradesFromCombat && !isSettingsFromCombat && !isShopFromCombat;
}

let combatDimAlpha = 0;
let lastDimUpdateTime = typeof performance !== 'undefined' ? performance.now() : Date.now();

// [UI.IP]
function drawCosmicNebulaBackground(w, h, customDim = null) {
  const dpr = getDpr();
  const isLowPerf = (typeof perfMode !== 'undefined' && perfMode === 'low') ? 'low' : 'high';
  const palKey = typeof activePalette !== 'undefined' ? activePalette : 'default';
  const key = Math.round(w) + 'x' + Math.round(h) + '@' + dpr + '_' + isLowPerf + '_' + palKey;
  if (!nebulaCache || nebulaCacheKey !== key) {
    nebulaCache = renderNebulaCache(w, h, dpr);
    nebulaCacheKey = key;
  }
  
  ctx.save();
  ctx.imageSmoothingEnabled = false;
  ctx.drawImage(nebulaCache, 0, 0, w, h);
  ctx.restore();

  combatDimAlpha = 0;
}

let initialLoaderHidden = false;

// [UI.IQ]
function warmUpNebulaAndHideLoader() {
  if (initialLoaderHidden) return;
  initialLoaderHidden = true;

  const loader = document.getElementById('initialLoadingScreen');
  const barFill = document.getElementById('initialProgressBarFill');
  const loadingTextEl = document.getElementById('initialLoadingText');

  // [UI.IR]
  const setProgress = (pct) => {
    if (barFill) barFill.style.width = pct + '%';
  };

  // [UI.IS]
  const stepWait = (pct, delayMs = 140) => new Promise(resolve => {
    // [UI.IT]
    requestAnimationFrame(() => {
      setProgress(pct);
      // [UI.IU]
      requestAnimationFrame(() => {
        setTimeout(resolve, delayMs);
      });
    });
  });

  // [UI.IV]
  (async () => {
    try {
      const dpr = getDpr();
      const w = (typeof canvas !== 'undefined' && canvas) ? (canvas.width / dpr || window.innerWidth) : window.innerWidth;
      const h = (typeof canvas !== 'undefined' && canvas) ? (canvas.height / dpr || window.innerHeight) : window.innerHeight;

      await stepWait(20, 100);

      if (typeof canvas !== 'undefined' && canvas) {
        drawCosmicNebulaBackground(w, h);
      }
      await stepWait(50, 120);

      const horizonY = h * 0.44;
      if (typeof renderTriangleLogoCache === 'function') {
        const isLowPerfFlag = (typeof perfMode !== 'undefined' && perfMode === 'low');
        const texScale = isLowPerfFlag ? 1.5 : Math.min(3.0, Math.max(2.0, dpr * 1.5));
        const palKey = typeof activePalette !== 'undefined' ? activePalette : 'default';
        const key = Math.round(w) + 'x' + Math.round(horizonY) + '@' + texScale.toFixed(2) + '_' + (isLowPerfFlag ? 'low' : 'high') + '_' + palKey;
        if (!triangleLogoCache || triangleLogoCacheKey !== key) {
          triangleLogoCache = renderTriangleLogoCache(w, horizonY, texScale);
          triangleLogoCacheKey = key;
        }
      }
      await stepWait(75, 100);

      if (typeof MusicManager !== 'undefined' && typeof MusicManager.warmUpMenuAudio === 'function') {
        await MusicManager.warmUpMenuAudio();
      }
      if (typeof SFX !== 'undefined' && typeof SFX.autoload === 'function') {
        await SFX.autoload();
      }
      await stepWait(92, 100);

      if (typeof drawSynthWavePerspectiveScene === 'function') {
        drawSynthWavePerspectiveScene(performance.now());
      }
      const startSc = document.getElementById('startScreen');
      if (startSc) void startSc.offsetHeight;

      await stepWait(100, 160);

    } catch (e) {
      console.warn('Pre-warm scene failed:', e);
      setProgress(100);
    }

    if (loader) {
      if (barFill) {
        barFill.style.transition = 'none';
        barFill.style.setProperty('width', '100%', 'important');
      }

      if (loadingTextEl) {
        loadingTextEl.textContent = typeof t === 'function' ? t('ready') : 'READY';
      }

      const titleBox = document.createElement('div');
      titleBox.className = 'loader-title-zone';
      titleBox.innerHTML = `
        <div class="start-sub-title">Synth Wave</div>
        <div class="start-main-title">Defense</div>
      `;
      loader.appendChild(titleBox);

      const goBtn = document.createElement('button');
      goBtn.className = 'shop-item-btn shop-btn-free';
      goBtn.setAttribute('data-sfx', 'tap');
      goBtn.style.position = 'absolute';
      goBtn.style.left = '50%';
      const centerBox = document.getElementById('initialLoaderCenterBox');
      const baseTop = (centerBox && centerBox.style.top) ? centerBox.style.top : '50lvh';
      goBtn.style.top = `calc(${baseTop} + 56px)`;
      goBtn.style.transform = 'translateX(-50%)';
      goBtn.style.pointerEvents = 'auto';
      goBtn.style.padding = '10px 42px';
      goBtn.style.fontSize = '14px';
      goBtn.style.opacity = '0';
      goBtn.style.animation = 'goBtnAppear 1s ease-out forwards, goBtnPulse 2s infinite ease-in-out 1s';
      goBtn.innerHTML = `<span>${typeof t === 'function' ? t('go') : 'GO'}</span>`;

      // [UI.IW]
      goBtn.onclick = () => {
        if (typeof SFX !== 'undefined' && typeof SFX.unlock === 'function') SFX.unlock();
        if (typeof musicUnlock === 'function') musicUnlock();

        loader.style.opacity = '0';
        loader.style.pointerEvents = 'none';
        // [UI.IX]
        setTimeout(() => {
          if (loader.parentNode) loader.parentNode.removeChild(loader);
        }, 400);
      };

      loader.appendChild(goBtn);
    }
  })();
}

// [UI.IY]
function createStar(randomizeLife = false, inNebula = false) {
  const maxLife = Math.random() * 16.0 + 10.0;
  const u = Math.random();
  const cls = u < 0.25 ? 0 : u < 0.55 ? 1 : u < 0.82 ? 2 : u < 0.95 ? 3 : 4;
  const aR = STAR_CLASSES[cls].alpha;

  const pos = inNebula ? pickNebulaStarPosition() : { x: Math.random(), y: Math.random() };

  return {
    x: pos.x,
    y: pos.y,
    cls: cls,
    tint: pickTint(),
    baseAlpha: aR[0] + Math.random() * (aR[1] - aR[0]),
    twinkleSpeed: Math.random() * 1.6 + 0.7,
    twinklePhase: Math.random() * Math.PI * 2,
    life: randomizeLife ? Math.random() * maxLife : 0,
    maxLife: maxLife
  };
}

// [UI.IZ]
function initSynthStars() {
  synthStars = [];
  for (let i = 0; i < TWINKLE_STAR_COUNT; i++) {
    synthStars.push(createStar(true, Math.random() < STAR_NEBULA_SHARE));
  }
}
initSynthStars();

// [UI.JA]
function updateAndDrawStars(w, h, now) {
  const dt = Math.min((now - lastStarUpdateTime) / 1000, 0.1);
  lastStarUpdateTime = now;
  const time = now / 1000;

  const isLowPerf = (typeof perfMode !== 'undefined' && perfMode === 'low');
  const activeCount = isLowPerf ? Math.min(synthStars.length, TWINKLE_STAR_COUNT_LOW) : synthStars.length;

  ctx.save();
  ctx.globalCompositeOperation = 'lighter';

  for (let i = 0; i < activeCount; i++) {
    const star = synthStars[i];
    star.life += dt;
    if (star.life >= star.maxLife) {
      synthStars[i] = createStar(false, Math.random() < STAR_NEBULA_SHARE);
      continue;
    }

    const lifeProgress = star.life / star.maxLife;
    const fade = Math.min(1, Math.sin(lifeProgress * Math.PI) * 3);

    const twinkle = 0.55 + 0.45 * Math.sin(time * star.twinkleSpeed + star.twinklePhase);
    const alpha = star.baseAlpha * twinkle * fade;
    if (alpha <= 0.02) continue;

    const px = Math.round(star.x * w);
    const py = Math.round(star.y * h);

    ctx.globalAlpha = alpha;

    let starBrightness;
    if (star.cls >= 4) {
      starBrightness = '#ffffff';
    } else if (star.cls >= 3) {
      starBrightness = '#e2e8f0';
    } else if (star.cls >= 2) {
      starBrightness = '#cbd5e1';
    } else if (star.cls >= 1) {
      starBrightness = '#94a3b8';
    } else {
      starBrightness = '#64748b';
    }

    ctx.fillStyle = starBrightness;
    ctx.fillRect(px, py, 1, 1);
  }
  ctx.restore();
}

let triangleLogoCache = null;
let triangleLogoCacheKey = '';

// [UI.JB]
function renderTriangleLogoCache(w, horizonY, texScale) {
  const isLowPerf = (typeof perfMode !== 'undefined' && perfMode === 'low');
  const effScale = texScale || (isLowPerf ? 1.5 : Math.min(3.0, Math.max(2.0, getDpr() * 1.5)));

  const pad = 70;
  const ch = Math.ceil(horizonY + pad);
  const off = document.createElement('canvas');
  off.width = Math.max(1, Math.round(w * effScale));
  off.height = Math.max(1, Math.round(ch * effScale));
  const c = off.getContext('2d');
  c.scale(effScale, effScale);

  const cx = w * 0.5;
  const tipY = horizonY - 24;
  const topY = Math.max(98, horizonY * 0.26);
  const halfW = Math.min(w * 0.35, (tipY - topY) * 0.65);

  const A = { x: cx,         y: tipY };
  const B = { x: cx - halfW, y: topY };
  const C = { x: cx + halfW, y: topY };

  const sa = Math.hypot(B.x - C.x, B.y - C.y);
  const sb = Math.hypot(A.x - C.x, A.y - C.y);
  const sc = Math.hypot(A.x - B.x, A.y - B.y);
  const per = sa + sb + sc;
  const inX = (sa * A.x + sb * B.x + sc * C.x) / per;
  const inY = (sa * A.y + sb * B.y + sc * C.y) / per;
  const inR = (halfW * (tipY - topY)) / (per / 2);

  // [UI.JC]
  const triPoints = (offset) => {
    const k = 1 + offset / inR;
    // [UI.JD]
    const p = v => ({ x: inX + (v.x - inX) * k, y: inY + (v.y - inY) * k });
    return [p(A), p(B), p(C)];
  };

  const triPath = (offset) => {
    const [a, b, d] = triPoints(offset);
    c.beginPath();
    c.moveTo(a.x, a.y);
    c.lineTo(b.x, b.y);
    c.lineTo(d.x, d.y);
    c.closePath();
  };

  const th = getTheme();
  const c1Rgb = th.rgb1 ? th.rgb1.cssRgb : '0, 229, 255';
  const c2Rgb = th.rgb2 ? th.rgb2.cssRgb : '217, 70, 239';
  const c3Rgb = th.rgb3 ? th.rgb3.cssRgb : '240, 95, 159';

  const drawRadialSpot = (x, y, r, stops) => {
    const g = c.createRadialGradient(x, y, 0, x, y, r);
    for (let i = 0; i < stops.length; i++) {
      g.addColorStop(stops[i][0], stops[i][1]);
    }
    c.fillStyle = g;
    c.beginPath();
    c.arc(x, y, r, 0, Math.PI * 2);
    c.fill();
  };

  // [UI.JE]
  const makeGrad = (lighten) => {
    const g = c.createLinearGradient(B.x - 20, 0, C.x + 20, 0);
    if (lighten) {
      g.addColorStop(0.00, th.c1Light);
      g.addColorStop(0.52, th.c2Light);
      g.addColorStop(1.00, th.c3Light);
    } else {
      g.addColorStop(0.00, th.c1);
      g.addColorStop(0.52, th.c2);
      g.addColorStop(1.00, th.c3);
    }
    return g;
  };

  c.save();
  c.globalCompositeOperation = 'lighter';

  const cornerR = halfW * 0.30;
  const cornerSpots = [
    { x: B.x, y: B.y, r: cornerR, stops: [[0.0, `rgba(${c1Rgb}, 0.24)`], [0.4, `rgba(${c1Rgb}, 0.10)`], [1.0, `rgba(${c1Rgb}, 0)`]] },
    { x: C.x, y: C.y, r: cornerR, stops: [[0.0, `rgba(${c3Rgb}, 0.24)`], [0.4, `rgba(${c2Rgb}, 0.10)`], [1.0, `rgba(${c2Rgb}, 0)`]] },
    { x: A.x, y: A.y - 3, r: cornerR * 0.50, stops: [[0.0, 'rgba(255, 255, 255, 0.10)'], [0.30, `rgba(${c2Rgb}, 0.18)`], [0.65, `rgba(${c3Rgb}, 0.06)`], [1.0, `rgba(${c2Rgb}, 0)`]] }
  ];
  for (let i = 0; i < cornerSpots.length; i++) {
    const s = cornerSpots[i];
    drawRadialSpot(s.x, s.y, s.r, s.stops);
  }
  c.restore();

  // [UI.JEM] Soft inner tinting veil & volumetric neon mist inside outer triangle.
  c.save();
  triPath(0);
  c.clip();

  const veilGrad = c.createLinearGradient(0, topY, 0, tipY);
  veilGrad.addColorStop(0.0, 'rgba(10, 14, 34, 0.36)');
  veilGrad.addColorStop(0.55, 'rgba(14, 18, 46, 0.30)');
  veilGrad.addColorStop(1.0, `rgba(${c2Rgb}, 0.28)`);
  c.fillStyle = veilGrad;
  c.fillRect(B.x - 10, B.y - 10, halfW * 2 + 20, (tipY - topY) + 20);

  c.globalAlpha = 0.08;
  c.fillStyle = makeGrad(false);
  c.fillRect(B.x - 10, B.y - 10, halfW * 2 + 20, (tipY - topY) + 20);

  c.globalCompositeOperation = 'lighter';
  c.globalAlpha = 1.0;
  drawRadialSpot(inX, inY, inR * 1.35, [
    [0.0, `rgba(${c2Rgb}, 0.15)`],
    [0.55, `rgba(${c1Rgb}, 0.07)`],
    [1.0, 'rgba(0, 0, 0, 0)']
  ]);

  c.lineJoin = 'round';
  c.lineCap = 'round';
  c.strokeStyle = makeGrad(false);
  c.globalAlpha = 0.09;
  c.lineWidth = 24;
  triPath(0);
  c.stroke();
  c.globalAlpha = 0.12;
  c.lineWidth = 10;
  triPath(0);
  c.stroke();
  c.restore();

  const GLOW_FALLOFF = [
    { mult: 5.8, alpha: 0.015 },
    { mult: 4.3, alpha: 0.024 },
    { mult: 3.1, alpha: 0.040 },
    { mult: 2.1, alpha: 0.065 },
    { mult: 1.3, alpha: 0.100 }
  ];

  // [UI.JF]
  const neonTriSoft = (offset, width, lighten, strength) => {
    c.save();
    c.lineJoin = 'round';
    c.lineCap = 'round';

    const glowGrad = makeGrad(false);
    const coreGrad = makeGrad(lighten);

    c.globalCompositeOperation = 'lighter';
    c.strokeStyle = glowGrad;
    for (let i = 0; i < GLOW_FALLOFF.length; i++) {
      const layer = GLOW_FALLOFF[i];
      c.globalAlpha = layer.alpha * strength;
      c.lineWidth = width * layer.mult;
      triPath(offset);
      c.stroke();
    }

    c.globalCompositeOperation = 'screen';
    c.globalAlpha = 0.92;
    c.strokeStyle = coreGrad;
    c.lineWidth = width;
    triPath(offset);
    c.stroke();

    c.globalCompositeOperation = 'lighter';
    c.globalAlpha = 0.48 * strength;
    c.strokeStyle = '#ffffff';
    c.lineWidth = width * 0.34;
    triPath(offset);
    c.stroke();

    c.restore();
  };

  neonTriSoft(-inR * 0.40, 4.2, false, 0.88);
  neonTriSoft(-14,         4.8, false, 0.94);
  neonTriSoft(0,           5.2, true,  1.12);

  // [UI.JFM] Post-line screen blooms positioned right inside each bottom V-tip to round out inner glow.
  const r2 = th.rgb2 ? th.rgb2.r : 217;
  const g2 = th.rgb2 ? th.rgb2.g : 70;
  const b2 = th.rgb2 ? th.rgb2.b : 239;
  const c2LightRgb = `${Math.round(r2 + (255 - r2) * 0.55)}, ${Math.round(g2 + (255 - g2) * 0.55)}, ${Math.round(b2 + (255 - b2) * 0.55)}`;

  c.save();
  triPath(0);
  c.clip();
  c.globalCompositeOperation = 'screen';

  const postSpots = [
    { x: A.x, y: inY + (A.y - inY) * 1.0 - 8,                  r: 20, stops: [[0.0, `rgba(${c2LightRgb}, 0.45)`], [0.45, `rgba(${c2Rgb}, 0.16)`], [1.0, `rgba(${c2Rgb}, 0)`]] },
    { x: A.x, y: inY + (A.y - inY) * (1 - 14 / inR) - 12,      r: 26, stops: [[0.0, `rgba(${c2LightRgb}, 0.42)`], [0.45, `rgba(${c2Rgb}, 0.16)`], [1.0, `rgba(${c2Rgb}, 0)`]] },
    { x: A.x, y: inY + (A.y - inY) * 0.60 - 14,                r: 34, stops: [[0.0, `rgba(${c2LightRgb}, 0.36)`], [0.45, `rgba(${c2Rgb}, 0.14)`], [1.0, `rgba(${c2Rgb}, 0)`]] },
    { x: B.x + 12, y: B.y + 8, r: cornerR * 0.65, stops: [[0.0, `rgba(${c1Rgb}, 0.18)`], [0.5, `rgba(${c1Rgb}, 0.06)`], [1.0, `rgba(${c1Rgb}, 0)`]] },
    { x: C.x - 12, y: C.y + 8, r: cornerR * 0.65, stops: [[0.0, `rgba(${c3Rgb}, 0.18)`], [0.5, `rgba(${c2Rgb}, 0.06)`], [1.0, `rgba(${c2Rgb}, 0)`]] }
  ];
  for (let i = 0; i < postSpots.length; i++) {
    const s = postSpots[i];
    drawRadialSpot(s.x, s.y, s.r, s.stops);
  }
  c.restore();

  return { canvas: off, height: ch };
}

// [UI.JG]
function drawSynthWaveTriangleLogo5C(w, horizonY, time) {
  const dpr = getDpr();
  const isLowPerfFlag = (typeof perfMode !== 'undefined' && perfMode === 'low');
  const texScale = isLowPerfFlag ? 1.5 : Math.min(3.0, Math.max(2.0, dpr * 1.5));
  const palKey = typeof activePalette !== 'undefined' ? activePalette : 'default';
  const key = Math.round(w) + 'x' + Math.round(horizonY) + '@' + texScale.toFixed(2) + '_' + (isLowPerfFlag ? 'low' : 'high') + '_' + palKey;

  if (!triangleLogoCache || triangleLogoCacheKey !== key) {
    triangleLogoCache = renderTriangleLogoCache(w, horizonY, texScale);
    triangleLogoCacheKey = key;
  }

  ctx.save();
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(triangleLogoCache.canvas, 0, 0, w, triangleLogoCache.height);
  ctx.restore();
}

//  Multi-pass neon horizon beam renderer (baked into menu stage cache).
// [UI.JH]
function drawSynthWaveHorizonBeam(w, horizonY, targetCtx) {
  const tCtx = targetCtx || ctx;
  const th = getTheme();
  const c1Rgb = th.rgb1 ? th.rgb1.cssRgb : '0, 229, 255';
  const c2Rgb = th.rgb2 ? th.rgb2.cssRgb : '217, 70, 239';
  const c3Rgb = th.rgb3 ? th.rgb3.cssRgb : '240, 95, 159';

  tCtx.save();
  tCtx.globalCompositeOperation = 'lighter';

  const bloomR = 46;
  const vBloom = tCtx.createLinearGradient(0, horizonY - bloomR, 0, horizonY + bloomR);
  vBloom.addColorStop(0.00, `rgba(${c2Rgb}, 0)`);
  vBloom.addColorStop(0.22, `rgba(${c2Rgb}, 0.04)`);
  vBloom.addColorStop(0.36, `rgba(${c2Rgb}, 0.11)`);
  vBloom.addColorStop(0.45, `rgba(${c1Rgb}, 0.25)`);
  vBloom.addColorStop(0.50, 'rgba(240, 250, 255, 0.44)');
  vBloom.addColorStop(0.55, `rgba(${c1Rgb}, 0.25)`);
  vBloom.addColorStop(0.64, `rgba(${c1Rgb}, 0.11)`);
  vBloom.addColorStop(0.78, `rgba(${c1Rgb}, 0.04)`);
  vBloom.addColorStop(1.00, `rgba(${c1Rgb}, 0)`);
  tCtx.fillStyle = vBloom;
  tCtx.fillRect(0, horizonY - bloomR, w, bloomR * 2);

  const sideRx = w * 0.46;
  const sideRy = 26;
  const sideGlows = [
    { x: w * 0.27, cStart: c1Rgb, cMid: c1Rgb },
    { x: w * 0.73, cStart: c3Rgb, cMid: c2Rgb }
  ];
  for (let i = 0; i < sideGlows.length; i++) {
    const sg = sideGlows[i];
    tCtx.save();
    tCtx.translate(sg.x, horizonY);
    tCtx.scale(1, sideRy / sideRx);
    const g = tCtx.createRadialGradient(0, 0, 0, 0, 0, sideRx);
    g.addColorStop(0.00, `rgba(${sg.cStart}, 0.38)`);
    g.addColorStop(0.35, `rgba(${sg.cMid}, 0.18)`);
    g.addColorStop(0.70, `rgba(${sg.cMid}, 0.05)`);
    g.addColorStop(1.00, `rgba(${sg.cMid}, 0)`);
    tCtx.fillStyle = g;
    tCtx.beginPath();
    tCtx.arc(0, 0, sideRx, 0, Math.PI * 2);
    tCtx.fill();
    tCtx.restore();
  }

  const tightR = 7;
  const tightBloom = tCtx.createLinearGradient(0, horizonY - tightR, 0, horizonY + tightR);
  tightBloom.addColorStop(0.00, 'rgba(255, 255, 255, 0)');
  tightBloom.addColorStop(0.30, `rgba(${c2Rgb}, 0.28)`);
  tightBloom.addColorStop(0.50, 'rgba(255, 255, 255, 0.76)');
  tightBloom.addColorStop(0.70, `rgba(${c1Rgb}, 0.28)`);
  tightBloom.addColorStop(1.00, 'rgba(255, 255, 255, 0)');
  tCtx.fillStyle = tightBloom;
  tCtx.fillRect(0, horizonY - tightR, w, tightR * 2);

  const hBeamGrad = tCtx.createLinearGradient(0, 0, w, 0);
  hBeamGrad.addColorStop(0.00, th.c1);
  hBeamGrad.addColorStop(0.22, th.c1Light);
  hBeamGrad.addColorStop(0.50, th.c2);
  hBeamGrad.addColorStop(0.78, th.c3Light || th.c3);
  hBeamGrad.addColorStop(1.00, th.c3);

  tCtx.globalCompositeOperation = 'source-over';
  tCtx.strokeStyle = hBeamGrad;
  tCtx.globalAlpha = 0.95;
  tCtx.lineWidth = 3.2;
  tCtx.beginPath();
  tCtx.moveTo(0, horizonY);
  tCtx.lineTo(w, horizonY);
  tCtx.stroke();

  const coreGrad = tCtx.createLinearGradient(0, 0, w, 0);
  coreGrad.addColorStop(0.00, 'rgba(255, 255, 255, 0.78)');
  coreGrad.addColorStop(0.15, 'rgba(255, 255, 255, 0.94)');
  coreGrad.addColorStop(0.50, 'rgba(255, 255, 255, 0.94)');
  coreGrad.addColorStop(0.85, 'rgba(255, 255, 255, 0.94)');
  coreGrad.addColorStop(1.00, 'rgba(255, 255, 255, 0.78)');

  tCtx.globalCompositeOperation = 'lighter';
  tCtx.strokeStyle = coreGrad;
  tCtx.globalAlpha = 0.95;
  tCtx.lineWidth = 1.6;
  tCtx.beginPath();
  tCtx.moveTo(0, horizonY);
  tCtx.lineTo(w, horizonY);
  tCtx.stroke();

  tCtx.restore();
}

let menuStageCache = null;
let menuStageCacheKey = '';

// [UI.JHM] Offscreen cache for static main menu stage (floor gradient, perspective rays, road, horizon beam).
function renderMenuStageCache(w, h, horizonY, texScale) {
  const off = document.createElement('canvas');
  off.width = Math.max(1, Math.round(w * texScale));
  off.height = Math.max(1, Math.round(h * texScale));
  const mCtx = off.getContext('2d');
  mCtx.scale(texScale, texScale);

  const floorH = h - horizonY;
  const vpX = w * 0.5;
  const th = getTheme();
  const c1Rgb = th.rgb1 ? th.rgb1.cssRgb : '0, 229, 255';

  mCtx.save();
  const planeGrad = mCtx.createLinearGradient(0, horizonY, 0, h);
  planeGrad.addColorStop(0, 'rgba(14, 22, 48, 0.06)');
  planeGrad.addColorStop(0.35, 'rgba(12, 20, 44, 0.18)');
  planeGrad.addColorStop(1, 'rgba(8, 14, 32, 0.36)');
  mCtx.fillStyle = planeGrad;
  mCtx.fillRect(0, horizonY, w, floorH);

  mCtx.beginPath();
  mCtx.rect(0, horizonY, w, floorH);
  mCtx.clip();

  mCtx.shadowColor = th.c1;
  mCtx.shadowBlur = 5;

  const horizCount = 14;
  const bottomStep = Math.max(34, (floorH / horizCount) * 1.5);
  const targetBottomCellWidth = bottomStep * 1.1;
  const numLines = Math.ceil((w * 1.4) / targetBottomCellWidth);

  mCtx.lineWidth = 1.0;
  mCtx.strokeStyle = `rgba(${c1Rgb}, 0.34)`;
  for (let i = -numLines; i <= numLines; i++) {
    const bottomX = vpX + (i + 0.5) * targetBottomCellWidth;
    const topX = vpX + (i + 0.5) * (targetBottomCellWidth * 0.32);
    mCtx.beginPath();
    mCtx.moveTo(topX, horizonY);
    mCtx.lineTo(bottomX, h);
    mCtx.stroke();
  }

  const roadTopHalfW = targetBottomCellWidth * 0.16;
  const roadBottomHalfW = targetBottomCellWidth * 0.50;

  mCtx.shadowBlur = 0;
  mCtx.fillStyle = 'rgba(12, 20, 44, 0.25)';
  mCtx.beginPath();
  mCtx.moveTo(vpX - roadTopHalfW, horizonY);
  mCtx.lineTo(vpX + roadTopHalfW, horizonY);
  mCtx.lineTo(vpX + roadBottomHalfW, h);
  mCtx.lineTo(vpX - roadBottomHalfW, h);
  mCtx.closePath();
  mCtx.fill();

  mCtx.lineWidth = 2.6;
  mCtx.strokeStyle = `rgba(${c1Rgb}, 0.24)`;
  mCtx.beginPath();
  mCtx.moveTo(vpX - roadTopHalfW, horizonY);
  mCtx.lineTo(vpX - roadBottomHalfW, h);
  mCtx.moveTo(vpX + roadTopHalfW, horizonY);
  mCtx.lineTo(vpX + roadBottomHalfW, h);
  mCtx.stroke();

  mCtx.restore();

  drawSynthWaveHorizonBeam(w, horizonY, mCtx);
  return { canvas: off, horizCount, targetBottomCellWidth, roadTopHalfW, roadBottomHalfW };
}

//  Synthwave background perspective grid scene renderer.
// [UI.JI]
function drawSynthWavePerspectiveScene(now) {
  const w = window.innerWidth;
  const h = window.innerHeight;
  const time = now / 1000;
  const horizonY = h * 0.44;
  const floorH = h - horizonY;
  const vpX = w * 0.5;
  const th = getTheme();
  const c1Rgb = th.rgb1 ? th.rgb1.cssRgb : '0, 229, 255';
  const c2Rgb = th.rgb2 ? th.rgb2.cssRgb : '217, 70, 239';
  const c4Rgb = th.rgb4 ? th.rgb4.cssRgb : '255, 145, 0';

  drawCosmicNebulaBackground(w, h);
  updateAndDrawStars(w, h, now);

  const dpr = getDpr();
  const isLowPerfFlag = (typeof perfMode !== 'undefined' && perfMode === 'low');
  const stageScale = isLowPerfFlag ? 1.25 : Math.min(3.0, Math.max(2.0, dpr));
  const palKey = typeof activePalette !== 'undefined' ? activePalette : 'default';
  const stageKey = Math.round(w) + 'x' + Math.round(h) + '@' + stageScale.toFixed(2) + '_' + (isLowPerfFlag ? 'low' : 'high') + '_' + palKey;

  if (!menuStageCache || menuStageCacheKey !== stageKey) {
    menuStageCache = renderMenuStageCache(w, h, horizonY, stageScale);
    menuStageCacheKey = stageKey;
  }

  ctx.save();
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(menuStageCache.canvas, 0, 0, w, h);

  ctx.beginPath();
  ctx.rect(0, horizonY, w, floorH);
  ctx.clip();

  const { horizCount, roadTopHalfW, roadBottomHalfW } = menuStageCache;
  const isDefaultTheme = (th.id === 'default');

  // Animated dashed road rails (no shadowBlur for 60+ FPS).
  ctx.save();
  ctx.setLineDash([12, 10]);
  ctx.lineDashOffset = (time * 36);
  ctx.lineWidth = 3.8;
  ctx.strokeStyle = `rgba(${c1Rgb}, 0.24)`;
  ctx.beginPath();
  ctx.moveTo(vpX - roadTopHalfW, horizonY);
  ctx.lineTo(vpX - roadBottomHalfW, h);
  ctx.moveTo(vpX + roadTopHalfW, horizonY);
  ctx.lineTo(vpX + roadBottomHalfW, h);
  ctx.stroke();

  ctx.lineWidth = 1.8;
  ctx.strokeStyle = th.c1Light;
  ctx.stroke();
  ctx.restore();

  const speed = 0.42;
  const cycle = (time * speed) % 1;
  const baseWave = Math.floor(time * speed);

  for (let j = 0; j < horizCount; j++) {
    const progress = (j + cycle) / horizCount;
    const currentY = horizonY + Math.pow(progress, 1.95) * floorH;
    const alpha = Math.min(0.42, 0.08 + progress * 0.35);

    const lineId = (baseWave - j) % 2;
    ctx.strokeStyle = (isDefaultTheme || lineId === 0)
      ? `rgba(${c1Rgb}, ${alpha})`
      : `rgba(${c2Rgb}, ${alpha})`;
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(0, currentY);
    ctx.lineTo(w, currentY);
    ctx.stroke();
  }

  const scoutColor = th.c4;
  const mobCycleDuration = 13.5;
  const mobLinearProgress = (time % mobCycleDuration) / mobCycleDuration;
  const u = 1 - mobLinearProgress;

  const mobY = horizonY + Math.pow(u, 1.95) * floorH;
  const mobScale = 0.2 + 0.8 * u;
  const scoutBaseR = 12 * mobScale;
  const mobFade = Math.min(1, Math.min(u / 0.15, (1 - u) / 0.12));

  ctx.save();
  ctx.translate(vpX, mobY);
  ctx.globalAlpha = Math.max(0, mobFade);
  ctx.rotate(-Math.PI / 2);

  const R = scoutBaseR * 1.25;
  ctx.beginPath();
  ctx.moveTo(R, 0);
  ctx.lineTo(-R * 0.5, R * 0.866);
  ctx.lineTo(-R * 0.5, -R * 0.866);
  ctx.closePath();

  ctx.strokeStyle = `rgba(${c4Rgb}, 0.30)`;
  ctx.lineWidth = 4.5 * mobScale;
  ctx.stroke();

  ctx.fillStyle = `rgba(${c4Rgb}, 0.34)`;
  ctx.strokeStyle = scoutColor;
  ctx.lineWidth = 1.8 * mobScale;
  ctx.fill();
  ctx.stroke();

  ctx.restore();
  ctx.restore();

  drawSynthWaveTriangleLogo5C(w, horizonY, time);
}

// [UI.JJ] Offscreen-кэш полноэкранного градиента для режимов Endless и Hardcore
let _modeOverlayCache = null;
let _modeOverlayKey = '';

function getModeOverlayCanvas(w, h, modeName) {
  const key = `${Math.round(w)}x${Math.round(h)}_${modeName}`;
  if (_modeOverlayCache && _modeOverlayKey === key) return _modeOverlayCache;

  const off = document.createElement('canvas');
  off.width = Math.max(1, Math.round(w));
  off.height = Math.max(1, Math.round(h));
  const mCtx = off.getContext('2d');

  const maxDim = Math.max(100, Math.max(w, h) * 0.75);
  const grad = mCtx.createRadialGradient(w * 0.5, h * 0.35, 10, w * 0.5, h * 0.45, maxDim);
  if (modeName === 'endless') {
    grad.addColorStop(0, 'rgba(110, 15, 140, 0.28)');
    grad.addColorStop(0.5, 'rgba(55, 8, 75, 0.18)');
    grad.addColorStop(1, 'rgba(4, 5, 14, 0.05)');
  } else {
    grad.addColorStop(0, 'rgba(120, 10, 60, 0.26)');
    grad.addColorStop(0.5, 'rgba(60, 5, 30, 0.16)');
    grad.addColorStop(1, 'rgba(4, 5, 14, 0.05)');
  }
  mCtx.fillStyle = grad;
  mCtx.fillRect(0, 0, off.width, off.height);

  _modeOverlayCache = off;
  _modeOverlayKey = key;
  return off;
}

// [UI.JKM] Offscreen-спрайт индикатора оглушения EMP над башней (3x разрешение)
let _empDisabledSprite = null;
function getEmpDisabledSprite() {
  if (_empDisabledSprite) return _empDisabledSprite;
  const texScale = 3.0;
  const logicalSize = 24;
  const half = logicalSize / 2;
  const off = document.createElement('canvas');
  off.width = logicalSize * texScale;
  off.height = logicalSize * texScale;
  const eCtx = off.getContext('2d');

  eCtx.scale(texScale, texScale);
  eCtx.translate(half, half);

  eCtx.fillStyle = '#0a0e1c';
  eCtx.beginPath();
  eCtx.arc(0, 0, 8, 0, Math.PI * 2);
  eCtx.fill();

  eCtx.strokeStyle = '#f05f9f';
  eCtx.lineWidth = 1.5;
  eCtx.stroke();

  eCtx.lineCap = 'round';
  eCtx.lineJoin = 'round';
  eCtx.beginPath();
  eCtx.moveTo(1, -4);
  eCtx.lineTo(-3, 1);
  eCtx.lineTo(0, 1);
  eCtx.lineTo(-1, 4);
  eCtx.lineTo(3, -1);
  eCtx.lineTo(0, -1);
  eCtx.closePath();
  eCtx.fillStyle = '#f05f9f';
  eCtx.fill();

  _empDisabledSprite = { canvas: off, half, size: logicalSize };
  return _empDisabledSprite;
}

// [UI.JL]
function renderCellRails(cell) {
  if (!cell.isTurn && cell.rails) {
    ctx.beginPath();
    ctx.moveTo(cell.rails[0].x1, cell.rails[0].y1);
    ctx.lineTo(cell.rails[0].x2, cell.rails[0].y2);
    ctx.moveTo(cell.rails[1].x1, cell.rails[1].y1);
    ctx.lineTo(cell.rails[1].x2, cell.rails[1].y2);
    ctx.stroke();
  } else if (cell.isTurn && cell.turnCurves) {
    cell.turnCurves.forEach(tc => {
      ctx.beginPath();
      ctx.moveTo(tc.startX, tc.startY);
      ctx.arcTo(tc.cornerX, tc.cornerY, tc.endX, tc.endY, tc.r);
      ctx.lineTo(tc.endX, tc.endY);
      ctx.stroke();
    });
  }
}

let battlePathAlpha = 1.0;
let lastPathTime = performance.now();
let battleStartedOnce = false;

//  Dynamic track flow and animated path rails pass.
// [UI.JM]
function drawPathRails(now) {
  if (!pathCells || pathCells.length <= 2) return;
  const totalCells = pathCells.length;
  const th = getTheme();
  const c1Rgb = th.rgb1 ? th.rgb1.cssRgb : '0, 229, 255';

  ctx.save();
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';

  ctx.strokeStyle = `rgba(${c1Rgb}, 0.18)`;
  ctx.lineWidth = 3.5;
  ctx.setLineDash([]);
  for (let i = 1; i < totalCells - 1; i++) {
    renderCellRails(pathCells[i]);
  }

  const curTime = (typeof now === 'number' && now > 0) ? now : performance.now();
  const dt = Math.min((curTime - (lastPathTime || curTime)) / 1000, 0.1);
  lastPathTime = curTime;

  const isBattleActive = (typeof waveInProgress !== 'undefined' && waveInProgress) || 
                         (typeof enemies !== 'undefined' && enemies.length > 0);

  if (isBattleActive) {
    battleStartedOnce = true;
  }

  if (battleStartedOnce || isBattleActive) {
    if (battlePathAlpha > 0) {
      battlePathAlpha = Math.max(0, battlePathAlpha - dt * 0.5);
    }
  } else {
    battlePathAlpha = 1.0;
  }

  if (battlePathAlpha > 0.005) {
    ctx.strokeStyle = `rgba(${c1Rgb}, ${0.90 * battlePathAlpha})`;
    ctx.lineWidth = 1.8;
    ctx.setLineDash([12, 10]);
    ctx.lineDashOffset = -((curTime / 1000) * 36);

    for (let i = 1; i < totalCells - 1; i++) {
      renderCellRails(pathCells[i]);
    }
  }

  ctx.restore();
}

// [UI.JP] Tower Beautification Renderer V8 (3x Retina Offscreen Base Cache + Zero-Blur Dynamic Turrets)
const TOWER_DARK = '#0a0e1c';

const TOWER_CORES_BY_LEVEL = {
  1: [{ cx: 0, cy: 0, r: 3.2 }],
  2: [{ cx: 0, cy: -4.2, r: 3 }, { cx: 0, cy: 4.2, r: 3 }],
  3: [{ cx: -3.4, cy: -4.2, r: 3 }, { cx: -3.4, cy: 4.2, r: 3 }, { cx: 4.2, cy: 0, r: 3 }]
};

const TOWER_VISUAL_CFG = {
  hullShape: 'round',       // Круглые основания башен
  roundRingStyle: 'solid',  // Ровное сплошное 3-е кольцо на Lv.3
  wideLegs: true,           // 4 широкие опоры (ноги) с эволюцией Lv.1 -> Lv.2 -> Lv.3
  whiteNeonRim: true,       // Белый неоновый контур с цветным свечением
  outrunStripes: true,      // Outrun-полосы внутри корпуса
  outerEvolution: true,     // Внешние кольца эволюции Lv.2 и Lv.3
  powerCellsGlow: true,     // Яркие энерго-ячейки с белым центром
  laserSight: true,         // Пунктирный лазерный целеуказатель на цель
  recoil: false,
  glowIntensity: 2.2
};

const TOWER_BASE_SPRITE_CACHE = Object.create(null);

// [UI.JPA]
function traceTowerPolygon(c, sides, r, rot = 0) {
  c.beginPath();
  for (let i = 0; i < sides; i++) {
    const a = rot + (i * Math.PI * 2) / sides;
    const px = Math.cos(a) * r;
    const py = Math.sin(a) * r;
    if (i === 0) c.moveTo(px, py);
    else c.lineTo(px, py);
  }
  c.closePath();
}

// [UI.JPB]
function traceTowerHullShape(c, lvl, r, cfg = TOWER_VISUAL_CFG) {
  if (cfg.hullShape === 'poly6816') {
    const sides = (lvl === 1) ? 6 : 8;
    const baseRot = (sides === 8) ? Math.PI / 8 : 0;
    traceTowerPolygon(c, sides, r * 1.04, baseRot);
  } else {
    c.beginPath();
    c.arc(0, 0, r, 0, Math.PI * 2);
  }
}

// [UI.JPC] Ступенчатая эволюция 4 широких опор (ног) Lv.1 -> Lv.2 -> Lv.3 (рисуется в кэш-спрайт)
function drawTowerWideLegsToCtx(c, lvl, col, glow, glowMult, isDisabled) {
  c.save();
  for (let i = 0; i < 4; i++) {
    c.save();
    c.rotate(Math.PI / 4 + i * (Math.PI / 2));

    // 1. Внутренняя секция ноги (Lv.1, Lv.2, Lv.3)
    c.beginPath();
    c.moveTo(13.0, -5.6);
    c.lineTo(20.2, -4.6);
    c.lineTo(20.2, 4.6);
    c.lineTo(13.0, 5.6);
    c.closePath();

    if (lvl === 1 || isDisabled) {
      c.shadowBlur = 0;
      c.fillStyle = col;
      c.globalAlpha = 0.35;
      c.fill();
      c.globalAlpha = 0.85;
      c.strokeStyle = col;
      c.lineWidth = 1.4;
      c.stroke();
    } else if (lvl === 2) {
      c.shadowBlur = 0;
      c.fillStyle = '#080d1e';
      c.globalAlpha = 1;
      c.fill();
      c.strokeStyle = col;
      c.globalAlpha = 0.82;
      c.lineWidth = 1.45;
      c.stroke();
      c.fillStyle = col;
      c.globalAlpha = 0.55;
      c.fillRect(15.2, -2.3, 3.8, 4.6);
    } else {
      c.fillStyle = '#070b19';
      c.shadowColor = glow;
      c.shadowBlur = 9 * glowMult;
      c.globalAlpha = 1;
      c.fill();
      c.strokeStyle = '#ffffff';
      c.lineWidth = 1.65;
      c.stroke();
      c.shadowBlur = 0;
      c.fillStyle = col;
      c.fillRect(15.2, -2.4, 3.8, 4.8);
    }

    // 2. Внешняя секция ноги (Lv.2 без неона, Lv.3 с ярким неоном)
    if (lvl >= 2) {
      c.beginPath();
      c.moveTo(20.2, -4.3);
      c.lineTo(25.2, -3.1);
      c.lineTo(26.4, -1.8);
      c.lineTo(26.4, 1.8);
      c.lineTo(25.2, 3.1);
      c.lineTo(20.2, 4.3);
      c.closePath();

      if (lvl === 2 || isDisabled) {
        c.shadowBlur = 0;
        c.fillStyle = col;
        c.globalAlpha = 0.30;
        c.fill();
        c.strokeStyle = col;
        c.globalAlpha = 0.85;
        c.lineWidth = 1.45;
        c.stroke();
      } else {
        c.fillStyle = col;
        c.shadowColor = glow;
        c.shadowBlur = 11 * glowMult;
        c.globalAlpha = 0.85;
        c.fill();
        c.strokeStyle = '#ffffff';
        c.globalAlpha = 1;
        c.lineWidth = 1.65;
        c.stroke();
        c.shadowBlur = 0;
      }
    }

    c.restore();
  }
  c.restore();
}

// [UI.JPD] Offscreen-кэш статичного корпуса башни в 3x разрешении (без размытия при зуме!)
function getTowerBaseSprite(lvl, col, glowCol, isDisabled, isLowPerf, isFarZoom = false) {
  const cfg = TOWER_VISUAL_CFG;
  const key = `${cfg.hullShape}_${lvl}_${col}_${glowCol}_${isDisabled ? 1 : 0}_${isLowPerf ? 1 : 0}_${isFarZoom ? 1 : 0}`;
  if (TOWER_BASE_SPRITE_CACHE[key]) return TOWER_BASE_SPRITE_CACHE[key];

  const texScale = isLowPerf ? 1.5 : 3.0;
  const logicalSize = 96;
  const half = logicalSize / 2;
  const off = document.createElement('canvas');
  off.width = Math.round(logicalSize * texScale);
  off.height = Math.round(logicalSize * texScale);
  const c = off.getContext('2d');

  const glowMult = (isLowPerf || isDisabled) ? 0.4 : (cfg.glowIntensity || 2.2);
  const lvlHaloScale = lvl === 1 ? 0.45 : (lvl === 2 ? 0.72 : 1.0);

  c.save();
  c.scale(texScale, texScale);
  c.translate(half, half);
  c.lineJoin = 'round';
  c.lineCap = 'round';

  // 1. Внешнее неоновое гало
  if (!isDisabled) {
    const haloR = (27 + lvl * 3.8) * Math.min(1.45, Math.max(0.7, glowMult * 0.62));
    const radGrad = c.createRadialGradient(0, 0, 5, 0, 0, haloR);
    radGrad.addColorStop(0, glowCol + (lvl === 3 ? '44' : (lvl === 2 ? '28' : '18')));
    radGrad.addColorStop(0.6, glowCol + (lvl === 3 ? '18' : '08'));
    radGrad.addColorStop(1, 'transparent');
    c.fillStyle = radGrad;
    c.beginPath();
    c.arc(0, 0, haloR, 0, Math.PI * 2);
    c.fill();
  }

  // 2. 4 широкие опоры (ноги)
  if (cfg.wideLegs) {
    drawTowerWideLegsToCtx(c, lvl, col, glowCol, glowMult * lvlHaloScale, isDisabled);
  }

  // 3. Внешние кольца эволюции Lv.2 и Lv.3
  if (cfg.outerEvolution) {
    if (lvl >= 2) {
      c.save();
      c.shadowBlur = 0;
      c.strokeStyle = col;
      c.globalAlpha = 0.68;
      c.lineWidth = 1.7;
      c.beginPath();
      c.arc(0, 0, 21.5, 0, Math.PI * 2);
      c.stroke();
      c.restore();
    }
    if (lvl >= 3) {
      c.save();
      if (!isDisabled) {
        c.shadowColor = glowCol;
        c.shadowBlur = 11 * glowMult;
      }
      c.globalAlpha = 0.96;

      c.strokeStyle = col;
      c.lineWidth = isFarZoom ? 3.25 : 3.0;
      c.beginPath();
      c.arc(0, 0, 26.0, 0, Math.PI * 2);
      c.stroke();

      c.shadowBlur = 0;
      c.strokeStyle = isDisabled ? '#64748b' : '#ffffff';
      if (isFarZoom) c.globalAlpha = 0.46;
      c.lineWidth = isFarZoom ? 0.78 : 1.08;
      c.beginPath();
      c.arc(0, 0, 26.0, 0, Math.PI * 2);
      c.stroke();
      c.restore();
    }
  }

  // 4. Главный круглый корпус + белый неоновый обод
  c.save();
  c.fillStyle = TOWER_DARK;
  traceTowerHullShape(c, lvl, 16.8, cfg);
  c.fill();

  if (cfg.whiteNeonRim) {
    c.strokeStyle = col;
    if (!isDisabled) {
      c.shadowColor = glowCol;
      c.shadowBlur = (lvl === 3 ? 13 : (lvl === 2 ? 7 : 3)) * glowMult * 0.65;
    }
    c.lineWidth = isFarZoom ? 3.25 : 3.0;
    c.stroke();

    c.strokeStyle = isDisabled ? '#64748b' : '#ffffff';
    if (!isDisabled && !isFarZoom) {
      c.shadowColor = '#ffffff';
      c.shadowBlur = (lvl === 3 ? 4 : 1.5) * glowMult * 0.5;
    } else {
      c.shadowBlur = 0;
    }
    if (isFarZoom) c.globalAlpha = 0.46;
    c.lineWidth = isFarZoom ? 0.78 : 1.08;
    c.stroke();
  } else {
    c.strokeStyle = col;
    c.lineWidth = 2.0;
    c.stroke();
  }
  c.restore();

  // 5. Outrun-полосы внутри корпуса (запекаются 1 раз в текстуру, без clip() в бою!)
  if (cfg.outrunStripes) {
    c.save();
    traceTowerHullShape(c, lvl, 15.2, cfg);
    c.clip();
    c.strokeStyle = col;
    c.globalAlpha = isFarZoom ? 0.24 : 0.44;
    c.lineWidth = 1.35;
    c.beginPath();
    for (let sy = -14; sy <= 14; sy += 3.8) {
      c.moveTo(-16, sy);
      c.lineTo(16, sy);
    }
    c.stroke();
    c.restore();
  }

  c.restore();

  const sprite = { canvas: off, half, size: logicalSize };
  TOWER_BASE_SPRITE_CACHE[key] = sprite;
  return sprite;
}

// [UI.JPE] Единая снежинка Stasis (Zero-Blur двойной штрих)
function drawStasisSnowflake(c, lvl, time, col, isDisabled) {
  c.save();
  if (!isDisabled) c.rotate(time * 0.42);
  c.lineCap = 'round';
  c.lineJoin = 'round';

  const mainR = lvl === 1 ? 10.2 : (lvl === 2 ? 11.4 : 12.6);

  if (!isDisabled) {
    c.strokeStyle = col;
    c.globalAlpha = lvl === 3 ? 0.45 : 0.28;
    c.lineWidth = (lvl === 1 ? 1.65 : 1.85) + 2.2;
    c.beginPath();
    for (let i = 0; i < 6; i++) {
      const a = (i * Math.PI) / 3;
      c.moveTo(0, 0);
      c.lineTo(Math.cos(a) * mainR, Math.sin(a) * mainR);
    }
    c.stroke();
    c.globalAlpha = 1;
  }

  c.strokeStyle = isDisabled ? '#64748b' : '#ffffff';
  c.lineWidth = lvl === 1 ? 1.65 : 1.85;

  for (let i = 0; i < 6; i++) {
    c.save();
    c.rotate((i * Math.PI) / 3);

    c.beginPath();
    c.moveTo(0, 0);
    c.lineTo(mainR, 0);
    c.stroke();

    const tipBranchPos = mainR * 0.62;
    const tipBranchLen = lvl === 1 ? 3.5 : 4.2;
    c.beginPath();
    c.moveTo(tipBranchPos + tipBranchLen * 0.68, -tipBranchLen * 0.75);
    c.lineTo(tipBranchPos, 0);
    c.lineTo(tipBranchPos + tipBranchLen * 0.68, tipBranchLen * 0.75);
    c.stroke();

    if (lvl >= 2) {
      const midBranchPos = mainR * 0.36;
      const midBranchLen = 3.0;
      c.beginPath();
      c.moveTo(midBranchPos + midBranchLen * 0.65, -midBranchLen * 0.72);
      c.lineTo(midBranchPos, 0);
      c.lineTo(midBranchPos + midBranchLen * 0.65, midBranchLen * 0.72);
      c.stroke();
    }

    if (lvl >= 3) {
      c.fillStyle = isDisabled ? '#64748b' : '#ffffff';
      c.beginPath();
      c.arc(mainR + 1.1, 0, 1.25, 0, Math.PI * 2);
      c.fill();
    }

    c.restore();
  }

  if (lvl >= 2) {
    c.strokeStyle = col;
    c.lineWidth = 1.25;
    traceTowerPolygon(c, 6, mainR * 0.44, Math.PI / 6);
    c.stroke();
  }

  if (lvl >= 3) {
    c.save();
    if (!isDisabled) c.rotate(-time * 0.8 + Math.PI / 6);
    c.strokeStyle = col;
    c.lineWidth = 1.35;
    for (let i = 0; i < 6; i++) {
      c.save();
      c.rotate((i * Math.PI) / 3);
      c.beginPath();
      c.moveTo(3.2, 0);
      c.lineTo(8.4, 0);
      c.moveTo(6.2 + 1.8, -2.0);
      c.lineTo(6.2, 0);
      c.lineTo(6.2 + 1.8, 2.0);
      c.stroke();
      c.restore();
    }
    c.restore();
  }

  c.fillStyle = col;
  traceTowerPolygon(c, 6, 3.0, 0);
  c.fill();
  c.fillStyle = isDisabled ? '#64748b' : '#ffffff';
  c.beginPath();
  c.arc(0, 0, 1.4, 0, Math.PI * 2);
  c.fill();

  c.restore();
}

// [UI.JPF] Круговой прогресс-бар перегрева Melter (Zero-Blur)
function drawMelterOverheatGauge(c, heat, time, col, isCooling) {
  const clamped = Math.max(0, Math.min(1, heat));
  const gaugeR = 13.8;

  c.save();
  c.rotate(-Math.PI / 2);

  c.strokeStyle = 'rgba(15, 23, 42, 0.88)';
  c.lineWidth = 3.4;
  c.beginPath();
  c.arc(0, 0, gaugeR, 0, Math.PI * 2);
  c.stroke();

  c.strokeStyle = 'rgba(232, 82, 104, 0.28)';
  c.lineWidth = 1;
  c.setLineDash([2, 4.2]);
  c.beginPath();
  c.arc(0, 0, gaugeR, 0, Math.PI * 2);
  c.stroke();
  c.setLineDash([]);

  if (clamped > 0.01) {
    const isMaxHeat = clamped > 0.88 || isCooling;
    const arcCol = isMaxHeat
      ? (Math.sin(time * 30) > 0 ? '#ffffff' : '#fde047')
      : (clamped > 0.45 ? '#fb923c' : col);

    c.lineCap = 'round';
    c.strokeStyle = arcCol;
    c.globalAlpha = 0.35;
    c.lineWidth = 6.2;
    c.beginPath();
    c.arc(0, 0, gaugeR, 0, Math.PI * 2 * clamped);
    c.stroke();

    c.globalAlpha = 1;
    c.lineWidth = 3.2;
    c.beginPath();
    c.arc(0, 0, gaugeR, 0, Math.PI * 2 * clamped);
    c.stroke();

    const tipAngle = Math.PI * 2 * clamped;
    c.fillStyle = '#ffffff';
    c.beginPath();
    c.arc(Math.cos(tipAngle) * gaugeR, Math.sin(tipAngle) * gaugeR, 2.0, 0, Math.PI * 2);
    c.fill();
  }

  c.restore();
}

// [UI.JPG] Главная функция отрисовки башни
function drawTowerModel(type, angle, color, level = 1, glow = '#00e5ff', isDisabled = false, isCooling = false, isShooting = false, heatProgress = 0, extra = null) {
  const cfg = TOWER_VISUAL_CFG;
  const id = type || 'gun';
  const baseCol = color || '#00e5ff';
  const col = isDisabled ? '#475569' : baseCol;
  const glowCol = isDisabled ? '#64748b' : (glow || baseCol);
  const lvl = Math.max(1, Math.min(3, level || 1));

  const time = (extra && typeof extra.time === 'number') ? extra.time : (performance.now() * 0.001);
  const target = extra ? extra.target : null;
  const towerX = extra ? extra.x : 0;
  const towerY = extra ? extra.y : 0;
  const isFiring = !!(isShooting || (target && !isDisabled && !isCooling));
  const recoil = (cfg.recoil && extra && extra.recoil) ? extra.recoil : 0;
  const heat = Math.max(0, Math.min(1, heatProgress || 0));
  const isLowPerf = (typeof perfMode !== 'undefined' && perfMode === 'low');
  const isFarZoom = (typeof camZoom === 'number' && camZoom > 0 && camZoom < 0.65);

  ctx.save();
  if (isDisabled) ctx.globalAlpha = 0.55;
  ctx.lineJoin = 'round';
  ctx.lineCap = 'round';

  // 1. Статичный корпус башни (3x Retina Offscreen-кэш с LOD по зуму)
  const baseSprite = getTowerBaseSprite(lvl, col, glowCol, isDisabled, isLowPerf, isFarZoom);
  ctx.drawImage(baseSprite.canvas, -baseSprite.half, -baseSprite.half, baseSprite.size, baseSprite.size);

  // 2. Круговой прогресс-бар перегрева Melter
  if (id === 'melter' && (heat > 0 || isCooling)) {
    drawMelterOverheatGauge(ctx, heat, time, col, isCooling);
  }

  // 3. Поворотная башня, прицел, стволы и ядро
  const effAngle = (id === 'stasis') ? 0 : (angle || 0);
  ctx.save();
  ctx.rotate(effAngle);

  // Лазерный целеуказатель на захваченную цель
  if (cfg.laserSight && id !== 'stasis' && target && !isDisabled && !isCooling) {
    const dist = Math.hypot(target.x - towerX, target.y - towerY);
    const sightEnd = Math.max(26, dist);
    ctx.save();
    ctx.strokeStyle = col;
    ctx.globalAlpha = 0.65;
    ctx.lineWidth = 1.3;
    ctx.setLineDash([5, 4]);
    ctx.lineDashOffset = -time * 24;
    ctx.beginPath();
    ctx.moveTo(22, 0);
    ctx.lineTo(sightEnd, 0);
    ctx.stroke();
    ctx.setLineDash([]);

    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(sightEnd, 0, 1.8, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  const recShift = -recoil * 4.0;

  if (id === 'gun') {
    const sinceShot = (extra && typeof extra.lastFire === 'number') ? extra.lastFire : 999;
    const shotIdx = (extra && typeof extra.shotIndex === 'number') ? extra.shotIndex : 0;
    const kickT = (sinceShot >= 0 && sinceShot < 0.16) ? (1 - sinceShot / 0.16) : 0;
    const kickOffset = -(kickT * kickT) * 3.4;

    const topShift = (shotIdx === 0) ? kickOffset : 0;
    const botShift = (shotIdx === 1) ? kickOffset : 0;

    ctx.fillStyle = TOWER_DARK;
    ctx.strokeStyle = col;
    ctx.lineWidth = 1.4;
    ctx.fillRect(7, -6.2, 8.5, 12.4);
    ctx.strokeRect(7, -6.2, 8.5, 12.4);

    ctx.fillStyle = col;
    ctx.fillRect(11.5 + recShift + topShift, -5.0, 14 + lvl * 1.1, 2.7);
    ctx.fillRect(11.5 + recShift + botShift, 2.3, 14 + lvl * 1.1, 2.7);
    ctx.fillStyle = isDisabled ? '#64748b' : '#ffffff';
    ctx.fillRect(23.5 + recShift + topShift, -4.6, 2.4, 1.9);
    ctx.fillRect(23.5 + recShift + botShift, 2.7, 2.4, 1.9);
  } else if (id === 'laser') {
    ctx.fillStyle = TOWER_DARK;
    ctx.strokeStyle = col;
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(8, -6.5);
    ctx.lineTo(24 + lvl, -2.0);
    ctx.lineTo(24 + lvl, 2.0);
    ctx.lineTo(8, 6.5);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    ctx.strokeStyle = isDisabled ? '#64748b' : '#ffffff';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(10, 0);
    ctx.lineTo(23 + lvl, 0);
    ctx.stroke();

    ctx.fillStyle = (isFiring && !isDisabled) ? '#ffffff' : col;
    ctx.beginPath();
    ctx.arc(24 + lvl, 0, isFiring ? 3.0 : 2.1, 0, Math.PI * 2);
    ctx.fill();
  } else if (id === 'mortar' || id === 'splash') {
    const fore = Math.cos(55 * Math.PI / 180);
    ctx.save();
    ctx.scale(fore, 1);
    ctx.fillStyle = TOWER_DARK;
    ctx.strokeStyle = col;
    ctx.lineWidth = 2;
    ctx.beginPath();
    if (typeof ctx.roundRect === 'function') {
      ctx.roundRect(7 + recShift * 1.4, -7.2, 16 + lvl, 14.4, 3);
    } else {
      ctx.rect(7 + recShift * 1.4, -7.2, 16 + lvl, 14.4);
    }
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = col;
    ctx.fillRect(11 + recShift * 1.4, -5.2, 9 + lvl, 10.4);
    ctx.restore();

    const mx = (23 + lvl + recShift * 1.4) * fore;
    ctx.beginPath();
    ctx.ellipse(mx, 0, 3.2, 5.5, 0, 0, Math.PI * 2);
    ctx.fillStyle = (isFiring && !isDisabled) ? '#ffffff' : TOWER_DARK;
    ctx.fill();
    ctx.strokeStyle = col;
    ctx.lineWidth = 1.8;
    ctx.stroke();
  } else if (id === 'tesla') {
    const bStart = 8.5 + recShift * 0.7;
    ctx.fillStyle = TOWER_DARK;
    ctx.strokeStyle = col;
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(bStart, -6.8);
    ctx.lineTo(bStart + 14.0, -5.8);
    ctx.lineTo(bStart + 16.0, -3.6);
    ctx.lineTo(bStart + 16.0, 3.6);
    ctx.lineTo(bStart + 14.0, 5.8);
    ctx.lineTo(bStart, 6.8);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    ctx.strokeStyle = isDisabled ? 'rgba(100, 116, 139, 0.45)' : 'rgba(255, 255, 255, 0.55)';
    ctx.lineWidth = 0.95;
    ctx.beginPath();
    ctx.moveTo(bStart + 2.0, -4.4);
    ctx.lineTo(bStart + 13.0, -3.8);
    ctx.moveTo(bStart + 2.0, 4.4);
    ctx.lineTo(bStart + 13.0, 3.8);
    ctx.stroke();

    ctx.save();
    ctx.translate(bStart + 8.3, 0);
    ctx.rotate(Math.PI / 2);
    ctx.scale(0.56, 0.56);
    ctx.fillStyle = isDisabled ? '#64748b' : '#ffffff';
    ctx.strokeStyle = col;
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    const boltPts = [2.5, -11, -6.0, 1.2, -0.4, 1.2, -3.2, 11, 6.5, -2.2, 0.8, -2.2];
    ctx.moveTo(boltPts[0], boltPts[1]);
    for (let i = 2; i < boltPts.length; i += 2) ctx.lineTo(boltPts[i], boltPts[i + 1]);
    ctx.closePath();
    ctx.stroke();
    ctx.fill();
    ctx.restore();
  } else if (id === 'melter') {
    const hotCol = isDisabled ? '#475569' : (heat > 0.75 ? '#ffffff' : (heat > 0.32 ? '#fb923c' : col));
    const innerPipeCol = isDisabled ? '#64748b' : (heat > 0.55 ? '#ffffff' : '#fb923c');

    ctx.strokeStyle = col;
    ctx.lineWidth = 2.6;
    ctx.beginPath();
    ctx.moveTo(9.0, -5.2);
    ctx.lineTo(20.5, -2.2);
    ctx.moveTo(9.0, 5.2);
    ctx.lineTo(20.5, 2.2);
    ctx.stroke();

    ctx.strokeStyle = innerPipeCol;
    ctx.lineWidth = 1.15;
    ctx.beginPath();
    ctx.moveTo(10.5, -4.8);
    ctx.lineTo(19.8, -2.4);
    ctx.moveTo(10.5, 4.8);
    ctx.lineTo(19.8, 2.4);
    ctx.stroke();

    ctx.fillStyle = TOWER_DARK;
    ctx.strokeStyle = isDisabled ? '#64748b' : '#ffffff';
    ctx.lineWidth = 1.3;
    ctx.beginPath();
    if (typeof ctx.roundRect === 'function') {
      ctx.roundRect(19.0, -4.5, 3.6, 9.0, 1.2);
    } else {
      ctx.rect(19.0, -4.5, 3.6, 9.0);
    }
    ctx.fill();
    ctx.stroke();

    if (!isCooling && !isDisabled) {
      const flameTip = 27.5 + heat * 2.5 + (isFiring ? Math.sin(time * 35) * 0.8 : 0);
      ctx.fillStyle = hotCol;
      ctx.beginPath();
      ctx.moveTo(22.6, -2.5);
      ctx.lineTo(flameTip, 0);
      ctx.lineTo(22.6, 2.5);
      ctx.closePath();
      ctx.fill();
    }
  } else if (id === 'railgun') {
    const railLen = 13.5 + lvl * 0.8;
    const rStart = 8.5 + recShift * 0.85;

    ctx.fillStyle = (isFiring && !isDisabled) ? '#ffffff' : col;
    ctx.globalAlpha = (isFiring && !isDisabled) ? 0.95 : 0.45;
    ctx.fillRect(rStart + 1.5, -1.3, railLen - 2.0, 2.6);
    ctx.globalAlpha = 1;

    ctx.fillStyle = TOWER_DARK;
    ctx.strokeStyle = col;
    ctx.lineWidth = 1.45;

    ctx.beginPath();
    ctx.moveTo(rStart, -4.4);
    ctx.lineTo(rStart + railLen, -3.6);
    ctx.lineTo(rStart + railLen - 2.0, -1.8);
    ctx.lineTo(rStart, -1.8);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(rStart, 4.4);
    ctx.lineTo(rStart + railLen, 3.6);
    ctx.lineTo(rStart + railLen - 2.0, 1.8);
    ctx.lineTo(rStart, 1.8);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = isDisabled ? '#64748b' : '#ffffff';
    ctx.fillRect(rStart + 2.2, -5.0, 2.2, 10.0);
  }

  // 4. Индикаторы в центре ядра
  if (id === 'stasis') {
    drawStasisSnowflake(ctx, lvl, time, col, isDisabled);
  } else {
    const cells = TOWER_CORES_BY_LEVEL[lvl];
    for (let i = 0; i < cells.length; i++) {
      const d = cells[i];
      const coreCol = (!isDisabled && id === 'melter' && heat > 0.65) ? '#ffffff' : col;
      ctx.fillStyle = coreCol;
      ctx.beginPath();
      ctx.arc(d.cx, d.cy, d.r + (cfg.powerCellsGlow ? 0.6 : 0), 0, Math.PI * 2);
      ctx.fill();
      if (cfg.powerCellsGlow && !isDisabled) {
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(d.cx, d.cy, d.r * (isFarZoom ? 0.28 : 0.36), 0, Math.PI * 2);
        ctx.fill();
      }
    }
  }

  ctx.restore();
  ctx.restore();
}

// Enemy model vector graphics and health bar renderer.
// [UI.JQ]
function drawEnemyModel(e, showHpBar = true) {
  if (typeof renderConfiguredEnemyModel === 'function') {
    renderConfiguredEnemyModel(e, showHpBar);
    return;
  }
}

//  Jagged lightning path generator and beam renderer.
// [UI.JR]
function drawJaggedLightning(x1, y1, x2, y3, color, alpha, progress = 1.0) {
  const fullDist = Math.hypot(x2 - x1, y3 - y1);
  if (fullDist <= 0 || progress <= 0) return;

  const currentDist = fullDist * Math.min(1.0, progress);
  const dirX = (x2 - x1) / fullDist;
  const dirY = (y3 - y1) / fullDist;
  const endX = x1 + dirX * currentDist;
  const endY = y1 + dirY * currentDist;

  const segments = Math.max(5, Math.floor(currentDist / 12));
  const normalX = -dirY;
  const normalY = dirX;

  const points = [{ x: x1, y: y1 }];
  const dx = (endX - x1) / segments;
  const dy = (endY - y1) / segments;

  for (let s = 1; s < segments; s++) {
    const jitter = (Math.random() - 0.5) * 22;
    points.push({
      x: x1 + dx * s + normalX * jitter,
      y: y1 + dy * s + normalY * jitter
    });
  }
  points.push({ x: endX, y: endY });

  const safeAlpha = Math.max(0, Math.min(1, alpha));
  const zapCol = color || '#00ffcc';

  ctx.save();
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  ctx.globalCompositeOperation = 'lighter';

  ctx.beginPath();
  ctx.moveTo(points[0].x, points[0].y);
  for (let i = 1; i < points.length; i++) {
    ctx.lineTo(points[i].x, points[i].y);
  }

  // 1. Внешний мягкий неоновый ореол (Zero-Blur)
  if (perfMode !== 'low') {
    ctx.strokeStyle = zapCol;
    ctx.globalAlpha = safeAlpha * 0.28;
    ctx.lineWidth = 9.0;
    ctx.stroke();
  }

  // 2. Основной цветной разряд
  ctx.strokeStyle = zapCol;
  ctx.globalAlpha = safeAlpha * 0.85;
  ctx.lineWidth = 4.2;
  ctx.stroke();

  // 3. Яркий белый сердечник молнии
  ctx.strokeStyle = '#ffffff';
  ctx.globalAlpha = safeAlpha;
  ctx.lineWidth = 1.8;
  ctx.stroke();

  // 4. Ответвления дуги
  if (points.length >= 4 && perfMode !== 'low') {
    ctx.lineWidth = 1.2;
    ctx.strokeStyle = zapCol;
    ctx.globalAlpha = safeAlpha * 0.75;
    const numForks = Math.min(3, Math.floor(points.length / 3));
    ctx.beginPath();
    for (let f = 0; f < numForks; f++) {
      const idx = 1 + Math.floor(Math.random() * (points.length - 2));
      const pt = points[idx];
      const forkAngle = Math.atan2(dirY, dirX) + (Math.random() > 0.5 ? 1 : -1) * (0.6 + Math.random() * 0.7);
      const forkLen = 8 + Math.random() * 14;
      const forkMidX = pt.x + Math.cos(forkAngle) * (forkLen * 0.5) + (Math.random() - 0.5) * 6;
      const forkMidY = pt.y + Math.sin(forkAngle) * (forkLen * 0.5) + (Math.random() - 0.5) * 6;
      const forkEndX = pt.x + Math.cos(forkAngle) * forkLen;
      const forkEndY = pt.y + Math.sin(forkAngle) * forkLen;
      ctx.moveTo(pt.x, pt.y);
      ctx.lineTo(forkMidX, forkMidY);
      ctx.lineTo(forkEndX, forkEndY);
    }
    ctx.stroke();
  }

  ctx.restore();
}
//  Master gameplay canvas graphics rendering pipeline.
let reviveStartTime = 0;

// [UI.JS]
function render(now) {
  const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);

  if (gameState === 'DEFEAT' && reviveTimerInterval) {
    const progressEl = document.getElementById('reviveTimerProgress');
    if (progressEl) {
      if (reviveStartTime === 0) reviveStartTime = now;
      const elapsed = (now - reviveStartTime) / 1000;
      const fraction = Math.max(0, 1 - (elapsed / 3));
      const totalDash = 276.46;
      progressEl.style.strokeDashoffset = (totalDash * (1 - fraction)).toFixed(2);
    }
  } else {
    reviveStartTime = 0;
  }

  if (isMenuSceneActive()) {
    const _lvlSc = document.getElementById('levelsScreen');
    const _isLevelsVisible = (_lvlSc && !_lvlSc.classList.contains('hidden') && !_lvlSc.classList.contains('screen-bg-only') && gameState === 'LEVELS');
    if (_isLevelsVisible && !ModeBattlePreview.isActive()) {
      startModeBattlePreview(typeof currentLevelMode !== 'undefined' ? currentLevelMode : 'normal');
    } else if (!_isLevelsVisible && ModeBattlePreview.isActive()) {
      stopNormalModePreview();
    }
    if (!ModeBattlePreview.isActive()) {
      clearFxLayerState();
    }
    _lastFxRenderNow = now;
    drawSynthWavePerspectiveScene(now);
    return;
  } else if (ModeBattlePreview.isActive()) {
    stopNormalModePreview();
  }

  let fxDt = _lastFxRenderNow > 0 ? (now - _lastFxRenderNow) * 0.001 : 0.016;
  _lastFxRenderNow = now;
  if (fxDt < 0 || fxDt > 0.05) fxDt = 0.016;
  if (typeof gameState !== 'undefined' && gameState !== 'PLAYING') fxDt = 0;
  else if (typeof isSimulationPaused !== 'undefined' && isSimulationPaused) fxDt = 0;
  else if (typeof gameTimeScale !== 'undefined' && gameTimeScale > 0) fxDt *= gameTimeScale;

  const w = window.innerWidth;
  const h = window.innerHeight;
  drawCosmicNebulaBackground(w, h);
  updateAndDrawStars(w, h, now);

  if (typeof isEndlessMode !== 'undefined' && isEndlessMode) {
    ctx.drawImage(getModeOverlayCanvas(w, h, 'endless'), 0, 0, w, h);
  } else if (typeof isOverdriveMode !== 'undefined' && isOverdriveMode) {
    ctx.drawImage(getModeOverlayCanvas(w, h, 'overdrive'), 0, 0, w, h);
  }

  let shakeX = 0;
  let shakeY = 0;

  if (typeof cameraShakeTimer !== 'undefined' && cameraShakeTimer > 0) {
    const maxDur = (typeof cameraShakeMaxDur !== 'undefined' && cameraShakeMaxDur > 0) ? cameraShakeMaxDur : 0.35;
    const decay = Math.max(0, Math.min(1, cameraShakeTimer / maxDur));
    const currentAmp = cameraShakeIntensity * decay;
    shakeX = (Math.random() - 0.5) * currentAmp;
    shakeY = (Math.random() - 0.5) * currentAmp;
  }

  const isHyperion = (typeof activePalette !== 'undefined' && activePalette === 'matrix_green');

  ctx.save();
  ctx.translate(camX + shakeX, camY + shakeY);
  ctx.scale(camZoom, camZoom);

  if (offscreenGridDirty || !offscreenGridCanvas) {
    updateOffscreenGrid();
  }
  ctx.drawImage(offscreenGridCanvas, 0, 0);

  drawPathRails(now);

  towers.forEach(t => {
    if (t.type === 'stasis') {
      ctx.save();
      ctx.fillStyle = isHyperion ? 'rgba(96, 165, 250, 0.08)' : 'rgba(56, 189, 248, 0.07)';
      ctx.strokeStyle = isHyperion ? 'rgba(96, 165, 250, 0.28)' : 'rgba(56, 189, 248, 0.22)';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.arc(t.x, t.y, t.range, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    }
  });

  enemies.forEach(e => {
    if (e.type === 'emp_bomber' || e.type === 'emp_overlord') {
      const effectRadius = e.type === 'emp_overlord' ? 180 : 110;
      ctx.save();
      ctx.fillStyle = 'rgba(240, 95, 159, 0.07)';
      ctx.strokeStyle = 'rgba(240, 95, 159, 0.22)';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.arc(e.x, e.y, effectRadius, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    }
  });

  if (selectedTower) {
    const thSel = getTheme();
    const selMainRgb = isHyperion ? '255, 145, 0' : (thSel.rgb1 ? thSel.rgb1.cssRgb : '0, 229, 255');
    const selStrokeRgb = isHyperion ? '255, 183, 0' : (thSel.rgb1 ? thSel.rgb1.cssRgb : '0, 229, 255');
    ctx.save();
    ctx.beginPath();
    ctx.arc(selectedTower.x, selectedTower.y, selectedTower.range, 0, Math.PI * 2);
    ctx.strokeStyle = `rgba(${selStrokeRgb}, 0.5)`;
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.fillStyle = `rgba(${selMainRgb}, 0.09)`;
    ctx.fillRect(selectedTower.c * TILE_SIZE, selectedTower.r * TILE_SIZE, TILE_SIZE, TILE_SIZE);
    ctx.strokeStyle = `rgba(${selStrokeRgb}, 0.5)`;
    ctx.strokeRect(selectedTower.c * TILE_SIZE, selectedTower.r * TILE_SIZE, TILE_SIZE, TILE_SIZE);
    ctx.restore();
  }

  const nowSec = now * 0.001;
  const empBadge = getEmpDisabledSprite();

  towers.forEach(t => {
    if (fxDt > 0 && (t.type === 'gun' || t.type === 'mortar' || t.type === 'stasis')) {
      if (t._fxPrevLastFire !== undefined && t.lastFire < t._fxPrevLastFire) {
        if (t.type === 'stasis') {
          const rSq = (t.range || 110) * (t.range || 110);
          for (let ei = 0; ei < enemies.length; ei++) {
            const em = enemies[ei];
            const dxS = em.x - t.x, dyS = em.y - t.y;
            if (dxS * dxS + dyS * dyS <= rSq && !em.isShielded) {
              spawnFxHitLayers(em.x, em.y, 'stasis', t.color || '#38bdf8', Math.atan2(dyS, dxS), em.radius || 13);
            }
          }
        } else {
          const cosA = Math.cos(t.angle), sinA = Math.sin(t.angle);
          const side = t.type === 'gun' ? ((t.shotIndex || 0) === 0 ? -3.5 : 3.5) : 0;
          const mDist = t.type === 'mortar' ? 14 : 24;
          spawnFxMuzzleLayers(t.x + cosA * mDist - sinA * side, t.y + sinA * mDist + cosA * side, t.type, t.color, t.angle);
        }
      }
      t._fxPrevLastFire = t.lastFire;
    }
    ctx.save();
    ctx.translate(t.x, t.y);
    const isCooling = (t.type === 'melter' && t.melterCoolingTimer > 0);
    const isTeslaShooting = (t.type === 'tesla' && lightningBolts.some(lb => lb.x1 === t.x && lb.life > 0.04));
    const isBeamShooting = ((t.type === 'laser' || t.type === 'melter') && t.target && t.isLockedOn && !isCooling && t.disabledTimer <= 0);
    const melterRampT = (t.type === 'melter') ? (t.melterRampTime || TOWER_CONFIGS.melter.rampTime || 4.0) : 4.0;
    const meltHeatProgress = (t.type === 'melter')
      ? (isCooling ? (t.melterCoolingTimer / melterRampT) : Math.min(1, (t.melterFireTimer || 0) / melterRampT))
      : 0;
    drawTowerModel(
      t.type, t.angle, t.color, t.level, t.glow,
      t.disabledTimer > 0, isCooling, isTeslaShooting || isBeamShooting, meltHeatProgress,
      { x: t.x, y: t.y, target: t.target, time: nowSec, lastFire: t.lastFire, shotIndex: t.shotIndex || 0 }
    );

    if (t.disabledTimer > 0) {
      ctx.drawImage(empBadge.canvas, 16 - empBadge.half, -16 - empBadge.half, empBadge.size, empBadge.size);
    }
    ctx.restore();

    if (t.type === 'laser' && t.target && t.isLockedOn && t.disabledTimer <= 0) {
      const muzzleX = t.x + Math.cos(t.angle) * 24;
      const muzzleY = t.y + Math.sin(t.angle) * 24;
      const laserBeamCol = t.color || '#f05f9f';
      const pulse = Math.sin(now * 0.024);
      ctx.save();
      ctx.lineCap = 'round';
      ctx.globalCompositeOperation = 'lighter';

      // Внешний неоновый ореол луча (Zero-Blur)
      ctx.strokeStyle = laserBeamCol;
      ctx.globalAlpha = 0.32;
      ctx.lineWidth = 9.5 + pulse * 2.0;
      ctx.beginPath();
      ctx.moveTo(muzzleX, muzzleY);
      ctx.lineTo(t.target.x, t.target.y);
      ctx.stroke();

      // Основной луч
      ctx.globalAlpha = 0.92;
      ctx.lineWidth = 3.6 + pulse * 1.1;
      ctx.beginPath();
      ctx.moveTo(muzzleX, muzzleY);
      ctx.lineTo(t.target.x, t.target.y);
      ctx.stroke();

      // Белый энергетический сердечник + точка плавления на мобе
      ctx.strokeStyle = '#ffffff';
      ctx.globalAlpha = 0.95;
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.moveTo(muzzleX, muzzleY);
      ctx.lineTo(t.target.x, t.target.y);
      ctx.stroke();

      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(t.target.x, t.target.y, 3.6 + pulse * 0.9, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    if (t.type === 'melter' && t.target && t.isLockedOn && t.disabledTimer <= 0 && t.melterCoolingTimer <= 0) {
      const muzzleX = t.x + Math.cos(t.angle) * 24;
      const muzzleY = t.y + Math.sin(t.angle) * 24;
      const heatCol = meltHeatProgress > 0.72 ? '#ffffff' : (meltHeatProgress > 0.35 ? '#fb923c' : (t.color || '#e85268'));
      const beamW = 3.2 + meltHeatProgress * 4.2 + Math.sin(now * 0.035) * (0.6 + meltHeatProgress * 1.1);
      ctx.save();
      ctx.lineCap = 'round';
      ctx.globalCompositeOperation = 'lighter';

      // Внешний плазменный ореол, раздувающийся с разогревом
      ctx.strokeStyle = meltHeatProgress > 0.45 ? '#fb923c' : (t.color || '#e85268');
      ctx.globalAlpha = 0.30 + meltHeatProgress * 0.25;
      ctx.lineWidth = beamW * 2.4;
      ctx.beginPath();
      ctx.moveTo(muzzleX, muzzleY);
      ctx.lineTo(t.target.x, t.target.y);
      ctx.stroke();

      // Основной ствол термического луча
      ctx.strokeStyle = heatCol;
      ctx.globalAlpha = 0.95;
      ctx.lineWidth = beamW;
      ctx.beginPath();
      ctx.moveTo(muzzleX, muzzleY);
      ctx.lineTo(t.target.x, t.target.y);
      ctx.stroke();

      // Белый сердечник при высоком разогреве + раскалённое пятно на цели
      if (meltHeatProgress > 0.25) {
        ctx.strokeStyle = '#ffffff';
        ctx.globalAlpha = Math.min(1, 0.45 + meltHeatProgress * 0.55);
        ctx.lineWidth = Math.max(1.4, beamW * 0.42);
        ctx.beginPath();
        ctx.moveTo(muzzleX, muzzleY);
        ctx.lineTo(t.target.x, t.target.y);
        ctx.stroke();
      }

      const spotR = 4.0 + meltHeatProgress * 5.5 + Math.sin(now * 0.04) * 1.1;
      ctx.fillStyle = heatCol;
      ctx.globalAlpha = 0.55;
      ctx.beginPath();
      ctx.arc(t.target.x, t.target.y, spotR * 1.6, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#ffffff';
      ctx.globalAlpha = 0.95;
      ctx.beginPath();
      ctx.arc(t.target.x, t.target.y, spotR * 0.7, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  });

  const viewLeft = -camX / camZoom - TILE_SIZE;
  const viewTop = -camY / camZoom - TILE_SIZE;
  const viewRight = (w - camX) / camZoom + TILE_SIZE;
  const viewBottom = (h - camY) / camZoom + TILE_SIZE;

  const _tMobsStart = performance.now();

  const enemyFxCfg = ENEMY_REACTIONS || {};
  const _beamTargets = new Set();
  for (let ti = 0; ti < towers.length; ti++) {
    const bt = towers[ti];
    if ((bt.type === 'laser' || bt.type === 'melter') && bt.target && bt.isLockedOn && bt.disabledTimer <= 0 && !(bt.type === 'melter' && bt.melterCoolingTimer > 0)) {
      _beamTargets.add(bt.target);
    }
  }
  for (let i = 0; i < enemies.length; i++) {
    const e = enemies[i];
    const isBeamTarget = _beamTargets.has(e);
    if (e._fxLastHp !== undefined && e.hp < e._fxLastHp && fxDt > 0) {
      const ang = (e.angle || 0) + Math.PI;
      if (!isBeamTarget) {
        if (enemyFxCfg.knockback) {
          e._fxKbX = Math.cos(ang) * (e.isBoss ? 1.8 : 3.5);
          e._fxKbY = Math.sin(ang) * (e.isBoss ? 1.8 : 3.5);
        }
        if (enemyFxCfg.hitTilt) e._fxTilt = (Math.random() > 0.5 ? 1 : -1) * (e.isBoss ? 0.06 : 0.14);
      }
      if (enemyFxCfg.jitter) {
        e._fxJitT = 0.10;
        e._fxJitBeam = isBeamTarget;
      }
    }
    e._fxLastHp = e.hp;

    if (fxDt > 0) {
      const sp = Math.exp(-18 * fxDt);
      if (e._fxKbX) e._fxKbX *= sp;
      if (e._fxKbY) e._fxKbY *= sp;
      if (e._fxTilt) e._fxTilt *= Math.exp(-14 * fxDt);
      if (e._fxJitT > 0) {
        e._fxJitT = Math.max(0, e._fxJitT - fxDt);
        if (e._fxJitBeam) {
          e._fxJitStep = (e._fxJitStep || 0) - fxDt;
          if (e._fxJitStep <= 0) {
            e._fxJitStep = 0.05; // <-- частота смены позиции (раз в 0.1 сек = 10 Гц), тряска, дрожь при попадании
            e._fxJx = (Math.random() - 0.5) * 2.0; // <-- амплитуда для лазера/мелтера
            e._fxJy = (Math.random() - 0.5) * 2.0;
          }
        } else {
          e._fxJx = (Math.random() - 0.5) * 3.8; // <-- амплитуда для обычных попаданий
          e._fxJy = (Math.random() - 0.5) * 3.8;
        }
      } else {
        e._fxJx = 0;
        e._fxJy = 0;
      }
    }

    const jx = (e._fxJitT > 0) ? (e._fxJx || 0) : 0;
    const jy = (e._fxJitT > 0) ? (e._fxJy || 0) : 0;
    const fxOx = (e._fxKbX || 0) + jx;
    const fxOy = (e._fxKbY || 0) + jy;
    const fxTilt = e._fxTilt || 0;

    if (e.x < viewLeft || e.x > viewRight || e.y < viewTop || e.y > viewBottom) continue;
    if (Math.abs(fxOx) > 0.05 || Math.abs(fxOy) > 0.05 || Math.abs(fxTilt) > 0.005) {
      ctx.save();
      ctx.translate(e.x + fxOx, e.y + fxOy);
      if (Math.abs(fxTilt) > 0.005) ctx.rotate(fxTilt);
      ctx.translate(-e.x, -e.y);
      drawEnemyModel(e);
      ctx.restore();
    } else {
      drawEnemyModel(e);
    }
  }

  if (window.perfProfiler) perfProfiler.accum.drawMobs += (performance.now() - _tMobsStart);

  projectiles.forEach(p => {
    ctx.save();
    if (p.type === 'bullet') {
      drawFxBulletTrails(p);
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(p.x - 2, p.y - 2, 4, 4);
      ctx.fillStyle = p.color || '#00e5ff';
      ctx.fillRect(p.x - 1, p.y - 1, 2, 2);
    } else if (p.type === 'mortar_shell') {
      const tProg = Math.max(0, Math.min(1, p.elapsed / p.duration));
      const apex = p.arcApex || 45;
      const heightOffset = 4 * apex * tProg * (1 - tProg);
      const shadowScale = 1 - 0.45 * (heightOffset / Math.max(1, apex));
      ctx.globalAlpha = 0.3;
      ctx.fillStyle = '#000000';
      ctx.beginPath();
      ctx.ellipse(p.x, p.y, 5 * shadowScale, 2.6 * shadowScale, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalAlpha = 1;
      const shellCol = p.color || '#ff9100';
      ctx.fillStyle = shellCol;
      setGlow(shellCol, 8);
      ctx.beginPath();
      ctx.arc(p.x, p.y - heightOffset, 6, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  });

  lightningBolts.forEach(lb => {
    if (lb.delay && lb.delay > 0) return;
    const alpha = lb.life / lb.maxLife;
    if (lb.isRail) {
      ctx.save();
      ctx.lineCap = 'round';
      ctx.globalCompositeOperation = 'lighter';
      const railGlowColor = lb.color || '#a275df';

      ctx.beginPath();
      ctx.moveTo(lb.x1, lb.y1);
      ctx.lineTo(lb.x2, lb.y2);

      if (perfMode !== 'low') {
        ctx.strokeStyle = railGlowColor;
        ctx.globalAlpha = alpha * 0.32;
        ctx.lineWidth = 14;
        ctx.stroke();
      }

      ctx.strokeStyle = railGlowColor;
      ctx.globalAlpha = alpha * 0.85;
      ctx.lineWidth = 6;
      ctx.stroke();

      ctx.strokeStyle = '#ffffff';
      ctx.globalAlpha = alpha;
      ctx.lineWidth = 2.5;
      ctx.stroke();

      ctx.restore();
    } else {
      const prog = lb.travelTime ? Math.min(1.0, (lb.elapsed || 0) / lb.travelTime) : 1.0;
      drawJaggedLightning(lb.x1, lb.y1, lb.x2, lb.y2, lb.towerColor || lb.color || '#00ffcc', alpha, prog);
    }
  });

  shockwaves.forEach(sw => {
    const prog = sw.elapsed / sw.duration;
    const currentR = sw.maxRadius * Math.sin(prog * (Math.PI / 2));
    const safeAlpha = Math.max(0, 1 - prog);
    ctx.save();
    ctx.beginPath();
    ctx.arc(sw.x, sw.y, currentR, 0, Math.PI * 2);

    if (perfMode !== 'low') {
      ctx.strokeStyle = sw.color;
      ctx.globalAlpha = safeAlpha * 0.28;
      ctx.lineWidth = 6.5 * (1 - prog);
      ctx.stroke();
    }

    ctx.strokeStyle = sw.color;
    ctx.globalAlpha = safeAlpha;
    ctx.lineWidth = 2.5 * (1 - prog);
    ctx.stroke();
    ctx.restore();
  });
  
  const _tFxStart = performance.now();
  
  ctx.globalCompositeOperation = 'source-over';
  const smokeSprite = typeof getSmokeSprite === 'function' ? getSmokeSprite() : null;

  for (let i = 0; i < particles.length; i++) {
    const pt = particles[i];
    if (!pt.isSmoke && !pt.isSteam) continue;

    const rawProg = Math.max(0, Math.min(1, pt.life / pt.maxLife));
    if (pt.isSmoke && smokeSprite) {
      let smokeAlpha = rawProg > 0.85 ? (1.0 - rawProg) / 0.15 : rawProg / 0.85;
      ctx.globalAlpha = Math.max(0, Math.min(0.6, smokeAlpha * 0.6));
      const currentR = pt.radius * (1.0 + (1.0 - rawProg) * 1.3);
      ctx.drawImage(smokeSprite, pt.x - currentR, pt.y - currentR, currentR * 2, currentR * 2);
    } else if (pt.isSteam) {
      const growProg = 1.0 - rawProg;
      ctx.globalAlpha = rawProg * 0.45;
      ctx.fillStyle = pt.color;
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, pt.radius * (0.6 + growProg * 0.9), 0, Math.PI * 2);
      ctx.fill();
    }
  }

  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = 1.0;
  for (let i = 0; i < particles.length; i++) {
    const pt = particles[i];
    if (!pt.isShard) continue;

    const rawProg = Math.max(0, Math.min(1, pt.life / pt.maxLife));
    pt.angle = (pt.angle || 0) + (pt.vRot || 0) * 0.016;
    ctx.globalAlpha = Math.min(1.0, rawProg * 1.4);

    ctx.save();
    ctx.translate(pt.x, pt.y);
    ctx.rotate(pt.angle);
    ctx.fillStyle = pt.color;
    ctx.beginPath();
    if (pt.pts && pt.pts.length >= 3) {
      ctx.moveTo(pt.pts[0].x, pt.pts[0].y);
      for (let k = 1; k < pt.pts.length; k++) {
        ctx.lineTo(pt.pts[k].x, pt.pts[k].y);
      }
    } else {
      ctx.rect(-pt.radius / 2, -pt.radius / 2, pt.radius, pt.radius);
    }
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  }

  ctx.globalCompositeOperation = 'lighter';
  for (let i = 0; i < particles.length; i++) {
    const pt = particles[i];
    if (pt.isSmoke || pt.isSteam || pt.isShard || pt.isText) continue;

    const rawProg = Math.max(0, Math.min(1, pt.life / pt.maxLife));
    const easeProg = rawProg * rawProg;

    if (pt.isRing) {
      const expandProg = 1.0 - rawProg;
      const curR = Math.max(2, pt.radius * Math.sin(expandProg * (Math.PI * 0.5)));
      ctx.globalAlpha = rawProg * 0.9;
      ctx.strokeStyle = pt.color || '#ffffff';
      ctx.lineWidth = Math.max(0.8, (pt.lineWidth || 2.2) * rawProg);
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, curR, 0, Math.PI * 2);
      ctx.stroke();
    } else if (pt.isCrossFlash) {
      const len = pt.radius * (0.45 + easeProg * 0.75);
      const thick = Math.max(1.2, pt.radius * 0.14 * rawProg);
      ctx.save();
      ctx.translate(pt.x, pt.y);
      ctx.rotate(pt.angle || 0);
      ctx.globalAlpha = rawProg * 0.95;

      ctx.fillStyle = pt.color || '#ff9100';
      ctx.beginPath();
      ctx.ellipse(0, 0, len, thick * 1.4, 0, 0, Math.PI * 2);
      ctx.ellipse(0, 0, thick * 1.4, len, 0, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.ellipse(0, 0, len * 0.68, thick * 0.65, 0, 0, Math.PI * 2);
      ctx.ellipse(0, 0, thick * 0.65, len * 0.68, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    } else if (pt.isFlash && typeof getGlowSprite === 'function') {
      ctx.globalAlpha = rawProg;
      const sprite = getGlowSprite(pt.color || '#ffffff');
      const r = pt.radius * (1.1 - (1.0 - rawProg) * 0.3);
      ctx.drawImage(sprite, pt.x - r, pt.y - r, r * 2, r * 2);
    } else if (pt.isGlowHalo && typeof getGlowSprite === 'function') {
      ctx.globalAlpha = rawProg * (pt.alphaMult || 0.4);
      const glowSprite = getGlowSprite(pt.color || '#ff9100');
      ctx.drawImage(glowSprite, pt.x - pt.radius, pt.y - pt.radius, pt.radius * 2, pt.radius * 2);
    } else if (pt.isStreak) {
      ctx.globalAlpha = rawProg * 0.9;
      ctx.save();
      ctx.translate(pt.x, pt.y);
      ctx.rotate(Math.atan2(pt.vy, pt.vx));
      const len = pt.radius * (1.5 + easeProg * 2.4);
      const width = Math.max(1.2, pt.radius * easeProg * 0.5);
      ctx.fillStyle = pt.color;
      ctx.beginPath();
      ctx.ellipse(0, 0, len, width, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    } else {
      ctx.globalAlpha = rawProg;
      const sprite = getNeonDiscSprite(pt.color || '#00e5ff');
      const curRadius = pt.radius * (0.4 + easeProg * 0.6);
      ctx.drawImage(sprite, pt.x - curRadius, pt.y - curRadius, curRadius * 2, curRadius * 2);
    }
  }

  updateAndDrawFxLayers(fxDt, nowSec);

  ctx.globalCompositeOperation = 'source-over';
  for (let i = 0; i < particles.length; i++) {
    const pt = particles[i];
    if (!pt.isText) continue;

    const rawProg = Math.max(0, Math.min(1, pt.life / pt.maxLife));
    ctx.globalAlpha = rawProg > 0.3 ? 1.0 : rawProg / 0.3;
    ctx.font = '900 12px Montserrat, sans-serif';
    ctx.fillStyle = pt.color || '#f05f9f';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.shadowColor = 'rgba(0, 0, 0, 0.8)';
    ctx.shadowBlur = 4;
    ctx.fillText(pt.text, pt.x, pt.y);
    ctx.shadowBlur = 0;
  }

  ctx.globalCompositeOperation = 'source-over';
  ctx.globalAlpha = 1.0;

  if (window.perfProfiler) perfProfiler.accum.drawFx += (performance.now() - _tFxStart);

  if (draggingTower) {
    const c = Math.floor(draggingTower.worldX / TILE_SIZE);
    const r = Math.floor(draggingTower.worldY / TILE_SIZE);
    const isValidCell = c >= 0 && c < COLS && r >= 0 && r < ROWS;
    const canBuild = isValidCell && grid[r][c] === 0;
    const conf = TOWER_CONFIGS[draggingTower.type];

    const thDrag = getTheme();
    const dragMainCol = isHyperion ? '#ff9100' : (thDrag.c1 || '#00e5ff');
    const dragMainRgb = isHyperion ? '255, 145, 0' : (thDrag.rgb1 ? thDrag.rgb1.cssRgb : '0, 229, 255');
    const validStroke = dragMainCol;
    const validFill = `rgba(${dragMainRgb}, 0.20)`;

    if (isValidCell) {
      ctx.fillStyle = canBuild ? validFill : 'rgba(240, 95, 159, 0.3)';
      ctx.fillRect(c * TILE_SIZE, r * TILE_SIZE, TILE_SIZE, TILE_SIZE);
      ctx.strokeStyle = canBuild ? validStroke : '#f05f9f';
      ctx.lineWidth = 2;
      ctx.strokeRect(c * TILE_SIZE, r * TILE_SIZE, TILE_SIZE, TILE_SIZE);
    }

    ctx.beginPath();
    ctx.arc(draggingTower.worldX, draggingTower.worldY, conf.range, 0, Math.PI * 2);
    ctx.strokeStyle = canBuild
      ? `rgba(${dragMainRgb}, 0.48)`
      : 'rgba(240, 95, 159, 0.5)';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    ctx.save();
    ctx.globalAlpha = 0.8;
    ctx.translate(draggingTower.worldX, draggingTower.worldY);
    drawTowerModel(draggingTower.type, 0, conf.color, 1, conf.glow);
    ctx.restore();
  }

  ctx.restore();

  updateTutorialOverlay(now);
}

if (typeof window !== 'undefined') {
  initDevResourceHold();
}

// [UI.JT]
function toggleTacticalTips() {
  const body = document.getElementById('tacticalTipsBody');
  const arrow = document.getElementById('tacticalTipsArrow');
  const preview = document.getElementById('tacticalTipsPreview');
  if (!body) return;
  if (body.classList.contains('hidden')) {
    body.classList.remove('hidden');
    if (arrow) arrow.textContent = '▴';
    if (preview) preview.classList.add('hidden');
  } else {
    body.classList.add('hidden');
    if (arrow) arrow.textContent = '▾';
    if (preview) preview.classList.remove('hidden');
  }
}
window.toggleTacticalTips = toggleTacticalTips;

// Listener to intercept Back button on Android.
// [UI.JU]
document.addEventListener('DOMContentLoaded', () => {
  if (window.Capacitor && window.Capacitor.Plugins) {
    if (window.Capacitor.Plugins.StatusBar) {
      window.Capacitor.Plugins.StatusBar.hide().catch(err => console.warn('StatusBar error:', err));
    }

    const App = window.Capacitor.Plugins.App;
    if (App && typeof App.addListener === 'function') {
      // [UI.JV]
      App.addListener('backButton', () => {
        if (typeof handleHardwareBack === 'function') {
          handleHardwareBack();
        }
      });
    }
  }
});