// Game Engine Module: Primary simulation state, game loop, persistent storage, and entity managers.
// Synth Wave Defense -- engine.js
//
// The simulation layer: everything about *what happens* in a match, with no
// opinion on how it's drawn or which screen is showing. Owns all mutable
// game state (gold, diamonds, towers/enemies/projectiles arrays, wave/level
// progress, save data) and the logic that changes it.

const canvas = document.getElementById('gameCanvas');
let ctx = canvas.getContext('2d');

const TILE_SIZE = 70;
const TOUCH_OFFSET_Y = 65;
let currentLevelSection = 1;

let COLS = 10;
let ROWS = 7;
let FIELD_WIDTH = COLS * TILE_SIZE;
let FIELD_HEIGHT = ROWS * TILE_SIZE;

let camZoom = 1.0;
let camX = 0;
let camY = 0;
let baseZoom = 1.0;
let minZoom = 1.0;
let maxZoom = 2.0;

let isPanning = false;
let panStartTouch = { x: 0, y: 0 };
let panStartCam = { x: 0, y: 0 };
let isMousePanning = false;
let mouseSpacePressed = false;
let panStartMouse = { x: 0, y: 0 };
let initialPinchDist = null;
let initialPinchZoom = 1.0;
let pinchCenterWorld = { x: 0, y: 0 };

let bossAlertScheduled = false;
let bossAlertShown = false;
let activeBossAlertType = null;
let bossAlertHideTimer = 0;
let newTowerBannerHideTimer = 0;

let cameraShakeTimer = 0;
let cameraShakeMaxDur = 0;
let cameraShakeIntensity = 0;

// [ENG.A]
function triggerCameraShake(dur = 0.5, intensity = 15, force = false) {
  if (!force && typeof settings !== 'undefined' && settings.screenShakeEnabled === false) return;
  if (dur <= 0 || intensity <= 0) return;
  const currentRemaining = (cameraShakeTimer > 0 && cameraShakeMaxDur > 0)
    ? cameraShakeIntensity * (cameraShakeTimer / cameraShakeMaxDur)
    : 0;
  if (intensity < currentRemaining) return;
  cameraShakeTimer = dur;
  cameraShakeMaxDur = dur;
  cameraShakeIntensity = intensity;
}

// [ENG.AM_SHAKE] Единый синхронизированный диспетчер тряски камеры и виброотклика
function triggerImpactFeedback(shakeTier, hapticTier = 'none', options = {}) {
  const opts = options || {};
  let effectiveShakeTier = shakeTier;
  if (opts.isSplash && typeof enemies !== 'undefined' && enemies.length > 18) {
    effectiveShakeTier = 'none';
  }

  let dur = 0;
  let intensity = 0;
  if (effectiveShakeTier === 'light') {
    dur = (typeof opts.dur === 'number') ? opts.dur : (opts.isSplash ? 0.13 : 0.14);
    intensity = (typeof opts.intensity === 'number') ? opts.intensity : 3;
  } else if (effectiveShakeTier === 'medium') {
    dur = (typeof opts.dur === 'number') ? opts.dur : 0.24;
    intensity = (typeof opts.intensity === 'number') ? opts.intensity : 7;
  } else if (effectiveShakeTier === 'heavy') {
    dur = (typeof opts.dur === 'number') ? opts.dur : 0.38;
    intensity = (typeof opts.intensity === 'number') ? opts.intensity : 14;
  }

  if (effectiveShakeTier && effectiveShakeTier !== 'none' && dur > 0 && intensity > 0) {
    triggerCameraShake(dur, intensity, !!opts.forceShake);
  }
  if (hapticTier && hapticTier !== 'none') {
    vibrate(hapticTier);
  }
}

// [ENG.AA_ADS] Диагностический объект рекламы для Dev-панели
window.AdDiagnostics = {
  pluginAvailable: false,
  isNative: false,
  initialized: false,
  videoReady: false,
  lastEvent: 'NONE',
  lastError: 'None',
  logs: []
};

function logAdEvent(msg) {
  const time = new Date().toTimeString().split(' ')[0];
  const line = `[${time}] ${msg}`;
  window.AdDiagnostics.logs.unshift(line);
  if (window.AdDiagnostics.logs.length > 20) window.AdDiagnostics.logs.pop();
  window.AdDiagnostics.lastEvent = msg;
  console.log('[AdsBridge]', line);
}

// Конфигурация рекламного блока (Тестовый ID для РСЯ: 'demo-rewarded-yandex')
const REWARDED_AD_UNIT_ID = 'demo-rewarded-yandex';
let isAdsInitialized = false;
let isRewardAdReady = false;
let activeAdCallbacks = { onRewarded: null, onNotRewarded: null, rewardedFlag: false };

// --- Глобальные обработчики событий нативного моста (вызываются из Java) ---

function handleAdLoaded() {
  isRewardAdReady = true;
  if (window.AdDiagnostics) {
    window.AdDiagnostics.videoReady = true;
  }
  logAdEvent('Reward Video READY');
}

function handleAdFailedToLoad(reason) {
  isRewardAdReady = false;
  const errStr = reason || 'Load failed';
  if (window.AdDiagnostics) {
    window.AdDiagnostics.videoReady = false;
    window.AdDiagnostics.lastError = errStr;
  }
  logAdEvent('Reward Ad Failed: ' + errStr);
}

function handleAdRewarded() {
  activeAdCallbacks.rewardedFlag = true;
  logAdEvent('Reward Granted');
}

function handleAdDismissed() {
  logAdEvent('Reward Ad Dismissed');
  isRewardAdReady = false;
  if (window.AdDiagnostics) {
    window.AdDiagnostics.videoReady = false;
  }

  const wasRewarded = activeAdCallbacks.rewardedFlag;
  const cbReward = activeAdCallbacks.onRewarded;
  const cbFail = activeAdCallbacks.onNotRewarded;

  // Очищаем коллбэки текущего показа
  activeAdCallbacks = { onRewarded: null, onNotRewarded: null, rewardedFlag: false };

  // Автоматическая фоновая предзагрузка следующего ролика
  preloadRewardedAd();

  if (wasRewarded) {
    if (typeof cbReward === 'function') cbReward();
  } else {
    if (typeof cbFail === 'function') cbFail();
  }
}

function handleAdFailedToShow(reason) {
  const errStr = reason || 'Show error';
  if (window.AdDiagnostics) {
    window.AdDiagnostics.videoReady = false;
    window.AdDiagnostics.lastError = errStr;
  }
  logAdEvent('Show Error: ' + errStr);
  isRewardAdReady = false;

  const cbFail = activeAdCallbacks.onNotRewarded;
  activeAdCallbacks = { onRewarded: null, onNotRewarded: null, rewardedFlag: false };

  preloadRewardedAd();
  if (typeof cbFail === 'function') cbFail();
}

// Привязываем оба формата имён (полная совместимость со всеми версиями MainActivity)
window.onNativeAdLoaded = handleAdLoaded;
window.onYandexAdLoaded = handleAdLoaded;

window.onNativeAdFailedToLoad = handleAdFailedToLoad;
window.onYandexAdFailedToLoad = handleAdFailedToLoad;

window.onNativeAdRewarded = handleAdRewarded;
window.onYandexAdRewarded = handleAdRewarded;

window.onNativeAdDismissed = handleAdDismissed;
window.onYandexAdDismissed = handleAdDismissed;

window.onNativeAdFailedToShow = handleAdFailedToShow;
window.onYandexAdFailedToShow = handleAdFailedToShow;

// [ENG.AB_ADS] Универсальная инициализация моста рекламы
async function initAdsBridge() {
  const isNative = typeof window.Capacitor !== 'undefined' && window.Capacitor.isNativePlatform();
  window.AdDiagnostics.isNative = isNative;

  const hasNativeBridge = typeof window.NativeYandexAdsBridge !== 'undefined' || typeof window.NativeAdsBridge !== 'undefined';
  const hasWebSdk = !!(window.Ya && window.Ya.Context && window.Ya.Context.AdvManager);
  window.AdDiagnostics.pluginAvailable = hasNativeBridge || hasWebSdk;

  if (hasNativeBridge) {
    try {
      logAdEvent('Initializing NativeAdsBridge...');
      const bridge = window.NativeYandexAdsBridge || window.NativeAdsBridge;
      bridge.initialize(REWARDED_AD_UNIT_ID);
      isAdsInitialized = true;
      window.AdDiagnostics.initialized = true;
      logAdEvent('Native Ads SDK initialized');
      preloadRewardedAd();
    } catch (err) {
      const errStr = (err && err.message) ? err.message : String(err);
      window.AdDiagnostics.lastError = errStr;
      logAdEvent('Init Error: ' + errStr);
    }
    return;
  }

  if (hasWebSdk) {
    isAdsInitialized = true;
    window.AdDiagnostics.initialized = true;
    isRewardAdReady = true;
    window.AdDiagnostics.videoReady = true;
    logAdEvent('Web Ads SDK ready');
    return;
  }

  logAdEvent('Native Ads Bridge NOT available (using Sim)');
}
window.initAdsBridge = initAdsBridge;

async function preloadRewardedAd() {
  if (!isAdsInitialized) {
    logAdEvent('Cannot preload: not initialized');
    return;
  }
  const bridge = window.NativeYandexAdsBridge || window.NativeAdsBridge;
  if (bridge && typeof bridge.loadRewardedAd === 'function') {
    try {
      // Если ролик уже загружен в нативной памяти — сразу синхронизируем статус без ожидания!
      if (typeof bridge.isRewardedAdReady === 'function' && bridge.isRewardedAdReady()) {
        isRewardAdReady = true;
        if (window.AdDiagnostics) window.AdDiagnostics.videoReady = true;
        logAdEvent('Reward Video READY (Cached)');
        return;
      }
      logAdEvent('Preloading Rewarded Ad...');
      bridge.loadRewardedAd(REWARDED_AD_UNIT_ID);
    } catch (err) {
      isRewardAdReady = false;
      if (window.AdDiagnostics) window.AdDiagnostics.videoReady = false;
      const errStr = (err && err.message) ? err.message : String(err);
      if (window.AdDiagnostics) window.AdDiagnostics.lastError = errStr;
      logAdEvent('Preload Failed: ' + errStr);
    }
  }
}

window.devPreloadRewardAd = function() {
  preloadRewardedAd();
};

window.devShowRewardAd = function() {
  showAdPlaceholder(
    () => { if (typeof showHintToast === 'function') showHintToast('Dev: Ad Rewarded!'); },
    () => { if (typeof showHintToast === 'function') showHintToast('Dev: Ad Dismissed (No Reward)'); }
  );
};

// [ENG.B]
function hasClearedLevelBefore(lvl) {
  return maxUnlockedLevel > lvl;
}

// [ENG.C]
function getBaseDamageFor(e) {
  if (e.isBoss) return 5;
  if (e.isMiniBoss) {
    if (typeof currentLevel !== 'undefined' && currentLevel === 34) return 1;
    return 2;
  }
  return 1;
}

// [ENG.D]
function checkEnemyEnrage(e) {
  if (isOverdriveMode && e && e.hp > 0 && (e.hp / e.maxHp) <= 0.3 && !e.isEnraged) {
    e.isEnraged = true;
    e.baseSpeed *= 1.35;
    e.speed *= 1.35;
  }
}

// [ENG.E]
function getNewlyUnlockedTowers(lvl) {
  const cur = (LEVELS_DATA[lvl] && LEVELS_DATA[lvl].unlockedTowers) || [];
  const prev = (LEVELS_DATA[lvl - 1] && LEVELS_DATA[lvl - 1].unlockedTowers) || [];
  return cur.filter(t => !prev.includes(t));
}

let gameState = 'START';
let currentLevel = 1;
let settings = {
  showEnemyHp: true,
  showDamage: true,
  vibrationEnabled: true,
  screenShakeEnabled: true,
  perfModeOverride: null,
  sfxEnabled: true, musicEnabled: true,
  sfxVolume: 100, musicVolume: 70,
  lang: 'en'
};

// [ENG.F]
function sfx(name, arg) {
  if (!settings.sfxEnabled) return;
  try {
    if (typeof SFX !== 'undefined' && SFX) SFX.play(name, arg);
  } catch (e) { }
}
// [ENG.G]
function sfxDeath(enemy) {
  if (!settings.sfxEnabled) return;
  try {
    if (typeof SFX !== 'undefined' && SFX) SFX.death(enemy);
  } catch (e) {}
}
// [ENG.H]
function sfxBeam(kind, active, intensity) {
  if (!settings.sfxEnabled) return;
  try {
    if (typeof SFX !== 'undefined' && SFX) SFX.beam(kind, active, intensity);
  } catch (e) {}
}
// [ENG.I]
function sfxStopBeams() {
  try {
    if (typeof SFX !== 'undefined' && SFX) SFX.stopBeams();
  } catch (e) {}
}
// [ENG.J]
function sfxReap() {
  try {
    if (typeof SFX !== 'undefined' && SFX) SFX.reap();
  } catch (e) {}
}
// [ENG.K]
function sfxSetEnabled(on) {
  try {
    if (typeof SFX !== 'undefined' && SFX) SFX.setEnabled(on);
  } catch (e) {}
}
// [ENG.L]
function sfxSetVolume(v) {
  try {
    if (typeof SFX !== 'undefined' && SFX && SFX.setVolume) SFX.setVolume(v);
  } catch (e) {}
}

// [ENG.M]
function music(category) {
  try {
    if (typeof MusicManager !== 'undefined' && MusicManager) MusicManager.play(category);
  } catch (e) { }
}
// [ENG.N]
function musicSetEnabled(on) {
  try {
    if (typeof MusicManager !== 'undefined' && MusicManager) MusicManager.setEnabled(on);
  } catch (e) {}
}
// [ENG.O]
function musicSetVolume(v) {
  try {
    if (typeof MusicManager !== 'undefined' && MusicManager && MusicManager.setVolume) MusicManager.setVolume(v);
  } catch (e) {}
}
// [ENG.P]
function musicUnlock() {
  try {
    if (typeof MusicManager !== 'undefined' && MusicManager) MusicManager.unlock();
  } catch (e) {}
}
// [ENG.Q]
function musicSuspend() {
  try {
    if (typeof MusicManager !== 'undefined' && MusicManager) MusicManager.suspend();
  } catch (e) {}
}
// [ENG.R]
function musicResume() {
  try {
    if (typeof MusicManager !== 'undefined' && MusicManager) MusicManager.resume();
  } catch (e) {}
}
// [ENG.S]
function musicSetDucked(on, dur) {
  try {
    if (typeof MusicManager !== 'undefined' && MusicManager && MusicManager.setDucked) MusicManager.setDucked(on, dur);
  } catch (e) {}
}

// Функция вибрации (должна быть доступна глобально):
// [ENG.T]
function vibrate(type = 'light') {
  if (!settings || !settings.vibrationEnabled) return;
  try {
    if (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.Haptics) {
      const Haptics = window.Capacitor.Plugins.Haptics;
      if (type === 'light') Haptics.impact({ style: 'LIGHT' });
      else if (type === 'medium') Haptics.impact({ style: 'MEDIUM' });
      else if (type === 'heavy') Haptics.impact({ style: 'HEAVY' });
      else if (type === 'warning') Haptics.notification({ type: 'WARNING' });
      else if (type === 'error') Haptics.notification({ type: 'ERROR' });
      return;
    }
    if (navigator.vibrate) {
      if (type === 'light') navigator.vibrate(15);
      else if (type === 'medium') navigator.vibrate(30);
      else if (type === 'heavy') navigator.vibrate(50);
      else if (type === 'warning') navigator.vibrate([30, 50, 30]);
      else if (type === 'error') navigator.vibrate([60, 80, 60]);
    }
  } catch (e) {}
}

window.vibrate = vibrate;

let devMode = false;
let devInputOpen = false;
let suppressBackgroundPauseUntil = 0;
// [ENG.U]
function suppressBackgroundPause(ms = 900) {
  suppressBackgroundPauseUntil = Date.now() + ms;
}
let gameTimeScale = 1.0;
let isLivePaused = false;

let gold = 100;
let baseHp = 10;
let wave = 1;
let waveInProgress = false;
let autoWaveTimeRemaining = 0;
let waveTimerActive = false;
let fieldClearDelayTimer = 0;
let isWaveTimerAccelerated = false;
let waveTotalSpawnTime = 1.0;
let waveSpawnElapsedTime = 0;
let victoryDelayTimer = 0;

let selectedLoadout = [];
let activeBattleLoadout = [];
const LOADOUT_SIZE = 3;

let draggingTower = null;
let selectedTower = null;
let sellConfirmArmed = false;
let sellConfirmTimer = null;

let diamonds = 0;
let prisms = 0;
let maxUnlockedLevel = 1;
let clearedLevels = [];
let overdriveClearedLevels = {};
let isOverdriveMode = false;
let regularSpawnCounter = 0;
let levelStars = {};
let matchStartBaseHp = 10;

let isEndlessMode = false;
let endlessBestWavesBySection = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
let endlessBestWave = 0; // Оставляем для обратной совместимости
let endlessDailyRunsUsed = 0;
let endlessDailyRunsDate = '';
let endlessMilestonesClaimed = {};

// [ENG.V]
function resetEndlessDailyRunsIfNeeded() {
  const todayStr = new Date().toISOString().slice(0, 10);
  if (endlessDailyRunsDate !== todayStr) {
    endlessDailyRunsDate = todayStr;
    endlessDailyRunsUsed = 0;
  }
}

// [ENG.X]
function getEndlessEntryStatus() {
  resetEndlessDailyRunsIfNeeded();

  let diamondCost = 25;
  if (endlessDailyRunsUsed === 4) {
    diamondCost = 50;
  } else if (endlessDailyRunsUsed >= 5) {
    diamondCost = 100;
  }

  // 1-й вход: бесплатно
  if (endlessDailyRunsUsed === 0) {
    return { type: 'free', text: 'FREE (1/1)', label: 'FREE (1/1)', cost: 0 };
  } else if (endlessDailyRunsUsed < 3) {
    // 2-й и 3-й заходы: строго за просмотр Rewarded Video
    const remainingAdRuns = 3 - endlessDailyRunsUsed;
    return { type: 'ad', text: `WATCH AD (${remainingAdRuns}/2)`, label: `WATCH AD (${remainingAdRuns}/2)`, cost: 0 };
  } else {
    // 4-й и далее: за алмазы
    return { 
      type: 'diamonds', 
      text: `${diamondCost} DIAMONDS`, 
      label: `${diamondCost} DIAMONDS`, 
      cost: diamondCost 
    };
  }
}

window.getEndlessEntryStatus = getEndlessEntryStatus;

// [ENG.Y] - Оставляем генератор волн без изменений (он идет следом в коде)
function generateEndlessWaveData(w) {
  const arena = (typeof currentLevelSection !== 'undefined') ? Math.min(5, Math.max(1, currentLevelSection)) : 1;
  const cWave = ((w - 1) % 20) + 1; // Позиция внутри 20-волнового цикла (1..20)
  const isSecondHalf = cWave > 10; // Вторые 10 волн цикла сложнее первых 10

  // 1. СТУПЕНЧАТАЯ КРИВАЯ HP С ЗАПАСОМ СЛОЖНОСТИ (Контрольные стены: 10 / 20 / 40 / 60 / 80 / <100)
  let hpScalingMult = 1.0;
  if (w === 1) {
    hpScalingMult = 0.90; // Мягкий старт на 1-й волне
  } else if (w === 2) {
    hpScalingMult = 1.15;
  } else if (w === 3) {
    hpScalingMult = 1.45;
  } else if (w <= 10) {
    // Волны 4–10: крутой разгон к стене 10-й волны (потолок для 0/10 Tech Tree)
    hpScalingMult = 1.45 * Math.pow(1.31, w - 3);
  } else if (w <= 20) {
    // Волны 11–20: стена 20-й волны (потолок для 4/10 Tech Tree)
    const w10 = 1.45 * Math.pow(1.31, 7); // ~9.62
    hpScalingMult = w10 * Math.pow(1.135, w - 10);
  } else if (w <= 40) {
    // Волны 21–40: стена 40-й волны (потолок для 6/10 Tech Tree)
    const w20 = 1.45 * Math.pow(1.31, 7) * Math.pow(1.135, 10); // ~34.1
    hpScalingMult = w20 * Math.pow(1.062, w - 20);
  } else if (w <= 60) {
    // Волны 41–60: стена 60-й волны (потолок для 8/10 Tech Tree)
    const w40 = 1.45 * Math.pow(1.31, 7) * Math.pow(1.135, 10) * Math.pow(1.062, 20); // ~113.6
    hpScalingMult = w40 * Math.pow(1.055, w - 40);
  } else if (w <= 80) {
    // Волны 61–80: стена 80-й волны (потолок для 10/10 Tech Tree)
    const w60 = 1.45 * Math.pow(1.31, 7) * Math.pow(1.135, 10) * Math.pow(1.062, 20) * Math.pow(1.055, 20); // ~331.5
    hpScalingMult = w60 * Math.pow(1.058, w - 60);
  } else {
    // Волны 81+: Финальный заслон для Ascended 15/15 + SYNTH (непроходимо к 95–100 волне)
    const w80 = 1.45 * Math.pow(1.31, 7) * Math.pow(1.135, 10) * Math.pow(1.062, 20) * Math.pow(1.055, 20) * Math.pow(1.058, 20); // ~1024
    hpScalingMult = w80 * Math.pow(1.14, w - 80);
  }

  // Надбавка сложности во второй половине 20-волнового цикла (волны 11-19 цикла плотнее на 12%)
  if (isSecondHalf && cWave !== 20) {
    hpScalingMult *= 1.12;
  }

  // Множитель HP от самой Арены (чем выше глава карты, тем крепче враги со старта)
  const arenaHpFactor = [1.0, 1.0, 1.12, 1.25, 1.38, 1.50][arena] || 1.0;
  hpScalingMult *= arenaHpFactor;

  // 2. ПРОГРЕССИЯ СКОРОСТИ И КОЛИЧЕСТВА МОБОВ
  const spdMult = Math.min(2.05, 1 + (w - 1) * 0.015 + (isSecondHalf ? 0.05 : 0));

  // Масштаб толпы: на 1-3 волнах мало врагов, к 40-80 волнам идут массированные армии
  const crowdScale = Math.min(4.2, 1 + (w - 1) * 0.055 + (isSecondHalf ? 0.25 : 0));

  // 3. ЭКОНОМИКА С УЧЕТОМ РАСТУЩЕГО БОНУСА КНОПКИ "GO"
  // Так как бонус за ранний вызов волны (15 + w * 1.5) растет, награда за самих мобов плавно сжимается,
  // чтобы игрок не смог застроить мусорные краевые слоты
  const targetWaveBounty = w <= 6 ? 75 : Math.max(18, Math.round(78 - (w - 6) * 1.15));

  const spawns = [];


  // БОССЫ ЦИКЛА: ВОЛНА 10 (МЛАДШИЙ БОСС) И ВОЛНА 20 (СТАРШИЙ БОСС)
  if (cWave === 10 || cWave === 20) {
    const isMajorBoss = (cWave === 20); // На 20, 40, 60, 80, 100 волнах — главный босс!

    // Выбор босса строго по главам Normal Mode для каждой Арены
    let bossType = 'tank';
    if (arena === 1) {
      // Арена 1 (Главы 1–2): W10 -> Mega Tank (босс Гл.1), W20 -> Hive Empress (босс Гл.2)
      bossType = isMajorBoss ? 'hive_empress' : 'tank';
    } else if (arena === 2) {
      // Арена 2 (Главы 1–3): W10 -> Hive Empress (Гл.2), W20 -> Chronos Warp (босс Гл.3)
      bossType = isMajorBoss ? 'chronos_warp' : 'hive_empress';
    } else if (arena === 3) {
      // Арена 3 (Главы 1–4): W10 -> Chronos Warp (Гл.3), W20 -> Titan Core (босс Гл.4)
      bossType = isMajorBoss ? 'titan_core' : 'chronos_warp';
    } else if (arena === 4) {
      // Арена 4 (Главы 1–5): W10 -> Titan Core (Гл.4), W20 -> EMP Overlord (босс Гл.5)
      bossType = isMajorBoss ? 'emp_overlord' : 'titan_core';
    } else {
      // Арена 5 (Главы 1–5, Альтернативная): W10 -> чередование Titan / Chronos, W20 -> EMP Overlord
      bossType = isMajorBoss ? 'emp_overlord' : ((Math.floor(w / 20) % 2 === 0) ? 'titan_core' : 'chronos_warp');
    }
    const protoBoss = (typeof ENEMY_CONFIGS !== 'undefined' && ENEMY_CONFIGS[bossType]) ? ENEMY_CONFIGS[bossType] : null;
    let bColor = protoBoss ? protoBoss.color : '#a06fdc';
    let bGlow = protoBoss ? protoBoss.glow : bColor;
    let bShape = protoBoss ? protoBoss.shape : 'octagon';
    let bBaseSpeed = 30;
    if (bossType === 'tank') { bShape = 'square'; bBaseSpeed = 29; }
    else if (bossType === 'hive_empress') { bShape = 'diamond'; bBaseSpeed = 36; }
    else if (bossType === 'chronos_warp') { bShape = 'hexagon'; bBaseSpeed = 38; }
    else if (bossType === 'titan_core') { bShape = 'octagon'; bBaseSpeed = 28; }
    else if (bossType === 'emp_overlord') { bShape = 'triangle_inverted'; bBaseSpeed = 28; }

    // База HP босса: на 10-й волне ~5800 HP (непроходимо с 0/10 Tech Tree), на 20-й волне Старший Босс еще мощнее
    const bossMultiplier = isMajorBoss ? 680 : 580;
    const bossHp = Math.round(bossMultiplier * hpScalingMult);
    const bossBounty = Math.round(targetWaveBounty * 0.60);

    // Свита босса (зависит от арены и половины цикла)
    let escortType = isMajorBoss ? 'tank' : 'grunt';
    if (arena >= 2 && isMajorBoss) escortType = 'blinker';
    if (arena >= 3 && isMajorBoss && w >= 40) escortType = 'goliath';

    const escortCount = isMajorBoss
      ? Math.min(28, Math.round(6 + w * 0.28))
      : Math.min(20, Math.round(5 + w * 0.22));
    const escortBounty = Math.max(1, Math.floor((targetWaveBounty * 0.40) / escortCount));
    const protoEscort = (typeof ENEMY_CONFIGS !== 'undefined' && ENEMY_CONFIGS[escortType])
      ? ENEMY_CONFIGS[escortType] : { baseHp: 40, baseSpeed: 50 };

    // Сначала запускаем часть авангарда, затем Босса
    spawns.push({
      type: escortType,
      isBoss: false,
      isMiniBoss: false,
      count: escortCount,
      hp: Math.round(protoEscort.baseHp * hpScalingMult * 0.85),
      speed: Math.min(165, Math.round(protoEscort.baseSpeed * spdMult)),
      bounty: escortBounty,
      interval: (escortType === 'tank' || escortType === 'goliath') ? 1.7 : 0.65
    });

    spawns.push({
      type: bossType,
      isBoss: true,
      isMiniBoss: false,
      count: 1,
      hp: bossHp,
      speed: Math.min(85, Math.round(bBaseSpeed * Math.min(1.5, spdMult))),
      bounty: bossBounty,
      interval: 2.0,
      shape: bShape,
      color: bColor,
      glow: bGlow
    });

    return { wave: w, delayAfter: 6.5, spawns };
  }

  // ==========================================
  // ОБЫЧНЫЕ ВОЛНЫ: 20-ВОЛНОВОЙ ЦИКЛ ДЛЯ КАЖДОЙ ИЗ 5 КАРТ
  // ==========================================
  let g1Type = 'grunt', g1BaseCount = 5, g1Interval = 0.65, g1HpMod = 1.0;
  let g2Type = null, g2BaseCount = 0, g2Interval = 0.65, g2HpMod = 0.9;

  // ------------------------------------------
  // АРЕНА 1 (Главы 1–2): ТОЛЬКО grunt, scout, tank, swarm
  // ------------------------------------------
  if (arena === 1) {
    if (!isSecondHalf) {
      // Волны 1–9 цикла (Попроще): знакомство со скоростями и первыми танками
      const step = cWave % 4;
      if (cWave === 1) {
        g1Type = 'grunt'; g1BaseCount = 5; g1Interval = 0.75;
      } else if (cWave === 2) {
        g1Type = 'grunt'; g1BaseCount = 5; g1Interval = 0.65;
        g2Type = 'scout'; g2BaseCount = 3; g2Interval = 0.50;
      } else if (step === 3) {
        g1Type = 'scout'; g1BaseCount = 7; g1Interval = 0.45;
      } else if (step === 0) {
        g1Type = 'tank'; g1BaseCount = 2; g1Interval = 1.75; // Танки идут свободно
        g2Type = 'grunt'; g2BaseCount = 5; g2Interval = 0.60;
      } else if (step === 1) {
        g1Type = 'swarm'; g1BaseCount = 12; g1Interval = 0.05; // Плотная пачка роя
        g2Type = 'grunt'; g2BaseCount = 4; g2Interval = 0.65;
      } else {
        g1Type = 'grunt'; g1BaseCount = 7; g1Interval = 0.58;
        g2Type = 'scout'; g2BaseCount = 5; g2Interval = 0.45;
      }
    } else {
      // Волны 11–19 цикла (Посложнее): плотные комбо танков, быстрых скаутов и двойного роя
      const step = cWave % 4;
      if (step === 3) {
        g1Type = 'tank'; g1BaseCount = 4; g1Interval = 1.65;
        g2Type = 'scout'; g2BaseCount = 8; g2Interval = 0.40;
      } else if (step === 0) {
        g1Type = 'swarm'; g1BaseCount = 22; g1Interval = 0.045;
        g2Type = 'scout'; g2BaseCount = 7; g2Interval = 0.42;
      } else if (step === 1) {
        g1Type = 'tank'; g1BaseCount = 3; g1Interval = 1.70;
        g2Type = 'swarm'; g2BaseCount = 16; g2Interval = 0.05;
      } else {
        g1Type = 'grunt'; g1BaseCount = 10; g1Interval = 0.50;
        g2Type = 'tank'; g2BaseCount = 3; g2Interval = 1.65;
      }
    }
  }
  // ------------------------------------------
  // АРЕНА 2 (Главы 1–3): + blinker (фазовые щиты)
  // ------------------------------------------
  else if (arena === 2) {
    if (!isSecondHalf) {
      // Волны 1–9 цикла: акцент на скорость, рой и первые выходы блинкеров
      const step = cWave % 4;
      if (cWave === 1) {
        g1Type = 'scout'; g1BaseCount = 6; g1Interval = 0.50;
      } else if (step === 2) {
        g1Type = 'swarm'; g1BaseCount = 14; g1Interval = 0.05;
        g2Type = 'grunt'; g2BaseCount = 5; g2Interval = 0.60;
      } else if (step === 3) {
        g1Type = 'blinker'; g1BaseCount = 3; g1Interval = 0.95;
        g2Type = 'scout'; g2BaseCount = 5; g2Interval = 0.45;
      } else if (step === 0) {
        g1Type = 'tank'; g1BaseCount = 3; g1Interval = 1.70;
        g2Type = 'grunt'; g2BaseCount = 6; g2Interval = 0.58;
      } else {
        g1Type = 'blinker'; g1BaseCount = 4; g1Interval = 0.90;
        g2Type = 'grunt'; g2BaseCount = 6; g2Interval = 0.58;
      }
    } else {
      // Волны 11–19 цикла: массированные атаки блинкеров под прикрытием роя и танков
      const step = cWave % 4;
      if (step === 3) {
        g1Type = 'blinker'; g1BaseCount = 6; g1Interval = 0.82;
        g2Type = 'swarm'; g2BaseCount = 20; g2Interval = 0.045;
      } else if (step === 0) {
        g1Type = 'tank'; g1BaseCount = 4; g1Interval = 1.65;
        g2Type = 'blinker'; g2BaseCount = 5; g2Interval = 0.85;
      } else if (step === 1) {
        g1Type = 'swarm'; g1BaseCount = 26; g1Interval = 0.045;
        g2Type = 'scout'; g2BaseCount = 9; g2Interval = 0.38;
      } else {
        g1Type = 'blinker'; g1BaseCount = 6; g1Interval = 0.80;
        g2Type = 'scout'; g2BaseCount = 8; g2Interval = 0.40;
      }
    }
  }
  // ------------------------------------------
  // АРЕНА 3 (Главы 1–4): + goliath (сверхтяжелая броня)
  // ------------------------------------------
  else if (arena === 3) {
    if (!isSecondHalf) {
      // Волны 1–9 цикла: пехота, танки, блинкеры и одиночные голиафы с 5-й волны
      const step = cWave % 4;
      if (cWave <= 2) {
        g1Type = 'grunt'; g1BaseCount = 6; g1Interval = 0.60;
        g2Type = 'scout'; g2BaseCount = 4; g2Interval = 0.48;
      } else if (step === 3) {
        g1Type = 'tank'; g1BaseCount = 3; g1Interval = 1.70;
        g2Type = 'scout'; g2BaseCount = 6; g2Interval = 0.45;
      } else if (step === 0) {
        g1Type = (cWave >= 6) ? 'goliath' : 'tank';
        g1BaseCount = (g1Type === 'goliath') ? 2 : 3;
        g1Interval = (g1Type === 'goliath') ? 2.30 : 1.70;
        g2Type = 'grunt'; g2BaseCount = 6; g2Interval = 0.58;
      } else if (step === 1) {
        g1Type = 'blinker'; g1BaseCount = 4; g1Interval = 0.88;
        g2Type = 'swarm'; g2BaseCount = 15; g2Interval = 0.05;
      } else {
        g1Type = 'tank'; g1BaseCount = 3; g1Interval = 1.65;
        g2Type = 'blinker'; g2BaseCount = 4; g2Interval = 0.90;
      }
    } else {
      // Волны 11–19 цикла: тяжелые осадные колонны голиафов и танков
      const step = cWave % 4;
      if (step === 3) {
        g1Type = 'goliath'; g1BaseCount = 3; g1Interval = 2.20;
        g2Type = 'blinker'; g2BaseCount = 5; g2Interval = 0.82;
      } else if (step === 0) {
        g1Type = 'goliath'; g1BaseCount = 2; g1Interval = 2.30;
        g2Type = 'tank'; g2BaseCount = 4; g2Interval = 1.65;
      } else if (step === 1) {
        g1Type = 'swarm'; g1BaseCount = 24; g1Interval = 0.045;
        g2Type = 'goliath'; g2BaseCount = 2; g2Interval = 2.20;
      } else {
        g1Type = 'tank'; g1BaseCount = 5; g1Interval = 1.60;
        g2Type = 'scout'; g2BaseCount = 9; g2Interval = 0.38;
      }
    }
  }
  // ------------------------------------------
  // АРЕНА 4 (Главы 1–5): + emp_bomber (отключают башни во 2-й половине цикла)
  // ------------------------------------------
  else if (arena === 4) {
    if (!isSecondHalf) {
      // Волны 1–9 цикла: без EMP, но плотные связки 1–4 глав
      const step = cWave % 4;
      if (cWave === 1) {
        g1Type = 'grunt'; g1BaseCount = 7; g1Interval = 0.58;
      } else if (step === 2) {
        g1Type = 'blinker'; g1BaseCount = 4; g1Interval = 0.85;
        g2Type = 'scout'; g2BaseCount = 6; g2Interval = 0.42;
      } else if (step === 3) {
        g1Type = 'goliath'; g1BaseCount = 2; g1Interval = 2.25;
        g2Type = 'grunt'; g2BaseCount = 6; g2Interval = 0.55;
      } else if (step === 0) {
        g1Type = 'swarm'; g1BaseCount = 18; g1Interval = 0.045;
        g2Type = 'tank'; g2BaseCount = 3; g2Interval = 1.70;
      } else {
        g1Type = 'tank'; g1BaseCount = 4; g1Interval = 1.65;
        g2Type = 'blinker'; g2BaseCount = 4; g2Interval = 0.85;
      }
    } else {
      // Волны 11–19 цикла: подключаются EMP Bomber (строго дозированно, с интервалом 2.5с)
      const step = cWave % 4;
      if (step === 3) {
        g1Type = 'goliath'; g1BaseCount = 3; g1Interval = 2.20;
        g2Type = 'emp_bomber'; g2BaseCount = 2; g2Interval = 2.50;
      } else if (step === 0) {
        g1Type = 'blinker'; g1BaseCount = 6; g1Interval = 0.80;
        g2Type = 'emp_bomber'; g2BaseCount = 2; g2Interval = 2.60;
      } else if (step === 1) {
        g1Type = 'swarm'; g1BaseCount = 26; g1Interval = 0.045;
        g2Type = 'blinker'; g2BaseCount = 5; g2Interval = 0.82;
      } else {
        g1Type = 'tank'; g1BaseCount = 5; g1Interval = 1.60;
        g2Type = 'goliath'; g2BaseCount = 2; g2Interval = 2.20;
      }
    }
  }
  // ------------------------------------------
  // АРЕНА 5 (Главы 1–5, Финальный Апекс): альтернативная последовательность элиты
  // ------------------------------------------
  else {
    if (!isSecondHalf) {
      // Волны 1–9 цикла: сразу быстрые и бронированные комбинации в обратном порядке
      const step = cWave % 4;
      if (cWave === 1) {
        g1Type = 'scout'; g1BaseCount = 8; g1Interval = 0.45;
      } else if (step === 2) {
        g1Type = 'tank'; g1BaseCount = 3; g1Interval = 1.65;
        g2Type = 'blinker'; g2BaseCount = 4; g2Interval = 0.85;
      } else if (step === 3) {
        g1Type = 'swarm'; g1BaseCount = 20; g1Interval = 0.045;
        g2Type = 'scout'; g2BaseCount = 6; g2Interval = 0.40;
      } else if (step === 0) {
        g1Type = 'goliath'; g1BaseCount = 2; g1Interval = 2.20;
        g2Type = 'emp_bomber'; g2BaseCount = 1; g2Interval = 2.60;
      } else {
        g1Type = 'blinker'; g1BaseCount = 5; g1Interval = 0.82;
        g2Type = 'grunt'; g2BaseCount = 7; g2Interval = 0.52;
      }
    } else {
      // Волны 11–19 цикла: тотальный штурм всеми типами войск
      const step = cWave % 4;
      if (step === 3) {
        g1Type = 'swarm'; g1BaseCount = 30; g1Interval = 0.04;
        g2Type = 'emp_bomber'; g2BaseCount = 2; g2Interval = 2.50;
      } else if (step === 0) {
        g1Type = 'goliath'; g1BaseCount = 4; g1Interval = 2.10;
        g2Type = 'blinker'; g2BaseCount = 6; g2Interval = 0.78;
      } else if (step === 1) {
        g1Type = 'tank'; g1BaseCount = 5; g1Interval = 1.55;
        g2Type = 'emp_bomber'; g2BaseCount = 2; g2Interval = 2.50;
      } else {
        g1Type = 'goliath'; g1BaseCount = 3; g1Interval = 2.15;
        g2Type = 'swarm'; g2BaseCount = 24; g2Interval = 0.045;
      }
    }
  }

  // Масштабируем численность групп с ростом номера волны (от малого на старте к огромным армиям на 40+)
  let g1Count = Math.round(g1BaseCount * crowdScale);
  if (g1Type === 'swarm') {
    g1Count = Math.min(60, Math.max(12, Math.round(g1BaseCount * (0.9 + w * 0.045))));
    g1HpMod = 0.35;
  } else if (g1Type === 'goliath') {
    g1Count = Math.min(12, Math.max(1, Math.round(g1BaseCount * (0.8 + w * 0.025))));
  } else if (g1Type === 'tank') {
    g1Count = Math.min(16, Math.max(2, Math.round(g1BaseCount * (0.85 + w * 0.03))));
  } else if (g1Type === 'emp_bomber') {
    g1Count = Math.min(4, 1 + Math.floor(w / 22));
  } else {
    g1Count = Math.min(35, Math.max(4, g1Count));
  }

  let g2Count = 0;
  if (g2Type && g2BaseCount > 0) {
    g2Count = Math.round(g2BaseCount * crowdScale);
    if (g2Type === 'swarm') {
      g2Count = Math.min(50, Math.max(10, Math.round(g2BaseCount * (0.9 + w * 0.04))));
      g2HpMod = 0.35;
    } else if (g2Type === 'goliath') {
      g2Count = Math.min(8, Math.max(1, Math.round(g2BaseCount * (0.8 + w * 0.02))));
    } else if (g2Type === 'tank') {
      g2Count = Math.min(12, Math.max(2, Math.round(g2BaseCount * (0.85 + w * 0.025))));
    } else if (g2Type === 'emp_bomber') {
      g2Count = Math.min(3, 1 + Math.floor(w / 25)); // Не больше 1-3 штук, чтобы не глушить всю карту
    } else {
      g2Count = Math.min(28, Math.max(3, g2Count));
    }
  }

  // Распределение бюджета золота за волну между группами
  let g1BountyShare = (g2Type && g2Count > 0) ? 0.60 : 1.0;
  if (g1Type === 'swarm' && g2Type) g1BountyShare = 0.30;

  const g1Bounty = Math.max(1, Math.floor((targetWaveBounty * g1BountyShare) / g1Count));
  const proto1 = (typeof ENEMY_CONFIGS !== 'undefined' && ENEMY_CONFIGS[g1Type])
    ? ENEMY_CONFIGS[g1Type] : { baseHp: 40, baseSpeed: 55 };

  spawns.push({
    type: g1Type,
    isBoss: false,
    isMiniBoss: false,
    count: g1Count,
    hp: Math.max(10, Math.round(proto1.baseHp * hpScalingMult * g1HpMod)),
    speed: Math.min(180, Math.round(proto1.baseSpeed * spdMult)),
    bounty: g1Bounty,
    interval: g1Interval,
    clumps: (g1Type === 'swarm') ? Math.max(2, Math.ceil(g1Count / 10)) : 0
  });

  if (g2Type && g2Count > 0) {
    const g2Bounty = Math.max(1, Math.floor((targetWaveBounty * (1 - g1BountyShare)) / g2Count));
    const proto2 = (typeof ENEMY_CONFIGS !== 'undefined' && ENEMY_CONFIGS[g2Type])
      ? ENEMY_CONFIGS[g2Type] : { baseHp: 40, baseSpeed: 55 };

    spawns.push({
      type: g2Type,
      isBoss: false,
      isMiniBoss: false,
      count: g2Count,
      hp: Math.max(10, Math.round(proto2.baseHp * hpScalingMult * g2HpMod)),
      speed: Math.min(180, Math.round(proto2.baseSpeed * spdMult)),
      bounty: g2Bounty,
      interval: g2Interval,
      clumps: (g2Type === 'swarm') ? Math.max(2, Math.ceil(g2Count / 10)) : 0
    });
  }

  return { wave: w, delayAfter: 5.5, spawns };
}

// [ENG.Z]
function isOverdriveUnlocked() {
  if (typeof devMode !== 'undefined' && devMode) return true;
  if (typeof clearedLevels !== 'undefined' && (clearedLevels.includes(20) || clearedLevels.some(l => l >= 20))) return true;
  if (typeof maxUnlockedLevel === 'number' && maxUnlockedLevel > 20) return true;
  return false;
}
window.isOverdriveUnlocked = isOverdriveUnlocked;

function isEndlessUnlocked() {
  if (typeof devMode !== 'undefined' && devMode) return true;
  if (typeof clearedLevels !== 'undefined' && (clearedLevels.includes(15) || clearedLevels.some(l => l >= 15))) return true;
  if (typeof maxUnlockedLevel === 'number' && maxUnlockedLevel > 15) return true;
  return false;
}
window.isEndlessUnlocked = isEndlessUnlocked;

let upgradesPreviousSource = 'main';
let lastVictoryDiamondsReward = 2;
let hasClaimedX2ThisLevel = false;

// Persistent Save State & LocalStorage Synchronization: Game progress serialization, save, and load pipeline.
// --- Gifts & Shop State ---
let dailyGiftsClaimedDate = '';
let dailyGiftsClaimedCount = 0; // 0, 1, 2 или 3 в день
let timeModTier = 0; // 0 = locked, 1 = Tier 1, 2 = Tier 2
let shopPreviousSource = 'start';

// --- Daily Login Calendar State ---
let lastLoginClaimDate = '';
let loginStreakDay = 1;
let hasAutoShownDailyLoginModalThisSession = false;
let dailyLoginDismissedThisSession = false;

// --- Synth Pass / Battle Pass State ---
let bpXp = 0;
let bpPremiumPurchased = false;
let bpClaimedFree = {};
let bpClaimedPrem = {};
let unlockedPalettes = ['default'];
let activePalette = 'default';
let sessionMobKillsCount = 0;

// [ENG.AA]
function addBpXp(amount) {
  if (!amount || amount <= 0) return;
  bpXp += amount;
  saveGameSoon();
  if (typeof updateBpProgressUI === 'function') {
    updateBpProgressUI();
  }
}

// Покупка Premium Synth Pass за 300 💎
function buyBpPremiumWithDiamonds() {
  const COST = 300;
  if (bpPremiumPurchased) {
    if (typeof showHintToast === 'function') showHintToast(typeof t === 'function' ? t('already_unlocked') : 'Already Owned');
    return false;
  }
  if (diamonds < COST) {
    if (typeof showHintToast === 'function') showHintToast(typeof t === 'function' ? t('not_enough_diamonds') : 'Not enough Diamonds!');
    vibrate('warning');
    return false;
  }

  diamonds -= COST;
  bpPremiumPurchased = true;
  if (!unlockedPalettes.includes('cyber_gold')) {
    unlockedPalettes.push('cyber_gold');
  }
  updateDiamondUI();
  saveGame();
  sfx('upgrade');
  vibrate('medium');

  if (typeof renderBattlePassScreen === 'function') renderBattlePassScreen();
  if (typeof updatePaletteSelectDropdown === 'function') {
    updatePaletteSelectDropdown('settingPaletteSelect');
    updatePaletteSelectDropdown('bpPaletteSelect');
  }
  if (typeof showHintToast === 'function') showHintToast(typeof t === 'function' ? t('prem_unlocked') : 'Premium Pass Unlocked!');
  safeTrack('bp_premium_unlocked_diamonds', { cost: COST });
  return true;
}
window.buyBpPremiumWithDiamonds = buyBpPremiumWithDiamonds;

// Покупка тем в магазине за 💎
function buyThemeWithDiamonds(paletteId, cost) {
  if (!paletteId || !cost) return false;
  if (!unlockedPalettes) unlockedPalettes = ['default'];

  if (unlockedPalettes.includes(paletteId)) {
    equipTheme(paletteId);
    return true;
  }

  if (diamonds < cost) {
    if (typeof showHintToast === 'function') showHintToast(typeof t === 'function' ? t('not_enough_diamonds') : 'Not enough Diamonds!');
    vibrate('warning');
    return false;
  }

  diamonds -= cost;
  unlockedPalettes.push(paletteId);
  activePalette = paletteId;
  applyPaletteColors(paletteId);
  updateDiamondUI();
  saveGame();

  sfx('upgrade');
  vibrate('medium');
  if (typeof renderShopScreen === 'function') renderShopScreen();
  if (typeof updatePaletteSelectDropdown === 'function') {
    updatePaletteSelectDropdown('settingPaletteSelect');
    updatePaletteSelectDropdown('bpPaletteSelect');
  }
  safeTrack('theme_purchased', { theme: paletteId, cost: cost });
  return true;
}
window.buyThemeWithDiamonds = buyThemeWithDiamonds;

// Экипировка уже купленной темы
function equipTheme(paletteId) {
  if (!unlockedPalettes || !unlockedPalettes.includes(paletteId)) return false;
  activePalette = paletteId;
  applyPaletteColors(paletteId);
  if (typeof renderShopScreen === 'function') renderShopScreen();
  saveGameSoon();
  return true;
}
window.equipTheme = equipTheme;

// Вспомогательные функции конвертации HEX -> RGB и осветления
// [ENG.AB]
function hexToRgbObj(hex) {
  let h = String(hex || '#00e5ff').replace('#', '').trim();
  if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
  const num = parseInt(h, 16) || 0;
  const r = (num >> 16) & 255;
  const g = (num >> 8) & 255;
  const b = num & 255;
  return {
    r, g, b,
    cssRgb: `${r}, ${g}, ${b}`,
    norm: [+(r / 255).toFixed(3), +(g / 255).toFixed(3), +(b / 255).toFixed(3)]
  };
}

// [ENG.AC]
function mixHexWithWhite(hex, whiteRatio = 0.45) {
  const { r, g, b } = hexToRgbObj(hex);
  const mr = Math.round(r + (255 - r) * whiteRatio);
  const mg = Math.round(g + (255 - g) * whiteRatio);
  const mb = Math.round(b + (255 - b) * whiteRatio);
  return '#' + [mr, mg, mb].map(x => x.toString(16).padStart(2, '0')).join('');
}

// [ENG.ACM]
// Смешивание двух HEX-цветов для создания уникальных оттенков башен в кастомных темах
function mixHexColors(hex1, hex2, ratio = 0.5) {
  const cA = hexToRgbObj(hex1);
  const cB = hexToRgbObj(hex2);
  const r = Math.round(cA.r + (cB.r - cA.r) * ratio);
  const g = Math.round(cA.g + (cB.g - cA.g) * ratio);
  const b = Math.round(cA.b + (cB.b - cA.b) * ratio);
  return '#' + [r, g, b].map(x => x.toString(16).padStart(2, '0')).join('');
}

// [ENG.AD]
function darkenNormRgb(normArr, factor = 0.42) {
  return [
    +(normArr[0] * factor).toFixed(3),
    +(normArr[1] * factor).toFixed(3),
    +(normArr[2] * factor).toFixed(3)
  ];
}

// [ENG.AE]
function applyPaletteColors(paletteId) {
  const pId = (typeof NEON_PALETTES !== 'undefined' && NEON_PALETTES[paletteId]) ? paletteId : 'default';
  activePalette = pId;
  const def = (typeof NEON_PALETTES !== 'undefined' && NEON_PALETTES['default']) || {};
  const raw = (typeof NEON_PALETTES !== 'undefined' && NEON_PALETTES[pId]) || def;

  // 5 базовых цветовых слотов темы
  const c1 = raw.c1 || raw.primary || def.c1 || '#00e5ff';
  const c2 = raw.c2 || def.c2 || '#d946ef';
  const c3 = raw.c3 || raw.secondary || def.c3 || '#f05f9f';
  const c4 = raw.c4 || def.c4 || '#ff9100';
  const c5 = raw.c5 || def.c5 || '#38bdf8';
  const bg = raw.bg || def.bg || '#03050d';

  const rgb1 = hexToRgbObj(c1);
  const rgb2 = hexToRgbObj(c2);
  const rgb3 = hexToRgbObj(c3);
  const rgb4 = hexToRgbObj(c4);
  const rgb5 = hexToRgbObj(c5);

  const c1Light = mixHexWithWhite(c1, 0.48);
  const c2Light = mixHexWithWhite(c2, 0.48);
  const c3Light = mixHexWithWhite(c3, 0.45);
  const c4Light = mixHexWithWhite(c4, 0.45);
  const c5Light = mixHexWithWhite(c5, 0.45);

  // Для правой части туманности: в Cyber Gold берем теплый оранж/фуксию (c4/c3), в Blood Moon и Sakura — c3 (вместо фиолетового слота призм c2)
  const nebRightRgb = (pId === 'cyber_gold') ? rgb4 : ((pId === 'blood_moon' || pId === 'sakura_wave') ? rgb3 : rgb2);

  // Сохраняем глобальный объект текущей темы для Canvas (ui.js и engine.js)
  window.activeThemeColors = {
    id: pId,
    c1, c2, c3, c4, c5, bg,
    c1Light, c2Light, c3Light, c4Light, c5Light,
    rgb1, rgb2, rgb3, rgb4, rgb5,
    // Кластеры туманности: слева c1, справа nebRightRgb
    nebulaClusters: [
      { cx: 0.22, cy: 0.22, scale: 0.43, angle: 0.38, aspect: 0.65, intensity: 1.08, base: darkenNormRgb(rgb1.norm, 0.45), hot: rgb1.norm },
      { cx: 0.78, cy: 0.20, scale: 0.42, angle: -0.38, aspect: 0.65, intensity: 1.08, base: darkenNormRgb(nebRightRgb.norm, 0.45), hot: nebRightRgb.norm },
      { cx: 0.20, cy: 0.76, scale: 0.45, angle: -0.28, aspect: 0.70, intensity: 0.52, base: darkenNormRgb(rgb1.norm, 0.35), hot: rgb1.norm },
      { cx: 0.80, cy: 0.74, scale: 0.44, angle: 0.32, aspect: 0.70, intensity: 0.52, base: darkenNormRgb(nebRightRgb.norm, 0.35), hot: nebRightRgb.norm }
    ]
  };
  
  // Записываем все переменные в CSS :root
  if (typeof document !== 'undefined') {
    const root = document.documentElement;
    if (root) {
      root.style.setProperty('--c1', c1);
      root.style.setProperty('--c2', c2);
      root.style.setProperty('--c3', c3);
      root.style.setProperty('--c4', c4);
      root.style.setProperty('--c5', c5);
      root.style.setProperty('--bg-dark', bg);

      root.style.setProperty('--c1-rgb', rgb1.cssRgb);
      root.style.setProperty('--c2-rgb', rgb2.cssRgb);
      root.style.setProperty('--c3-rgb', rgb3.cssRgb);
      root.style.setProperty('--c4-rgb', rgb4.cssRgb);
      root.style.setProperty('--c5-rgb', rgb5.cssRgb);

      root.style.setProperty('--c1-light', c1Light);
      root.style.setProperty('--c2-light', c2Light);
      root.style.setProperty('--c3-light', c3Light);
      root.style.setProperty('--c4-light', c4Light);
      root.style.setProperty('--c5-light', c5Light);

      // Обратная совместимость со старыми переменными
      root.style.setProperty('--neon-primary', c1);
      root.style.setProperty('--neon-secondary', c3);
      root.style.setProperty('--neon-glow', `rgba(${rgb1.cssRgb}, 0.8)`);
    }
    if (document.body) {
      document.body.setAttribute('data-theme', pId);
    }
  }

  // Индивидуальные цвета для всех 7 башен (в default — оригинальные цвета, в других темах — сдвиг оттенков в RGB)
  if (typeof TOWER_CONFIGS !== 'undefined' && TOWER_CONFIGS.gun) {
    if (pId === 'default') {
      TOWER_CONFIGS.gun.color = '#00e5ff'; TOWER_CONFIGS.gun.glow = '#00e5ff';
      TOWER_CONFIGS.laser.color = '#f05f9f'; TOWER_CONFIGS.laser.glow = '#f05f9f';
      TOWER_CONFIGS.mortar.color = '#ff9100'; TOWER_CONFIGS.mortar.glow = '#ff9100';
      TOWER_CONFIGS.tesla.color = '#00ffcc'; TOWER_CONFIGS.tesla.glow = '#00ffcc';
      TOWER_CONFIGS.stasis.color = '#38bdf8'; TOWER_CONFIGS.stasis.glow = '#38bdf8';
      TOWER_CONFIGS.melter.color = '#e85268'; TOWER_CONFIGS.melter.glow = '#e477a3';
      TOWER_CONFIGS.railgun.color = '#a275df'; TOWER_CONFIGS.railgun.glow = '#b57fdd';
    } else {
      // В кастомных темах разводим башни по оттенкам, чтобы все 7 отличались друг от друга:
      const teslaCol = mixHexColors(c1, '#00ffcc', 0.45); // сдвиг от основного в мятно-изумрудный
      const stasisCol = mixHexColors(c5, '#38bdf8', 0.35); // холодный ледяной оттенок c5
      const melterCol = mixHexColors(c3, c4, 0.38); // кораллово-алый между Laser (c3) и Splash (c4)
      const railgunCol = mixHexColors(c2, '#a275df', 0.30); // благородный фиолетовый сдвиг от c2

      TOWER_CONFIGS.gun.color = c1; TOWER_CONFIGS.gun.glow = c1Light;
      TOWER_CONFIGS.laser.color = c3; TOWER_CONFIGS.laser.glow = c3Light;
      TOWER_CONFIGS.mortar.color = c4; TOWER_CONFIGS.mortar.glow = c4Light;
      TOWER_CONFIGS.tesla.color = teslaCol; TOWER_CONFIGS.tesla.glow = mixHexWithWhite(teslaCol, 0.35);
      TOWER_CONFIGS.stasis.color = stasisCol;TOWER_CONFIGS.stasis.glow = mixHexWithWhite(stasisCol, 0.40);
      TOWER_CONFIGS.melter.color = melterCol;TOWER_CONFIGS.melter.glow = mixHexWithWhite(melterCol, 0.35);
      TOWER_CONFIGS.railgun.color = railgunCol; TOWER_CONFIGS.railgun.glow = mixHexWithWhite(railgunCol, 0.38);
    }

    // Записываем индивидуальные RGB-переменные каждой башни в CSS :root для кнопок постройки
    if (typeof document !== 'undefined' && document.documentElement) {
      const root = document.documentElement;
      Object.keys(TOWER_CONFIGS).forEach(tKey => {
        const tRgb = hexToRgbObj(TOWER_CONFIGS[tKey].color);
        root.style.setProperty(`--tower-${tKey}`, TOWER_CONFIGS[tKey].color);
        root.style.setProperty(`--tower-${tKey}-rgb`, tRgb.cssRgb);
      });
    }
  }

  // Цвета мобов и боссов: в default — оригинальные цвета из data.js, в других темах — стандартизированные слоты c1..c5
  if (typeof ENEMY_CONFIGS !== 'undefined' && ENEMY_CONFIGS.grunt) {
    if (pId === 'default') {
      ENEMY_CONFIGS.grunt.color = '#f05f9f'; ENEMY_CONFIGS.grunt.glow = '#f05f9f';
      ENEMY_CONFIGS.scout.color = '#ff9100'; ENEMY_CONFIGS.scout.glow = '#ffaa33';
      ENEMY_CONFIGS.tank.color = '#a06fdc'; ENEMY_CONFIGS.tank.glow = '#825cc2';
      ENEMY_CONFIGS.swarm.color = '#00ffcc'; ENEMY_CONFIGS.swarm.glow = '#00ffcc';
      ENEMY_CONFIGS.blinker.color = '#3b82f6'; ENEMY_CONFIGS.blinker.glow = '#60a5fa';
      ENEMY_CONFIGS.goliath.color = '#8964c4'; ENEMY_CONFIGS.goliath.glow = '#7050a4';
      ENEMY_CONFIGS.emp_bomber.color = '#38bdf8'; ENEMY_CONFIGS.emp_bomber.glow = '#f05f9f';
      ENEMY_CONFIGS.hive_empress.color = '#00ffcc'; ENEMY_CONFIGS.hive_empress.glow = '#00ffcc';
      ENEMY_CONFIGS.chronos_warp.color = '#3b82f6'; ENEMY_CONFIGS.chronos_warp.glow = '#60a5fa';
      ENEMY_CONFIGS.titan_core.color = '#f97316'; ENEMY_CONFIGS.titan_core.glow = '#fb923c';
      ENEMY_CONFIGS.emp_overlord.color = '#38bdf8'; ENEMY_CONFIGS.emp_overlord.glow = '#f05f9f';
    } else {
      ENEMY_CONFIGS.grunt.color = c3; ENEMY_CONFIGS.grunt.glow = c3;
      ENEMY_CONFIGS.scout.color = c4; ENEMY_CONFIGS.scout.glow = c4Light;
      ENEMY_CONFIGS.tank.color = c2; ENEMY_CONFIGS.tank.glow = c2;
      ENEMY_CONFIGS.swarm.color = c5; ENEMY_CONFIGS.swarm.glow = c5;
      ENEMY_CONFIGS.blinker.color = c5; ENEMY_CONFIGS.blinker.glow = c5Light;
      ENEMY_CONFIGS.goliath.color = c2; ENEMY_CONFIGS.goliath.glow = c2;
      ENEMY_CONFIGS.emp_bomber.color = c1; ENEMY_CONFIGS.emp_bomber.glow = c3;
      ENEMY_CONFIGS.hive_empress.color = c5; ENEMY_CONFIGS.hive_empress.glow = c5;
      ENEMY_CONFIGS.chronos_warp.color = c1; ENEMY_CONFIGS.chronos_warp.glow = c5Light;
      ENEMY_CONFIGS.titan_core.color = c4; ENEMY_CONFIGS.titan_core.glow = c4Light;
      ENEMY_CONFIGS.emp_overlord.color = c1; ENEMY_CONFIGS.emp_overlord.glow = c3;
    }
  }

  // Перестраиваем SVG-иконки башен и обновляем живые сущности на поле и в очереди спавна
  if (typeof TOWER_ICONS !== 'undefined' && typeof buildTowerIconSvg === 'function') {
    Object.keys(TOWER_CONFIGS).forEach(k => {
      TOWER_ICONS[k] = buildTowerIconSvg(k);
    });
  }
  if (typeof towers !== 'undefined' && Array.isArray(towers)) {
    towers.forEach(t => {
      if (TOWER_CONFIGS[t.type]) {
        t.color = TOWER_CONFIGS[t.type].color;
        t.glow = TOWER_CONFIGS[t.type].glow;
      }
    });
  }
  if (typeof enemies !== 'undefined' && Array.isArray(enemies)) {
    enemies.forEach(e => {
      if (ENEMY_CONFIGS[e.type]) {
        e.color = ENEMY_CONFIGS[e.type].color;
        e.glow = ENEMY_CONFIGS[e.type].glow;
      }
    });
  }
  if (typeof spawnQueue !== 'undefined' && Array.isArray(spawnQueue)) {
    spawnQueue.forEach(sq => {
      if (ENEMY_CONFIGS[sq.type]) {
        sq.color = ENEMY_CONFIGS[sq.type].color;
        sq.glow = ENEMY_CONFIGS[sq.type].glow;
      }
    });
  }
  if (typeof initBuildPanel === 'function' && typeof window.__gameBooted !== 'undefined' && window.__gameBooted) {
    initBuildPanel();
  }
  if (typeof renderLoadoutWidgetBody === 'function' && typeof window.__gameBooted !== 'undefined' && window.__gameBooted) {
    renderLoadoutWidgetBody();
  }

  // Сброс кэшей Canvas для мгновенной перерисовки фона, логотипа, сетки и мобов
  if (typeof nebulaCache !== 'undefined') nebulaCache = null;
  if (typeof nebulaCacheKey !== 'undefined') nebulaCacheKey = '';
  if (typeof triangleLogoCache !== 'undefined') triangleLogoCache = null;
  if (typeof triangleLogoCacheKey !== 'undefined') triangleLogoCacheKey = '';
  if (typeof invalidateGridCache === 'function') invalidateGridCache();
  if (typeof GLOW_SPRITES !== 'undefined' && GLOW_SPRITES) {
    for (const k in GLOW_SPRITES) delete GLOW_SPRITES[k];
  }
  if (typeof NEON_DISC_SPRITES !== 'undefined' && NEON_DISC_SPRITES) {
    for (const k in NEON_DISC_SPRITES) delete NEON_DISC_SPRITES[k];
  }
  if (typeof ENEMY_SPRITE_CACHE !== 'undefined' && ENEMY_SPRITE_CACHE) {
    for (const k in ENEMY_SPRITE_CACHE) delete ENEMY_SPRITE_CACHE[k];
  }
  if (typeof TOWER_BASE_SPRITE_CACHE !== 'undefined' && TOWER_BASE_SPRITE_CACHE) {
    for (const k in TOWER_BASE_SPRITE_CACHE) delete TOWER_BASE_SPRITE_CACHE[k];
  }
  if (typeof clearVariant4HullCache === 'function') {
    clearVariant4HullCache();
  }
}

let reviveUsedThisMatch = false;
let reviveTimerInterval = null;
let reviveRemainingSeconds = 3;
let reviveSkipShowTimer = null;

let tutorialActive = false;
let tutorialLevel = null;
let tutorialStep = -1;
let tutorialTargetTower = null;
let tutorialDestCell = null;
let tutorialSeen = { l1: false, l2: false, l3: false };

let activePathTiles = [];
let WAYPOINTS = [];
let grid = [];
let pathCells = [];
let obstacleCells = [];

const SAVE_KEY = 'sectorDefenseTD_save_v1';
let saveGameTimer = null;

let waveStartGold = 100;

// Настройки разгона времени после паузы/загрузки
const RESUME_RAMP_DURATION = 1.5; // Длительность разгона всей игры в секундах (1.0 - 2.0)
const RESUME_RAMP_START_MULT = 0.5; // Начальный множитель скорости игры (0.5 = 50% от текущей скорости)

let resumeRampTimer = 0; // Таймер разгона игрового времени

// Локальная разморозка мобов (оставляем для микро-задержки мобов, если нужно)
const RESUME_THAW_DURATION = 0.3; 
const RESUME_START_SPEED_MULT = 0.2;

let activeBattleSave = null;
let battleUpgradeSnapshot = null; // Замороженный слепок Tech Tree для текущего боя
let resumeThawTimer = 0; // Таймер текущей разморозки

// [ENG.AF]
function getBattleUpgradeEffectiveLevel(key) {
  if (battleUpgradeSnapshot && typeof battleUpgradeSnapshot[key] === 'number') {
    const lvl = battleUpgradeSnapshot[key];
    if (lvl <= 10) return lvl;
    if (lvl <= 15) return lvl === 15 ? 16.5 : lvl;
    if (key === 'base_hp') return 16.5 + (lvl - 15);
    const k = lvl - 15;
    return 16.5 + 20 * (1 - Math.pow(0.95, k));
  }
  return getUpgradeEffectiveLevel(key);
}

// [ENG.AG]
function getBattleUpgradeRangeBonus(towerType, effLvl) {
  if (typeof getUpgradeRangeBonus === 'function') {
    return getUpgradeRangeBonus(towerType, effLvl);
  }
  const conf = TOWER_CONFIGS[towerType];
  if (!conf) return 0;
  if (effLvl <= 10) return effLvl * (conf.powerRange || 0);
  return 10 * (conf.powerRange || 0) + (effLvl - 10) * 0.01;
}

// [ENG.AH]
function saveActiveBattleSnapshot() {
  if (gameState !== 'PLAYING' && gameState !== 'PAUSED') return;
  if (baseHp <= 0) return;

  if (!battleUpgradeSnapshot) {
    battleUpgradeSnapshot = Object.assign({}, upgradeTreeData);
  }

  activeBattleSave = {
    isEndlessMode: !!isEndlessMode,
    isOverdriveMode: !!isOverdriveMode,
    currentLevel: currentLevel,
    currentLevelSection: currentLevelSection || 1,
    wave: wave,
    waveInProgress: !!waveInProgress,
    waveTimerActive: !!waveTimerActive,
    autoWaveTimeRemaining: autoWaveTimeRemaining || 0,
    waveTotalSpawnTime: waveTotalSpawnTime || 1.0,
    waveSpawnElapsedTime: waveSpawnElapsedTime || 0,
    spawnTimer: spawnTimer || 0,
    regularSpawnCounter: regularSpawnCounter || 0,
    bossAlertScheduled: !!bossAlertScheduled,
    bossAlertShown: !!bossAlertShown,
    activeBossAlertType: activeBossAlertType || null,
    gold: gold,
    baseHp: baseHp,
    matchStartBaseHp: matchStartBaseHp,
    reviveUsedThisMatch: !!reviveUsedThisMatch,
    sessionMobKillsCount: sessionMobKillsCount || 0,
    activeBattleLoadout: activeBattleLoadout ? activeBattleLoadout.slice() : selectedLoadout.slice(),
    upgradeSnapshot: Object.assign({}, battleUpgradeSnapshot),
    towers: towers.map(t => ({
      type: t.type,
      c: t.c,
      r: t.r,
      level: t.level,
      totalInvested: t.totalInvested,
      angle: t.angle || 0,
      disabledTimer: t.disabledTimer || 0
    })),
    enemies: enemies.map(e => ({
      // Если моба сохранили в момент прыжка Титана или отброса Revive — ставим его сразу в конечную точку маневра
      x: e.revivePushAnim ? e.revivePushAnim.endX : (e.dashAnim ? e.dashAnim.endX : e.x),
      y: e.revivePushAnim ? e.revivePushAnim.endY : (e.dashAnim ? e.dashAnim.endY : e.y),
      wpIndex: e.revivePushAnim ? e.revivePushAnim.endWp : (e.dashAnim ? e.dashAnim.endWp : e.wpIndex),
      laneOffset: e.laneOffset || 0,
      angle: e.angle || 0,
      type: e.type,
      isBoss: !!e.isBoss,
      isMiniBoss: !!e.isMiniBoss,
      isElite: !!e.isElite,
      isEnraged: !!e.isEnraged,
      shape: e.shape,
      color: e.color,
      glow: e.glow,
      hp: e.hp,
      maxHp: e.maxHp,
      speed: e.speed,
      baseSpeed: e.baseSpeed,
      bounty: e.bounty,
      radius: e.radius,
      shieldTimer: e.shieldTimer || 0,
      isShielded: !!e.isShielded,
      warpTimer: e.warpTimer || 0,
      dashTimer: e.dashTimer || 0,
      summonTimer: e.summonTimer || 0,
      empTimer: e.empTimer || 0,
      slowTimer: e.slowTimer || 0
    })),
    spawnQueue: spawnQueue.map(sq => Object.assign({}, sq))
  };
}

// [ENG.AI]
function clearActiveBattleSave() {
  battleUpgradeSnapshot = null;
  if (activeBattleSave !== null) {
    activeBattleSave = null;
    saveGameSoon();
  }
}

// [ENG.AJ]
function resumeSavedBattle() {
  if (!activeBattleSave) return;
  const snap = activeBattleSave;

  isEndlessMode = !!snap.isEndlessMode;
  isOverdriveMode = !!snap.isOverdriveMode;
  currentLevel = snap.currentLevel || 1;
  currentLevelSection = snap.currentLevelSection || 1;
  battleUpgradeSnapshot = snap.upgradeSnapshot ? Object.assign({}, snap.upgradeSnapshot) : Object.assign({}, upgradeTreeData);

  if (typeof battleStartedOnce !== 'undefined') battleStartedOnce = (snap.wave > 1 || !!snap.waveInProgress);
  if (typeof battlePathAlpha !== 'undefined') battlePathAlpha = (snap.wave > 1 || !!snap.waveInProgress) ? 0.0 : 1.0;

  activeBattleLoadout = (Array.isArray(snap.activeBattleLoadout) && snap.activeBattleLoadout.length > 0)
    ? snap.activeBattleLoadout.slice()
    : selectedLoadout.slice();

  if (reviveTimerInterval) { clearInterval(reviveTimerInterval); reviveTimerInterval = null; }
  musicSetDucked(false);
  music('battle');

  ['levelsScreen', 'victoryScreen', 'defeatScreen', 'startScreen', 'settingsScreen', 'upgradesScreen'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.classList.add('hidden');
  });

  document.getElementById('econHpSplitBadge').classList.remove('hidden');
  document.getElementById('levelWaveSplitBadge').classList.remove('hidden');
  document.getElementById('hudRightGroup').classList.remove('hidden');
  updateStartChapterLabel(false);
  document.getElementById('controlsWrapper').classList.remove('hidden');

  const waveBtn = document.getElementById('waveBtn');
  if (waveBtn) waveBtn.classList.remove('hidden');

  resetLevelState();

  if (isEndlessMode) {
    const arenaMapKey = 'L' + (Math.min(5, Math.max(1, currentLevelSection)) * 10);
    const mapCfg = MAP_CATALOG[arenaMapKey] || MAP_CATALOG.L20 || MAP_CATALOG.L1;
    if (mapCfg) buildLevelGeometry(mapCfg.path, mapCfg.cols, mapCfg.rows, mapCfg.blocked);
  }

  // Восстанавливаем точное состояние волн, таймеров и ресурсов
  gold = snap.gold;
  baseHp = snap.baseHp;
  matchStartBaseHp = snap.matchStartBaseHp || snap.baseHp;
  wave = snap.wave || 1;
  waveInProgress = !!snap.waveInProgress;
  waveTimerActive = !!snap.waveTimerActive;
  autoWaveTimeRemaining = snap.autoWaveTimeRemaining || 0;
  waveTotalSpawnTime = snap.waveTotalSpawnTime || 1.0;
  waveSpawnElapsedTime = snap.waveSpawnElapsedTime || 0;
  spawnTimer = snap.spawnTimer || 0;
  regularSpawnCounter = snap.regularSpawnCounter || 0;
  bossAlertScheduled = !!snap.bossAlertScheduled;
  bossAlertShown = !!snap.bossAlertShown;
  activeBossAlertType = snap.activeBossAlertType || null;
  reviveUsedThisMatch = !!snap.reviveUsedThisMatch;
  sessionMobKillsCount = snap.sessionMobKillsCount || 0;

  // Восстанавливаем очередь спауна и живых мобов на карте
  spawnQueue = Array.isArray(snap.spawnQueue) ? snap.spawnQueue.map(sq => Object.assign({}, sq)) : [];
  enemies = Array.isArray(snap.enemies) ? snap.enemies.map(e => Object.assign({}, e)) : [];

  // Включаем плавную разморозку мобов, если на поле есть враги
  resumeThawTimer = enemies.length > 0 ? RESUME_THAW_DURATION : 0;
  resumeRampTimer = RESUME_RAMP_DURATION; // <-- Запуск плавного разгона игры

  // Восстанавливаем все башни с использованием замороженного слепка Tech Tree
  if (Array.isArray(snap.towers)) {
    snap.towers.forEach(savedT => {
      const conf = TOWER_CONFIGS[savedT.type];
      if (!conf || !grid[savedT.r] || grid[savedT.r][savedT.c] !== 0) return;

      grid[savedT.r][savedT.c] = 2;
      const powerLvl = getBattleUpgradeEffectiveLevel(`${savedT.type}_power`);
      const dmgBonus = 1 + powerLvl * (conf.powerDmg || 0);
      const rateBonus = 1 + powerLvl * (conf.powerRate || 0);
      const rangeBonus = 1 + getBattleUpgradeRangeBonus(savedT.type, powerLvl);

      let calcDamage = (conf.damage || conf.dps || conf.baseDps || 0) * dmgBonus;
      let calcRange = conf.range * rangeBonus;
      let calcFireRate = conf.fireRate ? (conf.fireRate / rateBonus) : 0;

      const baseLockOnDelay = (savedT.type === 'laser' || savedT.type === 'melter')
        ? (typeof LOCK_ON_DELAY_HEAVY === 'number' ? LOCK_ON_DELAY_HEAVY : 0.5)
        : (typeof LOCK_ON_DELAY_LIGHT === 'number' ? LOCK_ON_DELAY_LIGHT : 0.1);
      const calcLockOnDelay = (savedT.type === 'mortar') ? baseLockOnDelay : (baseLockOnDelay / rateBonus);
      const calcMortarTravelTime = (savedT.type === 'mortar')
        ? ((typeof MORTAR_BASE_TRAVEL_TIME === 'number' ? MORTAR_BASE_TRAVEL_TIME : 1.0) / rateBonus)
        : undefined;
      let calcMelterRampTime = (savedT.type === 'melter') ? ((conf.rampTime || 4.0) / rateBonus) : undefined;
      let calcMelterCooldownTime = (savedT.type === 'melter') ? ((conf.cooldownTime || 4.0) / rateBonus) : 0;
      let calcSlowFactor = conf.slowFactor || 0.30;

      const targetLvl = Math.min(3, Math.max(1, savedT.level || 1));
      const dmgMult = conf.damageMultiplier || 1.4;
      const rngMult = conf.rangeMultiplier || 1.1;
      const rateMult = conf.rateMultiplier || 1.0;

      for (let l = 1; l < targetLvl; l++) {
        calcDamage *= dmgMult;
        calcRange *= rngMult;
        if (calcFireRate && rateMult !== 1.0) calcFireRate *= rateMult;
      }

      if (savedT.type === 'stasis' && targetLvl > 1) {
        calcSlowFactor = (targetLvl === 2) ? 0.40 : 0.50;
      }
      if (savedT.type === 'melter' && targetLvl > 1) {
        calcMelterRampTime = (targetLvl === 2 ? 4.4 : 4.8) / rateBonus;
        calcMelterCooldownTime = (targetLvl === 2 ? 3.6 : 3.2) / rateBonus;
      }

      towers.push({
        c: savedT.c,
        r: savedT.r,
        x: savedT.c * TILE_SIZE + TILE_SIZE / 2,
        y: savedT.r * TILE_SIZE + TILE_SIZE / 2,
        type: savedT.type,
        level: targetLvl,
        totalInvested: savedT.totalInvested || conf.cost,
        damage: calcDamage,
        range: calcRange,
        fireRate: calcFireRate,
        color: conf.color,
        glow: conf.glow,
        lastFire: 0,
        target: null,
        angle: savedT.angle || 0,
        lockOnDelay: calcLockOnDelay,
        lockOnTimer: 0,
        mortarTravelTime: calcMortarTravelTime,
        melterRampTime: calcMelterRampTime,
        melterCooldownTime: calcMelterCooldownTime,
        slowFactor: calcSlowFactor,
        slowDuration: conf.slowDuration || 1.4,
        disabledTimer: savedT.disabledTimer || 0,
        melterFireTimer: 0,
        melterCoolingTimer: 0
      });
    });
  }

  initBuildPanel();
  gameState = 'PLAYING';
  updateWaveCircle(0);
  updateUI();
  resizeCanvasAndCamera();
  lastTime = performance.now();
}
window.resumeSavedBattle = resumeSavedBattle;

// [ENG.AK]
let lastSaveTimestamp = 0;
let lastCloudPushTimestamp = 0;
let cloudSyncTimer = null;
const CLOUD_PUSH_THROTTLE_MS = 30000; // Не чаще 1 раза в 30 сек для фоновых автосейвов

function serializeSaveData() {
  lastSaveTimestamp = Date.now();
  return {
    version: 1,
    updatedAt: lastSaveTimestamp,
    clientId: (typeof getAnalyticsClientId === 'function') ? getAnalyticsClientId() : 'local',
    uid: (window.CloudBackend && window.CloudBackend.uid) ? window.CloudBackend.uid : null,
    diamonds,
    prisms,
    maxUnlockedLevel,
    clearedLevels,
    overdriveClearedLevels,
    levelStars,
    upgradeTreeData: Object.assign({}, upgradeTreeData),
    selectedLoadout,
    settings,
    tutorialSeen,
    dailyGiftsClaimedDate,
    dailyGiftsClaimedCount,
    timeModTier,
    lastLoginClaimDate,
    loginStreakDay,
    bpXp,
    bpPremiumPurchased,
    bpClaimedFree: Object.assign({}, bpClaimedFree),
    bpClaimedPrem: Object.assign({}, bpClaimedPrem),
    unlockedPalettes: unlockedPalettes.slice(),
    activePalette,
    endlessBestWavesBySection: Object.assign({}, endlessBestWavesBySection),
    endlessDailyRunsUsed,
    endlessDailyRunsDate,
    endlessMilestonesClaimed: Object.assign({}, endlessMilestonesClaimed),
    activeBattleSave
  };
}

// [ENG.AKM] Фоновая отправка сейва в Firebase (с защитой от частых вызовов)
function scheduleCloudSavePush(forceImmediate = false) {
  if (!window.CloudBackend || !window.CloudBackend.isConfigured()) return;

  if (cloudSyncTimer) {
    clearTimeout(cloudSyncTimer);
    cloudSyncTimer = null;
  }

  const now = Date.now();
  const elapsed = now - lastCloudPushTimestamp;

  if (forceImmediate || elapsed >= CLOUD_PUSH_THROTTLE_MS) {
    lastCloudPushTimestamp = now;
    window.CloudBackend.pushCloudSave(serializeSaveData());
  } else {
    cloudSyncTimer = setTimeout(() => {
      cloudSyncTimer = null;
      lastCloudPushTimestamp = Date.now();
      window.CloudBackend.pushCloudSave(serializeSaveData());
    }, CLOUD_PUSH_THROTTLE_MS - elapsed);
  }
}
window.scheduleCloudSavePush = scheduleCloudSavePush;

// [ENG.AL]
function saveGame(forceCloud = false) {
  try {
    const payload = serializeSaveData();
    const dataStr = JSON.stringify(payload);
    localStorage.setItem(SAVE_KEY, dataStr);
    if (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.Preferences) {
      window.Capacitor.Plugins.Preferences.set({ key: SAVE_KEY, value: dataStr })
        .catch(err => console.warn('Capacitor save error:', err));
    }
    scheduleCloudSavePush(!!forceCloud);
  } catch (e) {
    console.warn('SectorDefenseTD: save failed', e);
  }
}

// [ENG.AM]
function saveGameSoon() {
  if (saveGameTimer) clearTimeout(saveGameTimer);
  saveGameTimer = setTimeout(() => saveGame(false), 300);
}

// [ENG.AMM] Применение распакованного объекта сохранения к состоянию движка
function applyParsedSaveData(data) {
  if (!data || typeof data !== 'object') return false;

  if (typeof data.updatedAt === 'number') lastSaveTimestamp = data.updatedAt;
  if (typeof data.dailyGiftsClaimedDate === 'string') dailyGiftsClaimedDate = data.dailyGiftsClaimedDate;
  if (typeof data.dailyGiftsClaimedCount === 'number') dailyGiftsClaimedCount = data.dailyGiftsClaimedCount;
  if (typeof data.timeModTier === 'number') timeModTier = data.timeModTier;
  if (typeof data.lastLoginClaimDate === 'string') lastLoginClaimDate = data.lastLoginClaimDate;
  if (typeof data.loginStreakDay === 'number' && data.loginStreakDay >= 1 && data.loginStreakDay <= 7) loginStreakDay = data.loginStreakDay;

  if (typeof data.bpXp === 'number' && data.bpXp >= 0) bpXp = data.bpXp;
  if (typeof data.bpPremiumPurchased === 'boolean') bpPremiumPurchased = data.bpPremiumPurchased;
  if (data.bpClaimedFree && typeof data.bpClaimedFree === 'object') bpClaimedFree = data.bpClaimedFree;
  if (data.bpClaimedPrem && typeof data.bpClaimedPrem === 'object') bpClaimedPrem = data.bpClaimedPrem;
  if (Array.isArray(data.unlockedPalettes) && data.unlockedPalettes.length > 0) {
    unlockedPalettes = data.unlockedPalettes.filter(p => typeof p === 'string');
  }
  if (typeof data.activePalette === 'string') activePalette = data.activePalette;
  applyPaletteColors(activePalette);

  if (typeof data.diamonds === 'number' && data.diamonds >= 0) diamonds = data.diamonds;
  prisms = typeof data.prisms === 'number' ? Math.max(0, Math.floor(data.prisms)) : 0;
  if (typeof data.maxUnlockedLevel === 'number' && data.maxUnlockedLevel >= 1) {
    maxUnlockedLevel = Math.min(data.maxUnlockedLevel, TOTAL_LEVELS);
  }
  if (Array.isArray(data.clearedLevels)) {
    clearedLevels = data.clearedLevels.filter(n => typeof n === 'number');
  }
  if (data.overdriveClearedLevels && typeof data.overdriveClearedLevels === 'object') {
    overdriveClearedLevels = data.overdriveClearedLevels;
  }
  if (data.levelStars && typeof data.levelStars === 'object') {
    levelStars = data.levelStars;
  }
  if (data.endlessBestWavesBySection && typeof data.endlessBestWavesBySection === 'object') {
    endlessBestWavesBySection = Object.assign({ 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 }, data.endlessBestWavesBySection);
  } else if (typeof data.endlessBestWave === 'number') {
    endlessBestWavesBySection[1] = data.endlessBestWave;
  }
  if (typeof data.endlessDailyRunsUsed === 'number' && data.endlessDailyRunsUsed >= 0) endlessDailyRunsUsed = data.endlessDailyRunsUsed;
  if (typeof data.endlessDailyRunsDate === 'string') endlessDailyRunsDate = data.endlessDailyRunsDate;
  if (data.endlessMilestonesClaimed && typeof data.endlessMilestonesClaimed === 'object') {
    endlessMilestonesClaimed = data.endlessMilestonesClaimed;
  }
  resetEndlessDailyRunsIfNeeded();
  if (data.upgradeTreeData && typeof data.upgradeTreeData === 'object') {
    Object.keys(upgradeTreeData).forEach(key => {
      const v = data.upgradeTreeData[key];
      if (typeof v === 'number' && v >= 0) upgradeTreeData[key] = v;
    });
  }
  if (Array.isArray(data.selectedLoadout) && data.selectedLoadout.length > 0) {
    selectedLoadout = data.selectedLoadout.filter(t => TOWER_CONFIGS[t]);
  }
  if (data.settings && typeof data.settings === 'object') {
    Object.assign(settings, data.settings);
    settings.screenShakeEnabled = settings.screenShakeEnabled !== false;
    if (typeof sfxSetEnabled === 'function') sfxSetEnabled(settings.sfxEnabled !== false);
  }
  if (data.tutorialSeen && typeof data.tutorialSeen === 'object') {
    if (typeof data.tutorialSeen.l1 === 'boolean') tutorialSeen.l1 = data.tutorialSeen.l1;
    if (typeof data.tutorialSeen.l2 === 'boolean') tutorialSeen.l2 = data.tutorialSeen.l2;
    if (typeof data.tutorialSeen.l3 === 'boolean') tutorialSeen.l3 = data.tutorialSeen.l3;
    Object.keys(data.tutorialSeen).forEach(k => {
      if (k.startsWith('towerUnlock_l') && typeof data.tutorialSeen[k] === 'boolean') {
        tutorialSeen[k] = data.tutorialSeen[k];
      }
    });
  }
  if (data.activeBattleSave && typeof data.activeBattleSave === 'object') {
    activeBattleSave = data.activeBattleSave;
  } else {
    activeBattleSave = null;
  }

  return true;
}

// [ENG.AMN] Умная синхронизация с Firebase после старта игры (не блокирует UI)
async function syncWithCloudSaveIfNeeded() {
  if (!window.CloudBackend || !window.CloudBackend.isConfigured()) return false;
  try {
    const cloudData = await window.CloudBackend.pullCloudSave();
    if (!cloudData || typeof cloudData !== 'object') {
      // В облаке ещё пусто — отправляем текущий локальный прогресс
      scheduleCloudSavePush(true);
      return false;
    }

    const cloudLvl = Number(cloudData.maxUnlockedLevel) || 1;
    const localLvl = Number(maxUnlockedLevel) || 1;
    const cloudXp = Number(cloudData.bpXp) || 0;
    const localXp = Number(bpXp) || 0;
    const cloudTs = Number(cloudData.updatedAt) || 0;
    const localTs = Number(lastSaveTimestamp) || 0;

    // Принимаем облачный сейв, если там открыт более высокий уровень, больше опыта BP или он свежее при равном прогрессе
    const isCloudAhead = (cloudLvl > localLvl) ||
      (cloudLvl === localLvl && cloudXp > localXp) ||
      (cloudLvl === localLvl && cloudXp === localXp && cloudTs > localTs + 5000);

    if (isCloudAhead && gameState === 'START') {
      applyParsedSaveData(cloudData);
      saveGame(false);
      if (typeof updateDiamondUI === 'function') updateDiamondUI();
      if (typeof updatePrismUI === 'function') updatePrismUI();
      if (typeof renderLevelsGrid === 'function') renderLevelsGrid();
      if (typeof updateUpgradeButtonsLock === 'function') updateUpgradeButtonsLock();
      if (typeof updateBpProgressUI === 'function') updateBpProgressUI();
      return true;
    } else if (localLvl > cloudLvl || localXp > cloudXp) {
      // Локальный сейв прогрессивнее облачного — обновляем облако
      scheduleCloudSavePush(true);
    }
  } catch (e) {}
  return false;
}
window.syncWithCloudSaveIfNeeded = syncWithCloudSaveIfNeeded;

// [ENG.AN]
async function loadGame() {
  let raw = null;

  if (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.Preferences) {
    try {
      const { value } = await window.Capacitor.Plugins.Preferences.get({ key: SAVE_KEY });
      if (value) raw = value;
    } catch (e) {
      console.warn('Capacitor load error:', e);
    }
  }

  if (!raw) {
    try {
      raw = localStorage.getItem(SAVE_KEY);
    } catch (e) {
      console.warn('SectorDefenseTD: localStorage unavailable, starting fresh', e);
      return false;
    }
  }

  if (!raw) return false;

  let data;
  try {
    data = JSON.parse(raw);
  } catch (e) {
    console.warn('SectorDefenseTD: save data corrupt, starting fresh', e);
    return false;
  }

  return applyParsedSaveData(data);
}
// [ENG.AO]
function safeTrack(name, params) {
  try {
    if (typeof trackEvent === 'function') trackEvent(name, params);
  } catch (e) { }
}

// Map Geometry & Path Grid Construction: Path nodes, cell blocking, and grid topology initialization.
// [ENG.AP]
function buildLevelGeometry(pathNodes, colsCount, rowsCount, blockedCells) {
  COLS = colsCount || 10;
  ROWS = rowsCount || 7;
  grid = Array(ROWS).fill(null).map(() => Array(COLS).fill(0));
  activePathTiles = pathNodes;
  pathCells = [];
  obstacleCells = [];

  for (let i = 0; i < pathNodes.length - 1; i++) {
    const p1 = pathNodes[i];
    const p2 = pathNodes[i + 1];
    const cStep = Math.sign(p2.c - p1.c);
    const rStep = Math.sign(p2.r - p1.r);
    let curC = p1.c;
    let curR = p1.r;

    while (curC !== p2.c || curR !== p2.r) {
      if (curR >= 0 && curR < ROWS && curC >= 0 && curC < COLS) grid[curR][curC] = 1;
      pathCells.push({ c: curC, r: curR, dirX: cStep, dirY: rStep });
      curC += cStep;
      curR += rStep;
    }
  }

  const lastNode = pathNodes[pathNodes.length - 1];
  const prevCell = pathCells[pathCells.length - 1];
  const lastDirX = prevCell ? prevCell.dirX : 0;
  const lastDirY = prevCell ? prevCell.dirY : 1;
  if (lastNode.r >= 0 && lastNode.r < ROWS && lastNode.c >= 0 && lastNode.c < COLS) {
    grid[lastNode.r][lastNode.c] = 1;
  }
  pathCells.push({ c: lastNode.c, r: lastNode.r, dirX: lastDirX, dirY: lastDirY });

  const lastVisit = new Map();
  const visitCounts = new Map();
  pathCells.forEach((cell, idx) => {
    const key = `${cell.c},${cell.r}`;
    lastVisit.set(key, idx);
    visitCounts.set(key, (visitCounts.get(key) || 0) + 1);
  });

  const totalCells = pathCells.length;
  const D = 23;
  const half = TILE_SIZE / 2;

  for (let i = 0; i < totalCells; i++) {
    const cell = pathCells[i];
    const key = `${cell.c},${cell.r}`;
    cell.isLowerLayer = (lastVisit.get(key) !== i);
    cell.isIntersection = (visitCounts.get(key) > 1);

    let inDir, outDir;
    if (i === 0) {
      inDir = { x: pathCells[1].c - cell.c, y: pathCells[1].r - cell.r };
      outDir = inDir;
    } else if (i === totalCells - 1) {
      outDir = { x: cell.c - pathCells[i - 1].c, y: cell.r - pathCells[i - 1].r };
      inDir = outDir;
    } else {
      inDir = { x: cell.c - pathCells[i - 1].c, y: cell.r - pathCells[i - 1].r };
      outDir = { x: pathCells[i + 1].c - cell.c, y: pathCells[i + 1].r - cell.r };
    }

    cell.inDir = inDir;
    cell.outDir = outDir;
    cell.isTurn = (inDir.x !== outDir.x || inDir.y !== outDir.y);
    const cx = cell.c * TILE_SIZE + half;
    const cy = cell.r * TILE_SIZE + half;

    if (!cell.isTurn) {
      const nx = -inDir.y;
      const ny = inDir.x;
      cell.rails = [
        { x1: cx - inDir.x * half - nx * D, y1: cy - inDir.y * half - ny * D, x2: cx + inDir.x * half - nx * D, y2: cy + inDir.y * half - ny * D },
        { x1: cx - inDir.x * half + nx * D, y1: cy - inDir.y * half + ny * D, x2: cx + inDir.x * half + nx * D, y2: cy + inDir.y * half + ny * D }
      ];
    } else {
      const innerR = half - D; // 12px — внутренний угол
      const outerR = half + D; // 58px — концентрический внешний угол (ширина коридора 2*D = 46px)

      const makeCornerCurve = (sideSign, rCorner) => {
        const startX = cx - inDir.x * half + outDir.x * (sideSign * D);
        const startY = cy - inDir.y * half + outDir.y * (sideSign * D);
        const endX = cx + outDir.x * half - inDir.x * (sideSign * D);
        const endY = cy + outDir.y * half - inDir.y * (sideSign * D);
        const cornerX = cx - inDir.x * (sideSign * D) + outDir.x * (sideSign * D);
        const cornerY = cy - inDir.y * (sideSign * D) + outDir.y * (sideSign * D);
        return { startX, startY, cornerX, cornerY, endX, endY, r: rCorner };
      };

      cell.turnCurves = [
        makeCornerCurve(1, innerR),
        makeCornerCurve(-1, outerR)
      ];
    }
  }

  // Строим гладкую траекторию: каждый поворот разбиваем на 24 микро-сегмента Безье (R = 28px),
  // чтобы кривизна поворота была абсолютно непрерывной без угловых ступенек
  const rawWaypoints = pathNodes.map(p => ({
    x: p.c * TILE_SIZE + TILE_SIZE / 2,
    y: p.r * TILE_SIZE + TILE_SIZE / 2
  }));

  if (rawWaypoints.length <= 2) {
    WAYPOINTS = rawWaypoints;
  } else {
    const smoothWps = [rawWaypoints[0]];
    const CORNER_CUT = 28;
    const ARC_SEGMENTS = 24;

    for (let i = 1; i < rawWaypoints.length - 1; i++) {
      const prev = rawWaypoints[i - 1];
      const curr = rawWaypoints[i];
      const next = rawWaypoints[i + 1];

      const v1x = curr.x - prev.x;
      const v1y = curr.y - prev.y;
      const len1 = Math.hypot(v1x, v1y) || 1;

      const v2x = next.x - curr.x;
      const v2y = next.y - curr.y;
      const len2 = Math.hypot(v2x, v2y) || 1;

      const cut = Math.min(CORNER_CUT, len1 * 0.45, len2 * 0.45);
      if (cut < 2) {
        smoothWps.push(curr);
        continue;
      }

      const pStart = {
        x: curr.x - (v1x / len1) * cut,
        y: curr.y - (v1y / len1) * cut
      };
      const pEnd = {
        x: curr.x + (v2x / len2) * cut,
        y: curr.y + (v2y / len2) * cut
      };

      for (let s = 0; s <= ARC_SEGMENTS; s++) {
        const t = s / ARC_SEGMENTS;
        const invT = 1 - t;
        smoothWps.push({
          x: invT * invT * pStart.x + 2 * invT * t * curr.x + t * t * pEnd.x,
          y: invT * invT * pStart.y + 2 * invT * t * curr.y + t * t * pEnd.y
        });
      }
    }

    smoothWps.push(rawWaypoints[rawWaypoints.length - 1]);
    WAYPOINTS = smoothWps;
  }

  if (Array.isArray(blockedCells)) {
    blockedCells.forEach(bc => {
      if (bc.r >= 0 && bc.r < ROWS && bc.c >= 0 && bc.c < COLS && grid[bc.r][bc.c] === 0) {
        grid[bc.r][bc.c] = 3;
        obstacleCells.push({ c: bc.c, r: bc.r });
      }
    });
  }
}

let towers = [];
let enemies = [];
let projectiles = [];
let particles = [];
let shockwaves = [];
let lightningBolts = [];
let spawnQueue = [];
let spawnTimer = 0;

let perfMode = 'high';
let perfDecided = false;
let perfSampleFrames = 0;
let perfSampleTime = 0;

// Meta-Upgrade Tech Tree & Player Loadout Management: Tower unlocks, loadout slots, and skill tree node handlers.
// [ENG.AQ]
function getMaxUpgradeStep() {
  const lvl = getLoadoutReferenceLevel();
  if (lvl < 11) return 0;
  if (lvl <= 20) return 6;
  if (lvl <= 30) return 8;
  return 10;
}

// [ENG.AR]
function handleNodeClick(key, stepIndex) {
  const currentVal = upgradeTreeData[key] || 0;
  if (devMode) {
    upgradeTreeData[key] = Math.max(0, stepIndex);
    updateDiamondUI();
    updatePrismUI();
    renderUpgradeTree();
    saveGameSoon();
    return;
  }

  if (stepIndex <= currentVal) return;
  const targetStep = currentVal + 1;
  if (stepIndex !== targetStep) return;

  if (currentVal >= 15 && !isScalingBranch(key)) {
    sfx('denied');
    showHintToast(typeof t === 'function' ? t('branch_ascended_max') : 'Branch is ASCENDED MAX (Lvl 15)');
    return;
  }

  const maxStep = getMaxUpgradeStep();
  const isPhase2UnlockedGlobally = getLoadoutReferenceLevel() >= 31 || maxUnlockedLevel >= 31 || (typeof clearedLevels !== 'undefined' && clearedLevels.includes(30));

  if (targetStep <= 10) {
    if (targetStep > maxStep) {
      let lvlNeeded = 11;
      if (targetStep > 8) lvlNeeded = 31;
      else if (targetStep > 6) lvlNeeded = 21;
      sfx('denied');
      showHintToast(typeof t === 'function' ? t('unlocks_on_level_n', { n: lvlNeeded }) : `Unlocks on Level ${lvlNeeded}`);
      return;
    }
  } else {
    if (!isPhase2UnlockedGlobally) {
      sfx('denied');
      showHintToast(typeof t === 'function' ? t('unlocks_on_level_n', { n: 31 }) : 'Unlocks on Level 31');
      return;
    }
    // Проверка для входа в ASC: все ветки должны быть 10/10
    if (!areAllBranchesMaxPhase1()) {
      sfx('denied');
      showHintToast(typeof t === 'function' ? t('upgrade_all_branches_10') : 'Upgrade all branches to 10/10 first to unlock ASC');
      return;
    }
  }

  const { diamonds: costD, prisms: costP } = getUpgradeCostForLevel(targetStep);

  if (diamonds >= costD && prisms >= costP) {
    diamonds -= costD;
    prisms -= costP;
    upgradeTreeData[key] = targetStep;
    sfx('confirm');
    updateDiamondUI();
    updatePrismUI();
    renderUpgradeTree();
    saveGameSoon();
    safeTrack('upgrade_purchased', { key, step: targetStep });
  } else {
    sfx('denied');
    if (diamonds < costD && prisms < costP) {
      showHintToast(typeof t === 'function' ? t('not_enough_diamonds_prisms') : 'Not enough Diamonds & Prisms!');
    } else if (diamonds < costD) {
      showHintToast(typeof t === 'function' ? t('not_enough_diamonds') : 'Not enough Diamonds!');
    } else {
      showHintToast(typeof t === 'function' ? t('not_enough_prisms') : 'Not enough Prisms!');
    }
  }
}

// [ENG.AS]
function getLoadoutReferenceLevel() {
  return Math.max(maxUnlockedLevel, currentLevel || 1);
}

// [ENG.AT]
function getLoadoutStartLevel() {
  for (let l = 1; l <= TOTAL_LEVELS; l++) {
    const pool = LEVELS_DATA[l] && LEVELS_DATA[l].unlockedTowers;
    if (pool && pool.length > LOADOUT_SIZE) return l;
  }
  return TOTAL_LEVELS + 1;
}

// [ENG.AU]
function getTowerUnlockLevel(type) {
  for (let l = 1; l <= TOTAL_LEVELS; l++) {
    const pool = LEVELS_DATA[l] && LEVELS_DATA[l].unlockedTowers;
    if (pool && pool.includes(type)) return l;
  }
  return 1;
}

// [ENG.AV]
function getPlayerUnlockedTowers() {
  if (devMode) return Object.keys(TOWER_CONFIGS);
  const highestLvl = Math.max(maxUnlockedLevel || 1, currentLevel || 1);
  const canonical = Object.keys(TOWER_CONFIGS);
  return canonical.filter(t => getTowerUnlockLevel(t) <= highestLvl);
}

// [ENG.AW]
function getBuildPanelPool(lvl) {
  if (devMode) return Object.keys(TOWER_CONFIGS);
  const highestLvl = Math.max(maxUnlockedLevel || 1, lvl || 1);
  const loadoutStart = getLoadoutStartLevel(); // 11

  // Если игрок в принципе еще не дошел до 11 уровня (ранняя игра) —
  // показываем 3 первыe башни (Gatling, Laser, Mortar), блокируя незаблокированные по уровню
  if (highestLvl < loadoutStart) {
    return ['gun', 'laser', 'mortar'];
  }

  // Если игрок дошел до 11 уровня и выше — на ЛЮБОМ уровне используются
  // башни из его зафиксированного боевого лодаута
  const pool = (activeBattleLoadout && activeBattleLoadout.length > 0)
    ? activeBattleLoadout
    : selectedLoadout;
  return (pool && pool.length > 0) ? pool.slice() : ['gun'];
}

// [ENG.AX]
function isTowerActiveThisLevel(type) {
  if (devMode) return true;
  const loadoutStart = getLoadoutStartLevel();

  if (isEndlessMode) {
    const pool = (activeBattleLoadout && activeBattleLoadout.length > 0) ? activeBattleLoadout : selectedLoadout;
    return pool.includes(type);
  }

  const highestLvl = Math.max(maxUnlockedLevel || 1, currentLevel || 1);
  if (highestLvl < loadoutStart) {
    const curUnlocked = (LEVELS_DATA[currentLevel] && LEVELS_DATA[currentLevel].unlockedTowers) || ['gun'];
    return curUnlocked.includes(type);
  }

  const pool = (activeBattleLoadout && activeBattleLoadout.length > 0)
    ? activeBattleLoadout
    : selectedLoadout;
  return pool.includes(type);
}

// [ENG.AY]
function computeDefaultLoadout(lvl, pool) {
  const prevLvl = lvl - 1;
  const prevPool = (prevLvl >= 1 && LEVELS_DATA[prevLvl] && LEVELS_DATA[prevLvl].unlockedTowers)
    ? LEVELS_DATA[prevLvl].unlockedTowers : [];
  const newlyUnlocked = pool.filter(t => !prevPool.includes(t));

  // Базовый набор из уже выбранных башен (или сохраняем предыдущие разблокированные)
  let picks = (selectedLoadout && selectedLoadout.length > 0)
    ? selectedLoadout.filter(t => pool.includes(t))
    : prevPool.slice(0, LOADOUT_SIZE);

  // Новая башня заменяет только последний свободный слот, либо добавляется в конец
  newlyUnlocked.forEach(t => {
    if (!picks.includes(t)) {
      if (picks.length < LOADOUT_SIZE) {
        picks.push(t);
      } else {
        // Если слоты полные, заменяем последний слот, сохраняя Gatling (gun) на 1-м месте
        picks[LOADOUT_SIZE - 1] = t;
      }
    }
  });

  // Дозаполняем слоты до ровно LOADOUT_SIZE башен
  for (const t of pool) {
    if (picks.length >= LOADOUT_SIZE) break;
    if (!picks.includes(t)) picks.push(t);
  }

  return { picks: picks.slice(0, LOADOUT_SIZE), newlyUnlocked };
}

let loadoutSyncedUpToLevel = 0;

// [ENG.AZ]
function refreshLoadoutForProgress() {
  const loadoutStart = getLoadoutStartLevel();
  const progressRef = getLoadoutReferenceLevel();
  const availableTowers = (typeof getPlayerUnlockedTowers === 'function')
    ? getPlayerUnlockedTowers()
    : ['gun'];

  if (progressRef < loadoutStart) {
    const priorLvl = loadoutStart - 1;
    const tierPool = (LEVELS_DATA[priorLvl] && LEVELS_DATA[priorLvl].unlockedTowers)
      ? LEVELS_DATA[priorLvl].unlockedTowers.slice() : availableTowers.slice(0, LOADOUT_SIZE);
    selectedLoadout = tierPool;
    return;
  }

  const ref = Math.min(progressRef, TOTAL_LEVELS);
  const pool = (LEVELS_DATA[ref] && LEVELS_DATA[ref].unlockedTowers) ? LEVELS_DATA[ref].unlockedTowers : availableTowers;

  if (ref > loadoutSyncedUpToLevel || !Array.isArray(selectedLoadout) || selectedLoadout.length === 0) {
    const { picks } = computeDefaultLoadout(ref, pool);
    selectedLoadout = picks;
    loadoutSyncedUpToLevel = ref;
  } else {
    let valid = selectedLoadout.filter(t => availableTowers.includes(t) && pool.includes(t));
    for (const t of pool) {
      if (valid.length >= LOADOUT_SIZE) break;
      if (availableTowers.includes(t) && !valid.includes(t)) valid.push(t);
    }
    selectedLoadout = valid.slice(0, LOADOUT_SIZE);
  }
}

// Game Match Lifecycle & State Controller: Level start, pause, hardware back button, and level reset routines.
// [ENG.BA]
function startSpecificLevel(lvl) {
  refreshLoadoutForProgress();
  reallyStartLevel(lvl);
}

// [ENG.BB]
function startEndlessMatch() {
  isEndlessMode = true;
  isOverdriveMode = false;
  currentLevel = 1;

  if (typeof battleStartedOnce !== 'undefined') battleStartedOnce = false;
  if (typeof battlePathAlpha !== 'undefined') battlePathAlpha = 1.0;

  if (typeof refreshLoadoutForProgress === 'function') refreshLoadoutForProgress();
  activeBattleLoadout = selectedLoadout.slice();

  if (reviveTimerInterval) { clearInterval(reviveTimerInterval); reviveTimerInterval = null; }
  musicSetDucked(false);
  music('battle');

  document.getElementById('levelsScreen').classList.add('hidden');
  document.getElementById('victoryScreen').classList.add('hidden');
  document.getElementById('defeatScreen').classList.add('hidden');
  document.getElementById('startScreen').classList.add('hidden');
  document.getElementById('settingsScreen').classList.add('hidden');
  document.getElementById('upgradesScreen').classList.add('hidden');

  document.getElementById('econHpSplitBadge').classList.remove('hidden');
  document.getElementById('levelWaveSplitBadge').classList.remove('hidden');
  document.getElementById('hudRightGroup').classList.remove('hidden');
  updateStartChapterLabel(false);
  document.getElementById('controlsWrapper').classList.remove('hidden');

  const waveBtn = document.getElementById('waveBtn');
  if (waveBtn) waveBtn.classList.remove('hidden');

  resetLevelState();
  const arenaMapKey = 'L' + (Math.min(5, Math.max(1, currentLevelSection)) * 10);
  const mapCfg = MAP_CATALOG[arenaMapKey] || MAP_CATALOG.L20 || MAP_CATALOG.L1;
  if (mapCfg) {
    buildLevelGeometry(mapCfg.path, mapCfg.cols, mapCfg.rows, mapCfg.blocked);
  }
  let baseGold = 150;
  if (bpClaimedPrem[15] || bpClaimedPrem['15']) {
    baseGold = Math.round(baseGold * 1.15);
  }
  gold = baseGold;
  waveStartGold = gold;
  baseHp = 10 + Math.round(getUpgradeEffectiveLevel('base_hp'));
  matchStartBaseHp = baseHp;
  wave = 1;

  initBuildPanel();
  updateUI();
  resizeCanvasAndCamera();
  gameState = 'PLAYING';
  updateUI();
  lastTime = performance.now();
  safeTrack('endless_start', { runsUsed: endlessDailyRunsUsed });
  battleUpgradeSnapshot = Object.assign({}, upgradeTreeData);
  saveActiveBattleSnapshot();
  saveGameSoon();
}

// [ENG.BC]
function reallyStartLevel(lvl) {
  isEndlessMode = false;
  // Сброс анимации дорожки для нового боя:
  if (typeof battleStartedOnce !== 'undefined') battleStartedOnce = false;
  if (typeof battlePathAlpha !== 'undefined') battlePathAlpha = 1.0;
  
  // Убеждаемся, что лодаут игрока валиден перед новым боем
  if (typeof refreshLoadoutForProgress === 'function') {
    refreshLoadoutForProgress();
  }
  // ФИКСИРУЕМ башни для ЭТОГО боя (снимок не изменится при смене лодаута в паузе)
  activeBattleLoadout = selectedLoadout.slice();
  
  if (reviveTimerInterval) { clearInterval(reviveTimerInterval); reviveTimerInterval = null; }
  musicSetDucked(false);
  music('battle');
  currentLevel = lvl;
  document.getElementById('levelsScreen').classList.add('hidden');
  document.getElementById('victoryScreen').classList.add('hidden');
  document.getElementById('defeatScreen').classList.add('hidden');
  document.getElementById('startScreen').classList.add('hidden');
  document.getElementById('settingsScreen').classList.add('hidden');
  document.getElementById('upgradesScreen').classList.add('hidden');

  document.getElementById('econHpSplitBadge').classList.remove('hidden');
  document.getElementById('levelWaveSplitBadge').classList.remove('hidden');
  document.getElementById('hudRightGroup').classList.remove('hidden');
  updateStartChapterLabel(false);
  document.getElementById('controlsWrapper').classList.remove('hidden');

  const waveBtn = document.getElementById('waveBtn');
  if (waveBtn) waveBtn.classList.remove('hidden');

  if (devMode) {
    const customSpawner = document.getElementById('devCustomSpawner');
    if (customSpawner) customSpawner.classList.remove('hidden');
  }

  resetLevelState();
  if (bpClaimedPrem[15] || bpClaimedPrem['15']) {
    gold = Math.round(gold * 1.15);
  }
  waveStartGold = gold;
  battleUpgradeSnapshot = Object.assign({}, upgradeTreeData);
  saveActiveBattleSnapshot();
  saveGameSoon();
  initBuildPanel();
  gameState = 'PLAYING';
  updateUI();
  resizeCanvasAndCamera();
  lastTime = performance.now();
  initTutorialForLevel(lvl);
  safeTrack('level_start', { level: lvl });
}

// [ENG.BD]
let finalWaveSpawned = false;

function resetLevelState() {
  if (typeof stopNormalModePreview === 'function') stopNormalModePreview();
  if (reviveTimerInterval) { clearInterval(reviveTimerInterval); reviveTimerInterval = null; }
  reviveUsedThisMatch = false;
  sessionMobKillsCount = 0;
  cameraShakeTimer = 0;
  cameraShakeMaxDur = 0;
  cameraShakeIntensity = 0;

  const lvlConfig = LEVELS_DATA[currentLevel];
  gold = lvlConfig ? lvlConfig.startGold : 100;
  const initialBaseHp = (lvlConfig && lvlConfig.startHp !== undefined) ? lvlConfig.startHp : 10;
  baseHp = isOverdriveMode ? 1 : (initialBaseHp + Math.round(getUpgradeEffectiveLevel('base_hp')));
  matchStartBaseHp = baseHp;
  regularSpawnCounter = 0;

  wave = 1;
  waveInProgress = false;
  finalWaveSpawned = false;
  autoWaveTimeRemaining = 0;
  waveTimerActive = false;
  fieldClearDelayTimer = 0;
  isWaveTimerAccelerated = false;
  victoryDelayTimer = 0;
  towers = [];
  enemies = [];
  projectiles = [];
  particles = [];
  shockwaves = [];
  lightningBolts = [];
  spawnQueue = [];
  bossAlertScheduled = false;
  bossAlertShown = false;
  activeBossAlertType = null;
  hideIncomingAlert();
  hideNewTowerBanner();

  if (lvlConfig && lvlConfig.mapId && MAP_CATALOG[lvlConfig.mapId]) {
    const mapCfg = MAP_CATALOG[lvlConfig.mapId];
    buildLevelGeometry(mapCfg.path, mapCfg.cols, mapCfg.rows, mapCfg.blocked);
  }

  camZoom = 0;

  deselectTower();
  const btn = document.getElementById('waveBtn');
  const btnText = document.getElementById('waveBtnText');
  if (btn) btn.disabled = false;
  if (btnText) btnText.textContent = (typeof t === 'function' ? t('go') : 'Go');
  updateWaveCircle(0);
  updateUI();
  if (devMode && typeof refreshDevDropdowns === 'function') refreshDevDropdowns();
}

// [ENG.BE]
function nextLevel() {
  if (currentLevel < TOTAL_LEVELS) {
    startSpecificLevel(currentLevel + 1);
  } else {
    showLevelSelect();
  }
}

// [ENG.BF]
function retryLevel() {
  if (isEndlessMode) {
    const status = getEndlessEntryStatus();
    // [ENG.BG]
    const launch = () => {
      endlessDailyRunsUsed++;
      saveGame();
      startEndlessMatch();
    };

    if (status.type === 'free') {
      launch();
    } else if (status.type === 'ad') {
      if (typeof showAdPlaceholder === 'function') {
        showAdPlaceholder(launch, null);
      } else {
        launch();
      }
    } else if (status.type === 'diamonds' || status.type === 'diamond') {
      const cost = status.cost || 25;
      if (diamonds < cost) {
        if (typeof showHintToast === 'function') showHintToast(`Need ${cost} Diamonds for entry!`);
        return;
      }
      diamonds -= cost;
      updateDiamondUI();
      launch();
    }
  } else {
    reallyStartLevel(currentLevel);
  }
}

// [ENG.BH]
function togglePause() {
  if (typeof handleHudSettingsClick === 'function') {
    handleHudSettingsClick();
  }
}

// [ENG.BI]
function forcePauseForBackground() {
  if (gameState === 'PLAYING' || gameState === 'PAUSED') {
    saveActiveBattleSnapshot();
  }
  if (devInputOpen || Date.now() < suppressBackgroundPauseUntil) {
    saveGame();
    return;
  }
  sfxStopBeams();
  musicSuspend();
  if (gameState === 'PLAYING') {
    gameState = 'PAUSED';
    if (typeof showSettings === 'function') {
      showSettings('combat');
    }
  }
  saveGame();
}

let lastBackPressTime = 0;
let lastHardwareBackRun = 0;

// [ENG.BJ]
function handleHardwareBack() {
  const now = Date.now();
  // Защита от дребезга системных событий
  if (now - lastHardwareBackRun < 300) return;
  lastHardwareBackRun = now;

  const giveUpModal = document.getElementById('giveUpConfirmModal');
  if (giveUpModal && !giveUpModal.classList.contains('hidden')) {
    if (typeof cancelGiveUp === 'function') cancelGiveUp();
    return;
  }

  const dailyModal = document.getElementById('dailyLoginModal');
  if (dailyModal && !dailyModal.classList.contains('hidden')) {
    if (typeof closeDailyLoginModal === 'function') closeDailyLoginModal();
    return;
  }

  const gameCompModal = document.getElementById('gameCompletionModal');
  if (gameCompModal && !gameCompModal.classList.contains('hidden')) {
    if (typeof closeGameCompletionModal === 'function') closeGameCompletionModal();
    return;
  }

  const bpScreen = document.getElementById('battlePassScreen');
  if (bpScreen && !bpScreen.classList.contains('hidden')) {
    if (typeof closeBattlePassScreen === 'function') closeBattlePassScreen();
    return;
  }

  const settingsEl = document.getElementById('settingsScreen');
  if (settingsEl && !settingsEl.classList.contains('hidden')) {
    if (typeof closeSettings === 'function') closeSettings();
    return;
  }

  const shopEl = document.getElementById('shopScreen');
  if (shopEl && !shopEl.classList.contains('hidden')) {
    if (typeof closeShopScreen === 'function') closeShopScreen();
    return;
  }

  const upgradesEl = document.getElementById('upgradesScreen');
  if (upgradesEl && !upgradesEl.classList.contains('hidden')) {
    if (typeof closeUpgradesScreen === 'function') closeUpgradesScreen();
    return;
  }

  const levelsEl = document.getElementById('levelsScreen');
  if (levelsEl && !levelsEl.classList.contains('hidden')) {
    if (typeof showStartScreen === 'function') showStartScreen();
    return;
  }

  const victoryEl = document.getElementById('victoryScreen');
  if (victoryEl && !victoryEl.classList.contains('hidden')) {
    if (typeof showLevelSelectFromGame === 'function') showLevelSelectFromGame();
    return;
  }

  const defeatEl = document.getElementById('defeatScreen');
  if (defeatEl && !defeatEl.classList.contains('hidden')) {
    if (typeof showLevelSelectFromGame === 'function') showLevelSelectFromGame();
    return;
  }

  if (gameState === 'PAUSED') {
    if (typeof closeSettings === 'function') closeSettings();
    return;
  }

  if (gameState === 'PLAYING') {
    if (typeof handleHudSettingsClick === 'function') handleHudSettingsClick();
    return;
  }

  // Строгая изоляция выхода: сработает только на экране START
  if (gameState === 'START') {
    if (now - lastBackPressTime < 2000) {
      const AppPlugin = window.Capacitor?.Plugins?.App || window.App;
      if (AppPlugin && typeof AppPlugin.exitApp === 'function') {
        AppPlugin.exitApp();
      }
    } else {
      lastBackPressTime = now;
      if (typeof showHintToast === 'function') {
        showHintToast(typeof t === 'function' ? t('tap_back_exit') : 'Tap Back one more time to close game');
      }
    }
  }
}
window.handleHardwareBack = handleHardwareBack;

// Match Result & Victory/Defeat Handlers: Star calculations, rewards, revive prompt, and victory/defeat sequences.
// [ENG.BK]
function calculateLevelStarsAndReward(lvl, currentHp, startingHp) {
  let earnedStars = 1;
  if (isOverdriveMode) {
    earnedStars = (currentHp > 0) ? 3 : 1;
  } else {
    const hpRatio = startingHp > 0 ? (currentHp / startingHp) : 1;
    if (hpRatio >= 0.999) {
      earnedStars = 3;
    } else if (hpRatio >= 0.5) {
      earnedStars = 2;
    } else {
      earnedStars = 1;
    }
  }

  const prevBestStars = levelStars[lvl] || 0;
  let rewardDiamonds = 0;
  let rewardKey = 'farm_reward';
  let rewardLabel = 'FARM REWARD';

  if (!isOverdriveMode && earnedStars > prevBestStars) {
    const deltaStars = earnedStars - prevBestStars;
    rewardDiamonds = deltaStars * 2;
    rewardKey = (prevBestStars === 0) ? 'first_clear_bonus' : 'star_upgrade_bonus';
    rewardLabel = (prevBestStars === 0) 
      ? (typeof t === 'function' ? t('first_clear_bonus') : 'FIRST CLEAR BONUS') 
      : (typeof t === 'function' ? t('star_upgrade_bonus') : 'STAR UPGRADE BONUS');
    levelStars[lvl] = earnedStars;
    if (!clearedLevels.includes(lvl)) {
      clearedLevels.push(lvl);
    }
  } else {
    if (lvl <= 20) rewardDiamonds = 1;
    else if (lvl <= 40) rewardDiamonds = 2;
    else rewardDiamonds = 3;
    rewardKey = 'farm_reward';
    rewardLabel = (typeof t === 'function' ? t('farm_reward') : 'FARM REWARD');
  }

  return { stars: earnedStars, reward: rewardDiamonds, rewardLabel, rewardKey };
}

// [ENG.BL] Универсальный показ вознаграждаемой рекламы (РСЯ / Web SDK)
async function showAdPlaceholder(onRewarded, onNotRewarded) {
  const bridge = window.NativeYandexAdsBridge || window.NativeAdsBridge;

  // 1. Показ через нативный мост РСЯ в приложении
  if (bridge && typeof bridge.showRewardedAd === 'function') {
    try {
      if (!isAdsInitialized) {
        await initAdsBridge();
      }

      const isReady = isRewardAdReady || (typeof bridge.isRewardedAdReady === 'function' && bridge.isRewardedAdReady());

      if (isReady) {
        activeAdCallbacks = {
          onRewarded: onRewarded || null,
          onNotRewarded: onNotRewarded || null,
          rewardedFlag: false
        };
        logAdEvent('Calling NativeBridge.showRewardedAd()...');

        if (typeof suppressBackgroundPause === 'function') suppressBackgroundPause(60000);
        bridge.showRewardedAd();
        return;
      } else {
        logAdEvent('Ad not ready yet, triggering preload and showing toast...');
        preloadRewardedAd();
        const toastMsg = typeof t === 'function' ? t('ad_not_ready') : 'Video is loading, please check network connection.';
        if (typeof showHintToast === 'function') showHintToast(toastMsg);
        if (typeof onNotRewarded === 'function') onNotRewarded();
        return;
      }
    } catch (e) {
      const errStr = (e && e.message) ? e.message : String(e);
      if (window.AdDiagnostics) window.AdDiagnostics.lastError = errStr;
      logAdEvent('Native Show Exception: ' + errStr);
      const toastMsg = typeof t === 'function' ? t('ad_not_ready') : 'Video is loading, please check network connection.';
      if (typeof showHintToast === 'function') showHintToast(toastMsg);
      if (typeof onNotRewarded === 'function') onNotRewarded();
      return;
    }
  }

  // 2. Показ через веб-версию РСЯ (при запуске в браузере с подключенным AdvManager)
  if (window.Ya && window.Ya.Context && window.Ya.Context.AdvManager) {
    let webRewarded = false;
    logAdEvent('Calling Web AdvManager (rewarded)...');
    window.Ya.Context.AdvManager.render({
      blockId: REWARDED_AD_UNIT_ID,
      type: 'rewarded',
      platform: 'touch',
      onRewarded: function(isRewarded) {
        webRewarded = !!isRewarded;
        logAdEvent('Web onRewarded: ' + webRewarded);
      },
      onClose: function() {
        logAdEvent('Web Ad Closed');
        if (webRewarded) {
          if (typeof onRewarded === 'function') onRewarded();
        } else {
          if (typeof onNotRewarded === 'function') onNotRewarded();
        }
      },
      onError: function(err) {
        const errStr = JSON.stringify(err);
        if (window.AdDiagnostics) window.AdDiagnostics.lastError = errStr;
        logAdEvent('Web Ad Error: ' + errStr);
        const toastMsg = typeof t === 'function' ? t('ad_not_ready') : 'Video is loading, please check network connection.';
        if (typeof showHintToast === 'function') showHintToast(toastMsg);
        if (typeof onNotRewarded === 'function') onNotRewarded();
      }
    });
    return;
  }

  // 3. Если нет рекламного плагина и нет интернета — информируем игрока и отклоняем награду
  logAdEvent('Ad bridge unavailable');
  const toastMsg = typeof t === 'function' ? t('ad_not_ready') : 'Video is loading, please check network connection.';
  if (typeof showHintToast === 'function') showHintToast(toastMsg);
  if (typeof onNotRewarded === 'function') onNotRewarded();
}

// [ENG.BP]
function getStandardAdIconSvg() {
  return `<svg width="18" height="15" viewBox="0 0 16 13" fill="none" style="flex:none; margin-right:6px;"><rect x="0.8" y="0.8" width="14.4" height="11.4" rx="2.5" fill="none" stroke="#ffffff" stroke-width="1.6"/><polygon points="6,3.5 11,6.5 6,9.5" fill="#ffffff"/></svg>`;
}

// [ENG.BQ]
function claimX2Reward() {
  if (hasClaimedX2ThisLevel) return;
  const claimBtn = document.getElementById('claimX2Btn');

  // [ENG.BR]
  const executeGrant = () => {
    hasClaimedX2ThisLevel = true;
    diamonds += lastVictoryDiamondsReward;
    updateDiamondUI();
    if (claimBtn) {
      claimBtn.disabled = true;
      const claimedLabel = typeof t === 'function' ? t('claimed_x2') : 'CLAIMED x2';
      claimBtn.innerHTML = `<span style="display:inline-flex; align-items:center; gap:4px;">${claimedLabel} (+${lastVictoryDiamondsReward} <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linejoin="round"><polygon points="6 3 18 3 22 9 12 22 2 9" fill="currentColor" fill-opacity="0.25"/><polyline points="2 9 12 13 22 9"/><line x1="12" y1="22" x2="12" y2="13"/></svg>)</span>`;
    }
    sfx('reward');
    saveGame();
  };

  showAdPlaceholder(executeGrant, null);
}

// [ENG.BS]
function claimOverdriveBonusPrism() {
  if (hasClaimedX2ThisLevel) return;
  const claimBtn = document.getElementById('claimX2Btn');

  // [ENG.BT]
  const executeGrant = () => {
    hasClaimedX2ThisLevel = true;
    prisms += 1;
    if (typeof updatePrismUI === 'function') updatePrismUI();
    if (claimBtn) {
      claimBtn.disabled = true;
      const prismSvg = `
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linejoin="round" style="vertical-align: middle; display: inline-block; margin: 0 3px;">
          <polygon points="12 2 21 12 12 22 3 12" fill="currentColor" fill-opacity="0.25"/>
          <polyline points="3 12 12 15 21 12"/>
          <line x1="12" y1="22" x2="12" y2="22"/>
        </svg>`;
      const claimedPlus1Label = typeof t === 'function' ? t('claimed_plus_1') : 'CLAIMED +1';
      claimBtn.innerHTML = `<span style="display:inline-flex; align-items:center;">${claimedPlus1Label} ${prismSvg}</span>`;
    }
    sfx('reward');
    saveGame();
  };

  showAdPlaceholder(executeGrant, null);
}

// [ENG.BU]
function restoreNormalVictoryRewardBox() {
  const rewardBox = document.getElementById('victoryRewardBox');
  const isHyperion = (typeof activePalette !== 'undefined' && activePalette === 'matrix_green');
  const borderCol = isHyperion ? '#3b82f6' : '#00e5ff';
  const labelCol = isHyperion ? '#93c5fd' : '#8ef3ff';
  const dFill = isHyperion ? 'rgba(59,130,246,.28)' : 'rgba(0,229,255,.25)';
  const diamondsLabel = typeof t === 'function' ? t('diamonds_upper') : 'DIAMONDS';
  if (rewardBox) {
    rewardBox.style.setProperty('--chip-border', borderCol);
    rewardBox.style.setProperty('--chip-label', labelCol);
    rewardBox.innerHTML = `
      <span class="reward-label" id="victoryRewardBadgeType">${diamondsLabel}</span>
      <div style="display:flex; align-items:center; gap:6px;">
        <span class="reward-amount" id="victoryRewardVal">+2</span>
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="${borderCol}" stroke-width="2.2" stroke-linejoin="round">
          <polygon points="6 3 18 3 22 9 12 22 2 9" fill="${dFill}"/>
          <polyline points="2 9 12 13 22 9"/><line x1="12" y1="22" x2="12" y2="13"/>
        </svg>
      </div>
    `;
  }
}

let victoryFanfareTimer = null;

// [ENG.BV]
function playVictoryFanfare() {
  const stack = document.querySelector('#victoryScreen .result-stack');
  if (!stack) return;

  if (victoryFanfareTimer) {
    clearTimeout(victoryFanfareTimer);
    victoryFanfareTimer = null;
  }

  const existing = document.getElementById('victoryFanfareRays');
  if (existing && existing.parentNode) {
    existing.parentNode.removeChild(existing);
  }

  const rays = document.createElement('div');
  rays.className = 'victory-fanfare-rays';
  rays.id = 'victoryFanfareRays';
  stack.insertBefore(rays, stack.firstChild);
}

// [ENG.BW]
function triggerVictory() {
  gameState = 'VICTORY';
  if (typeof syncTopHudVisibility === 'function') syncTopHudVisibility();
  const defeatScreen = document.getElementById('defeatScreen');
  if (defeatScreen) defeatScreen.classList.add('hidden');
  sfxStopBeams();
  music('win');
  sfx('victory');
  vibrate('light');
  const { stars, reward, rewardLabel, rewardKey } = calculateLevelStarsAndReward(currentLevel, baseHp, matchStartBaseHp);
  lastVictoryDiamondsReward = reward;
  hasClaimedX2ThisLevel = false;

  if (!isOverdriveMode) {
    restoreNormalVictoryRewardBox();
    diamonds += reward;
    addBpXp(25);
    updateDiamondUI();
    renderVictoryStars(stars);
    playVictoryFanfare();

    const badgeTypeEl = document.getElementById('victoryRewardBadgeType');
    if (badgeTypeEl) {
      const isHyperion = (typeof activePalette !== 'undefined' && activePalette === 'matrix_green');
      badgeTypeEl.textContent = rewardLabel;
      badgeTypeEl.style.color = (rewardKey === 'first_clear_bonus' || rewardKey === 'star_upgrade_bonus') ? '#f59e0b' : (isHyperion ? '#93c5fd' : '#8ef3ff');
    }

    const rewardValEl = document.getElementById('victoryRewardVal');
    if (rewardValEl) rewardValEl.textContent = `+${reward}`;

    const claimBtn = document.getElementById('claimX2Btn');
    if (claimBtn) {
      claimBtn.disabled = false;
      claimBtn.classList.remove('hidden');
      const activeIcon = getStandardAdIconSvg();
      const claimX2Label = typeof t === 'function' ? t('claim_x2') : 'CLAIM x2';
      claimBtn.innerHTML = `${activeIcon}<span>${claimX2Label}</span>`;
      claimBtn.onclick = claimX2Reward;
    }
  } else {
    const isFirstOverdriveClear = !overdriveClearedLevels[currentLevel];
    let gainedPrisms = 0;
    let gainedDiamonds = 0;
    let odRewardLabel = typeof t === 'function' ? t('hardcore_farm') : 'HARDCORE FARM';

    if (isFirstOverdriveClear) {
      const isBossLvl = (currentLevel % LEVELS_PER_SECTION === 0);
      gainedPrisms = isBossLvl ? 5 : 3;
      gainedDiamonds = isBossLvl ? 30 : 15;
      odRewardLabel = typeof t === 'function' ? t('hardcore_clear') : 'HARDCORE CLEAR';
      overdriveClearedLevels[currentLevel] = true;
    } else {
      if (currentLevel <= 20) gainedDiamonds = 3;
      else if (currentLevel <= 40) gainedDiamonds = 4;
      else gainedDiamonds = 5;
      gainedPrisms = 0;
      odRewardLabel = typeof t === 'function' ? t('hardcore_farm') : 'HARDCORE FARM';
    }

    diamonds += gainedDiamonds;
    prisms += gainedPrisms;
    addBpXp(50);
    updateDiamondUI();
    if (typeof updatePrismUI === 'function') updatePrismUI();
    renderVictoryStars(3);
    playVictoryFanfare();

    const rewardBox = document.getElementById('victoryRewardBox');
    if (rewardBox) {
      rewardBox.style.setProperty('--chip-border', '#f05f9f');
      rewardBox.style.setProperty('--chip-label', '#ffd1f4');

      const diamondSvg = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#00e5ff" stroke-width="2.2" stroke-linejoin="round" style="flex:none; filter: drop-shadow(0 0 5px rgba(0,229,255,0.7));"><polygon points="6 3 18 3 22 9 12 22 2 9" fill="rgba(0,229,255,.25)"/><polyline points="2 9 12 13 22 9"/><line x1="12" y1="22" x2="12" y2="13"/></svg>`;
      const prismSvg = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#d946ef" stroke-width="2.2" stroke-linejoin="round" style="flex:none; filter: drop-shadow(0 0 5px rgba(217,70,239,0.7));"><polygon points="12 2 21 12 12 22 3 12" fill="rgba(217,70,239,.25)"/><polyline points="3 12 12 15 21 12"/><line x1="12" y1="22" x2="12" y2="22"/></svg>`;

      if (gainedPrisms > 0) {
        rewardBox.innerHTML = `
          <span class="reward-label" id="victoryRewardBadgeType">${odRewardLabel}</span>
          <div class="reward-row-content">
            <span class="reward-amount" id="victoryRewardVal">+${gainedDiamonds}</span>
            ${diamondSvg}
            <span class="reward-sep">|</span>
            <span class="reward-amount">+${gainedPrisms}</span>
            ${prismSvg}
          </div>
        `;
      } else {
        rewardBox.innerHTML = `
          <span class="reward-label" id="victoryRewardBadgeType">${odRewardLabel}</span>
          <div class="reward-row-content">
            <span class="reward-amount" id="victoryRewardVal">+${gainedDiamonds}</span>
            ${diamondSvg}
          </div>
        `;
      }
    }

    const claimBtn = document.getElementById('claimX2Btn');
    if (claimBtn) {
      claimBtn.disabled = false;
      claimBtn.classList.remove('hidden');

      const adSvg = getStandardAdIconSvg();
      const prismSvg = `
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#d946ef" stroke-width="2.2" stroke-linejoin="round" style="vertical-align: middle; display: inline-block; margin: 0 4px;">
          <polygon points="12 2 21 12 12 22 3 12" fill="rgba(217,70,239,.35)"/>
          <polyline points="3 12 12 15 21 12"/>
          <line x1="12" y1="22" x2="12" y2="22"/>
        </svg>`;

      const claimPlus1Label = typeof t === 'function' ? t('claim_plus_1') : 'CLAIM +1';
      claimBtn.innerHTML = `
        ${adSvg}
        <span style="display:inline-flex; align-items:center;">${claimPlus1Label} ${prismSvg}</span>
      `;
      claimBtn.onclick = claimOverdriveBonusPrism;
    }
  }

  setTimeout(() => sfx('reward'), 760);

  const wasUpgradesLocked = !(devMode || getLoadoutReferenceLevel() >= getLoadoutStartLevel());
  const isFirstClear = currentLevel >= maxUnlockedLevel;

  if (currentLevel >= maxUnlockedLevel && maxUnlockedLevel < TOTAL_LEVELS) {
    maxUnlockedLevel = currentLevel + 1;
  }
  refreshLoadoutForProgress();
  renderLevelsGrid();
  updateUpgradeButtonsLock();

  const nowUnlocked = (devMode || getLoadoutReferenceLevel() >= getLoadoutStartLevel());
  pendingUpgradeUnlockFx = wasUpgradesLocked && nowUnlocked;
  pendingLoadoutRevealFx = pendingUpgradeUnlockFx;

  // [ENG.BX]
  const showVictory = () => {
    document.getElementById('victoryScreen').classList.remove('hidden');
    showLoadoutWidgetIn('loadoutAnchor-victory');
    playVictoryUnlockFx();
    if (currentLevel === 50) {
      showGameCompletionModal();
    }
  };

  saveGame();
  safeTrack('level_complete', { level: currentLevel, stars, reward, isOverdrive: isOverdriveMode });

  if (!isOverdriveMode && isFirstClear && typeof hasMilestoneForLevel === 'function' && hasMilestoneForLevel(currentLevel)) {
    showMilestoneSequence(currentLevel, showVictory);
  } else {
    showVictory();
  }
  clearActiveBattleSave();
}

// [ENG.BY]
function playVictoryUnlockFx() {
  if (pendingUpgradeUnlockFx) {
    const btn = document.getElementById('victoryUpgradesBtn');
    if (btn) {
      const pcbTreeIcon = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" style="flex:none; margin-right: 4px;"><path d="M12 21 v-5 l-4 -3.5 v-4 m4 7.5 l4 -3.5 v-4 m-4 7.5 v-8" /><circle cx="12" cy="21" r="1.5" fill="currentColor" stroke="none" /><circle cx="8" cy="8.5" r="1.5" fill="currentColor" stroke="none" /><circle cx="16" cy="8.5" r="1.5" fill="currentColor" stroke="none" /><circle cx="12" cy="5" r="1.5" fill="currentColor" stroke="none" /></svg>`;
      btn.classList.add('btn-locked', 'btn-unlocking');
      btn.disabled = true;
      btn.innerHTML = pcbTreeIcon + '<span>TECH TREE</span>';
      // [ENG.BZ]
      setTimeout(() => {
        btn.disabled = false;
        btn.classList.remove('btn-locked', 'btn-unlocking', 'no-press-feedback');
        btn.innerHTML = pcbTreeIcon + '<span>TECH TREE</span>';
      }, 1700);
    }
    pendingUpgradeUnlockFx = false;
  }
  if (pendingLoadoutRevealFx) {
    const widget = document.getElementById('loadoutWidget');
    if (widget) {
      widget.classList.remove('loadout-revealing');
      void widget.offsetWidth;
      widget.classList.add('loadout-revealing');
      setTimeout(() => widget.classList.remove('loadout-revealing'), 2100);
    }
    pendingLoadoutRevealFx = false;
  }
}

// [ENG.CA]
function triggerDefeat() {
  musicSetDucked(false);
  sfxStopBeams();
  music('lose');
  sfx('defeat');
  vibrate('error');
  if (reviveTimerInterval) { clearInterval(reviveTimerInterval); reviveTimerInterval = null; }
  if (reviveSkipShowTimer) { clearTimeout(reviveSkipShowTimer); reviveSkipShowTimer = null; }
  gameState = 'DEFEAT';
  if (typeof syncTopHudVisibility === 'function') syncTopHudVisibility();

  const victoryScreen = document.getElementById('victoryScreen');
  if (victoryScreen) victoryScreen.classList.add('hidden');

  const reviveTimerContainer = document.getElementById('reviveTimerContainer');
  if (reviveTimerContainer) reviveTimerContainer.classList.add('hidden');

  const tacticalTipsWidget = document.getElementById('tacticalTipsWidget');
  if (tacticalTipsWidget) {
    tacticalTipsWidget.classList.toggle('hidden', !!isEndlessMode);
  }

  const reviveBtn = document.getElementById('reviveBtn');
  const skipBtn = document.getElementById('reviveSkipBtn');
  const retryBtn = document.getElementById('defeatRetryBtn');
  const upgBtn = document.getElementById('defeatUpgradesBtn');
  const levelsBtn = document.getElementById('defeatLevelsBtn');
  const shopBtn = document.getElementById('defeatShopBtn');

  if (reviveBtn) reviveBtn.classList.add('hidden');
  if (skipBtn) skipBtn.classList.add('hidden');
  if (retryBtn) retryBtn.classList.toggle('hidden', !!isEndlessMode);
  if (upgBtn) upgBtn.classList.remove('hidden');
  if (levelsBtn) levelsBtn.classList.remove('hidden');
  if (shopBtn) shopBtn.classList.remove('hidden');

  updateUpgradeButtonsLock();
  updateDefeatWaveLine();
  document.getElementById('defeatScreen').classList.remove('hidden');
  if (!isEndlessMode) {
    replayDefeatFlash();
  } else {
    const existingFlash = document.getElementById('defeatFlash');
    if (existingFlash) existingFlash.remove();
  }
  showLoadoutWidgetIn('loadoutAnchor-defeat');
  registerDefeatOutcome();
  clearActiveBattleSave();
}

// [ENG.CB]
function registerDefeatOutcome() {
  safeTrack('level_failed', { level: currentLevel, wave });
}

// [ENG.CC]
function showGameCompletionModal() {
  const modal = document.getElementById('gameCompletionModal');
  if (modal) modal.classList.remove('hidden');
}

// [ENG.CD]
function closeGameCompletionModal() {
  const modal = document.getElementById('gameCompletionModal');
  if (modal) modal.classList.add('hidden');
}

// [ENG.CE]
function setReviveBtnLabel(seconds) {
  const numEl = document.getElementById('reviveTimerNumber');
  if (numEl) numEl.textContent = `${seconds}s`;
  const label = document.getElementById('reviveBtnLabel');
  if (label) {
    label.textContent = (typeof t === 'function' ? t('revive') : 'REVIVE');
  }
}

let defeatFlashTimeout = null;

// [ENG.CF]
function replayDefeatFlash() {
  if (typeof isEndlessMode !== 'undefined' && isEndlessMode) return;
  const defeatScreen = document.getElementById('defeatScreen');
  if (!defeatScreen) return;

  let flash = document.getElementById('defeatFlash');
  if (!flash) {
    flash = document.createElement('div');
    flash.className = 'defeat-flash';
    flash.id = 'defeatFlash';
    defeatScreen.insertBefore(flash, defeatScreen.firstChild);
  } else {
    const fresh = flash.cloneNode(false);
    flash.parentNode.replaceChild(fresh, flash);
    flash = fresh;
  }

  const heading = defeatScreen.querySelector('.result-heading');
  if (heading) {
    heading.classList.remove('fail-shake');
    void heading.offsetWidth;
    heading.classList.add('fail-shake');
  }
}

let lastEndlessEarnedDiamonds = 0;
let lastEndlessEarnedPrisms = 0;
let endlessHasClaimedDouble = false;

// [ENG.CG]
function claimEndlessDoubleRewards() {
  if (endlessHasClaimedDouble || (lastEndlessEarnedDiamonds <= 0 && lastEndlessEarnedPrisms <= 0)) return;
  const doubleBtn = document.getElementById('endlessDoubleBtn');

  // [ENG.CH]
  const executeDouble = () => {
    endlessHasClaimedDouble = true;
    diamonds += lastEndlessEarnedDiamonds;
    prisms += lastEndlessEarnedPrisms;
    updateDiamondUI();
    if (typeof updatePrismUI === 'function') updatePrismUI();
    if (doubleBtn) {
      doubleBtn.disabled = true;
      const diamondSvg = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linejoin="round"><polygon points="6 3 18 3 22 9 12 22 2 9" fill="currentColor" fill-opacity="0.25"/><polyline points="2 9 12 13 22 9"/><line x1="12" y1="22" x2="12" y2="13"/></svg>`;
      const prismSvg = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linejoin="round"><polygon points="12 2 21 12 12 22 3 12" fill="currentColor" fill-opacity="0.25"/><polyline points="3 12 12 15 21 12"/><line x1="12" y1="22" x2="12" y2="22"/></svg>`;
      
      let rewardText = `(+${lastEndlessEarnedDiamonds} ${diamondSvg}`;
      if (lastEndlessEarnedPrisms > 0) {
        rewardText += ` +${lastEndlessEarnedPrisms} ${prismSvg}`;
      }
      rewardText += `)`;

      const claimedLabel = typeof t === 'function' ? t('claimed_x2') : 'CLAIMED x2';
      doubleBtn.innerHTML = `<span style="display:inline-flex; align-items:center; gap:4px; font-size:11px; letter-spacing:0.5px;">${claimedLabel} ${rewardText}</span>`;
    }
    sfx('reward');
    saveGame();
  };

  showAdPlaceholder(executeDouble, null);
}

// [ENG.CI]
function updateDefeatWaveLine() {
  const el = document.getElementById('defeatWaveLine');
  const defeatScreen = document.getElementById('defeatScreen');
  const kicker = defeatScreen ? defeatScreen.querySelector('.result-kicker') : null;
  const title = defeatScreen ? defeatScreen.querySelector('.result-title') : null;
  const rewardsBox = document.getElementById('endlessRewardsBox');
  const lootLine = document.getElementById('endlessLootLine');
  const doubleBtn = document.getElementById('endlessDoubleBtn');
  const tacticalTipsWidget = document.getElementById('tacticalTipsWidget');

  if (isEndlessMode) {
    if (defeatScreen) defeatScreen.classList.add('endless-result-active');
    if (tacticalTipsWidget) tacticalTipsWidget.classList.add('hidden');

    const clearedWaves = Math.max(0, wave - 1);
    const sec = currentLevelSection || 1;
    const currentMapBest = endlessBestWavesBySection[sec] || 0;
    const isNewRecord = clearedWaves > currentMapBest;
    if (isNewRecord) {
      endlessBestWavesBySection[sec] = clearedWaves;
      endlessBestWave = Math.max(...Object.values(endlessBestWavesBySection));
      saveGameSoon();
    }

    if (kicker) kicker.textContent = typeof t === 'function' ? t('endless_arena') : 'ENDLESS ARENA';
    if (title) {
      const runCompleteText = typeof t === 'function' ? t('run_complete') : 'RUN COMPLETE';
      title.textContent = runCompleteText;
      title.setAttribute('data-text', runCompleteText);
    }
    if (el) {
      el.textContent = typeof t === 'function'
        ? t('wave_n_cleared', { n: wave, c: clearedWaves })
        : `WAVE ${wave} REACHED (${clearedWaves} CLEARED)`;
    }

    lastEndlessEarnedDiamonds = clearedWaves * 2;
    const basePrisms = Math.floor(clearedWaves / 10);
    let milestonePrisms = 0;
    const milestones = [15, 30, 50, 75, 100];
    milestones.forEach(m => {
      if (clearedWaves >= m && !endlessMilestonesClaimed[m]) {
        endlessMilestonesClaimed[m] = true;
        milestonePrisms += 5;
      }
    });

    lastEndlessEarnedPrisms = basePrisms;
    const totalPrismsGranted = basePrisms + milestonePrisms;

    diamonds += lastEndlessEarnedDiamonds;
    prisms += totalPrismsGranted;
    updateDiamondUI();
    if (typeof updatePrismUI === 'function') updatePrismUI();
    saveGame();

    endlessHasClaimedDouble = false;

    if (rewardsBox) rewardsBox.classList.remove('hidden');

    if (lootLine) {
      const diamondSvg = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#00e5ff" stroke-width="2.2" stroke-linejoin="round" style="filter: drop-shadow(0 0 5px rgba(0,229,255,0.7));"><polygon points="6 3 18 3 22 9 12 22 2 9" fill="rgba(0,229,255,.25)"/><polyline points="2 9 12 13 22 9"/><line x1="12" y1="22" x2="12" y2="13"/></svg>`;
      const prismSvg = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#d946ef" stroke-width="2.2" stroke-linejoin="round" style="filter: drop-shadow(0 0 5px rgba(217,70,239,0.7));"><polygon points="12 2 21 12 12 22 3 12" fill="rgba(217,70,239,.25)"/><polyline points="3 12 12 15 21 12"/><line x1="12" y1="22" x2="12" y2="22"/></svg>`;

      const rewardsLabel = typeof t === 'function' ? t('rewards') : 'REWARDS';

      lootLine.innerHTML = `
        <div class="result-reward-chip" style="--chip-border: #d946ef; --chip-label: #f5d0fe; margin: 10px auto 8px auto;">
          <span class="reward-label">${rewardsLabel}</span>
          <div style="display:flex; align-items:center; gap:8px;">
            <span class="reward-amount">+${lastEndlessEarnedDiamonds}</span>
            ${diamondSvg}
            <span style="color: rgba(255, 255, 255, 0.2); font-weight: 300; margin: 0 2px;">|</span>
            <span class="reward-amount" style="color:#f5d0fe;">+${totalPrismsGranted}</span>
            ${prismSvg}
          </div>
        </div>
      `;
    }

    if (doubleBtn) {
      if (lastEndlessEarnedDiamonds > 0 || lastEndlessEarnedPrisms > 0) {
        doubleBtn.classList.remove('hidden');
        doubleBtn.disabled = false;
        const endlessAdIcon = getStandardAdIconSvg();
        const claimX2Label = typeof t === 'function' ? t('claim_x2') : 'CLAIM x2';
        doubleBtn.innerHTML = `
          ${endlessAdIcon}
          <span style="color:#ffffff; font-weight:800; letter-spacing:1px;">${claimX2Label}</span>
        `;
      } else {
        doubleBtn.classList.add('hidden');
      }
    }
  } else {
    if (defeatScreen) defeatScreen.classList.remove('endless-result-active');
    if (kicker) {
      if (typeof t === 'function') {
        kicker.textContent = isOverdriveMode ? t('hardcore') : t('level_kicker');
      } else {
        kicker.textContent = isOverdriveMode ? 'HARDCORE' : 'LEVEL';
      }
    }
    if (title) {
      const failedText = typeof t === 'function' ? t('failed') : 'FAILED';
      title.textContent = failedText;
      title.setAttribute('data-text', failedText);
    }
    if (rewardsBox) rewardsBox.classList.add('hidden');
    if (el) {
      const maxW = (LEVELS_DATA[currentLevel] && LEVELS_DATA[currentLevel].totalWaves) || 1;
      el.textContent = typeof t === 'function'
        ? t('wave_n_of_m', { n: Math.min(wave, maxW), m: maxW })
        : `WAVE ${Math.min(wave, maxW)} OF ${maxW} REACHED`;
    }
  }
}

// [ENG.CJ]
function updateRevivePromptHeadings() {
  const defeatScreen = document.getElementById('defeatScreen');
  const kicker = defeatScreen ? defeatScreen.querySelector('.result-kicker') : null;
  const title = defeatScreen ? defeatScreen.querySelector('.result-title') : null;
  const el = document.getElementById('defeatWaveLine');
  const rewardsBox = document.getElementById('endlessRewardsBox');

  if (rewardsBox) rewardsBox.classList.add('hidden');

  if (isEndlessMode) {
    if (defeatScreen) defeatScreen.classList.add('endless-result-active');
    if (kicker) kicker.textContent = typeof t === 'function' ? t('endless_arena') : 'ENDLESS ARENA';
    if (el) {
      const clearedWaves = Math.max(0, wave - 1);
      el.textContent = typeof t === 'function'
        ? t('wave_n_cleared', { n: wave, c: clearedWaves })
        : `WAVE ${wave} REACHED (${clearedWaves} CLEARED)`;
    }
  } else {
    if (defeatScreen) defeatScreen.classList.remove('endless-result-active');
    if (kicker) {
      if (typeof t === 'function') {
        kicker.textContent = isOverdriveMode ? t('hardcore') : t('level_kicker');
      } else {
        kicker.textContent = isOverdriveMode ? 'HARDCORE' : 'LEVEL';
      }
    }
    if (el) {
      const maxW = (LEVELS_DATA[currentLevel] && LEVELS_DATA[currentLevel].totalWaves) || 1;
      el.textContent = typeof t === 'function'
        ? t('wave_n_of_m', { n: Math.min(wave, maxW), m: maxW })
        : `WAVE ${Math.min(wave, maxW)} OF ${maxW} REACHED`;
    }
  }

  if (title) {
    const revQ = typeof t === 'function' ? t('revive_q') : 'REVIVE?';
    title.textContent = revQ;
    title.setAttribute('data-text', revQ);
  }
}

// [ENG.CK]
let isReviveAdPending = false;

function triggerEmergencyRevivePrompt() {
  gameState = 'DEFEAT';
  isReviveAdPending = false;
  if (typeof syncTopHudVisibility === 'function') syncTopHudVisibility();
  musicSetDucked(true);
  reviveRemainingSeconds = 3;

  const victoryScreen = document.getElementById('victoryScreen');
  if (victoryScreen) victoryScreen.classList.add('hidden');

  const reviveTimerContainer = document.getElementById('reviveTimerContainer');
  if (reviveTimerContainer) reviveTimerContainer.classList.remove('hidden');

  const tacticalTipsWidget = document.getElementById('tacticalTipsWidget');
  if (tacticalTipsWidget) tacticalTipsWidget.classList.add('hidden');

  const reviveBtn = document.getElementById('reviveBtn');
  const skipBtn = document.getElementById('reviveSkipBtn');
  const retryBtn = document.getElementById('defeatRetryBtn');
  const upgBtn = document.getElementById('defeatUpgradesBtn');
  const levelsBtn = document.getElementById('defeatLevelsBtn');
  const shopBtn = document.getElementById('defeatShopBtn');
  
  if (reviveBtn) {
    reviveBtn.disabled = false;
    reviveBtn.classList.remove('hidden');
    const reviveIcon = getStandardAdIconSvg();
    const reviveText = (typeof t === 'function' ? t('revive') : 'REVIVE');
    reviveBtn.innerHTML = `
      ${reviveIcon}
      <span id="reviveBtnLabel">${reviveText}</span>
    `;
    setReviveBtnLabel(reviveRemainingSeconds);
  }
  if (skipBtn) skipBtn.classList.add('hidden');
  if (retryBtn) retryBtn.classList.add('hidden');
  if (upgBtn) upgBtn.classList.add('hidden');
  if (levelsBtn) levelsBtn.classList.add('hidden');
  if (shopBtn) shopBtn.classList.add('hidden');

  updateRevivePromptHeadings();

  const loadoutWidget = document.getElementById('loadoutWidget');
  if (loadoutWidget) loadoutWidget.classList.add('hidden');
  document.getElementById('defeatScreen').classList.remove('hidden');
  if (!isEndlessMode) {
    replayDefeatFlash();
  } else {
    const existingFlash = document.getElementById('defeatFlash');
    if (existingFlash) existingFlash.remove();
  }

  if (reviveSkipShowTimer) clearTimeout(reviveSkipShowTimer);
  // [ENG.CL]
  reviveSkipShowTimer = setTimeout(() => {
    reviveSkipShowTimer = null;
    if (skipBtn) skipBtn.classList.remove('hidden');
  }, 1000);

  if (reviveTimerInterval) clearInterval(reviveTimerInterval);
  // [ENG.CM]
  reviveTimerInterval = setInterval(() => {
    if (isReviveAdPending) return;
    reviveRemainingSeconds--;
    if (reviveBtn && reviveRemainingSeconds > 0) {
      setReviveBtnLabel(reviveRemainingSeconds);
    }
    if (reviveRemainingSeconds <= 0) {
      finishRevivePromptWindow();
    }
  }, 1000);
}

// [ENG.CN]
function finishRevivePromptWindow() {
  isReviveAdPending = false;
  if (reviveTimerInterval) { clearInterval(reviveTimerInterval); reviveTimerInterval = null; }
  if (reviveSkipShowTimer) { clearTimeout(reviveSkipShowTimer); reviveSkipShowTimer = null; }
  musicSetDucked(false);
  music('lose');
  sfx('defeat');
  vibrate('error');

  const reviveTimerContainer = document.getElementById('reviveTimerContainer');
  if (reviveTimerContainer) reviveTimerContainer.classList.add('hidden');

  const tacticalTipsWidget = document.getElementById('tacticalTipsWidget');
  if (tacticalTipsWidget) {
    tacticalTipsWidget.classList.toggle('hidden', !!isEndlessMode);
  }

  const reviveBtn = document.getElementById('reviveBtn');
  const skipBtn = document.getElementById('reviveSkipBtn');
  const retryBtn = document.getElementById('defeatRetryBtn');
  const upgBtn = document.getElementById('defeatUpgradesBtn');
  const levelsBtn = document.getElementById('defeatLevelsBtn');
  const shopBtn = document.getElementById('defeatShopBtn');

  if (reviveBtn) {
    reviveBtn.disabled = false;
    reviveBtn.classList.add('hidden');
  }
  if (skipBtn) skipBtn.classList.add('hidden');
  if (retryBtn) retryBtn.classList.toggle('hidden', !!isEndlessMode);
  if (upgBtn) upgBtn.classList.remove('hidden');
  if (levelsBtn) levelsBtn.classList.remove('hidden');
  if (shopBtn) shopBtn.classList.remove('hidden');

  updateDefeatWaveLine();
  updateUpgradeButtonsLock();
  showLoadoutWidgetIn('loadoutAnchor-defeat');
  registerDefeatOutcome();
  clearActiveBattleSave();
}

// [ENG.CO]
function skipEmergencyRevive() {
  if (isReviveAdPending) return;
  finishRevivePromptWindow();
}

// [ENG.CP]
function acceptEmergencyRevive() {
  if (isReviveAdPending) return;
  isReviveAdPending = true;

  const reviveBtn = document.getElementById('reviveBtn');
  if (reviveBtn) reviveBtn.disabled = true;
  sfx('revive');

  // [ENG.CQ]
  const executeRevive = () => {
    isReviveAdPending = false;
    if (reviveTimerInterval) { clearInterval(reviveTimerInterval); reviveTimerInterval = null; }
    if (reviveSkipShowTimer) { clearTimeout(reviveSkipShowTimer); reviveSkipShowTimer = null; }
    if (reviveBtn) reviveBtn.disabled = false;
    const defeatScreen = document.getElementById('defeatScreen');
    if (defeatScreen) defeatScreen.classList.add('hidden');
    musicSetDucked(false);
    baseHp = Math.max(3, Math.round(matchStartBaseHp * 0.5));
    reviveUsedThisMatch = true;
    updateUI();

    if (WAYPOINTS && WAYPOINTS.length > 1) {
      const basePt = WAYPOINTS[WAYPOINTS.length - 1];
      const fw = typeof FIELD_WIDTH !== 'undefined' ? FIELD_WIDTH : 700;
      createShockwave(basePt.x, basePt.y, fw * 0.9, '#00e5ff');
      createShockwave(basePt.x, basePt.y, fw * 0.6, '#ffffff');
      createShockwave(basePt.x, basePt.y, fw * 0.3, '#38bdf8');
      if (typeof createExplosion === 'function') createExplosion(basePt.x, basePt.y, 100);
      if (typeof createDamageShards === 'function') createDamageShards(basePt.x, basePt.y, '#00e5ff', 50, false);
      triggerImpactFeedback('heavy', 'heavy', { dur: 0.5, intensity: 16, forceShake: true });
      sfx('bossIncoming');
      sfx('revive');

      const numWps = WAYPOINTS.length;
      const cumDist = [0];
      for (let k = 1; k < numWps; k++) {
        const d = Math.hypot(WAYPOINTS[k].x - WAYPOINTS[k - 1].x, WAYPOINTS[k].y - WAYPOINTS[k - 1].y);
        cumDist.push(cumDist[k - 1] + d);
      }
      const totalRouteDistance = cumDist[numWps - 1];
      const pushDistance = totalRouteDistance * 0.45;

      enemies.forEach(e => {
        let k = e.wpIndex;
        if (k < 1) k = 1;
        if (k >= numWps) k = numWps - 1;

        const prevWp = WAYPOINTS[k - 1];
        const targetWp = WAYPOINTS[k];
        const segDx = targetWp.x - prevWp.x;
        const segDy = targetWp.y - prevWp.y;
        const segLen = Math.hypot(segDx, segDy);

        let dInSeg = 0;
        if (segLen > 0) {
          const ex = e.x - prevWp.x;
          const ey = e.y - prevWp.y;
          const proj = (ex * segDx + ey * segDy) / segLen;
          dInSeg = Math.max(0, Math.min(segLen, proj));
        }

        const currentDistFromSpawn = cumDist[k - 1] + dInSeg;
        const newDistFromSpawn = Math.max(0, currentDistFromSpawn - pushDistance);

        let newK = 1;
        while (newK < numWps - 1 && cumDist[newK] < newDistFromSpawn) {
          newK++;
        }

        const pSegStart = WAYPOINTS[newK - 1];
        const pSegEnd = WAYPOINTS[newK];
        const pSegLen = cumDist[newK] - cumDist[newK - 1];
        const pSegDist = newDistFromSpawn - cumDist[newK - 1];

        let t = 0;
        if (pSegLen > 0) {
          t = Math.max(0, Math.min(1, pSegDist / pSegLen));
        }

        let newX = pSegStart.x + t * (pSegEnd.x - pSegStart.x);
        let newY = pSegStart.y + t * (pSegEnd.y - pSegStart.y);

        if (e.laneOffset) {
          const sDx = pSegEnd.x - pSegStart.x;
          const sDy = pSegEnd.y - pSegStart.y;
          const sLen = Math.hypot(sDx, sDy) || 1;
          let offX = -sDy / sLen;
          let offY = sDx / sLen;
          const nextWp = WAYPOINTS[newK + 1];
          if (nextWp) {
            const s2Dx = nextWp.x - pSegEnd.x;
            const s2Dy = nextWp.y - pSegEnd.y;
            const s2Len = Math.hypot(s2Dx, s2Dy) || 1;
            offX += -s2Dy / s2Len;
            offY += s2Dx / s2Len;
          }
          newX += offX * e.laneOffset;
          newY += offY * e.laneOffset;
        }

        e.revivePushAnim = {
          startX: e.x,
          startY: e.y,
          endX: newX,
          endY: newY,
          endWp: newK,
          timer: 0,
          duration: 0.75
        };
      });
    }
    gameState = 'PLAYING';
    if (typeof syncTopHudVisibility === 'function') syncTopHudVisibility();
    updateUI();
    lastTime = performance.now();
  };

  const onNotRewarded = () => {
    isReviveAdPending = false;
    if (reviveBtn) reviveBtn.disabled = false;
    if (reviveRemainingSeconds <= 0) {
      finishRevivePromptWindow();
      return;
    }
    const skipBtn = document.getElementById('reviveSkipBtn');
    if (skipBtn) skipBtn.classList.remove('hidden');
    if (reviveBtn) setReviveBtnLabel(reviveRemainingSeconds);
  };

  showAdPlaceholder(executeRevive, onNotRewarded);
}

// Tower Construction & Inspection Management: Build, upgrade, sell, and drag-and-drop placement logic.
// [ENG.CR]
function buildTowerAt(type, c, r) {
  const conf = TOWER_CONFIGS[type];
  if (grid[r][c] === 0 && gold >= conf.cost) {
    gold -= conf.cost;
    grid[r][c] = 2;

    const powerLvl = getBattleUpgradeEffectiveLevel(`${type}_power`);
    const dmgBonus = 1 + powerLvl * (conf.powerDmg || 0);
    const rateBonus = 1 + powerLvl * (conf.powerRate || 0);
    const rangeBonus = 1 + getBattleUpgradeRangeBonus(type, powerLvl);
    const calcDamage = (conf.damage || conf.dps || conf.baseDps || 0) * dmgBonus;
    const calcFireRate = conf.fireRate ? (conf.fireRate / rateBonus) : 0;

    const baseLockOnDelay = (type === 'laser' || type === 'melter')
      ? (typeof LOCK_ON_DELAY_HEAVY === 'number' ? LOCK_ON_DELAY_HEAVY : 0.5)
      : (typeof LOCK_ON_DELAY_LIGHT === 'number' ? LOCK_ON_DELAY_LIGHT : 0.1);
    const calcLockOnDelay = (type === 'mortar') ? baseLockOnDelay : (baseLockOnDelay / rateBonus);
    const calcMortarTravelTime = (type === 'mortar')
      ? ((typeof MORTAR_BASE_TRAVEL_TIME === 'number' ? MORTAR_BASE_TRAVEL_TIME : 1.0) / rateBonus)
      : undefined;
    const calcMelterRampTime = (type === 'melter')
      ? ((conf.rampTime || 4.0) / rateBonus)
      : undefined;

    sfx('build');
    vibrate('light');
    const newTower = {
      c, r,
      x: c * TILE_SIZE + TILE_SIZE / 2,
      y: r * TILE_SIZE + TILE_SIZE / 2,
      type: type,
      level: 1,
      totalInvested: conf.cost,
      damage: calcDamage,
      range: conf.range * rangeBonus,
      fireRate: calcFireRate,
      color: conf.color,
      glow: conf.glow,
      lastFire: 0,
      target: null,
      angle: 0,
      lockOnDelay: calcLockOnDelay,
      lockOnTimer: 0,
      mortarTravelTime: calcMortarTravelTime,
      melterRampTime: calcMelterRampTime,
      melterCooldownTime: (type === 'melter') ? ((conf.cooldownTime || 4.0) / rateBonus) : 0,
      slowFactor: conf.slowFactor || 0.30,
      slowDuration: conf.slowDuration || 1.4,
      disabledTimer: 0,
      melterFireTimer: 0,
      melterCoolingTimer: 0,
      accumDamage: 0,
      accumTimer: 0,
      accumTarget: null
    };

    towers.push(newTower);
    createShockwave(newTower.x, newTower.y, 40, conf.color);
    updateUI();
    saveActiveBattleSnapshot();
    saveGameSoon();

    if (tutorialActive && tutorialLevel === 1 && tutorialStep === 0) {
      tutorialStep = 1;
    } else if (tutorialActive && tutorialLevel === 2 && tutorialStep === -1) {
      tutorialStep = 0;
      tutorialTargetTower = newTower;
    }

    safeTrack('tower_built', { type, level: currentLevel });
    return true;
  }
  return false;
}

// [ENG.CS]
function handleDrop(worldX, worldY, clientX, clientY) {
  if (!draggingTower || gameState !== 'PLAYING') {
    draggingTower = null;
    showCancelZoneVisual(false);
    return;
  }

  try {
    const isCancelled = isOverCancelZone(clientX, clientY);
    if (!isCancelled) {
      const c = Math.floor(worldX / TILE_SIZE);
      const r = Math.floor(worldY / TILE_SIZE);
      if (c >= 0 && c < COLS && r >= 0 && r < ROWS) {
        buildTowerAt(draggingTower.type, c, r);
      }
    }
  } catch (err) {
    console.error(err);
  } finally {
    draggingTower = null;
    showCancelZoneVisual(false);
  }
}

// [ENG.CT]
function getUpgradeCost(towerOrType, level) {
  const type = typeof towerOrType === 'object' ? towerOrType.type : towerOrType;
  const lvl = typeof towerOrType === 'object' ? towerOrType.level : level;
  const conf = TOWER_CONFIGS[type];
  const costMult = (conf && conf.costMultiplier) ? conf.costMultiplier : 1.3;
  return Math.floor(conf.cost * Math.pow(costMult, lvl));
}

// [ENG.CU]
function upgradeSelectedTower() {
  const lvlConfig = LEVELS_DATA[currentLevel];
  const isL1FirstTime = (currentLevel === 1 && !isEndlessMode && !isOverdriveMode && !hasClearedLevelBefore(1) && !devMode);
  if (lvlConfig && lvlConfig.canUpgrade === false && isL1FirstTime) return;
  if (!selectedTower || selectedTower.level >= 3) return;
  const cost = getUpgradeCost(selectedTower.type, selectedTower.level);
  if (gold >= cost) {
    const conf = TOWER_CONFIGS[selectedTower.type];
    const dmgMult = (conf && conf.damageMultiplier) ? conf.damageMultiplier : 1.4;
    const rngMult = (conf && conf.rangeMultiplier) ? conf.rangeMultiplier : 1.1;
    const rateMult = (conf && conf.rateMultiplier) ? conf.rateMultiplier : 1.0;

    gold -= cost;
    selectedTower.level++;
    sfx('upgrade');
    selectedTower.totalInvested += cost;
    selectedTower.damage *= dmgMult;
    selectedTower.range *= rngMult;
    if (selectedTower.fireRate && rateMult !== 1.0) {
      selectedTower.fireRate *= rateMult;
    }

    if (selectedTower.type === 'stasis') {
      selectedTower.slowFactor = (selectedTower.level === 2) ? 0.40 : 0.50;
    }

    if (selectedTower.type === 'melter') {
      selectedTower.melterFireTimer = 0;
      selectedTower.melterCoolingTimer = 0;
      const powerLvl = getBattleUpgradeEffectiveLevel('melter_power');
      const rateBonus = 1 + powerLvl * (conf.powerRate || 0);
      if (selectedTower.level === 2) {
        selectedTower.melterRampTime = 4.4 / rateBonus;
        selectedTower.melterCooldownTime = 3.6 / rateBonus;
      } else if (selectedTower.level === 3) {
        selectedTower.melterRampTime = 4.8 / rateBonus;
        selectedTower.melterCooldownTime = 3.2 / rateBonus;
      }
    }

    createShockwave(selectedTower.x, selectedTower.y, 60, selectedTower.color);
    createDamageShards(selectedTower.x, selectedTower.y, selectedTower.color, 40, false);
    updateUI();
    saveActiveBattleSnapshot();
    saveGameSoon();

    if (tutorialActive && tutorialLevel === 2 && tutorialStep === 1) {
      tutorialStep = 2;
    }
  }
}

// [ENG.CV]
function sellSelectedTower() {
  if (!selectedTower) return;
  if (!sellConfirmArmed) {
    armSellConfirm();
    return;
  }
  resetSellConfirm();

  const sc = selectedTower.c;
  const sr = selectedTower.r;
  const sx = selectedTower.x;
  const sy = selectedTower.y;
  const refund = Math.floor(selectedTower.totalInvested * 0.7);
  gold += refund;
  sfx('sell');

  grid[sr][sc] = 0;
  towers = towers.filter(t => t.c !== sc || t.r !== sr);
  particles = particles.filter(p => Math.hypot(p.x - sx, p.y - sy) > 28);
  deselectTower();

  createShockwave(sx, sy, 40, '#f05f9f');
  createDamageShards(sx, sy, '#f05f9f', 30, false);
  updateUI();
  saveActiveBattleSnapshot();
  saveGameSoon();
}

// Wave Spawning & Enemy Queue Management: Auto/manual wave triggers, miniboss/boss delays, and spawn timers.
// [ENG.CW]
function getAutoWaveDelay() {
  if (currentLevel >= 40) return 9.0;
  if (currentLevel >= 30) return 7.0;
  return 5.0;
}

// [ENG.CX]
function triggerManualWave() {
  if (tutorialActive && tutorialLevel === 1 && tutorialStep === 1) {
    completeTutorial(1);
  }

  const lvlConfig = LEVELS_DATA[currentLevel];
  const maxW = lvlConfig ? lvlConfig.totalWaves : 10;

  if (!isEndlessMode && finalWaveSpawned) {
    return;
  }

  if (waveTimerActive) {
    const secondsSaved = autoWaveTimeRemaining;
    waveTimerActive = false;
    autoWaveTimeRemaining = 0;
    fieldClearDelayTimer = 0;
    isWaveTimerAccelerated = false;
    if (isEndlessMode || wave < maxW) {
      let totalDelay = 5.0;
      let currentWaveObj = null;
      let baseBonus = 15;

      if (isEndlessMode) {
        addBpXp(5);
        baseBonus = 15 + Math.floor(wave * 1.5);
      } else if (lvlConfig && lvlConfig.waves) {
        currentWaveObj = lvlConfig.waves.find(w => w.wave === wave);
        if (currentWaveObj && currentWaveObj.delayAfter !== undefined) {
          totalDelay = currentWaveObj.delayAfter;
        }
        if (currentWaveObj && currentWaveObj.earlyBonus !== undefined) {
          baseBonus = currentWaveObj.earlyBonus;
        }
      }

      wave++;
      const moneyMultiplier = 1 + getBattleUpgradeEffectiveLevel('base_gold') * 0.05;
      const fractionSaved = totalDelay > 0 ? Math.min(1, Math.max(0, secondsSaved / totalDelay)) : 0;
      const earlyCallBonus = Math.round(fractionSaved * baseBonus * moneyMultiplier);

      if (earlyCallBonus > 0) {
        gold += earlyCallBonus;
        sfx('confirm');
      }
      startWave();
    }
  } else if (!waveInProgress && spawnQueue.length === 0) {
    if (isEndlessMode || (wave <= maxW && !finalWaveSpawned)) startWave();
  }
}

// [ENG.CY]
function getMinibossPreDelay() { return 2.0; }
// [ENG.CZ]
function getBossPreDelay(lvl) {
  const clamped = Math.max(10, Math.min(50, lvl));
  return 2.5 + ((clamped - 10) / 40) * 2.5;
}

// [ENG.DA]
function startWave() {
  if (isEndlessMode) {
    waveInProgress = true;
    waveTimerActive = false;
    autoWaveTimeRemaining = 0;
    fieldClearDelayTimer = 0;
    isWaveTimerAccelerated = false;
    spawnQueue = [];

    const waveData = generateEndlessWaveData(wave);
    let hasBoss = false;
    let hasMiniBoss = false;

    if (waveData && waveData.spawns) {
      waveData.spawns.forEach(grp => {
        if (grp.isBoss) hasBoss = true;
        if (grp.isMiniBoss) hasMiniBoss = true;

        if ((grp.isBoss || grp.isMiniBoss) && spawnQueue.length > 0) {
          const preDelay = grp.isBoss ? getBossPreDelay(10) : getMinibossPreDelay();
          spawnQueue[spawnQueue.length - 1].interval += preDelay;
        }

        const proto = (typeof ENEMY_CONFIGS !== 'undefined' && ENEMY_CONFIGS[grp.type]) || { size: 10, shape: 'circle', color: '#00e5ff', glow: '#00e5ff' };
        const isSwarm = grp.type === 'swarm';
        const spawnCount = grp.count || 1;
        const baseRadius = proto.size * (grp.isBoss ? 1.75 : (grp.isMiniBoss ? 1.35 : 1.0));
        const finalRadius = isSwarm ? baseRadius * 0.5 : baseRadius;
        const spawnInterval = grp.interval || 0.8;

        for (let i = 0; i < spawnCount; i++) {
          const isLeft = (i % 2 === 0);
          const laneOffset = isSwarm ? (isLeft ? -6 : 6) : 0;

          spawnQueue.push({
            type: grp.type,
            isBoss: grp.isBoss,
            isMiniBoss: grp.isMiniBoss,
            hp: grp.hp,
            maxHp: grp.hp,
            speed: grp.speed,
            bounty: grp.bounty,
            radius: finalRadius,
            shape: grp.shape || proto.shape,
            color: proto.color || grp.color,
            glow: proto.glow || grp.glow,
            interval: spawnInterval,
            laneOffset: laneOffset
          });
        }
      });
    }

    bossAlertScheduled = false;
    bossAlertShown = false;
    activeBossAlertType = null;
    hideIncomingAlert();

    let firstUnitIsBoss = false;
    if (spawnQueue.length > 0 && (spawnQueue[0].isBoss || spawnQueue[0].isMiniBoss)) {
      firstUnitIsBoss = true;
    }

    if (hasBoss) {
      activeBossAlertType = 'boss';
      bossAlertScheduled = true;
    } else if (hasMiniBoss) {
      activeBossAlertType = 'miniboss';
      bossAlertScheduled = true;
    }

    spawnTimer = firstUnitIsBoss ? 2.0 : 0.15;

    let totalTime = 0;
    if (spawnQueue.length > 1) {
      for (let i = 0; i < spawnQueue.length - 1; i++) totalTime += (spawnQueue[i].interval || 0.8);
    } else {
      totalTime = 0.5;
    }
    waveTotalSpawnTime = totalTime > 0 ? totalTime : 0.8;
    waveSpawnElapsedTime = 0;

    updateWaveCircle(0);
    updateUI();
    if (devMode && typeof refreshDevDropdowns === 'function') refreshDevDropdowns();
    saveActiveBattleSnapshot();
    saveGameSoon();
    return;
  }

  const lvlConfig = LEVELS_DATA[currentLevel];
  const maxW = lvlConfig ? lvlConfig.totalWaves : 10;
  if (wave > maxW) return;

  waveInProgress = true;
  waveTimerActive = false;
  autoWaveTimeRemaining = 0;
  fieldClearDelayTimer = 0;
  isWaveTimerAccelerated = false;
  spawnQueue = [];

  const waveData = lvlConfig ? lvlConfig.waves.find(w => w.wave === wave) : null;
  let hasBoss = false;
  let hasMiniBoss = false;

  if (waveData && waveData.spawns) {
    waveData.spawns.forEach(grp => {
      if (grp.isBoss) hasBoss = true;
      if (grp.isMiniBoss) hasMiniBoss = true;

      if ((grp.isBoss || grp.isMiniBoss) && spawnQueue.length > 0) {
        const preDelay = grp.isBoss ? getBossPreDelay(currentLevel) : getMinibossPreDelay();
        spawnQueue[spawnQueue.length - 1].interval += preDelay;
      }

      const proto = ENEMY_CONFIGS[grp.type] || ENEMY_CONFIGS.grunt;
      const isSwarm = grp.type === 'swarm';
      const swarmClumps = isSwarm ? Math.max(1, grp.clumps || 3) : 0;
      const clumpSize = typeof swarmClumpSizeFor === 'function' ? swarmClumpSizeFor(currentLevel) : 10;
      const spawnCount = isSwarm ? (swarmClumps * clumpSize) : grp.count;
      const baseRadius = proto.size * (grp.isBoss ? 1.75 : (grp.isMiniBoss ? 1.35 : 1.0));
      const finalRadius = isSwarm ? baseRadius * 0.5 : baseRadius;
      const spawnInterval = isSwarm ? (typeof SWARM_CLUMP_INTERVAL !== 'undefined' ? SWARM_CLUMP_INTERVAL : 0.03) : (grp.interval || 0.8);
      const clumpGap = typeof SWARM_CLUMP_GAP !== 'undefined' ? SWARM_CLUMP_GAP : 3.2;

      for (let i = 0; i < spawnCount; i++) {
        const isLeft = (i % 2 === 0);
        const laneOffset = isSwarm ? (isLeft ? -6 : 6) : 0;
        const startsNewClump = isSwarm && i > 0 && (i % clumpSize === 0);
        const interval = startsNewClump ? clumpGap : spawnInterval;

        spawnQueue.push({
          type: grp.type,
          isBoss: grp.isBoss,
          isMiniBoss: grp.isMiniBoss,
          hp: isSwarm ? Math.max(6, Math.round(grp.hp * 0.65)) : grp.hp,
          maxHp: isSwarm ? Math.max(6, Math.round(grp.hp * 0.65)) : grp.hp,
          speed: grp.speed,
          bounty: isSwarm ? Math.max(1, Math.round(grp.bounty * 0.35 * (typeof SWARM_BOUNTY_SCALE !== 'undefined' ? SWARM_BOUNTY_SCALE : 0.62))) : grp.bounty,
          radius: finalRadius,
          shape: grp.shape || proto.shape,
          color: proto.color || grp.color,
          glow: proto.glow || grp.glow,
          interval: interval,
          laneOffset: laneOffset
        });
      }
    });
  }

  bossAlertScheduled = false;
  bossAlertShown = false;
  activeBossAlertType = null;
  hideIncomingAlert();

  let firstUnitIsBoss = false;
  if (spawnQueue.length > 0 && (spawnQueue[0].isBoss || spawnQueue[0].isMiniBoss)) {
    firstUnitIsBoss = true;
  }

  if (hasBoss) {
    activeBossAlertType = 'boss';
    bossAlertScheduled = true;
  } else if (hasMiniBoss) {
    activeBossAlertType = 'miniboss';
    bossAlertScheduled = true;
  }

  spawnTimer = firstUnitIsBoss ? 2.0 : 0.15;

  let totalTime = 0;
  if (spawnQueue.length > 1) {
    for (let i = 0; i < spawnQueue.length - 1; i++) totalTime += (spawnQueue[i].interval || 0.8);
  } else {
    totalTime = 0.5;
  }
  waveTotalSpawnTime = totalTime > 0 ? totalTime : 0.8;
  waveSpawnElapsedTime = 0;

  updateWaveCircle(0);
  updateUI();
  if (devMode && typeof refreshDevDropdowns === 'function') refreshDevDropdowns();
  saveActiveBattleSnapshot();
  saveGameSoon();
}

// Developer Tools & Spawner Integration: Custom spawner injections, dev controls, and cheat handlers.
// [ENG.DB]
function handleDevSpawnClick() {
  if (!devMode || gameState !== 'PLAYING') return;
  const typeSel = document.getElementById('devSpawnType');
  const countEl = document.getElementById('devSpawnCount');
  const intEl = document.getElementById('devSpawnInterval');
  
  if (typeSel && countEl && intEl) {
    const type = typeSel.value;
    const count = parseInt(countEl.value, 10) || 1;
    const interval = parseFloat(intEl.value) || 0.5;
    injectCustomSpawn(type, count, interval, 1.0, 1.0);
  }
}

// [ENG.DC]
function onDomReady() {
  if (window.__APP_STAGE__ === 'development') {
    import('./dev/ota-service.dev.js')
      .then(m => m.runOtaUpdate())
      .catch(err => console.warn('[DevSync] Not loaded:', err));
  } else {
    // Production mode: читаем только локальный манифест для версии и легальной докачки музыки (.ogg)
    fetch('update_manifest.json?t=' + Date.now(), { cache: 'no-store' })
      .then(r => r.ok ? r.json() : null)
      .then(manifest => {
        if (!manifest) return;
        if (manifest.version) {
          window.APP_VERSION = String(manifest.version);
          const verLabel = document.getElementById('settingsVersionLabel');
          if (verLabel) {
            verLabel.textContent = (typeof t === 'function')
              ? t('version_label', { v: window.APP_VERSION })
              : `Version: ${window.APP_VERSION}`;
          }
        }
        if (window.MusicDownloader) {
          window.MusicDownloader.setManifest(manifest);
          window.MusicDownloader.startBackgroundDownload(manifest);
        }
      })
      .catch(() => {});
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', onDomReady);
} else {
  onDomReady();
}

// [ENG.DD]
function injectCustomSpawn(type, count, interval, hpMult, speedMult) {
  if (gameState !== 'PLAYING') return;

  const proto = ENEMY_CONFIGS[type] || ENEMY_CONFIGS.grunt;
  const isSwarm = type === 'swarm';
  const isBoss = ['hive_empress', 'chronos_warp', 'titan_core', 'emp_overlord'].includes(type);
  
  const clumpSize = typeof swarmClumpSizeFor === 'function' ? swarmClumpSizeFor(currentLevel) : 10;
  const baseRadius = proto.size * (isBoss ? 1.75 : 1.0);
  const finalRadius = isSwarm ? baseRadius * 0.5 : baseRadius;
  const spawnInterval = isSwarm ? (typeof SWARM_CLUMP_INTERVAL !== 'undefined' ? SWARM_CLUMP_INTERVAL : 0.03) : interval;
  const clumpGap = typeof SWARM_CLUMP_GAP !== 'undefined' ? SWARM_CLUMP_GAP : 3.2;

  for (let i = 0; i < count; i++) {
    const isLeft = (i % 2 === 0);
    const laneOffset = isSwarm ? (isLeft ? -6 : 6) : 0;
    const startsNewClump = isSwarm && i > 0 && (i % clumpSize === 0);
    const currentInterval = startsNewClump ? clumpGap : spawnInterval;

    spawnQueue.push({
      type: type,
      isBoss: isBoss,
      isMiniBoss: false,
      hp: Math.max(1, Math.round(proto.baseHp * hpMult)),
      maxHp: Math.max(1, Math.round(proto.baseHp * hpMult)),
      speed: Math.round(proto.baseSpeed * speedMult),
      bounty: Math.max(1, Math.round(proto.baseBounty * (isSwarm ? (typeof SWARM_BOUNTY_SCALE !== 'undefined' ? SWARM_BOUNTY_SCALE : 0.62) : (isBoss ? 4.5 : 1.0)))),
      radius: finalRadius,
      shape: proto.shape,
      color: proto.color,
      glow: proto.glow,
      interval: currentInterval,
      laneOffset: laneOffset
    });
  }

  if (spawnTimer <= 0) spawnTimer = 0.15;
  updateUI();
}

let lastTime = performance.now();

// Performance Monitor & Main Game Loop: Dynamic performance downgrades and main requestAnimationFrame loop.
// [ENG.DE]
function samplePerfAndMaybeDowngrade(rawDt) {
  if (perfDecided) return;
  if (settings.perfModeOverride) { perfDecided = true; return; }
  if (gameState !== 'PLAYING' || isLivePaused) return;

  perfSampleFrames++;
  perfSampleTime += rawDt;
  if (perfSampleFrames < 90) return;

  const avgFps = perfSampleTime > 0 ? perfSampleFrames / perfSampleTime : 60;
  perfDecided = true;
  if (avgFps < 42 && perfMode !== 'low') {
    perfMode = 'low';
  }
}

// [ENG.DF]
function gameLoop(now) {
  sfxReap();
  const rawDt = Math.min((now - lastTime) / 1000, 0.1);
  lastTime = now;

  // Расчет коэффициента плавного разгона игры после паузы
  let rampMult = 1.0;
  if (resumeRampTimer > 0 && gameState === 'PLAYING' && !isLivePaused) {
    resumeRampTimer = Math.max(0, resumeRampTimer - rawDt);
    const progress = 1.0 - (resumeRampTimer / RESUME_RAMP_DURATION);
    // Плавное ускорение от RESUME_RAMP_START_MULT (0.5) до 1.0
    rampMult = RESUME_RAMP_START_MULT + (1.0 - RESUME_RAMP_START_MULT) * progress;
  }

  const dt = isLivePaused ? 0 : rawDt * gameTimeScale * rampMult;

  samplePerfAndMaybeDowngrade(rawDt);

  if (gameState === 'PLAYING' && dt > 0) {
    update(dt);
  }
  render(now);
  requestAnimationFrame(gameLoop);
}

const _elCache = Object.create(null);
// [ENG.DG]
function el(id) {
  let n = _elCache[id];
  if (n && n.isConnected !== false) return n;
  n = document.getElementById(id);
  _elCache[id] = n;
  return n;
}

// [ENG.DH]
function handleClearSaveClick() {
  if (!devMode) return;
  devInputOpen = true;
  const ok = confirm('Clear all saved progress (diamonds, levels, upgrades, loadout, tutorial) and reset to a fresh install?');
  devInputOpen = false;
  suppressBackgroundPause();
  if (!ok) return;

  try {
    localStorage.removeItem(SAVE_KEY);
    if (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.Preferences) {
      window.Capacitor.Plugins.Preferences.remove({ key: SAVE_KEY });
    }
  } catch (e) {
    console.warn('SectorDefenseTD: could not clear localStorage', e);
  }

  diamonds = 0;
  prisms = 0;
  maxUnlockedLevel = 1;
  clearedLevels = [];
  overdriveClearedLevels = {};
  isOverdriveMode = false;
  levelStars = {};
  Object.keys(upgradeTreeData).forEach(key => { upgradeTreeData[key] = 0; });
  selectedLoadout = [];
  loadoutSyncedUpToLevel = 0;
  settings.showEnemyHp = true;
  settings.perfModeOverride = null;
  perfMode = 'high';
  perfDecided = false;
  perfSampleFrames = 0;
  perfSampleTime = 0;
  tutorialSeen.l1 = false;
  tutorialSeen.l2 = false;
  tutorialSeen.l3 = false;
  hasClaimedX2ThisLevel = false;

  dailyGiftsClaimedDate = '';
  dailyGiftsClaimedCount = 0;
  timeModTier = 0;
  lastLoginClaimDate = '';
  loginStreakDay = 1;
  hasAutoShownDailyLoginModalThisSession = false;
  dailyLoginDismissedThisSession = false;

  endlessBestWave = 0;
  endlessDailyRunsUsed = 0;
  endlessDailyRunsDate = '';
  endlessMilestonesClaimed = {};
  isEndlessMode = false;

  bpXp = 0;
  bpPremiumPurchased = false;
  bpClaimedFree = {};
  bpClaimedPrem = {};
  unlockedPalettes = ['default'];
  activePalette = 'default';
  applyPaletteColors('default');

  activeBattleSave = null;
  showStartScreen();
  renderLevelsGrid();
  updateDiamondUI();
  if (typeof updatePrismUI === 'function') updatePrismUI();
  updateUpgradeButtonsLock();
  if (typeof showHintToast === 'function') showHintToast('Save cleared');
  console.log('SectorDefenseTD: save cleared, state reset.');
}

// Daily Rewards & Shop Operations
// [ENG.DI]
function getTodayDateString() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

// [ENG.DJ]
function checkDailyGiftReset() {
  const today = getTodayDateString();
  if (dailyGiftsClaimedDate !== today) {
    dailyGiftsClaimedDate = today;
    dailyGiftsClaimedCount = 0;
    saveGameSoon();
  }
}
window.forcePauseForBackground = forcePauseForBackground;

// [ENG.DK]
function claimDailyGiftsPack() {
  checkDailyGiftReset();
  if (dailyGiftsClaimedCount >= 3) {
    showHintToast(typeof t === 'function' ? t('daily_limit_reached') : 'Daily limit reached (3/3)');
    return;
  }

  // 1-й пак бесплатно, 2-й и 3-й строго через просмотр видео
  const needsAd = dailyGiftsClaimedCount > 0;

  // [ENG.DL]
  const grantGift = () => {
    let msg = '';
    if (dailyGiftsClaimedCount === 0) {
      diamonds += 10;
      msg = typeof t === 'function' ? t('diamonds_claimed', { n: 10 }) : '+10 Diamonds claimed!';
    } else if (dailyGiftsClaimedCount === 1) {
      diamonds += 15;
      msg = typeof t === 'function' ? t('diamonds_claimed', { n: 15 }) : '+15 Diamonds claimed!';
    } else {
      diamonds += 20;
      prisms += 1;
      msg = typeof t === 'function' ? t('combo_claimed', { d: 20, p: 1 }) : '+20 Diamonds & +1 Prism claimed!';
    }
    dailyGiftsClaimedCount++;
    updateDiamondUI();
    if (typeof updatePrismUI === 'function') updatePrismUI();
    if (typeof updateMenuBadges === 'function') updateMenuBadges();
    saveGame();
    sfx('reward');
    if (typeof renderShopScreen === 'function') renderShopScreen();
    showHintToast(msg);
  };

  if (needsAd) {
    showAdPlaceholder(grantGift, null);
  } else {
    grantGift();
  }
}

// [ENG.DM]
function synthesizePrism() {
  const isUnlocked = (typeof devMode !== 'undefined' && devMode) ||
    (typeof maxUnlockedLevel !== 'undefined' && maxUnlockedLevel >= 21) ||
    (typeof clearedLevels !== 'undefined' && clearedLevels.includes(20));
  if (!isUnlocked) {
    showHintToast(typeof t === 'function' ? t('unlocks_on_level_n', { n: 21 }) : 'Unlocks on Level 21');
    sfx('denied');
    return;
  }
  if (diamonds < 20) {
    showHintToast(typeof t === 'function' ? t('not_enough_diamonds_cost', { cost: 20 }) : 'Not enough Diamonds! (20 required)');
    sfx('denied');
    return;
  }
  diamonds -= 20;
  prisms = (prisms || 0) + 1;
  updateDiamondUI();
  if (typeof updatePrismUI === 'function') updatePrismUI();
  saveGame();
  sfx('reward');
  if (typeof renderShopScreen === 'function') renderShopScreen();
  showHintToast(typeof t === 'function' ? t('prism_synthesized') : '+1 Prism synthesized!');
}

// [ENG.DN]
function deconstructPrism() {
  const isUnlocked = (typeof devMode !== 'undefined' && devMode) ||
    (typeof maxUnlockedLevel !== 'undefined' && maxUnlockedLevel >= 21) ||
    (typeof clearedLevels !== 'undefined' && clearedLevels.includes(20));
  if (!isUnlocked) {
    showHintToast(typeof t === 'function' ? t('unlocks_on_level_n', { n: 21 }) : 'Unlocks on Level 21');
    sfx('denied');
    return;
  }
  if (prisms < 1) {
    showHintToast(typeof t === 'function' ? t('not_enough_prisms_cost', { cost: 1 }) : 'Not enough Prisms! (1 required)');
    sfx('denied');
    return;
  }
  prisms -= 1;
  diamonds = (diamonds || 0) + 15;
  updateDiamondUI();
  if (typeof updatePrismUI === 'function') updatePrismUI();
  saveGame();
  sfx('reward');
  if (typeof renderShopScreen === 'function') renderShopScreen();
  showHintToast(typeof t === 'function' ? t('diamonds_deconstructed') : '+15 Diamonds deconstructed!');
}

// [ENG.DO] Покупки только внутриигровых перков за кристаллы
function buyShopIAP(productId) {
  sfx('confirm');

  if (productId === 'time_mod_t1') {
    if (timeModTier >= 1) {
      showHintToast(typeof t === 'function' ? t('already_unlocked') : 'Already unlocked!');
      return;
    }
    if (diamonds < 50) {
      sfx('denied');
      showHintToast(typeof t === 'function' ? t('not_enough_diamonds_cost', { cost: 50 }) : 'Not enough Diamonds! (50 required)');
      return;
    }
    diamonds -= 50;
    timeModTier = 1;
    updateDiamondUI();
    saveGame();
    sfx('reward');
    if (typeof renderShopScreen === 'function') renderShopScreen();
    showHintToast(typeof t === 'function' ? t('time_mod_t1_unlocked') : 'Time Control Tier 1 unlocked!');
    return;
  }

  if (productId === 'time_mod_t2') {
    if (timeModTier >= 2) {
      showHintToast(typeof t === 'function' ? t('already_maxed') : 'Already maxed!');
      return;
    }
    if (timeModTier < 1) {
      sfx('denied');
      showHintToast(typeof t === 'function' ? t('unlock_tier_1_first') : 'Unlock Tier 1 first!');
      return;
    }
    if (diamonds < 200) {
      sfx('denied');
      showHintToast(typeof t === 'function' ? t('not_enough_diamonds_cost', { cost: 200 }) : 'Not enough Diamonds! (200 required)');
      return;
    }
    diamonds -= 200;
    timeModTier = 2;
    updateDiamondUI();
    saveGame();
    sfx('reward');
    if (typeof renderShopScreen === 'function') renderShopScreen();
    showHintToast(typeof t === 'function' ? t('time_mod_t2_unlocked') : 'Time Control Tier 2 unlocked!');
    return;
  }
}
window.buyShopIAP = buyShopIAP;

// Navigation & Screen Transition Helpers: Start screen, level selection, and chapter label controllers.
// Simulation Step Update Pipeline: Enemy movement, tower targeting, projectile physics, and status effects.
// javascript-obfuscator: disable
// [ENG.DPM] Вспомогательные функции физических реакций врагов на попадание (ENEMY_REACTIONS)
function normalizeAngle(a) {
  while (a > Math.PI) a -= Math.PI * 2;
  while (a < -Math.PI) a += Math.PI * 2;
  return a;
}

function applyEnemyHitReaction(e, dirAngle, isBeam) {
  if (!e || typeof ENEMY_REACTIONS === 'undefined' || !ENEMY_REACTIONS) return;
  const hasAngle = (typeof dirAngle === 'number' && isFinite(dirAngle));
  if (ENEMY_REACTIONS.knockback && !isBeam && !e.isBoss && hasAngle) {
    e.kbX = Math.cos(dirAngle) * 3.5;
    e.kbY = Math.sin(dirAngle) * 3.5;
  }
  if (ENEMY_REACTIONS.jitter) {
    e.jitterTimer = 0.105;
  }
  if (ENEMY_REACTIONS.hitTilt && !isBeam && hasAngle) {
    const relAngle = normalizeAngle(dirAngle - (e.angle || 0));
    e.hitTilt = (relAngle >= 0 ? 1 : -1) * 0.14;
  }
}

// [ENG.DQ]
function update(dt) {
  if (cameraShakeTimer > 0) {
    cameraShakeTimer -= dt;
    if (cameraShakeTimer <= 0) {
      cameraShakeTimer = 0;
      cameraShakeMaxDur = 0;
      cameraShakeIntensity = 0;
    }
  }

  // Расчет плавной разморозки с защитой от NaN / деления на 0
  let thawMult = 1.0;
  if (typeof resumeThawTimer !== 'undefined' && resumeThawTimer > 0) {
    resumeThawTimer = Math.max(0, resumeThawTimer - dt);
    const dur = (typeof RESUME_THAW_DURATION === 'number' && RESUME_THAW_DURATION > 0) ? RESUME_THAW_DURATION : 0.3;
    const startMult = (typeof RESUME_START_SPEED_MULT === 'number') ? RESUME_START_SPEED_MULT : 0.2;
    const thawProg = Math.min(1.0, Math.max(0, 1.0 - resumeThawTimer / dur));
    thawMult = startMult + (1.0 - startMult) * thawProg;
  }
  if (!isFinite(thawMult) || thawMult <= 0) thawMult = 1.0;

  const lvlConfig = LEVELS_DATA[currentLevel];
  const maxW = lvlConfig ? lvlConfig.totalWaves : 10;
  const btn = el('waveBtn');
  const btnText = el('waveBtnText');

  if (waveInProgress && spawnQueue.length > 0) waveSpawnElapsedTime += dt;
  updateWaveCircle(dt);

  // [ENG.EA] Предупреждение о приближении босса
  if (bossAlertScheduled && !bossAlertShown && spawnQueue.length > 0) {
    let timeToBoss = spawnTimer;
    let foundBoss = false;
    for (let i = 0; i < spawnQueue.length; i++) {
      const item = spawnQueue[i];
      if (item.isBoss || item.isMiniBoss) {
        foundBoss = true;
        break;
      }
      timeToBoss += (item.interval || 0.8);
    }
    if (foundBoss && timeToBoss <= 2.0) {
      bossAlertShown = true;
      sfx('bossIncoming');
      showIncomingAlert(activeBossAlertType);
      bossAlertHideTimer = Math.max(1.0, timeToBoss + 1.0);
    }
  }

  if (bossAlertShown && bossAlertHideTimer > 0) {
    bossAlertHideTimer -= dt;
    if (bossAlertHideTimer <= 0) {
      hideIncomingAlert();
    }
  }

  if (newTowerBannerHideTimer > 0) {
    newTowerBannerHideTimer -= dt;
    if (newTowerBannerHideTimer <= 0) {
      hideNewTowerBanner();
    }
  }

  // [ENG.EB] Кнопка Go и таймер между волнами
  const goLabel = (typeof t === 'function' ? t('go') : 'Go');
  if (waveTimerActive && autoWaveTimeRemaining > 0) {
    if (enemies.length === 0 && spawnQueue.length === 0) {
      fieldClearDelayTimer += dt;
    } else {
      fieldClearDelayTimer = 0;
    }

    const canAccelerate = (fieldClearDelayTimer >= 0.30) && (autoWaveTimeRemaining > 0.75);
    isWaveTimerAccelerated = canAccelerate;

    const timerSpeedMult = canAccelerate ? 2.0 : 1.0;
    autoWaveTimeRemaining -= dt * timerSpeedMult;

    if (autoWaveTimeRemaining <= 0) {
      autoWaveTimeRemaining = 0;
      waveTimerActive = false;
      isWaveTimerAccelerated = false;
      fieldClearDelayTimer = 0;
      if (isEndlessMode || wave < maxW) {
        if (isEndlessMode) {
          addBpXp(5);
        }
        wave++;
        startWave();
      }
    } else {
      if (btn) btn.disabled = false;
      if (btnText) btnText.textContent = goLabel;
    }
  } else {
    isWaveTimerAccelerated = false;
    fieldClearDelayTimer = 0;
  }

  // Спавн мобов из очереди на карту
  if (spawnQueue.length > 0) {
    spawnTimer -= dt;
    while (spawnTimer <= 0 && spawnQueue.length > 0) {
      const eData = spawnQueue.shift();
      if (WAYPOINTS && WAYPOINTS.length > 1) {
        let spawnX = WAYPOINTS[0].x;
        let spawnY = WAYPOINTS[0].y;
        if (eData.laneOffset) {
          const segDx = WAYPOINTS[1].x - WAYPOINTS[0].x;
          const segDy = WAYPOINTS[1].y - WAYPOINTS[0].y;
          const segLen = Math.hypot(segDx, segDy) || 1;
          const nx = -segDy / segLen;
          const ny = segDx / segLen;
          spawnX += nx * eData.laneOffset;
          spawnY += ny * eData.laneOffset;
        }

      const initAngle = Math.atan2(WAYPOINTS[1].y - WAYPOINTS[0].y, WAYPOINTS[1].x - WAYPOINTS[0].x);
      const spawnedEnemy = {
        x: spawnX,
        y: spawnY,
        laneOffset: eData.laneOffset || 0,
        angle: initAngle,
        wpIndex: 1,
          type: eData.type,
          isBoss: !!eData.isBoss,
          isMiniBoss: !!eData.isMiniBoss,
          shape: eData.shape,
          color: eData.color,
          glow: eData.glow,
          hp: eData.hp,
          maxHp: eData.hp,
          speed: eData.speed,
          baseSpeed: eData.speed,
          bounty: eData.bounty,
          radius: eData.radius,
          shieldTimer: 0,
          isShielded: false,
          warpTimer: 0,
          dashTimer: 0,
          summonTimer: 0,
          empTimer: 0,
          slowTimer: 0,
          spawnTimer: 0.22,
          spawnDuration: 0.22
        };

        if (isOverdriveMode && !eData.isBoss && !eData.isMiniBoss) {
          regularSpawnCounter++;
          if (regularSpawnCounter % 10 === 0) {
            spawnedEnemy.maxHp *= 2.5;
            spawnedEnemy.hp = spawnedEnemy.maxHp;
            spawnedEnemy.radius *= 1.25;
            spawnedEnemy.isElite = true;
          }
        }

        enemies.push(spawnedEnemy);
        if (typeof spawnEnemySpawnFx === 'function') {
          spawnEnemySpawnFx(spawnX, spawnY, spawnedEnemy);
        }
      }
      spawnTimer += (eData.interval || 0.8);

      if (spawnQueue.length === 0 && waveInProgress) {
        waveInProgress = false;
        if (isEndlessMode) {
          endlessBestWave = Math.max(endlessBestWave, wave);
          saveGameSoon();
          waveTimerActive = true;
          autoWaveTimeRemaining = 5.0;
          if (btn) btn.disabled = false;
          if (btnText) btnText.textContent = goLabel;
        } else if (wave < maxW) {
          waveTimerActive = true;
          let delay = 5.0;
          if (lvlConfig && lvlConfig.waves) {
            const currentWaveObj = lvlConfig.waves.find(w => w.wave === wave);
            if (currentWaveObj && currentWaveObj.delayAfter !== undefined) {
              delay = currentWaveObj.delayAfter;
            }
          }
          autoWaveTimeRemaining = delay;

          if (btn) btn.disabled = false;
          if (btnText) btnText.textContent = goLabel;
        }
      }
    }
  }

  // Обновление состояния и перемещение врагов
  for (let i = enemies.length - 1; i >= 0; i--) {
    const e = enemies[i];

    // Пружинящий возврат физических реакций (ENEMY_REACTIONS) и таймер материализации
    if (e.kbX) e.kbX *= Math.exp(-18 * dt);
    if (e.kbY) e.kbY *= Math.exp(-18 * dt);
    if (e.hitTilt) e.hitTilt *= Math.exp(-14 * dt);
    if (e.jitterTimer > 0) e.jitterTimer = Math.max(0, e.jitterTimer - dt);
    if (e.spawnTimer > 0) e.spawnTimer = Math.max(0, e.spawnTimer - dt);

    // Анимация ударной волны базы при Revive
    if (e.revivePushAnim) {
      e.revivePushAnim.timer += dt;
      const prog = Math.min(1.0, e.revivePushAnim.timer / e.revivePushAnim.duration);
      const ease = 1 - Math.pow(1 - prog, 3);
      e.x = e.revivePushAnim.startX + (e.revivePushAnim.endX - e.revivePushAnim.startX) * ease;
      e.y = e.revivePushAnim.startY + (e.revivePushAnim.endY - e.revivePushAnim.startY) * ease;

      if (Math.random() < 0.4 && typeof createImpactSmoke === 'function') {
        createImpactSmoke(e.x, e.y, 8);
      }

      if (prog >= 1.0) {
        e.x = e.revivePushAnim.endX;
        e.y = e.revivePushAnim.endY;
        e.wpIndex = e.revivePushAnim.endWp;
        e.revivePushAnim = null;
      }
      continue;
    }

    if (e.type === 'blinker') {
      e.shieldTimer = (e.shieldTimer || 0) + dt;
      if (e.shieldTimer >= 3.0) e.shieldTimer -= 3.0;
      e.isShielded = e.shieldTimer < 1.0;
    }

    if (e.type === 'chronos_warp') {
      e.shieldTimer = (e.shieldTimer || 0) + dt;
      if (e.shieldTimer >= 3.0) e.shieldTimer -= 3.0;
      e.isShielded = e.shieldTimer < 1.2;
    }

    if (e.teleportFlashTimer > 0) {
      e.teleportFlashTimer -= dt;
      if (e.teleportFlashTimer < 0) e.teleportFlashTimer = 0;
    }

    if (e.type === 'titan_core') {
      if (e.dashAnim) {
        e.dashAnim.timer += dt;
        const progress = Math.min(1.0, e.dashAnim.timer / e.dashAnim.duration);

        if (progress <= 0.24) {
          e.x = e.dashAnim.startX;
          e.y = e.dashAnim.startY;
          e.dashLineMoving = false;
          if (Math.random() < 0.8) {
            if (typeof createDamageShards === 'function') createDamageShards(e.x, e.y, '#f97316', 15, false);
            if (typeof createSparks === 'function') createSparks(e.x, e.y, '#fb923c', 3, '#f97316');
          }
        } else if (progress <= 0.76) {
          const moveT = (progress - 0.24) / (0.76 - 0.24);
          e.x = e.dashAnim.startX + (e.dashAnim.endX - e.dashAnim.startX) * moveT;
          e.y = e.dashAnim.startY + (e.dashAnim.endY - e.dashAnim.startY) * moveT;
          const dx = e.dashAnim.endX - e.dashAnim.startX;
          const dy = e.dashAnim.endY - e.dashAnim.startY;
          if (dx !== 0 || dy !== 0) {
            e.angle = Math.atan2(dy, dx);
          }
          e.dashLineMoving = true;
          if (Math.random() < 0.7) {
            if (typeof createDamageShards === 'function') createDamageShards(e.x, e.y, '#f97316', 20, false);
            if (typeof createSparks === 'function') createSparks(e.x, e.y, '#fb923c', 4, '#f97316');
          }
        } else {
          e.x = e.dashAnim.endX;
          e.y = e.dashAnim.endY;
          e.wpIndex = e.dashAnim.endWp;
          e.dashLineMoving = false;
        }

        if (progress >= 1.0) {
          e.x = e.dashAnim.endX;
          e.y = e.dashAnim.endY;
          e.wpIndex = e.dashAnim.endWp;
          e.dashAnim = null;
          e.dashLineMoving = false;
          e.teleportFlashTimer = 0.25;
          if (typeof createShockwave === 'function') createShockwave(e.x, e.y, 65, '#fb923c');
          if (typeof createDamageShards === 'function') createDamageShards(e.x, e.y, '#f97316', 40, false);
          if (typeof createSparks === 'function') createSparks(e.x, e.y, '#fb923c', 10, '#f97316');
        }
        continue;
      }

      e.dashTimer = (e.dashTimer || 0) + dt;
      if (e.dashTimer >= 6.0) {
        e.dashTimer -= 6.0;
        const startX = e.x;
        const startY = e.y;
        const wasFrozen = (e.slowTimer > 0);

        e.speed = e.baseSpeed;
        e.slowTimer = 0;

        if (wasFrozen) {
          if (typeof createDamageShards === 'function') createDamageShards(startX, startY, '#38bdf8', 25, true);
          if (typeof createSparks === 'function') createSparks(startX, startY, '#38bdf8', 12, '#ffffff');
        }
        if (typeof createShockwave === 'function') createShockwave(startX, startY, 50, '#f97316');

        let simX = e.x;
        let simY = e.y;
        let simWp = e.wpIndex;
        const isEndlessArena1 = (typeof isEndlessMode !== 'undefined' && isEndlessMode) && 
          ((typeof currentLevelSection === 'undefined') || currentLevelSection === 1);
        let dashRemaining = isEndlessArena1 ? 70 : 140;

        while (dashRemaining > 0 && simWp < WAYPOINTS.length) {
          const twp = WAYPOINTS[simWp];
          const distToWp = Math.hypot(twp.x - simX, twp.y - simY);
          if (distToWp <= dashRemaining) {
            dashRemaining -= distToWp;
            simX = twp.x; simY = twp.y;
            simWp++;
          } else {
            simX += ((twp.x - simX) / distToWp) * dashRemaining;
            simY += ((twp.y - simY) / distToWp) * dashRemaining;
            dashRemaining = 0;
          }
        }

        e.dashAnim = {
          startX: startX,
          startY: startY,
          endX: simX,
          endY: simY,
          endWp: simWp,
          timer: 0,
          duration: 0.50
        };
        sfx('stasis');
      }
    }

    if (e.type === 'hive_empress') {
      e.summonTimer = (e.summonTimer || 0) + dt;
      if (e.summonTimer >= 3.0) {
        e.summonTimer -= 3.0;
        const swCol = (typeof ENEMY_CONFIGS !== 'undefined' && ENEMY_CONFIGS.swarm) ? ENEMY_CONFIGS.swarm.color : '#00ffcc';
        const swGlow = (typeof ENEMY_CONFIGS !== 'undefined' && ENEMY_CONFIGS.swarm) ? ENEMY_CONFIGS.swarm.glow : swCol;
        createShockwave(e.x, e.y, 65, swCol);
        for (let s = 0; s < 3; s++) {
          const drone = {
            x: e.x + (Math.random() - 0.5) * 16,
            y: e.y + (Math.random() - 0.5) * 16,
            angle: e.angle,
            wpIndex: e.wpIndex,
            type: 'swarm',
            isBoss: false,
            isMiniBoss: false,
            shape: 'diamond',
            color: swCol,
            glow: swGlow,
            hp: 20,
            maxHp: 20,
            speed: 95,
            baseSpeed: 95,
            bounty: 3,
            radius: 8,
            slowTimer: 0,
            spawnTimer: 0.22,
            spawnDuration: 0.22
          };
          enemies.push(drone);
          if (typeof spawnEnemySpawnFx === 'function') {
            spawnEnemySpawnFx(drone.x, drone.y, drone);
          }
        }
      }
    }

    if (e.type === 'emp_overlord') {
      e.empTimer = (e.empTimer || 0) + dt;
      if (e.empTimer >= 5.0) {
        e.empTimer -= 5.0;
        sfx('stasis');
        createShockwave(e.x, e.y, 180, '#f05f9f');
        towers.forEach(t => {
          if (Math.hypot(t.x - e.x, t.y - e.y) <= 180) {
            t.disabledTimer = Math.max(t.disabledTimer || 0, 2.5);
            sfx('steam');
            createDamageShards(t.x, t.y, '#f05f9f', 16, false);
          }
        });
      }
    }

    if (e.slowTimer > 0) {
      e.slowTimer -= dt;
      if (e.slowTimer <= 0) e.speed = e.baseSpeed;
    }

    const targetWp = WAYPOINTS[e.wpIndex];
    if (!targetWp) continue;

    const effectiveSpeed = e.speed * (isOverdriveMode ? 1.2 : 1.0) * thawMult;
    let remainingStep = effectiveSpeed * dt;
    let reachedBase = false;

    const getWpPosWithOffset = (idx) => {
      const wpCurr = WAYPOINTS[idx];
      let tx = wpCurr.x;
      let ty = wpCurr.y;
      if (e.laneOffset) {
        const prevWp = WAYPOINTS[idx - 1] || WAYPOINTS[0];
        const nextWp = WAYPOINTS[idx + 1];
        const segDx = wpCurr.x - prevWp.x;
        const segDy = wpCurr.y - prevWp.y;
        const segLen = Math.hypot(segDx, segDy) || 1;
        let offX = -segDy / segLen;
        let offY = segDx / segLen;
        if (nextWp) {
          const seg2Dx = nextWp.x - wpCurr.x;
          const seg2Dy = nextWp.y - wpCurr.y;
          const seg2Len = Math.hypot(seg2Dx, seg2Dy) || 1;
          offX += -seg2Dy / seg2Len;
          offY += seg2Dx / seg2Len;
        }
        const offLen = Math.hypot(offX, offY);
        if (offLen > 1e-4) {
          tx += (offX / offLen) * e.laneOffset;
          ty += (offY / offLen) * e.laneOffset;
        }
      }
      return { x: tx, y: ty };
    };

    while (remainingStep > 0 && e.wpIndex < WAYPOINTS.length) {
      const targetPt = getWpPosWithOffset(e.wpIndex);
      const dx = targetPt.x - e.x;
      const dy = targetPt.y - e.y;
      const dist = Math.hypot(dx, dy);

      if (dist <= remainingStep) {
        e.x = targetPt.x;
        e.y = targetPt.y;
        remainingStep -= dist;
        e.wpIndex++;
        if (e.wpIndex >= WAYPOINTS.length) {
          reachedBase = true;
          break;
        }
      } else {
        e.x += (dx / dist) * remainingStep;
        e.y += (dy / dist) * remainingStep;
        remainingStep = 0;
      }
    }

    // Непрерывное сглаживание угла корпуса с упреждением на 14px вперёд по траектории (без ступенек)
    if (!reachedBase && e.wpIndex < WAYPOINTS.length) {
      let lookDist = 14.0;
      let lx = e.x;
      let ly = e.y;
      let lIdx = e.wpIndex;

      while (lookDist > 0 && lIdx < WAYPOINTS.length) {
        const pt = getWpPosWithOffset(lIdx);
        const ldx = pt.x - lx;
        const ldy = pt.y - ly;
        const ld = Math.hypot(ldx, ldy);
        if (ld <= lookDist) {
          lx = pt.x;
          ly = pt.y;
          lookDist -= ld;
          lIdx++;
        } else {
          lx += (ldx / ld) * lookDist;
          ly += (ldy / ld) * lookDist;
          lookDist = 0;
        }
      }

      const aimDx = lx - e.x;
      const aimDy = ly - e.y;
      if (aimDx * aimDx + aimDy * aimDy > 0.0001) {
        const desiredAngle = Math.atan2(aimDy, aimDx);
        if (typeof e.angle !== 'number' || !isFinite(e.angle)) {
          e.angle = desiredAngle;
        } else {
          let diff = desiredAngle - e.angle;
          while (diff > Math.PI) diff -= Math.PI * 2;
          while (diff < -Math.PI) diff += Math.PI * 2;
          // Экспоненциальный фильтр: поворот пропорционален скорости моба и абсолютно плавный на каждом кадре
          const turnRate = Math.max(8.0, (effectiveSpeed / 45) * 9.5);
          const blend = 1 - Math.exp(-turnRate * dt);
          e.angle += diff * blend;
        }
      }
    }

    if (reachedBase) {
      const damageToBasePath = getBaseDamageFor(e);
      baseHp = Math.max(0, baseHp - damageToBasePath);
      saveActiveBattleSnapshot();
      saveGameSoon();
      sfx('baseHit');
      if (typeof spawnEnemyBaseHitFx === 'function') {
        spawnEnemyBaseHitFx(e.x, e.y, e);
      } else {
        createShockwave(e.x, e.y, e.isBoss ? 80 : (e.isMiniBoss ? 50 : 35), '#f05f9f');
      }
      if (e.isBoss || damageToBasePath >= 4) {
        triggerImpactFeedback('heavy', 'heavy', { dur: 0.40, intensity: 14 });
      } else if (e.isMiniBoss || (damageToBasePath >= 2 && damageToBasePath <= 3)) {
        triggerImpactFeedback('medium', 'heavy');
      } else if (damageToBasePath === 1) {
        triggerImpactFeedback('light', 'light');
      }
      enemies.splice(i, 1);
      updateUI();
      if (baseHp <= 0) {
        baseHp = 0;
        if (!reviveUsedThisMatch && !isOverdriveMode) {
          triggerEmergencyRevivePrompt();
          return;
        }
        triggerDefeat();
        return;
      }
      continue;
    }
  }

  // Обновление и стрельба башен
  towers.forEach(t => {
    if (t.disabledTimer > 0) {
      t.disabledTimer -= dt;
      if (t.disabledTimer < 0) t.disabledTimer = 0;
      return;
    }

    let target = null;
    const rangeSq = t.range * t.range;
    const isLockingTowerType = (typeof LOCKED_TARGET_TOWERS !== 'undefined' ? LOCKED_TARGET_TOWERS : ['laser', 'melter']).includes(t.type);

    if (isLockingTowerType && t.target && enemies.includes(t.target) && t.target.hp > 0) {
      const dxL = t.target.x - t.x;
      const dyL = t.target.y - t.y;
      if (dxL * dxL + dyL * dyL <= rangeSq) target = t.target;
    }

    if (!target) {
      let maxDistProgress = -1;
      for (let e of enemies) {
        const dx = e.x - t.x;
        const dy = e.y - t.y;
        if (dx * dx + dy * dy <= rangeSq && WAYPOINTS[e.wpIndex]) {
          const wp = WAYPOINTS[e.wpIndex];
          const wdx = wp.x - e.x;
          const wdy = wp.y - e.y;
          const progress = e.wpIndex * 1000 - (Math.abs(wdx) + Math.abs(wdy));
          if (progress > maxDistProgress) {
            maxDistProgress = progress;
            target = e;
          }
        }
      }
    }

    const isNewTarget = (t.target !== target);
    if (isNewTarget) {
      t.lockOnTimer = 0;
      t.target = target;
    } else if (target) {
      t.lockOnTimer = (t.lockOnTimer || 0) + dt;
    }
    const isLockedOn = !!target && (t.lockOnTimer || 0) >= (t.lockOnDelay || 0);
    t.isLockedOn = isLockedOn;

    if (target && t.type !== 'stasis') {
      t.angle = Math.atan2(target.y - t.y, target.x - t.x);
    }

    if (t.type === 'gun') {
      t.lastFire += dt;
      if (target && isLockedOn && t.lastFire >= t.fireRate) {
        t.lastFire = 0;
        t.shotIndex = ((t.shotIndex || 0) + 1) % 2;
        sfx('gun');
        const barrelSide = (t.shotIndex === 0) ? -3.6 : 3.6;
        const cosA = Math.cos(t.angle);
        const sinA = Math.sin(t.angle);
        const mx = t.x + cosA * 24 - sinA * barrelSide;
        const my = t.y + sinA * 24 + cosA * barrelSide;
        projectiles.push({
          type: 'bullet',
          x: mx,
          y: my,
          target: target,
          damage: t.damage,
          speed: 460,
          color: t.color,
          hasTrail: true
        });
      }
    }

    if (t.type === 'laser') {
      const isFiring = target && isLockedOn && !target.isShielded && t.disabledTimer <= 0;

      if ((!isFiring || t.accumTarget !== target) && t.accumDamage >= 1) {
        const flushX = t.accumTarget ? t.accumTarget.x : t.x;
        const flushY = t.accumTarget ? t.accumTarget.y : t.y;
        if (typeof createFloatingDamage === 'function') {
          createFloatingDamage(flushX, flushY, t.accumDamage, t.color || '#f05f9f');
        }
        t.accumDamage = 0;
        t.accumTimer = 0;
      }

      if (isFiring) {
        sfx('laserHit');
        const dDmg = t.damage * dt;
        target.hp -= dDmg;
        checkEnemyEnrage(target);

        t.accumTarget = target;
        t.accumDamage = (t.accumDamage || 0) + dDmg;
        t.accumTimer = (t.accumTimer || 0) + dt;

        if (t.accumTimer >= 1.0) {
          if (typeof createFloatingDamage === 'function' && t.accumDamage >= 1) {
            createFloatingDamage(target.x, target.y, t.accumDamage, t.color || '#f05f9f');
          }
          t.accumDamage = 0;
          t.accumTimer -= 1.0;
        }

        applyEnemyHitReaction(target, t.angle, true);
        t.fxAccum = (t.fxAccum || 0) + dt;
        if (t.fxAccum >= 0.10) {
          t.fxAccum -= 0.10;
          if (t.fxAccum >= 0.10) t.fxAccum = 0;
          if (typeof createHitImpactFx === 'function') {
            createHitImpactFx(target.x, target.y, t.color || '#f05f9f', 'bullet', t.angle);
          } else {
            createDamageShards(target.x, target.y, target.color, dDmg * 4, false);
          }
          if (Math.random() < 0.5) createImpactSmoke(target.x, target.y, 8);
        }
      } else {
        t.accumTarget = null;
        t.fxAccum = 0;
      }
    }

    if (t.type === 'mortar') {
      t.lastFire += dt;
      if (target && isLockedOn && t.lastFire >= t.fireRate) {
        t.lastFire = 0;
        sfx('mortarFire');
        const mSpec = TOWER_GLYPH_SPECS.mortar;
        const elevRad = (mSpec.elevationDeg || 55) * Math.PI / 180;
        const muzzleDist = (mSpec.muzzle ? mSpec.muzzle.atX : 23) * Math.cos(elevRad);
        const launchX = t.x + Math.cos(t.angle) * muzzleDist;
        const launchY = t.y + Math.sin(t.angle) * muzzleDist;
        const range = Math.hypot(target.x - launchX, target.y - launchY);
        projectiles.push({
          type: 'mortar_shell',
          x: launchX,
          y: launchY,
          targetX: target.x,
          targetY: target.y,
          targetRef: target,
          damage: t.damage,
          splash: TOWER_CONFIGS.mortar.splash * (1 + (t.level - 1) * 0.15),
          duration: t.mortarTravelTime || MORTAR_BASE_TRAVEL_TIME || 1.0,
          elapsed: 0,
          startX: launchX,
          startY: launchY,
          arcApex: Math.max(12, range * Math.tan(elevRad) / 4),
          color: t.color
        });
      }
    }

    if (t.type === 'tesla') {
      t.lastFire += dt;
      if (target && isLockedOn && t.lastFire >= t.fireRate) {
        sfx('tesla');
        t.lastFire = 0;
        const maxChains = (t.level === 1) ? 3 : (t.level === 2 ? 4 : 5);
        const jumpRadius = TOWER_CONFIGS.tesla.jumpRadius;
        const hitTargets = [target];
        let currentChainSource = target;
        let chainDmg = t.damage;

        lightningBolts.push({
          x1: t.x, y1: t.y - 6, x2: target.x, y2: target.y,
          delay: 0, travelTime: 0.05, life: 0.22, maxLife: 0.22,
          targetRef: target, damage: chainDmg, hasDealtDamage: false,
          color: '#00ffcc', towerColor: t.color
        });

        for (let c = 1; c < maxChains; c++) {
          let nextTarget = null;
          let minDist = jumpRadius;
          for (let e of enemies) {
            if (!hitTargets.includes(e)) {
              const d = Math.hypot(e.x - currentChainSource.x, e.y - currentChainSource.y);
              if (d < minDist) {
                minDist = d;
                nextTarget = e;
              }
            }
          }
          if (nextTarget) {
            chainDmg *= 0.65;
            lightningBolts.push({
              x1: currentChainSource.x, y1: currentChainSource.y, x2: nextTarget.x, y2: nextTarget.y,
              delay: c * 0.045, travelTime: 0.05, life: 0.22, maxLife: 0.22,
              targetRef: nextTarget, damage: chainDmg, hasDealtDamage: false,
              color: '#00ffcc', towerColor: t.color
            });
            hitTargets.push(nextTarget);
            currentChainSource = nextTarget;
          } else {
            break;
          }
        }
      }
    }

    if (t.type === 'stasis') {
      t.lastFire += dt;
      if (t.lastFire >= t.fireRate) {
        t.lastFire = 0;
        sfx('stasis');
        createShockwave(t.x, t.y, t.range, t.color);
        enemies.forEach(e => {
          const dxS = e.x - t.x;
          const dyS = e.y - t.y;
          if (dxS * dxS + dyS * dyS <= rangeSq && !e.isShielded) {
            const stasisPowerLvl = getBattleUpgradeEffectiveLevel('stasis_power');
            const baseSlow = (t.slowFactor !== undefined) ? t.slowFactor : (TOWER_CONFIGS.stasis.slowFactor || 0.30);
            const baseDur = (t.slowDuration !== undefined) ? t.slowDuration : (TOWER_CONFIGS.stasis.slowDuration || 1.4);
            const boostedSlow = Math.min(0.9, baseSlow * (1 + stasisPowerLvl * (TOWER_CONFIGS.stasis.powerSlow || 0)));
            const boostedDuration = baseDur * (1 + stasisPowerLvl * (TOWER_CONFIGS.stasis.powerDuration || 0));
            e.slowTimer = boostedDuration;
            e.speed = e.baseSpeed * (1 - boostedSlow);
            createDamageShards(e.x, e.y, t.color, 10, false);
          }
        });
      }
    }

    if (t.type === 'melter') {
      const rampTime = t.melterRampTime || TOWER_CONFIGS.melter.rampTime || 4.0;
      const rampCap = TOWER_CONFIGS.melter.rampCap || 40;
      const isFiring = target && isLockedOn && !target.isShielded && t.melterCoolingTimer <= 0 && t.disabledTimer <= 0;

      if ((!isFiring || t.accumTarget !== target) && t.accumDamage >= 1) {
        const flushX = t.accumTarget ? t.accumTarget.x : t.x;
        const flushY = t.accumTarget ? t.accumTarget.y : t.y;
        if (typeof createFloatingDamage === 'function') {
          createFloatingDamage(flushX, flushY, t.accumDamage, t.color || '#e85268');
        }
        t.accumDamage = 0;
        t.accumTimer = 0;
      }

      if (t.melterCoolingTimer > 0) {
        t.melterCoolingTimer -= dt;
        t.steamTimer = (t.steamTimer || 0) - dt;
        if (t.steamTimer <= 0) {
          t.steamTimer = 0.08 + Math.random() * 0.07;
          createSteamPuff(t.x, t.y - 9);
        }
        if (t.melterCoolingTimer <= 0) {
          t.melterCoolingTimer = 0;
          t.melterFireTimer = 0;
        }
      } else if (target && isLockedOn) {
        t.melterFireTimer = (t.melterFireTimer || 0) + dt;
        sfx('melterHit');

        if (!target.isShielded) {
          const rampProgress = Math.min(t.melterFireTimer, rampTime) / rampTime;
          const rampMultiplier = Math.pow(rampCap, rampProgress);
          const dDmg = t.damage * rampMultiplier * dt;
          target.hp -= dDmg;

          t.accumTarget = target;
          t.accumDamage = (t.accumDamage || 0) + dDmg;
          t.accumTimer = (t.accumTimer || 0) + dt;

          if (t.accumTimer >= 1.0) {
            if (typeof createFloatingDamage === 'function' && t.accumDamage >= 1) {
              createFloatingDamage(target.x, target.y, t.accumDamage, t.color || '#e85268');
            }
            t.accumDamage = 0;
            t.accumTimer -= 1.0;
          }

          applyEnemyHitReaction(target, t.angle, true);
          t.fxAccum = (t.fxAccum || 0) + dt;
          if (t.fxAccum >= 0.10) {
            t.fxAccum -= 0.10;
            if (t.fxAccum >= 0.10) t.fxAccum = 0;
            const sparkCol = rampProgress > 0.7 ? '#ffffff' : (rampProgress > 0.35 ? '#fb923c' : (t.color || '#e85268'));
            if (typeof createHitImpactFx === 'function') {
              createHitImpactFx(target.x, target.y, sparkCol, 'bullet', t.angle);
            } else {
              createDamageShards(target.x, target.y, target.color, dDmg * 3, false);
            }
            createImpactSmoke(target.x, target.y, 9 + rampProgress * 6);
          }
        } else {
          t.fxAccum = 0;
        }

        checkEnemyEnrage(target);

        if (t.melterFireTimer >= rampTime) {
          if (t.accumDamage >= 1 && typeof createFloatingDamage === 'function') {
            createFloatingDamage(target.x, target.y, t.accumDamage, t.color || '#e85268');
            t.accumDamage = 0;
            t.accumTimer = 0;
          }
          t.melterCoolingTimer = t.melterCooldownTime || rampTime;
          t.melterFireTimer = 0;
          createDamageShards(t.x, t.y, '#fb923c', 25, false);
          for (let s = 0; s < 7; s++) createSteamPuff(t.x, t.y - 9);
        }
      } else {
        t.accumTarget = null;
        if (t.melterFireTimer > 0) {
          t.melterFireTimer = Math.max(0, t.melterFireTimer - dt);
        }
      }
    }

    if (t.type === 'railgun') {
      t.lastFire += dt;
      if (target && isLockedOn && t.lastFire >= t.fireRate) {
        t.lastFire = 0;
        sfx('railgun');

        const rMuzzleDist = (typeof TOWER_GLYPH_SPECS !== 'undefined' && TOWER_GLYPH_SPECS.railgun && TOWER_GLYPH_SPECS.railgun.muzzle)
          ? TOWER_GLYPH_SPECS.railgun.muzzle.atX : 26;
        const rMx = t.x + Math.cos(t.angle) * rMuzzleDist;
        const rMy = t.y + Math.sin(t.angle) * rMuzzleDist;

        const beamLength = 3500;
        const beamEndX = t.x + Math.cos(t.angle) * beamLength;
        const beamEndY = t.y + Math.sin(t.angle) * beamLength;
        let railShardCount = 0;
        let nonSwarmKills = 0;

        for (let j = 0; j < enemies.length; j++) {
          const e = enemies[j];
          const vx = beamEndX - t.x;
          const vy = beamEndY - t.y;
          const wx = e.x - t.x;
          const wy = e.y - t.y;
          const c1 = wx * vx + wy * vy;
          const c2 = vx * vx + vy * vy;
          const param = c2 !== 0 ? Math.max(0, Math.min(1, c1 / c2)) : 0;
          const projX = t.x + param * vx;
          const projY = t.y + param * vy;
          const distSq = (e.x - projX) * (e.x - projX) + (e.y - projY) * (e.y - projY);
          const hitR = e.radius + 14;

          if (distSq <= hitR * hitR && !e.isShielded) {
            const wasAlive = e.hp > 0;
            e.hp -= t.damage;
            if (wasAlive && e.hp <= 0 && e.type !== 'swarm') {
              nonSwarmKills++;
            }
            checkEnemyEnrage(e);
            applyEnemyHitReaction(e, t.angle, false);
            if (typeof createFloatingDamage === 'function') {
              createFloatingDamage(e.x, e.y, t.damage, t.color || '#a275df');
            }
            if (typeof createHitImpactFx === 'function') {
              createHitImpactFx(e.x, e.y, t.color || '#a275df', 'railgun', t.angle);
            }
            if (railShardCount < 4) {
              createDamageShards(e.x, e.y, e.color, t.damage, false);
              if (typeof createImpactSmoke === 'function') createImpactSmoke(e.x, e.y, 12);
              railShardCount++;
            }
          }
        }

        if (nonSwarmKills >= 8) {
          triggerImpactFeedback('heavy', 'light', { dur: 0.35, intensity: 12 });
        } else if (nonSwarmKills >= 4) {
          triggerImpactFeedback('medium', 'light', { isMultiKill: true });
        }

        if (typeof createRailBeamFx === 'function') {
          createRailBeamFx(t.x, t.y, beamEndX, beamEndY, t.color || '#00e5ff');
        }
      }
    }
  });

// Полет пуль и снарядов мортиры
  for (let i = projectiles.length - 1; i >= 0; i--) {
    const p = projectiles[i];
    if (p.type === 'bullet') {
      if (!enemies.includes(p.target)) { projectiles.splice(i, 1); continue; }
      const dx = p.target.x - p.x;
      const dy = p.target.y - p.y;
      const dist = Math.hypot(dx, dy);
      const step = p.speed * dt;
      const hitAngle = Math.atan2(dy, dx);

      if (dist <= step) {
        if (!p.target.isShielded) {
          p.target.hp -= p.damage;
          checkEnemyEnrage(p.target);
          if (typeof createFloatingDamage === 'function') {
            createFloatingDamage(p.target.x, p.target.y, p.damage, p.color || '#00e5ff');
          }
          applyEnemyHitReaction(p.target, hitAngle, false);
          if (typeof createHitImpactFx === 'function') {
            createHitImpactFx(p.target.x, p.target.y, p.color || '#00e5ff', 'bullet', hitAngle);
          } else {
            createShockwave(p.target.x, p.target.y, 14, p.color || '#00e5ff');
          }
          createDamageShards(p.target.x, p.target.y, p.target.color, p.damage, false);
          createImpactSmoke(p.target.x, p.target.y, 11);
        } else {
          if (typeof createHitImpactFx === 'function') {
            createHitImpactFx(p.target.x, p.target.y, '#60a5fa', 'shield', hitAngle);
          }
          createDamageShards(p.target.x, p.target.y, '#60a5fa', 10, false);
        }
        projectiles.splice(i, 1);
      } else {
        p.x += (dx / dist) * step;
        p.y += (dy / dist) * step;
      }
    } else if (p.type === 'mortar_shell') {
      p.elapsed += dt;
      const tProg = p.elapsed / p.duration;
      p.x = p.startX + (p.targetX - p.startX) * tProg;
      p.y = p.startY + (p.targetY - p.startY) * tProg;

      if (tProg >= 1) {
        sfx('explosion');
        let hitEnemyColor = (p.targetRef && enemies.includes(p.targetRef)) ? p.targetRef.color : null;
        const splashSq = p.splash * p.splash;
        let shardSpawnCount = 0;
        let hitCount = 0;
        let nonSwarmKills = 0;

        for (let j = 0; j < enemies.length; j++) {
          const e = enemies[j];
          const dx = e.x - p.targetX;
          const dy = e.y - p.targetY;
          const distSq = dx * dx + dy * dy;

          if (distSq <= splashSq && !e.isShielded) {
            hitCount++;
            if (!hitEnemyColor) hitEnemyColor = e.color;
            const d = Math.sqrt(distSq);
            const splashDmg = p.damage * (1 - d / (p.splash * 1.3));
            const wasAlive = e.hp > 0;
            e.hp -= splashDmg;
            if (wasAlive && e.hp <= 0 && e.type !== 'swarm') {
              nonSwarmKills++;
            }
            checkEnemyEnrage(e);
            const blastDir = Math.atan2(e.y - p.targetY, e.x - p.targetX);
            applyEnemyHitReaction(e, blastDir, false);
            if (typeof createFloatingDamage === 'function') {
              createFloatingDamage(e.x, e.y, splashDmg, p.color || '#ff9100');
            }

            if (shardSpawnCount < 3) {
              createDamageShards(e.x, e.y, e.color, splashDmg, false);
              if (typeof createImpactSmoke === 'function') createImpactSmoke(e.x, e.y, 10);
              shardSpawnCount++;
            }
          }
        }
        if (nonSwarmKills >= 8) {
          triggerImpactFeedback('heavy', 'light', { dur: 0.35, intensity: 12 });
        } else if (nonSwarmKills >= 4) {
          triggerImpactFeedback('medium', 'light', { isMultiKill: true });
        } else if (hitCount > 0) {
          triggerImpactFeedback('light', 'light', { isSplash: true });
        }
        createExplosion(p.targetX, p.targetY, p.splash, p.color || '#ff9100', '#f05f9f', 'mortar');
        projectiles.splice(i, 1);
      }
    }
  }

  // Гибель врагов
  let enemyKilledThisTick = false;
  for (let i = enemies.length - 1; i >= 0; i--) {
    const e = enemies[i];
    if (e.hp <= 0) {
      enemyKilledThisTick = true;
      sessionMobKillsCount++;
      if (sessionMobKillsCount % 5 === 0) {
        addBpXp(1);
      }
      const moneyMultiplier = 1 + getBattleUpgradeEffectiveLevel('base_gold') * 0.05;
      gold += Math.round(e.bounty * moneyMultiplier);
      sfxDeath(e);

      if (e.type === 'emp_bomber') {
        sfx('stasis');
        createShockwave(e.x, e.y, 110, '#f05f9f');
        if (typeof createExplosion === 'function') {
          createExplosion(e.x, e.y, 48, '#f05f9f', '#38bdf8', 'standard');
        }
        towers.forEach(t => {
          if (Math.hypot(t.x - e.x, t.y - e.y) <= 110) {
            t.disabledTimer = Math.max(t.disabledTimer || 0, 3.0);
            sfx('steam');
            createDamageShards(t.x, t.y, '#f05f9f', 16, false);
          }
        });
      }

      if (e.isBoss || e.isMiniBoss) {
        if (e.isBoss) {
          triggerImpactFeedback('heavy', 'heavy', { dur: 0.38, intensity: 14 });
        } else {
          triggerImpactFeedback('medium', 'light');
        }
        createExplosion(e.x, e.y, e.isBoss ? 52 : 28, e.color, e.glow || e.color, 'boss');
      } else if (e.isElite) {
        triggerImpactFeedback('medium', 'light');
      }

      createDamageShards(e.x, e.y, e.color, e.isBoss ? 120 : (e.isMiniBoss ? 60 : 35), true);
      enemies.splice(i, 1);
    }
  }
  if (enemyKilledThisTick) {
    updateUI();
  }

  // Частицы (с физическим торможением drag для искр и осколков)
  for (let i = particles.length - 1; i >= 0; i--) {
    const pt = particles[i];
    if (pt.drag) {
      const damping = Math.pow(pt.drag, dt * 60);
      pt.vx *= damping;
      pt.vy *= damping;
    }
    pt.x += pt.vx * dt;
    pt.y += pt.vy * dt;
    pt.life -= dt;
    if (pt.life <= 0) particles.splice(i, 1);
  }

  // Ударные волны
  for (let i = shockwaves.length - 1; i >= 0; i--) {
    const sw = shockwaves[i];
    sw.elapsed += dt;
    if (sw.elapsed >= sw.duration) shockwaves.splice(i, 1);
  }

  // Разряды молний Tesla
  for (let i = lightningBolts.length - 1; i >= 0; i--) {
    const lb = lightningBolts[i];
    if (lb.delay && lb.delay > 0) {
      lb.delay -= dt;
      continue;
    }
    lb.elapsed = (lb.elapsed || 0) + dt;
    lb.life -= dt;

    if (!lb.hasDealtDamage && !lb.targetRef.isShielded && enemies.includes(lb.targetRef)) {
      lb.hasDealtDamage = true;
      lb.targetRef.hp -= lb.damage;
      checkEnemyEnrage(lb.targetRef);

      if (typeof createFloatingDamage === 'function') {
        createFloatingDamage(lb.targetRef.x, lb.targetRef.y, lb.damage, lb.towerColor || lb.color || '#00ffcc');
      }

      const chainDir = Math.atan2(lb.targetRef.y - lb.y1, lb.targetRef.x - lb.x1);
      applyEnemyHitReaction(lb.targetRef, chainDir, false);
      if (typeof createHitImpactFx === 'function') {
        createHitImpactFx(lb.x2, lb.y2, lb.towerColor || lb.color || '#00ffcc', 'tesla');
      }

      if (Math.random() < 0.6) {
        if (typeof createDamageShards === 'function') {
          createDamageShards(lb.x2, lb.y2, lb.targetRef.color, lb.damage, false);
        } else {
          createSparks(lb.x2, lb.y2, lb.towerColor || lb.color || '#00ffcc', 3, lb.targetRef.color);
        }
      }
    }

    if (lb.life <= 0) lightningBolts.splice(i, 1);
  }

  // Проверка завершения матча (Победа)
  if (!isEndlessMode && wave >= maxW && spawnQueue.length === 0 && enemies.length === 0 && baseHp > 0 && gameState === 'PLAYING') {
    if (victoryDelayTimer <= 0) {
      victoryDelayTimer = 1.0;
    } else {
      victoryDelayTimer -= dt;
      if (victoryDelayTimer <= 0) {
        triggerVictory();
      }
    }
  } else {
    victoryDelayTimer = 0;
  }
}
// javascript-obfuscator: enable
